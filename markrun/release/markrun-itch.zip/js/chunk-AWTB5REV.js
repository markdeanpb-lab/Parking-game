import{a as Ph,c as li,d as ci,g as Di,h as Ui,i as Lh,m as Ka,s as ja}from"./chunk-32HAT2Y7.js";import{a as Uh,b as Nh,c as Fh}from"./chunk-MYWWDALL.js";import{a as Se,b as hi,c as Ot,d as Je,e as Mn,f as Ni,g as Fi,h as As,i as ss,j as cn,k as kh,l as Qa,m as Xn,n as mo,o as Mr,p as go,q as Dh,r as tl,s as yo,t as el}from"./chunk-4A4CZJCN.js";import{b as dd}from"./chunk-F4WF5Y7G.js";var pd=/(daniel|george|arthur|ryan|oliver|thomas|male|james|harry|guy|brian|fred|alex|aaron)/i,md=/(kate|serena|martha|libby|sonia|hazel|susan|female|stephanie|fiona|moira|tessa|karen|emma|amy|samantha|victoria|zira|aria|jenny|catherine)/i;function Oh({onLine:n,onIdle:t}={}){var v;let e=typeof window<"u"?window.speechSynthesis:null,i=!0,s=.9,r={jeff:null,pam:null},o=[],a=null,l=null;function c(){if(!e)return;let u=e.getVoices()||[];if(!u.length)return;let f=u.filter(A=>/en[-_]GB/i.test(A.lang)),S=u.filter(A=>/^en/i.test(A.lang)),y=f.length?f:S.length?S:u,L=(A=>[...A.filter(M=>M.localService),...A.filter(M=>!M.localService)])(y),b=L.find(A=>pd.test(A.name))||L[0],T=L.find(A=>md.test(A.name)&&A!==b)||L.find(A=>A!==b)||b;r={jeff:b,pam:T}}e&&(c(),(v=e.addEventListener)==null||v.call(e,"voiceschanged",c));let h=u=>Math.max(2200,String(u).split(/\s+/).length*400+600);function m(){clearTimeout(l),a=null;let u=o.shift();for(;u&&u.priority<3&&Date.now()-u.at>8e3;)u=o.shift();if(!u){t==null||t();return}a=u,n==null||n(u);let f=()=>{a===u&&m()};if(i&&e&&(r.jeff||r.pam)){let S=new SpeechSynthesisUtterance(u.text),y=u.speaker==="pam"?r.pam:r.jeff;y?(S.voice=y,S.lang=y.lang):S.lang="en-GB";let x=r.jeff===r.pam;S.pitch=u.speaker==="pam"?x?1.35:1.08:x?.8:.95,S.rate=u.rate||1.06,S.volume=s,S.onend=f,S.onerror=f;try{e.speak(S)}catch{}l=setTimeout(()=>{try{e.cancel()}catch{}f()},h(u.text)*2.2+2e3)}else l=setTimeout(f,h(u.text))}function g(u,f="jeff",{priority:S=2,interrupt:y=!1}={}){if(!u)return;let x={text:String(u),speaker:f,priority:S,at:Date.now()};for(y&&(o.length=0,d()),o.push(x);o.length>2;){let L=0;for(let b=1;b<o.length;b++)o[b].priority<o[L].priority&&(L=b);o.splice(L,1)}a||m()}function d(){if(clearTimeout(l),e)try{e.cancel()}catch{}a=null}function p(){o.length=0,d(),t==null||t()}return{say:g,clear:p,get busy(){return!!a||o.length>0},get available(){return!!e},setEnabled(u){if(i=!!u,!i&&e)try{e.cancel()}catch{}},setVolume(u){s=Math.max(0,Math.min(1,u))},whenIdle(u=15e3){return new Promise(f=>{let S=Date.now(),y=setInterval(()=>{(!a&&!o.length||Date.now()-S>u)&&(clearInterval(y),f())},120)})},get voiceNames(){var u,f;return{jeff:(u=r.jeff)==null?void 0:u.name,pam:(f=r.pam)==null?void 0:f.name}}}}var Rs="#14183c";function zh(n,{course:t,round:e,plan:i,speed:s=1}){let r=document.createElement("canvas");r.style.cssText="position:absolute;inset:0;width:100%;height:100%;display:block",n.appendChild(r);let o=r.getContext("2d",{alpha:!1}),a=(e==null?void 0:e.runners)||[],l=(t==null?void 0:t.points)||[],c=0,h=!1,m=!1,g=0,d="idle",p=0,v=0,u=-1,f=null,S=null,y=[],x=null,L=1/0,b=-1/0,T=1/0,A=-1/0;for(let U of l)L=Math.min(L,U[0]),b=Math.max(b,U[0]),T=Math.min(T,U[2]),A=Math.max(A,U[2]);function M(){let U=Math.min(1,1100/Math.max(1,n.clientWidth));r.width=Math.round(n.clientWidth*U),r.height=Math.round(n.clientHeight*U)}M();let _=new ResizeObserver(M);_.observe(n);function w(U,z){let Z=r.width,Y=r.height,k=Y*.16,mt=Y*.24,bt=Z*.08,D=Math.min((Z-bt*2-Z*.22)/(b-L||1),(Y-k-mt)/(A-T||1)),G=bt+(Z-bt*2-Z*.22-(b-L)*D)/2,q=k+(Y-k-mt-(A-T)*D)/2;return[G+(U-L)*D,q+(z-T)*D,D]}function P(U){if(!l.length)return[0,0];let z=Math.max(0,Math.min(l.length-1,U/5e3*(l.length-1))),Z=Math.floor(z),Y=Math.min(l.length-1,Z+1),k=z-Z;return[l[Z][0]+(l[Y][0]-l[Z][0])*k,l[Z][2]+(l[Y][2]-l[Z][2])*k]}let E=null;function F(){let U=r.width,z=r.height;E=document.createElement("canvas"),E.width=U,E.height=z;let Z=E.getContext("2d"),Y=Z.createLinearGradient(0,0,0,z);Y.addColorStop(0,"#45cf86"),Y.addColorStop(1,"#1f9e5c"),Z.fillStyle=Y,Z.fillRect(0,0,U,z),Z.fillStyle="rgba(255,255,255,.05)";let k=U/1920;for(let mt=-z;mt<U;mt+=160*k)Z.beginPath(),Z.moveTo(mt,0),Z.lineTo(mt+80*k,0),Z.lineTo(mt+80*k+z*.5,z),Z.lineTo(mt+z*.5,z),Z.fill();if(l.length){let mt=new Path2D;l.forEach((q,W)=>{let[J,it]=w(q[0],q[2]);W?mt.lineTo(J,it):mt.moveTo(J,it)});let bt=w(0,0)[2];Z.lineCap="round",Z.lineJoin="round",Z.strokeStyle=Rs,Z.lineWidth=Math.max(16,bt*14),Z.stroke(mt),Z.strokeStyle="#fff",Z.lineWidth=Math.max(12,bt*11),Z.stroke(mt),Z.strokeStyle="#6f84a8",Z.lineWidth=Math.max(8,bt*8),Z.stroke(mt);let[D,G]=w(...t.finish?[t.finish[0],t.finish[1]]:[l.at(-1)[0],l.at(-1)[2]]);Z.save(),Z.translate(D,G);for(let q=-2;q<2;q++)for(let W=-1;W<1;W++)Z.fillStyle=q+W&1?"#fff":Rs,Z.fillRect(q*8,W*8,8,8);Z.restore()}}function R(){var W;let U=r.width,z=r.height;(!E||E.width!==U||E.height!==z)&&F(),o.drawImage(E,0,0);let Z=i?Ui(i.timeMap,g):0,Y=((i==null?void 0:i.runners)||[]).map(J=>({id:J.id,m:li(J.progress,Z),done:Z>=J.officialS,f:J.officialS}));Y.sort((J,it)=>it.m-J.m||J.f-it.f);let k=Math.max(14,U/90);for(let J of[...Y].reverse()){let it=a.find(nt=>nt.id===J.id),[Mt,Ct]=w(...P(J.m));o.beginPath(),o.arc(Mt,Ct+4,k,0,Math.PI*2),o.fillStyle="rgba(0,0,0,.25)",o.fill(),o.beginPath(),o.arc(Mt,Ct,k,0,Math.PI*2),o.fillStyle=((W=it==null?void 0:it.colour)==null?void 0:W.primary)||"#fff",o.fill(),o.lineWidth=k*.28,o.strokeStyle=Rs,o.stroke(),o.fillStyle="#fff",o.font=`${Math.round(k*1.15)}px "Lilita One", sans-serif`,o.textAlign="center",o.textBaseline="middle",o.lineWidth=k*.25,o.strokeText(String((it==null?void 0:it.lane)??""),Mt,Ct+1),o.fillText(String((it==null?void 0:it.lane)??""),Mt,Ct+1)}let mt=U*.77,bt=z*.16,D=z*.075;o.font=`${Math.round(z*.035)}px "Lilita One", sans-serif`,o.textAlign="left",o.textBaseline="middle",Y.forEach((J,it)=>{var nt;let Mt=a.find(pt=>pt.id===J.id),Ct=bt+it*D;o.save(),o.translate(mt,Ct),o.transform(1,0,-.14,1,0,0),o.fillStyle=Rs,o.fillRect(4,6,U*.2,D*.82),o.fillStyle=it===0?"#ffd23f":"#2a62e0",o.fillRect(0,0,U*.2,D*.82),o.fillStyle=((nt=Mt==null?void 0:Mt.colour)==null?void 0:nt.primary)||"#fff",o.fillRect(0,0,U*.012,D*.82),o.restore(),o.fillStyle=it===0?Rs:"#fff",o.fillText(`${it+1}  ${((Mt==null?void 0:Mt.shortName)||(Mt==null?void 0:Mt.nickname)||J.id).slice(0,16)}`,mt+U*.02,Ct+D*.41)}),o.font=`${Math.round(z*.04)}px "Lilita One", sans-serif`,o.textAlign="left";let G=Math.floor(Z),q=`${Math.floor(G/60)}:${String(G%60).padStart(2,"0")}`;o.lineWidth=8,o.strokeStyle=Rs,o.strokeText(q,mt,bt-z*.05),o.fillStyle="#ffd23f",o.fillText(q,mt,bt-z*.05)}function N(U){if(m)return;let z=p?Math.min(.1,(U-p)/1e3):0;if(p=U,d==="race"&&!h){for(g+=z*s;y.length&&y[0].broadcastS<=g;){let Z=y.shift();try{f==null||f(Z)}catch(Y){console.warn(Y)}}if(g>=(i.timeMap.durationS||0)+1.5){d="done";let Z=S;S=null,Z==null||Z()}}U-v>45&&(g!==u||!E)&&(v=U,u=g,R()),c=requestAnimationFrame(N)}return c=requestAnimationFrame(N),{kind:"2d",playIntro(U){setTimeout(()=>U==null?void 0:U(),10)},playRace(U,z){f=U,S=z,y=[...i.events||[],...i.commentary||[]].sort((Z,Y)=>Z.broadcastS-Y.broadcastS),g=0,d="race"},showPodium(U){x=U},setPaused(U){h=!!U},seek(U){for(g=Math.max(0,Number(U)||0);y.length&&y[0].broadcastS<=g;)y.shift();d="race"},get broadcastTime(){return d==="race"||d==="done"?g:-1},dispose(){m=!0,cancelAnimationFrame(c),_.disconnect(),r.remove()}}}var Pi={};dd(Pi,{createRaceView:()=>xx});var sh="170";var gd=0,Bh=1,yd=2;var eu=1,rh=2,Si=3,Yi=0,En=1,hn=2,Xi=0,Js=1,Hh=2,Vh=3,Gh=4,vd=5,us=100,xd=101,_d=102,Md=103,bd=104,Sd=200,wd=201,Ed=202,Td=203,Nl=204,Fl=205,Ad=206,Rd=207,Cd=208,Id=209,Pd=210,Ld=211,kd=212,Dd=213,Ud=214,Ol=0,zl=1,Bl=2,tr=3,Hl=4,Vl=5,Gl=6,Wl=7,nu=0,Nd=1,Fd=2,pi=0,Od=1,zd=2,Bd=3,Hd=4,Vd=5,Gd=6,Wd=7;var iu=300,er=301,nr=302,$l=303,Xl=304,Ua=306,gs=1e3,ps=1001,ql=1002,Un=1003,$d=1004;var vo=1005;var ui=1006,nl=1007;var ms=1008;var Ai=1009,su=1010,ru=1011,zr=1012,oh=1013,ys=1014,di=1015,Qr=1016,ah=1017,lh=1018,ir=1020,ou=35902,au=1021,lu=1022,Wn=1023,cu=1024,hu=1025,Ks=1026,sr=1027,ch=1028,hh=1029,fu=1030,fh=1031;var uh=1033,Zo=33776,Jo=33777,Ko=33778,jo=33779,Yl=35840,Zl=35841,Jl=35842,Kl=35843,jl=36196,Ql=37492,tc=37496,ec=37808,nc=37809,ic=37810,sc=37811,rc=37812,oc=37813,ac=37814,lc=37815,cc=37816,hc=37817,fc=37818,uc=37819,dc=37820,pc=37821,Qo=36492,mc=36494,gc=36495,uu=36283,yc=36284,vc=36285,xc=36286;var ta=2300,_c=2301,il=2302,Wh=2400,$h=2401,Xh=2402;var Xd=3200,qd=3201;var du=0,Yd=1,Wi="",Sn="srgb",hr="srgb-linear",Na="linear",Xe="srgb";var Cs=7680;var qh=519,Zd=512,Jd=513,Kd=514,pu=515,jd=516,Qd=517,tp=518,ep=519,Mc=35044;var Yh="300 es",Ei=2e3,ea=2001,Zi=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let i=this._listeners;i[t]===void 0&&(i[t]=[]),i[t].indexOf(e)===-1&&i[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;let i=this._listeners;return i[t]!==void 0&&i[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;let s=this._listeners[t];if(s!==void 0){let r=s.indexOf(e);r!==-1&&s.splice(r,1)}}dispatchEvent(t){if(this._listeners===void 0)return;let i=this._listeners[t.type];if(i!==void 0){t.target=this;let s=i.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,t);t.target=null}}},In=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Zh=1234567,Dr=Math.PI/180,Br=180/Math.PI;function mi(){let n=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(In[n&255]+In[n>>8&255]+In[n>>16&255]+In[n>>24&255]+"-"+In[t&255]+In[t>>8&255]+"-"+In[t>>16&15|64]+In[t>>24&255]+"-"+In[e&63|128]+In[e>>8&255]+"-"+In[e>>16&255]+In[e>>24&255]+In[i&255]+In[i>>8&255]+In[i>>16&255]+In[i>>24&255]).toLowerCase()}function wn(n,t,e){return Math.max(t,Math.min(e,n))}function dh(n,t){return(n%t+t)%t}function np(n,t,e,i,s){return i+(n-t)*(s-i)/(e-t)}function ip(n,t,e){return n!==t?(e-n)/(t-n):0}function Ur(n,t,e){return(1-e)*n+e*t}function sp(n,t,e,i){return Ur(n,t,1-Math.exp(-e*i))}function rp(n,t=1){return t-Math.abs(dh(n,t*2)-t)}function op(n,t,e){return n<=t?0:n>=e?1:(n=(n-t)/(e-t),n*n*(3-2*n))}function ap(n,t,e){return n<=t?0:n>=e?1:(n=(n-t)/(e-t),n*n*n*(n*(n*6-15)+10))}function lp(n,t){return n+Math.floor(Math.random()*(t-n+1))}function cp(n,t){return n+Math.random()*(t-n)}function hp(n){return n*(.5-Math.random())}function fp(n){n!==void 0&&(Zh=n);let t=Zh+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function up(n){return n*Dr}function dp(n){return n*Br}function pp(n){return(n&n-1)===0&&n!==0}function mp(n){return Math.pow(2,Math.ceil(Math.log(n)/Math.LN2))}function gp(n){return Math.pow(2,Math.floor(Math.log(n)/Math.LN2))}function yp(n,t,e,i,s){let r=Math.cos,o=Math.sin,a=r(e/2),l=o(e/2),c=r((t+i)/2),h=o((t+i)/2),m=r((t-i)/2),g=o((t-i)/2),d=r((i-t)/2),p=o((i-t)/2);switch(s){case"XYX":n.set(a*h,l*m,l*g,a*c);break;case"YZY":n.set(l*g,a*h,l*m,a*c);break;case"ZXZ":n.set(l*m,l*g,a*h,a*c);break;case"XZX":n.set(a*h,l*p,l*d,a*c);break;case"YXY":n.set(l*d,a*h,l*p,a*c);break;case"ZYZ":n.set(l*p,l*d,a*h,a*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function ni(n,t){switch(t.constructor){case Float32Array:return n;case Uint32Array:return n/4294967295;case Uint16Array:return n/65535;case Uint8Array:return n/255;case Int32Array:return Math.max(n/2147483647,-1);case Int16Array:return Math.max(n/32767,-1);case Int8Array:return Math.max(n/127,-1);default:throw new Error("Invalid component type.")}}function Ge(n,t){switch(t.constructor){case Float32Array:return n;case Uint32Array:return Math.round(n*4294967295);case Uint16Array:return Math.round(n*65535);case Uint8Array:return Math.round(n*255);case Int32Array:return Math.round(n*2147483647);case Int16Array:return Math.round(n*32767);case Int8Array:return Math.round(n*127);default:throw new Error("Invalid component type.")}}var Ki={DEG2RAD:Dr,RAD2DEG:Br,generateUUID:mi,clamp:wn,euclideanModulo:dh,mapLinear:np,inverseLerp:ip,lerp:Ur,damp:sp,pingpong:rp,smoothstep:op,smootherstep:ap,randInt:lp,randFloat:cp,randFloatSpread:hp,seededRandom:fp,degToRad:up,radToDeg:dp,isPowerOfTwo:pp,ceilPowerOfTwo:mp,floorPowerOfTwo:gp,setQuaternionFromProperEuler:yp,normalize:Ge,denormalize:ni},Ht=class n{constructor(t=0,e=0){n.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,i=this.y,s=t.elements;return this.x=s[0]*e+s[3]*i+s[6],this.y=s[1]*e+s[4]*i+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(e,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let i=this.dot(t)/e;return Math.acos(wn(i,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,i=this.y-t.y;return e*e+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let i=Math.cos(e),s=Math.sin(e),r=this.x-t.x,o=this.y-t.y;return this.x=r*i-o*s+t.x,this.y=r*s+o*i+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},De=class n{constructor(t,e,i,s,r,o,a,l,c){n.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,i,s,r,o,a,l,c)}set(t,e,i,s,r,o,a,l,c){let h=this.elements;return h[0]=t,h[1]=s,h[2]=a,h[3]=e,h[4]=r,h[5]=l,h[6]=i,h[7]=o,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,i=t.elements;return e[0]=i[0],e[1]=i[1],e[2]=i[2],e[3]=i[3],e[4]=i[4],e[5]=i[5],e[6]=i[6],e[7]=i[7],e[8]=i[8],this}extractBasis(t,e,i){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let i=t.elements,s=e.elements,r=this.elements,o=i[0],a=i[3],l=i[6],c=i[1],h=i[4],m=i[7],g=i[2],d=i[5],p=i[8],v=s[0],u=s[3],f=s[6],S=s[1],y=s[4],x=s[7],L=s[2],b=s[5],T=s[8];return r[0]=o*v+a*S+l*L,r[3]=o*u+a*y+l*b,r[6]=o*f+a*x+l*T,r[1]=c*v+h*S+m*L,r[4]=c*u+h*y+m*b,r[7]=c*f+h*x+m*T,r[2]=g*v+d*S+p*L,r[5]=g*u+d*y+p*b,r[8]=g*f+d*x+p*T,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8];return e*o*h-e*a*c-i*r*h+i*a*l+s*r*c-s*o*l}invert(){let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8],m=h*o-a*c,g=a*l-h*r,d=c*r-o*l,p=e*m+i*g+s*d;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);let v=1/p;return t[0]=m*v,t[1]=(s*c-h*i)*v,t[2]=(a*i-s*o)*v,t[3]=g*v,t[4]=(h*e-s*l)*v,t[5]=(s*r-a*e)*v,t[6]=d*v,t[7]=(i*l-c*e)*v,t[8]=(o*e-i*r)*v,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,i,s,r,o,a){let l=Math.cos(r),c=Math.sin(r);return this.set(i*l,i*c,-i*(l*o+c*a)+o+t,-s*c,s*l,-s*(-c*o+l*a)+a+e,0,0,1),this}scale(t,e){return this.premultiply(sl.makeScale(t,e)),this}rotate(t){return this.premultiply(sl.makeRotation(-t)),this}translate(t,e){return this.premultiply(sl.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),i=Math.sin(t);return this.set(e,-i,0,i,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,i=t.elements;for(let s=0;s<9;s++)if(e[s]!==i[s])return!1;return!0}fromArray(t,e=0){for(let i=0;i<9;i++)this.elements[i]=t[i+e];return this}toArray(t=[],e=0){let i=this.elements;return t[e]=i[0],t[e+1]=i[1],t[e+2]=i[2],t[e+3]=i[3],t[e+4]=i[4],t[e+5]=i[5],t[e+6]=i[6],t[e+7]=i[7],t[e+8]=i[8],t}clone(){return new this.constructor().fromArray(this.elements)}},sl=new De;function mu(n){for(let t=n.length-1;t>=0;--t)if(n[t]>=65535)return!0;return!1}function na(n){return document.createElementNS("http://www.w3.org/1999/xhtml",n)}function vp(){let n=na("canvas");return n.style.display="block",n}var Jh={};function Lr(n){n in Jh||(Jh[n]=!0,console.warn(n))}function xp(n,t,e){return new Promise(function(i,s){function r(){switch(n.clientWaitSync(t,n.SYNC_FLUSH_COMMANDS_BIT,0)){case n.WAIT_FAILED:s();break;case n.TIMEOUT_EXPIRED:setTimeout(r,e);break;default:i()}}setTimeout(r,e)})}function _p(n){let t=n.elements;t[2]=.5*t[2]+.5*t[3],t[6]=.5*t[6]+.5*t[7],t[10]=.5*t[10]+.5*t[11],t[14]=.5*t[14]+.5*t[15]}function Mp(n){let t=n.elements;t[11]===-1?(t[10]=-t[10]-1,t[14]=-t[14]):(t[10]=-t[10],t[14]=-t[14]+1)}var Be={enabled:!0,workingColorSpace:hr,spaces:{},convert:function(n,t,e){return this.enabled===!1||t===e||!t||!e||(this.spaces[t].transfer===Xe&&(n.r=Ti(n.r),n.g=Ti(n.g),n.b=Ti(n.b)),this.spaces[t].primaries!==this.spaces[e].primaries&&(n.applyMatrix3(this.spaces[t].toXYZ),n.applyMatrix3(this.spaces[e].fromXYZ)),this.spaces[e].transfer===Xe&&(n.r=js(n.r),n.g=js(n.g),n.b=js(n.b))),n},fromWorkingColorSpace:function(n,t){return this.convert(n,this.workingColorSpace,t)},toWorkingColorSpace:function(n,t){return this.convert(n,t,this.workingColorSpace)},getPrimaries:function(n){return this.spaces[n].primaries},getTransfer:function(n){return n===Wi?Na:this.spaces[n].transfer},getLuminanceCoefficients:function(n,t=this.workingColorSpace){return n.fromArray(this.spaces[t].luminanceCoefficients)},define:function(n){Object.assign(this.spaces,n)},_getMatrix:function(n,t,e){return n.copy(this.spaces[t].toXYZ).multiply(this.spaces[e].fromXYZ)},_getDrawingBufferColorSpace:function(n){return this.spaces[n].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(n=this.workingColorSpace){return this.spaces[n].workingColorSpaceConfig.unpackColorSpace}};function Ti(n){return n<.04045?n*.0773993808:Math.pow(n*.9478672986+.0521327014,2.4)}function js(n){return n<.0031308?n*12.92:1.055*Math.pow(n,.41666)-.055}var Kh=[.64,.33,.3,.6,.15,.06],jh=[.2126,.7152,.0722],Qh=[.3127,.329],tf=new De().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),ef=new De().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);Be.define({[hr]:{primaries:Kh,whitePoint:Qh,transfer:Na,toXYZ:tf,fromXYZ:ef,luminanceCoefficients:jh,workingColorSpaceConfig:{unpackColorSpace:Sn},outputColorSpaceConfig:{drawingBufferColorSpace:Sn}},[Sn]:{primaries:Kh,whitePoint:Qh,transfer:Xe,toXYZ:tf,fromXYZ:ef,luminanceCoefficients:jh,outputColorSpaceConfig:{drawingBufferColorSpace:Sn}}});var Is,bc=class{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{Is===void 0&&(Is=na("canvas")),Is.width=t.width,Is.height=t.height;let i=Is.getContext("2d");t instanceof ImageData?i.putImageData(t,0,0):i.drawImage(t,0,0,t.width,t.height),e=Is}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=na("canvas");e.width=t.width,e.height=t.height;let i=e.getContext("2d");i.drawImage(t,0,0,t.width,t.height);let s=i.getImageData(0,0,t.width,t.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=Ti(r[o]/255)*255;return i.putImageData(s,0,0),e}else if(t.data){let e=t.data.slice(0);for(let i=0;i<e.length;i++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[i]=Math.floor(Ti(e[i]/255)*255):e[i]=Ti(e[i]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},bp=0,ia=class{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:bp++}),this.uuid=mi(),this.data=t,this.dataReady=!0,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let i={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,a=s.length;o<a;o++)s[o].isDataTexture?r.push(rl(s[o].image)):r.push(rl(s[o]))}else r=rl(s);i.url=r}return e||(t.images[this.uuid]=i),i}};function rl(n){return typeof HTMLImageElement<"u"&&n instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&n instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&n instanceof ImageBitmap?bc.getDataURL(n):n.data?{data:Array.from(n.data),width:n.width,height:n.height,type:n.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var Sp=0,Fn=class n extends Zi{constructor(t=n.DEFAULT_IMAGE,e=n.DEFAULT_MAPPING,i=ps,s=ps,r=ui,o=ms,a=Wn,l=Ai,c=n.DEFAULT_ANISOTROPY,h=Wi){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Sp++}),this.uuid=mi(),this.name="",this.source=new ia(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=i,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=c,this.format=a,this.internalFormat=null,this.type=l,this.offset=new Ht(0,0),this.repeat=new Ht(1,1),this.center=new Ht(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new De,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),e||(t.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==iu)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case gs:t.x=t.x-Math.floor(t.x);break;case ps:t.x=t.x<0?0:1;break;case ql:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case gs:t.y=t.y-Math.floor(t.y);break;case ps:t.y=t.y<0?0:1;break;case ql:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}};Fn.DEFAULT_IMAGE=null;Fn.DEFAULT_MAPPING=iu;Fn.DEFAULT_ANISOTROPY=1;var an=class n{constructor(t=0,e=0,i=0,s=1){n.prototype.isVector4=!0,this.x=t,this.y=e,this.z=i,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,i,s){return this.x=t,this.y=e,this.z=i,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,i=this.y,s=this.z,r=this.w,o=t.elements;return this.x=o[0]*e+o[4]*i+o[8]*s+o[12]*r,this.y=o[1]*e+o[5]*i+o[9]*s+o[13]*r,this.z=o[2]*e+o[6]*i+o[10]*s+o[14]*r,this.w=o[3]*e+o[7]*i+o[11]*s+o[15]*r,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,i,s,r,l=t.elements,c=l[0],h=l[4],m=l[8],g=l[1],d=l[5],p=l[9],v=l[2],u=l[6],f=l[10];if(Math.abs(h-g)<.01&&Math.abs(m-v)<.01&&Math.abs(p-u)<.01){if(Math.abs(h+g)<.1&&Math.abs(m+v)<.1&&Math.abs(p+u)<.1&&Math.abs(c+d+f-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let y=(c+1)/2,x=(d+1)/2,L=(f+1)/2,b=(h+g)/4,T=(m+v)/4,A=(p+u)/4;return y>x&&y>L?y<.01?(i=0,s=.707106781,r=.707106781):(i=Math.sqrt(y),s=b/i,r=T/i):x>L?x<.01?(i=.707106781,s=0,r=.707106781):(s=Math.sqrt(x),i=b/s,r=A/s):L<.01?(i=.707106781,s=.707106781,r=0):(r=Math.sqrt(L),i=T/r,s=A/r),this.set(i,s,r,e),this}let S=Math.sqrt((u-p)*(u-p)+(m-v)*(m-v)+(g-h)*(g-h));return Math.abs(S)<.001&&(S=1),this.x=(u-p)/S,this.y=(m-v)/S,this.z=(g-h)/S,this.w=Math.acos((c+d+f-1)/2),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(e,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this.z=t.z+(e.z-t.z)*i,this.w=t.w+(e.w-t.w)*i,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Sc=class extends Zi{constructor(t=1,e=1,i={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new an(0,0,t,e),this.scissorTest=!1,this.viewport=new an(0,0,t,e);let s={width:t,height:e,depth:1};i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:ui,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},i);let r=new Fn(s,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace);r.flipY=!1,r.generateMipmaps=i.generateMipmaps,r.internalFormat=i.internalFormat,this.textures=[];let o=i.count;for(let a=0;a<o;a++)this.textures[a]=r.clone(),this.textures[a].isRenderTargetTexture=!0;this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.resolveDepthBuffer=i.resolveDepthBuffer,this.resolveStencilBuffer=i.resolveStencilBuffer,this.depthTexture=i.depthTexture,this.samples=i.samples}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}setSize(t,e,i=1){if(this.width!==t||this.height!==e||this.depth!==i){this.width=t,this.height=e,this.depth=i;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=t,this.textures[s].image.height=e,this.textures[s].image.depth=i;this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let i=0,s=t.textures.length;i<s;i++)this.textures[i]=t.textures[i].clone(),this.textures[i].isRenderTargetTexture=!0;let e=Object.assign({},t.texture.image);return this.texture.source=new ia(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},Ri=class extends Sc{constructor(t=1,e=1,i={}){super(t,e,i),this.isWebGLRenderTarget=!0}},sa=class extends Fn{constructor(t=null,e=1,i=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:i,depth:s},this.magFilter=Un,this.minFilter=Un,this.wrapR=ps,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}};var wc=class extends Fn{constructor(t=null,e=1,i=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:i,depth:s},this.magFilter=Un,this.minFilter=Un,this.wrapR=ps,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var $n=class{constructor(t=0,e=0,i=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=i,this._w=s}static slerpFlat(t,e,i,s,r,o,a){let l=i[s+0],c=i[s+1],h=i[s+2],m=i[s+3],g=r[o+0],d=r[o+1],p=r[o+2],v=r[o+3];if(a===0){t[e+0]=l,t[e+1]=c,t[e+2]=h,t[e+3]=m;return}if(a===1){t[e+0]=g,t[e+1]=d,t[e+2]=p,t[e+3]=v;return}if(m!==v||l!==g||c!==d||h!==p){let u=1-a,f=l*g+c*d+h*p+m*v,S=f>=0?1:-1,y=1-f*f;if(y>Number.EPSILON){let L=Math.sqrt(y),b=Math.atan2(L,f*S);u=Math.sin(u*b)/L,a=Math.sin(a*b)/L}let x=a*S;if(l=l*u+g*x,c=c*u+d*x,h=h*u+p*x,m=m*u+v*x,u===1-a){let L=1/Math.sqrt(l*l+c*c+h*h+m*m);l*=L,c*=L,h*=L,m*=L}}t[e]=l,t[e+1]=c,t[e+2]=h,t[e+3]=m}static multiplyQuaternionsFlat(t,e,i,s,r,o){let a=i[s],l=i[s+1],c=i[s+2],h=i[s+3],m=r[o],g=r[o+1],d=r[o+2],p=r[o+3];return t[e]=a*p+h*m+l*d-c*g,t[e+1]=l*p+h*g+c*m-a*d,t[e+2]=c*p+h*d+a*g-l*m,t[e+3]=h*p-a*m-l*g-c*d,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,i,s){return this._x=t,this._y=e,this._z=i,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let i=t._x,s=t._y,r=t._z,o=t._order,a=Math.cos,l=Math.sin,c=a(i/2),h=a(s/2),m=a(r/2),g=l(i/2),d=l(s/2),p=l(r/2);switch(o){case"XYZ":this._x=g*h*m+c*d*p,this._y=c*d*m-g*h*p,this._z=c*h*p+g*d*m,this._w=c*h*m-g*d*p;break;case"YXZ":this._x=g*h*m+c*d*p,this._y=c*d*m-g*h*p,this._z=c*h*p-g*d*m,this._w=c*h*m+g*d*p;break;case"ZXY":this._x=g*h*m-c*d*p,this._y=c*d*m+g*h*p,this._z=c*h*p+g*d*m,this._w=c*h*m-g*d*p;break;case"ZYX":this._x=g*h*m-c*d*p,this._y=c*d*m+g*h*p,this._z=c*h*p-g*d*m,this._w=c*h*m+g*d*p;break;case"YZX":this._x=g*h*m+c*d*p,this._y=c*d*m+g*h*p,this._z=c*h*p-g*d*m,this._w=c*h*m-g*d*p;break;case"XZY":this._x=g*h*m-c*d*p,this._y=c*d*m-g*h*p,this._z=c*h*p+g*d*m,this._w=c*h*m+g*d*p;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let i=e/2,s=Math.sin(i);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,i=e[0],s=e[4],r=e[8],o=e[1],a=e[5],l=e[9],c=e[2],h=e[6],m=e[10],g=i+a+m;if(g>0){let d=.5/Math.sqrt(g+1);this._w=.25/d,this._x=(h-l)*d,this._y=(r-c)*d,this._z=(o-s)*d}else if(i>a&&i>m){let d=2*Math.sqrt(1+i-a-m);this._w=(h-l)/d,this._x=.25*d,this._y=(s+o)/d,this._z=(r+c)/d}else if(a>m){let d=2*Math.sqrt(1+a-i-m);this._w=(r-c)/d,this._x=(s+o)/d,this._y=.25*d,this._z=(l+h)/d}else{let d=2*Math.sqrt(1+m-i-a);this._w=(o-s)/d,this._x=(r+c)/d,this._y=(l+h)/d,this._z=.25*d}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let i=t.dot(e)+1;return i<Number.EPSILON?(i=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=i):(this._x=0,this._y=-t.z,this._z=t.y,this._w=i)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=i),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(wn(this.dot(t),-1,1)))}rotateTowards(t,e){let i=this.angleTo(t);if(i===0)return this;let s=Math.min(1,e/i);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let i=t._x,s=t._y,r=t._z,o=t._w,a=e._x,l=e._y,c=e._z,h=e._w;return this._x=i*h+o*a+s*c-r*l,this._y=s*h+o*l+r*a-i*c,this._z=r*h+o*c+i*l-s*a,this._w=o*h-i*a-s*l-r*c,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);let i=this._x,s=this._y,r=this._z,o=this._w,a=o*t._w+i*t._x+s*t._y+r*t._z;if(a<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,a=-a):this.copy(t),a>=1)return this._w=o,this._x=i,this._y=s,this._z=r,this;let l=1-a*a;if(l<=Number.EPSILON){let d=1-e;return this._w=d*o+e*this._w,this._x=d*i+e*this._x,this._y=d*s+e*this._y,this._z=d*r+e*this._z,this.normalize(),this}let c=Math.sqrt(l),h=Math.atan2(c,a),m=Math.sin((1-e)*h)/c,g=Math.sin(e*h)/c;return this._w=o*m+this._w*g,this._x=i*m+this._x*g,this._y=s*m+this._y*g,this._z=r*m+this._z*g,this._onChangeCallback(),this}slerpQuaternions(t,e,i){return this.copy(t).slerp(e,i)}random(){let t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),i=Math.random(),s=Math.sqrt(1-i),r=Math.sqrt(i);return this.set(s*Math.sin(t),s*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},V=class n{constructor(t=0,e=0,i=0){n.prototype.isVector3=!0,this.x=t,this.y=e,this.z=i}set(t,e,i){return i===void 0&&(i=this.z),this.x=t,this.y=e,this.z=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(nf.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(nf.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,i=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[3]*i+r[6]*s,this.y=r[1]*e+r[4]*i+r[7]*s,this.z=r[2]*e+r[5]*i+r[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,i=this.y,s=this.z,r=t.elements,o=1/(r[3]*e+r[7]*i+r[11]*s+r[15]);return this.x=(r[0]*e+r[4]*i+r[8]*s+r[12])*o,this.y=(r[1]*e+r[5]*i+r[9]*s+r[13])*o,this.z=(r[2]*e+r[6]*i+r[10]*s+r[14])*o,this}applyQuaternion(t){let e=this.x,i=this.y,s=this.z,r=t.x,o=t.y,a=t.z,l=t.w,c=2*(o*s-a*i),h=2*(a*e-r*s),m=2*(r*i-o*e);return this.x=e+l*c+o*m-a*h,this.y=i+l*h+a*c-r*m,this.z=s+l*m+r*h-o*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,i=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[4]*i+r[8]*s,this.y=r[1]*e+r[5]*i+r[9]*s,this.z=r[2]*e+r[6]*i+r[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(t,Math.min(e,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,i){return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this.z=t.z+(e.z-t.z)*i,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let i=t.x,s=t.y,r=t.z,o=e.x,a=e.y,l=e.z;return this.x=s*l-r*a,this.y=r*o-i*l,this.z=i*a-s*o,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let i=t.dot(this)/e;return this.copy(t).multiplyScalar(i)}projectOnPlane(t){return ol.copy(this).projectOnVector(t),this.sub(ol)}reflect(t){return this.sub(ol.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let i=this.dot(t)/e;return Math.acos(wn(i,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,i=this.y-t.y,s=this.z-t.z;return e*e+i*i+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,i){let s=Math.sin(e)*t;return this.x=s*Math.sin(i),this.y=Math.cos(e)*t,this.z=s*Math.cos(i),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,i){return this.x=t*Math.sin(e),this.y=i,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),i=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=i,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=Math.random()*Math.PI*2,e=Math.random()*2-1,i=Math.sqrt(1-e*e);return this.x=i*Math.cos(t),this.y=e,this.z=i*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},ol=new V,nf=new $n,Ci=class{constructor(t=new V(1/0,1/0,1/0),e=new V(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,i=t.length;e<i;e+=3)this.expandByPoint(Qn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,i=t.count;e<i;e++)this.expandByPoint(Qn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,i=t.length;e<i;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let i=Qn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(i),this.max.copy(t).add(i),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let i=t.geometry;if(i!==void 0){let r=i.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)t.isMesh===!0?t.getVertexPosition(o,Qn):Qn.fromBufferAttribute(r,o),Qn.applyMatrix4(t.matrixWorld),this.expandByPoint(Qn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),xo.copy(t.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),xo.copy(i.boundingBox)),xo.applyMatrix4(t.matrixWorld),this.union(xo)}let s=t.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,Qn),Qn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,i;return t.normal.x>0?(e=t.normal.x*this.min.x,i=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,i=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,i+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,i+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,i+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,i+=t.normal.z*this.min.z),e<=-t.constant&&i>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(br),_o.subVectors(this.max,br),Ps.subVectors(t.a,br),Ls.subVectors(t.b,br),ks.subVectors(t.c,br),Oi.subVectors(Ls,Ps),zi.subVectors(ks,Ls),rs.subVectors(Ps,ks);let e=[0,-Oi.z,Oi.y,0,-zi.z,zi.y,0,-rs.z,rs.y,Oi.z,0,-Oi.x,zi.z,0,-zi.x,rs.z,0,-rs.x,-Oi.y,Oi.x,0,-zi.y,zi.x,0,-rs.y,rs.x,0];return!al(e,Ps,Ls,ks,_o)||(e=[1,0,0,0,1,0,0,0,1],!al(e,Ps,Ls,ks,_o))?!1:(Mo.crossVectors(Oi,zi),e=[Mo.x,Mo.y,Mo.z],al(e,Ps,Ls,ks,_o))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Qn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Qn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(vi[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),vi[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),vi[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),vi[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),vi[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),vi[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),vi[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),vi[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(vi),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}},vi=[new V,new V,new V,new V,new V,new V,new V,new V],Qn=new V,xo=new Ci,Ps=new V,Ls=new V,ks=new V,Oi=new V,zi=new V,rs=new V,br=new V,_o=new V,Mo=new V,os=new V;function al(n,t,e,i,s){for(let r=0,o=n.length-3;r<=o;r+=3){os.fromArray(n,r);let a=s.x*Math.abs(os.x)+s.y*Math.abs(os.y)+s.z*Math.abs(os.z),l=t.dot(os),c=e.dot(os),h=i.dot(os);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>a)return!1}return!0}var wp=new Ci,Sr=new V,ll=new V,Ji=class{constructor(t=new V,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let i=this.center;e!==void 0?i.copy(e):wp.setFromPoints(t).getCenter(i);let s=0;for(let r=0,o=t.length;r<o;r++)s=Math.max(s,i.distanceToSquared(t[r]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let i=this.center.distanceToSquared(t);return e.copy(t),i>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Sr.subVectors(t,this.center);let e=Sr.lengthSq();if(e>this.radius*this.radius){let i=Math.sqrt(e),s=(i-this.radius)*.5;this.center.addScaledVector(Sr,s/i),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(ll.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Sr.copy(t.center).add(ll)),this.expandByPoint(Sr.copy(t.center).sub(ll))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}},xi=new V,cl=new V,bo=new V,Bi=new V,hl=new V,So=new V,fl=new V,ra=class{constructor(t=new V,e=new V(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,xi)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let i=e.dot(this.direction);return i<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=xi.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(xi.copy(this.origin).addScaledVector(this.direction,e),xi.distanceToSquared(t))}distanceSqToSegment(t,e,i,s){cl.copy(t).add(e).multiplyScalar(.5),bo.copy(e).sub(t).normalize(),Bi.copy(this.origin).sub(cl);let r=t.distanceTo(e)*.5,o=-this.direction.dot(bo),a=Bi.dot(this.direction),l=-Bi.dot(bo),c=Bi.lengthSq(),h=Math.abs(1-o*o),m,g,d,p;if(h>0)if(m=o*l-a,g=o*a-l,p=r*h,m>=0)if(g>=-p)if(g<=p){let v=1/h;m*=v,g*=v,d=m*(m+o*g+2*a)+g*(o*m+g+2*l)+c}else g=r,m=Math.max(0,-(o*g+a)),d=-m*m+g*(g+2*l)+c;else g=-r,m=Math.max(0,-(o*g+a)),d=-m*m+g*(g+2*l)+c;else g<=-p?(m=Math.max(0,-(-o*r+a)),g=m>0?-r:Math.min(Math.max(-r,-l),r),d=-m*m+g*(g+2*l)+c):g<=p?(m=0,g=Math.min(Math.max(-r,-l),r),d=g*(g+2*l)+c):(m=Math.max(0,-(o*r+a)),g=m>0?r:Math.min(Math.max(-r,-l),r),d=-m*m+g*(g+2*l)+c);else g=o>0?-r:r,m=Math.max(0,-(o*g+a)),d=-m*m+g*(g+2*l)+c;return i&&i.copy(this.origin).addScaledVector(this.direction,m),s&&s.copy(cl).addScaledVector(bo,g),d}intersectSphere(t,e){xi.subVectors(t.center,this.origin);let i=xi.dot(this.direction),s=xi.dot(xi)-i*i,r=t.radius*t.radius;if(s>r)return null;let o=Math.sqrt(r-s),a=i-o,l=i+o;return l<0?null:a<0?this.at(l,e):this.at(a,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let i=-(this.origin.dot(t.normal)+t.constant)/e;return i>=0?i:null}intersectPlane(t,e){let i=this.distanceToPlane(t);return i===null?null:this.at(i,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let i,s,r,o,a,l,c=1/this.direction.x,h=1/this.direction.y,m=1/this.direction.z,g=this.origin;return c>=0?(i=(t.min.x-g.x)*c,s=(t.max.x-g.x)*c):(i=(t.max.x-g.x)*c,s=(t.min.x-g.x)*c),h>=0?(r=(t.min.y-g.y)*h,o=(t.max.y-g.y)*h):(r=(t.max.y-g.y)*h,o=(t.min.y-g.y)*h),i>o||r>s||((r>i||isNaN(i))&&(i=r),(o<s||isNaN(s))&&(s=o),m>=0?(a=(t.min.z-g.z)*m,l=(t.max.z-g.z)*m):(a=(t.max.z-g.z)*m,l=(t.min.z-g.z)*m),i>l||a>s)||((a>i||i!==i)&&(i=a),(l<s||s!==s)&&(s=l),s<0)?null:this.at(i>=0?i:s,e)}intersectsBox(t){return this.intersectBox(t,xi)!==null}intersectTriangle(t,e,i,s,r){hl.subVectors(e,t),So.subVectors(i,t),fl.crossVectors(hl,So);let o=this.direction.dot(fl),a;if(o>0){if(s)return null;a=1}else if(o<0)a=-1,o=-o;else return null;Bi.subVectors(this.origin,t);let l=a*this.direction.dot(So.crossVectors(Bi,So));if(l<0)return null;let c=a*this.direction.dot(hl.cross(Bi));if(c<0||l+c>o)return null;let h=-a*Bi.dot(fl);return h<0?null:this.at(h/o,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},Fe=class n{constructor(t,e,i,s,r,o,a,l,c,h,m,g,d,p,v,u){n.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,i,s,r,o,a,l,c,h,m,g,d,p,v,u)}set(t,e,i,s,r,o,a,l,c,h,m,g,d,p,v,u){let f=this.elements;return f[0]=t,f[4]=e,f[8]=i,f[12]=s,f[1]=r,f[5]=o,f[9]=a,f[13]=l,f[2]=c,f[6]=h,f[10]=m,f[14]=g,f[3]=d,f[7]=p,f[11]=v,f[15]=u,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new n().fromArray(this.elements)}copy(t){let e=this.elements,i=t.elements;return e[0]=i[0],e[1]=i[1],e[2]=i[2],e[3]=i[3],e[4]=i[4],e[5]=i[5],e[6]=i[6],e[7]=i[7],e[8]=i[8],e[9]=i[9],e[10]=i[10],e[11]=i[11],e[12]=i[12],e[13]=i[13],e[14]=i[14],e[15]=i[15],this}copyPosition(t){let e=this.elements,i=t.elements;return e[12]=i[12],e[13]=i[13],e[14]=i[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,i){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(t,e,i){return this.set(t.x,e.x,i.x,0,t.y,e.y,i.y,0,t.z,e.z,i.z,0,0,0,0,1),this}extractRotation(t){let e=this.elements,i=t.elements,s=1/Ds.setFromMatrixColumn(t,0).length(),r=1/Ds.setFromMatrixColumn(t,1).length(),o=1/Ds.setFromMatrixColumn(t,2).length();return e[0]=i[0]*s,e[1]=i[1]*s,e[2]=i[2]*s,e[3]=0,e[4]=i[4]*r,e[5]=i[5]*r,e[6]=i[6]*r,e[7]=0,e[8]=i[8]*o,e[9]=i[9]*o,e[10]=i[10]*o,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,i=t.x,s=t.y,r=t.z,o=Math.cos(i),a=Math.sin(i),l=Math.cos(s),c=Math.sin(s),h=Math.cos(r),m=Math.sin(r);if(t.order==="XYZ"){let g=o*h,d=o*m,p=a*h,v=a*m;e[0]=l*h,e[4]=-l*m,e[8]=c,e[1]=d+p*c,e[5]=g-v*c,e[9]=-a*l,e[2]=v-g*c,e[6]=p+d*c,e[10]=o*l}else if(t.order==="YXZ"){let g=l*h,d=l*m,p=c*h,v=c*m;e[0]=g+v*a,e[4]=p*a-d,e[8]=o*c,e[1]=o*m,e[5]=o*h,e[9]=-a,e[2]=d*a-p,e[6]=v+g*a,e[10]=o*l}else if(t.order==="ZXY"){let g=l*h,d=l*m,p=c*h,v=c*m;e[0]=g-v*a,e[4]=-o*m,e[8]=p+d*a,e[1]=d+p*a,e[5]=o*h,e[9]=v-g*a,e[2]=-o*c,e[6]=a,e[10]=o*l}else if(t.order==="ZYX"){let g=o*h,d=o*m,p=a*h,v=a*m;e[0]=l*h,e[4]=p*c-d,e[8]=g*c+v,e[1]=l*m,e[5]=v*c+g,e[9]=d*c-p,e[2]=-c,e[6]=a*l,e[10]=o*l}else if(t.order==="YZX"){let g=o*l,d=o*c,p=a*l,v=a*c;e[0]=l*h,e[4]=v-g*m,e[8]=p*m+d,e[1]=m,e[5]=o*h,e[9]=-a*h,e[2]=-c*h,e[6]=d*m+p,e[10]=g-v*m}else if(t.order==="XZY"){let g=o*l,d=o*c,p=a*l,v=a*c;e[0]=l*h,e[4]=-m,e[8]=c*h,e[1]=g*m+v,e[5]=o*h,e[9]=d*m-p,e[2]=p*m-d,e[6]=a*h,e[10]=v*m+g}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(Ep,t,Tp)}lookAt(t,e,i){let s=this.elements;return Vn.subVectors(t,e),Vn.lengthSq()===0&&(Vn.z=1),Vn.normalize(),Hi.crossVectors(i,Vn),Hi.lengthSq()===0&&(Math.abs(i.z)===1?Vn.x+=1e-4:Vn.z+=1e-4,Vn.normalize(),Hi.crossVectors(i,Vn)),Hi.normalize(),wo.crossVectors(Vn,Hi),s[0]=Hi.x,s[4]=wo.x,s[8]=Vn.x,s[1]=Hi.y,s[5]=wo.y,s[9]=Vn.y,s[2]=Hi.z,s[6]=wo.z,s[10]=Vn.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let i=t.elements,s=e.elements,r=this.elements,o=i[0],a=i[4],l=i[8],c=i[12],h=i[1],m=i[5],g=i[9],d=i[13],p=i[2],v=i[6],u=i[10],f=i[14],S=i[3],y=i[7],x=i[11],L=i[15],b=s[0],T=s[4],A=s[8],M=s[12],_=s[1],w=s[5],P=s[9],E=s[13],F=s[2],R=s[6],N=s[10],U=s[14],z=s[3],Z=s[7],Y=s[11],k=s[15];return r[0]=o*b+a*_+l*F+c*z,r[4]=o*T+a*w+l*R+c*Z,r[8]=o*A+a*P+l*N+c*Y,r[12]=o*M+a*E+l*U+c*k,r[1]=h*b+m*_+g*F+d*z,r[5]=h*T+m*w+g*R+d*Z,r[9]=h*A+m*P+g*N+d*Y,r[13]=h*M+m*E+g*U+d*k,r[2]=p*b+v*_+u*F+f*z,r[6]=p*T+v*w+u*R+f*Z,r[10]=p*A+v*P+u*N+f*Y,r[14]=p*M+v*E+u*U+f*k,r[3]=S*b+y*_+x*F+L*z,r[7]=S*T+y*w+x*R+L*Z,r[11]=S*A+y*P+x*N+L*Y,r[15]=S*M+y*E+x*U+L*k,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],i=t[4],s=t[8],r=t[12],o=t[1],a=t[5],l=t[9],c=t[13],h=t[2],m=t[6],g=t[10],d=t[14],p=t[3],v=t[7],u=t[11],f=t[15];return p*(+r*l*m-s*c*m-r*a*g+i*c*g+s*a*d-i*l*d)+v*(+e*l*d-e*c*g+r*o*g-s*o*d+s*c*h-r*l*h)+u*(+e*c*m-e*a*d-r*o*m+i*o*d+r*a*h-i*c*h)+f*(-s*a*h-e*l*m+e*a*g+s*o*m-i*o*g+i*l*h)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,i){let s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=i),this}invert(){let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],o=t[4],a=t[5],l=t[6],c=t[7],h=t[8],m=t[9],g=t[10],d=t[11],p=t[12],v=t[13],u=t[14],f=t[15],S=m*u*c-v*g*c+v*l*d-a*u*d-m*l*f+a*g*f,y=p*g*c-h*u*c-p*l*d+o*u*d+h*l*f-o*g*f,x=h*v*c-p*m*c+p*a*d-o*v*d-h*a*f+o*m*f,L=p*m*l-h*v*l-p*a*g+o*v*g+h*a*u-o*m*u,b=e*S+i*y+s*x+r*L;if(b===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let T=1/b;return t[0]=S*T,t[1]=(v*g*r-m*u*r-v*s*d+i*u*d+m*s*f-i*g*f)*T,t[2]=(a*u*r-v*l*r+v*s*c-i*u*c-a*s*f+i*l*f)*T,t[3]=(m*l*r-a*g*r-m*s*c+i*g*c+a*s*d-i*l*d)*T,t[4]=y*T,t[5]=(h*u*r-p*g*r+p*s*d-e*u*d-h*s*f+e*g*f)*T,t[6]=(p*l*r-o*u*r-p*s*c+e*u*c+o*s*f-e*l*f)*T,t[7]=(o*g*r-h*l*r+h*s*c-e*g*c-o*s*d+e*l*d)*T,t[8]=x*T,t[9]=(p*m*r-h*v*r-p*i*d+e*v*d+h*i*f-e*m*f)*T,t[10]=(o*v*r-p*a*r+p*i*c-e*v*c-o*i*f+e*a*f)*T,t[11]=(h*a*r-o*m*r-h*i*c+e*m*c+o*i*d-e*a*d)*T,t[12]=L*T,t[13]=(h*v*s-p*m*s+p*i*g-e*v*g-h*i*u+e*m*u)*T,t[14]=(p*a*s-o*v*s-p*i*l+e*v*l+o*i*u-e*a*u)*T,t[15]=(o*m*s-h*a*s+h*i*l-e*m*l-o*i*g+e*a*g)*T,this}scale(t){let e=this.elements,i=t.x,s=t.y,r=t.z;return e[0]*=i,e[4]*=s,e[8]*=r,e[1]*=i,e[5]*=s,e[9]*=r,e[2]*=i,e[6]*=s,e[10]*=r,e[3]*=i,e[7]*=s,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],i=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,i,s))}makeTranslation(t,e,i){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,i,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),i=Math.sin(t);return this.set(1,0,0,0,0,e,-i,0,0,i,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),i=Math.sin(t);return this.set(e,0,i,0,0,1,0,0,-i,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),i=Math.sin(t);return this.set(e,-i,0,0,i,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let i=Math.cos(e),s=Math.sin(e),r=1-i,o=t.x,a=t.y,l=t.z,c=r*o,h=r*a;return this.set(c*o+i,c*a-s*l,c*l+s*a,0,c*a+s*l,h*a+i,h*l-s*o,0,c*l-s*a,h*l+s*o,r*l*l+i,0,0,0,0,1),this}makeScale(t,e,i){return this.set(t,0,0,0,0,e,0,0,0,0,i,0,0,0,0,1),this}makeShear(t,e,i,s,r,o){return this.set(1,i,r,0,t,1,o,0,e,s,1,0,0,0,0,1),this}compose(t,e,i){let s=this.elements,r=e._x,o=e._y,a=e._z,l=e._w,c=r+r,h=o+o,m=a+a,g=r*c,d=r*h,p=r*m,v=o*h,u=o*m,f=a*m,S=l*c,y=l*h,x=l*m,L=i.x,b=i.y,T=i.z;return s[0]=(1-(v+f))*L,s[1]=(d+x)*L,s[2]=(p-y)*L,s[3]=0,s[4]=(d-x)*b,s[5]=(1-(g+f))*b,s[6]=(u+S)*b,s[7]=0,s[8]=(p+y)*T,s[9]=(u-S)*T,s[10]=(1-(g+v))*T,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,i){let s=this.elements,r=Ds.set(s[0],s[1],s[2]).length(),o=Ds.set(s[4],s[5],s[6]).length(),a=Ds.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),t.x=s[12],t.y=s[13],t.z=s[14],ti.copy(this);let c=1/r,h=1/o,m=1/a;return ti.elements[0]*=c,ti.elements[1]*=c,ti.elements[2]*=c,ti.elements[4]*=h,ti.elements[5]*=h,ti.elements[6]*=h,ti.elements[8]*=m,ti.elements[9]*=m,ti.elements[10]*=m,e.setFromRotationMatrix(ti),i.x=r,i.y=o,i.z=a,this}makePerspective(t,e,i,s,r,o,a=Ei){let l=this.elements,c=2*r/(e-t),h=2*r/(i-s),m=(e+t)/(e-t),g=(i+s)/(i-s),d,p;if(a===Ei)d=-(o+r)/(o-r),p=-2*o*r/(o-r);else if(a===ea)d=-o/(o-r),p=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=c,l[4]=0,l[8]=m,l[12]=0,l[1]=0,l[5]=h,l[9]=g,l[13]=0,l[2]=0,l[6]=0,l[10]=d,l[14]=p,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,e,i,s,r,o,a=Ei){let l=this.elements,c=1/(e-t),h=1/(i-s),m=1/(o-r),g=(e+t)*c,d=(i+s)*h,p,v;if(a===Ei)p=(o+r)*m,v=-2*m;else if(a===ea)p=r*m,v=-1*m;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-g,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-d,l[2]=0,l[6]=0,l[10]=v,l[14]=-p,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){let e=this.elements,i=t.elements;for(let s=0;s<16;s++)if(e[s]!==i[s])return!1;return!0}fromArray(t,e=0){for(let i=0;i<16;i++)this.elements[i]=t[i+e];return this}toArray(t=[],e=0){let i=this.elements;return t[e]=i[0],t[e+1]=i[1],t[e+2]=i[2],t[e+3]=i[3],t[e+4]=i[4],t[e+5]=i[5],t[e+6]=i[6],t[e+7]=i[7],t[e+8]=i[8],t[e+9]=i[9],t[e+10]=i[10],t[e+11]=i[11],t[e+12]=i[12],t[e+13]=i[13],t[e+14]=i[14],t[e+15]=i[15],t}},Ds=new V,ti=new Fe,Ep=new V(0,0,0),Tp=new V(1,1,1),Hi=new V,wo=new V,Vn=new V,sf=new Fe,rf=new $n,ii=class n{constructor(t=0,e=0,i=0,s=n.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=i,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,i,s=this._order){return this._x=t,this._y=e,this._z=i,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,i=!0){let s=t.elements,r=s[0],o=s[4],a=s[8],l=s[1],c=s[5],h=s[9],m=s[2],g=s[6],d=s[10];switch(e){case"XYZ":this._y=Math.asin(wn(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,d),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(g,c),this._z=0);break;case"YXZ":this._x=Math.asin(-wn(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,d),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-m,r),this._z=0);break;case"ZXY":this._x=Math.asin(wn(g,-1,1)),Math.abs(g)<.9999999?(this._y=Math.atan2(-m,d),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-wn(m,-1,1)),Math.abs(m)<.9999999?(this._x=Math.atan2(g,d),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(wn(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-m,r)):(this._x=0,this._y=Math.atan2(a,d));break;case"XZY":this._z=Math.asin(-wn(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(g,c),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-h,d),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,i===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,i){return sf.makeRotationFromQuaternion(t),this.setFromRotationMatrix(sf,e,i)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return rf.setFromEuler(this),this.setFromQuaternion(rf,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};ii.DEFAULT_ORDER="XYZ";var oa=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},Ap=0,of=new V,Us=new $n,_i=new Fe,Eo=new V,wr=new V,Rp=new V,Cp=new $n,af=new V(1,0,0),lf=new V(0,1,0),cf=new V(0,0,1),hf={type:"added"},Ip={type:"removed"},Ns={type:"childadded",child:null},ul={type:"childremoved",child:null},qe=class n extends Zi{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Ap++}),this.uuid=mi(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=n.DEFAULT_UP.clone();let t=new V,e=new ii,i=new $n,s=new V(1,1,1);function r(){i.setFromEuler(e,!1)}function o(){e.setFromQuaternion(i,void 0,!1)}e._onChange(r),i._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new Fe},normalMatrix:{value:new De}}),this.matrix=new Fe,this.matrixWorld=new Fe,this.matrixAutoUpdate=n.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=n.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new oa,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return Us.setFromAxisAngle(t,e),this.quaternion.multiply(Us),this}rotateOnWorldAxis(t,e){return Us.setFromAxisAngle(t,e),this.quaternion.premultiply(Us),this}rotateX(t){return this.rotateOnAxis(af,t)}rotateY(t){return this.rotateOnAxis(lf,t)}rotateZ(t){return this.rotateOnAxis(cf,t)}translateOnAxis(t,e){return of.copy(t).applyQuaternion(this.quaternion),this.position.add(of.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(af,t)}translateY(t){return this.translateOnAxis(lf,t)}translateZ(t){return this.translateOnAxis(cf,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(_i.copy(this.matrixWorld).invert())}lookAt(t,e,i){t.isVector3?Eo.copy(t):Eo.set(t,e,i);let s=this.parent;this.updateWorldMatrix(!0,!1),wr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?_i.lookAt(wr,Eo,this.up):_i.lookAt(Eo,wr,this.up),this.quaternion.setFromRotationMatrix(_i),s&&(_i.extractRotation(s.matrixWorld),Us.setFromRotationMatrix(_i),this.quaternion.premultiply(Us.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(hf),Ns.child=t,this.dispatchEvent(Ns),Ns.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(Ip),ul.child=t,this.dispatchEvent(ul),ul.child=null),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),_i.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),_i.multiply(t.parent.matrixWorld)),t.applyMatrix4(_i),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(hf),Ns.child=t,this.dispatchEvent(Ns),Ns.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let i=0,s=this.children.length;i<s;i++){let o=this.children[i].getObjectByProperty(t,e);if(o!==void 0)return o}}getObjectsByProperty(t,e,i=[]){this[t]===e&&i.push(this);let s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(t,e,i);return i}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(wr,t,Rp),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(wr,Cp,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);let e=this.children;for(let i=0,s=e.length;i<s;i++)e[i].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let i=0,s=e.length;i<s;i++)e[i].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let i=0,s=e.length;i<s;i++)e[i].updateMatrixWorld(t)}updateWorldMatrix(t,e){let i=this.parent;if(t===!0&&i!==null&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),e===!0){let s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].updateWorldMatrix(!1,!0)}}toJSON(t){let e=t===void 0||typeof t=="string",i={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(a=>({boxInitialized:a.boxInitialized,boxMin:a.box.min.toArray(),boxMax:a.box.max.toArray(),sphereInitialized:a.sphereInitialized,sphereRadius:a.sphere.radius,sphereCenter:a.sphere.center.toArray()})),s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(t),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(t.geometries,this.geometry);let a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){let l=a.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){let m=l[c];r(t.shapes,m)}else r(t.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let a=[];for(let l=0,c=this.material.length;l<c;l++)a.push(r(t.materials,this.material[l]));s.material=a}else s.material=r(t.materials,this.material);if(this.children.length>0){s.children=[];for(let a=0;a<this.children.length;a++)s.children.push(this.children[a].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let a=0;a<this.animations.length;a++){let l=this.animations[a];s.animations.push(r(t.animations,l))}}if(e){let a=o(t.geometries),l=o(t.materials),c=o(t.textures),h=o(t.images),m=o(t.shapes),g=o(t.skeletons),d=o(t.animations),p=o(t.nodes);a.length>0&&(i.geometries=a),l.length>0&&(i.materials=l),c.length>0&&(i.textures=c),h.length>0&&(i.images=h),m.length>0&&(i.shapes=m),g.length>0&&(i.skeletons=g),d.length>0&&(i.animations=d),p.length>0&&(i.nodes=p)}return i.object=s,i;function o(a){let l=[];for(let c in a){let h=a[c];delete h.metadata,l.push(h)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let i=0;i<t.children.length;i++){let s=t.children[i];this.add(s.clone())}return this}};qe.DEFAULT_UP=new V(0,1,0);qe.DEFAULT_MATRIX_AUTO_UPDATE=!0;qe.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var ei=new V,Mi=new V,dl=new V,bi=new V,Fs=new V,Os=new V,ff=new V,pl=new V,ml=new V,gl=new V,yl=new an,vl=new an,xl=new an,$i=class n{constructor(t=new V,e=new V,i=new V){this.a=t,this.b=e,this.c=i}static getNormal(t,e,i,s){s.subVectors(i,e),ei.subVectors(t,e),s.cross(ei);let r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(t,e,i,s,r){ei.subVectors(s,e),Mi.subVectors(i,e),dl.subVectors(t,e);let o=ei.dot(ei),a=ei.dot(Mi),l=ei.dot(dl),c=Mi.dot(Mi),h=Mi.dot(dl),m=o*c-a*a;if(m===0)return r.set(0,0,0),null;let g=1/m,d=(c*l-a*h)*g,p=(o*h-a*l)*g;return r.set(1-d-p,p,d)}static containsPoint(t,e,i,s){return this.getBarycoord(t,e,i,s,bi)===null?!1:bi.x>=0&&bi.y>=0&&bi.x+bi.y<=1}static getInterpolation(t,e,i,s,r,o,a,l){return this.getBarycoord(t,e,i,s,bi)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,bi.x),l.addScaledVector(o,bi.y),l.addScaledVector(a,bi.z),l)}static getInterpolatedAttribute(t,e,i,s,r,o){return yl.setScalar(0),vl.setScalar(0),xl.setScalar(0),yl.fromBufferAttribute(t,e),vl.fromBufferAttribute(t,i),xl.fromBufferAttribute(t,s),o.setScalar(0),o.addScaledVector(yl,r.x),o.addScaledVector(vl,r.y),o.addScaledVector(xl,r.z),o}static isFrontFacing(t,e,i,s){return ei.subVectors(i,e),Mi.subVectors(t,e),ei.cross(Mi).dot(s)<0}set(t,e,i){return this.a.copy(t),this.b.copy(e),this.c.copy(i),this}setFromPointsAndIndices(t,e,i,s){return this.a.copy(t[e]),this.b.copy(t[i]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,i,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,i),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return ei.subVectors(this.c,this.b),Mi.subVectors(this.a,this.b),ei.cross(Mi).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return n.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return n.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,i,s,r){return n.getInterpolation(t,this.a,this.b,this.c,e,i,s,r)}containsPoint(t){return n.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return n.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let i=this.a,s=this.b,r=this.c,o,a;Fs.subVectors(s,i),Os.subVectors(r,i),pl.subVectors(t,i);let l=Fs.dot(pl),c=Os.dot(pl);if(l<=0&&c<=0)return e.copy(i);ml.subVectors(t,s);let h=Fs.dot(ml),m=Os.dot(ml);if(h>=0&&m<=h)return e.copy(s);let g=l*m-h*c;if(g<=0&&l>=0&&h<=0)return o=l/(l-h),e.copy(i).addScaledVector(Fs,o);gl.subVectors(t,r);let d=Fs.dot(gl),p=Os.dot(gl);if(p>=0&&d<=p)return e.copy(r);let v=d*c-l*p;if(v<=0&&c>=0&&p<=0)return a=c/(c-p),e.copy(i).addScaledVector(Os,a);let u=h*p-d*m;if(u<=0&&m-h>=0&&d-p>=0)return ff.subVectors(r,s),a=(m-h)/(m-h+(d-p)),e.copy(s).addScaledVector(ff,a);let f=1/(u+v+g);return o=v*f,a=g*f,e.copy(i).addScaledVector(Fs,o).addScaledVector(Os,a)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},gu={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Vi={h:0,s:0,l:0},To={h:0,s:0,l:0};function _l(n,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?n+(t-n)*6*e:e<1/2?t:e<2/3?n+(t-n)*6*(2/3-e):n}var fe=class{constructor(t,e,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,i)}set(t,e,i){if(e===void 0&&i===void 0){let s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,i);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Sn){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Be.toWorkingColorSpace(this,e),this}setRGB(t,e,i,s=Be.workingColorSpace){return this.r=t,this.g=e,this.b=i,Be.toWorkingColorSpace(this,s),this}setHSL(t,e,i,s=Be.workingColorSpace){if(t=dh(t,1),e=wn(e,0,1),i=wn(i,0,1),e===0)this.r=this.g=this.b=i;else{let r=i<=.5?i*(1+e):i+e-i*e,o=2*i-r;this.r=_l(o,r,t+1/3),this.g=_l(o,r,t),this.b=_l(o,r,t-1/3)}return Be.toWorkingColorSpace(this,s),this}setStyle(t,e=Sn){function i(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,o=s[1],a=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return i(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return i(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return i(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(o===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Sn){let i=gu[t.toLowerCase()];return i!==void 0?this.setHex(i,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Ti(t.r),this.g=Ti(t.g),this.b=Ti(t.b),this}copyLinearToSRGB(t){return this.r=js(t.r),this.g=js(t.g),this.b=js(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Sn){return Be.fromWorkingColorSpace(Pn.copy(this),t),Math.round(wn(Pn.r*255,0,255))*65536+Math.round(wn(Pn.g*255,0,255))*256+Math.round(wn(Pn.b*255,0,255))}getHexString(t=Sn){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=Be.workingColorSpace){Be.fromWorkingColorSpace(Pn.copy(this),e);let i=Pn.r,s=Pn.g,r=Pn.b,o=Math.max(i,s,r),a=Math.min(i,s,r),l,c,h=(a+o)/2;if(a===o)l=0,c=0;else{let m=o-a;switch(c=h<=.5?m/(o+a):m/(2-o-a),o){case i:l=(s-r)/m+(s<r?6:0);break;case s:l=(r-i)/m+2;break;case r:l=(i-s)/m+4;break}l/=6}return t.h=l,t.s=c,t.l=h,t}getRGB(t,e=Be.workingColorSpace){return Be.fromWorkingColorSpace(Pn.copy(this),e),t.r=Pn.r,t.g=Pn.g,t.b=Pn.b,t}getStyle(t=Sn){Be.fromWorkingColorSpace(Pn.copy(this),t);let e=Pn.r,i=Pn.g,s=Pn.b;return t!==Sn?`color(${t} ${e.toFixed(3)} ${i.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(i*255)},${Math.round(s*255)})`}offsetHSL(t,e,i){return this.getHSL(Vi),this.setHSL(Vi.h+t,Vi.s+e,Vi.l+i)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,i){return this.r=t.r+(e.r-t.r)*i,this.g=t.g+(e.g-t.g)*i,this.b=t.b+(e.b-t.b)*i,this}lerpHSL(t,e){this.getHSL(Vi),t.getHSL(To);let i=Ur(Vi.h,To.h,e),s=Ur(Vi.s,To.s,e),r=Ur(Vi.l,To.l,e);return this.setHSL(i,s,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,i=this.g,s=this.b,r=t.elements;return this.r=r[0]*e+r[3]*i+r[6]*s,this.g=r[1]*e+r[4]*i+r[7]*s,this.b=r[2]*e+r[5]*i+r[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Pn=new fe;fe.NAMES=gu;var Pp=0,Ii=class extends Zi{static get type(){return"Material"}get type(){return this.constructor.type}set type(t){}constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Pp++}),this.uuid=mi(),this.name="",this.blending=Js,this.side=Yi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Nl,this.blendDst=Fl,this.blendEquation=us,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new fe(0,0,0),this.blendAlpha=0,this.depthFunc=tr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=qh,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Cs,this.stencilZFail=Cs,this.stencilZPass=Cs,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let i=t[e];if(i===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}let s=this[e];if(s===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(i):s&&s.isVector3&&i&&i.isVector3?s.copy(i):this[e]=i}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let i={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(i.dispersion=this.dispersion),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(t).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(t).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(t).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(t).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(t).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapRotation!==void 0&&(i.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==Js&&(i.blending=this.blending),this.side!==Yi&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==Nl&&(i.blendSrc=this.blendSrc),this.blendDst!==Fl&&(i.blendDst=this.blendDst),this.blendEquation!==us&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==tr&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==qh&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Cs&&(i.stencilFail=this.stencilFail),this.stencilZFail!==Cs&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==Cs&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData);function s(r){let o=[];for(let a in r){let l=r[a];delete l.metadata,o.push(l)}return o}if(e){let r=s(t.textures),o=s(t.images);r.length>0&&(i.textures=r),o.length>0&&(i.images=o)}return i}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,i=null;if(e!==null){let s=e.length;i=new Array(s);for(let r=0;r!==s;++r)i[r]=e[r].clone()}return this.clippingPlanes=i,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}},On=class extends Ii{static get type(){return"MeshBasicMaterial"}constructor(t){super(),this.isMeshBasicMaterial=!0,this.color=new fe(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new ii,this.combine=nu,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};var un=new V,Ao=new Ht,Qe=class{constructor(t,e,i=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=i,this.usage=Mc,this.updateRanges=[],this.gpuType=di,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,i){t*=this.itemSize,i*=e.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[t+s]=e.array[i+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,i=this.count;e<i;e++)Ao.fromBufferAttribute(this,e),Ao.applyMatrix3(t),this.setXY(e,Ao.x,Ao.y);else if(this.itemSize===3)for(let e=0,i=this.count;e<i;e++)un.fromBufferAttribute(this,e),un.applyMatrix3(t),this.setXYZ(e,un.x,un.y,un.z);return this}applyMatrix4(t){for(let e=0,i=this.count;e<i;e++)un.fromBufferAttribute(this,e),un.applyMatrix4(t),this.setXYZ(e,un.x,un.y,un.z);return this}applyNormalMatrix(t){for(let e=0,i=this.count;e<i;e++)un.fromBufferAttribute(this,e),un.applyNormalMatrix(t),this.setXYZ(e,un.x,un.y,un.z);return this}transformDirection(t){for(let e=0,i=this.count;e<i;e++)un.fromBufferAttribute(this,e),un.transformDirection(t),this.setXYZ(e,un.x,un.y,un.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let i=this.array[t*this.itemSize+e];return this.normalized&&(i=ni(i,this.array)),i}setComponent(t,e,i){return this.normalized&&(i=Ge(i,this.array)),this.array[t*this.itemSize+e]=i,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=ni(e,this.array)),e}setX(t,e){return this.normalized&&(e=Ge(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=ni(e,this.array)),e}setY(t,e){return this.normalized&&(e=Ge(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=ni(e,this.array)),e}setZ(t,e){return this.normalized&&(e=Ge(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=ni(e,this.array)),e}setW(t,e){return this.normalized&&(e=Ge(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,i){return t*=this.itemSize,this.normalized&&(e=Ge(e,this.array),i=Ge(i,this.array)),this.array[t+0]=e,this.array[t+1]=i,this}setXYZ(t,e,i,s){return t*=this.itemSize,this.normalized&&(e=Ge(e,this.array),i=Ge(i,this.array),s=Ge(s,this.array)),this.array[t+0]=e,this.array[t+1]=i,this.array[t+2]=s,this}setXYZW(t,e,i,s,r){return t*=this.itemSize,this.normalized&&(e=Ge(e,this.array),i=Ge(i,this.array),s=Ge(s,this.array),r=Ge(r,this.array)),this.array[t+0]=e,this.array[t+1]=i,this.array[t+2]=s,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==Mc&&(t.usage=this.usage),t}};var aa=class extends Qe{constructor(t,e,i){super(new Uint16Array(t),e,i)}};var la=class extends Qe{constructor(t,e,i){super(new Uint32Array(t),e,i)}};var Te=class extends Qe{constructor(t,e,i){super(new Float32Array(t),e,i)}},Lp=0,qn=new Fe,Ml=new qe,zs=new V,Gn=new Ci,Er=new Ci,bn=new V,Ye=class n extends Zi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Lp++}),this.uuid=mi(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(mu(t)?la:aa)(t,1):this.index=t,this}setIndirect(t){return this.indirect=t,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,i=0){this.groups.push({start:t,count:e,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let i=this.attributes.normal;if(i!==void 0){let r=new De().getNormalMatrix(t);i.applyNormalMatrix(r),i.needsUpdate=!0}let s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return qn.makeRotationFromQuaternion(t),this.applyMatrix4(qn),this}rotateX(t){return qn.makeRotationX(t),this.applyMatrix4(qn),this}rotateY(t){return qn.makeRotationY(t),this.applyMatrix4(qn),this}rotateZ(t){return qn.makeRotationZ(t),this.applyMatrix4(qn),this}translate(t,e,i){return qn.makeTranslation(t,e,i),this.applyMatrix4(qn),this}scale(t,e,i){return qn.makeScale(t,e,i),this.applyMatrix4(qn),this}lookAt(t){return Ml.lookAt(t),Ml.updateMatrix(),this.applyMatrix4(Ml.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(zs).negate(),this.translate(zs.x,zs.y,zs.z),this}setFromPoints(t){let e=this.getAttribute("position");if(e===void 0){let i=[];for(let s=0,r=t.length;s<r;s++){let o=t[s];i.push(o.x,o.y,o.z||0)}this.setAttribute("position",new Te(i,3))}else{for(let i=0,s=e.count;i<s;i++){let r=t[i];e.setXYZ(i,r.x,r.y,r.z||0)}t.length>e.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Ci);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new V(-1/0,-1/0,-1/0),new V(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let i=0,s=e.length;i<s;i++){let r=e[i];Gn.setFromBufferAttribute(r),this.morphTargetsRelative?(bn.addVectors(this.boundingBox.min,Gn.min),this.boundingBox.expandByPoint(bn),bn.addVectors(this.boundingBox.max,Gn.max),this.boundingBox.expandByPoint(bn)):(this.boundingBox.expandByPoint(Gn.min),this.boundingBox.expandByPoint(Gn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ji);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new V,1/0);return}if(t){let i=this.boundingSphere.center;if(Gn.setFromBufferAttribute(t),e)for(let r=0,o=e.length;r<o;r++){let a=e[r];Er.setFromBufferAttribute(a),this.morphTargetsRelative?(bn.addVectors(Gn.min,Er.min),Gn.expandByPoint(bn),bn.addVectors(Gn.max,Er.max),Gn.expandByPoint(bn)):(Gn.expandByPoint(Er.min),Gn.expandByPoint(Er.max))}Gn.getCenter(i);let s=0;for(let r=0,o=t.count;r<o;r++)bn.fromBufferAttribute(t,r),s=Math.max(s,i.distanceToSquared(bn));if(e)for(let r=0,o=e.length;r<o;r++){let a=e[r],l=this.morphTargetsRelative;for(let c=0,h=a.count;c<h;c++)bn.fromBufferAttribute(a,c),l&&(zs.fromBufferAttribute(t,c),bn.add(zs)),s=Math.max(s,i.distanceToSquared(bn))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let i=e.position,s=e.normal,r=e.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Qe(new Float32Array(4*i.count),4));let o=this.getAttribute("tangent"),a=[],l=[];for(let A=0;A<i.count;A++)a[A]=new V,l[A]=new V;let c=new V,h=new V,m=new V,g=new Ht,d=new Ht,p=new Ht,v=new V,u=new V;function f(A,M,_){c.fromBufferAttribute(i,A),h.fromBufferAttribute(i,M),m.fromBufferAttribute(i,_),g.fromBufferAttribute(r,A),d.fromBufferAttribute(r,M),p.fromBufferAttribute(r,_),h.sub(c),m.sub(c),d.sub(g),p.sub(g);let w=1/(d.x*p.y-p.x*d.y);isFinite(w)&&(v.copy(h).multiplyScalar(p.y).addScaledVector(m,-d.y).multiplyScalar(w),u.copy(m).multiplyScalar(d.x).addScaledVector(h,-p.x).multiplyScalar(w),a[A].add(v),a[M].add(v),a[_].add(v),l[A].add(u),l[M].add(u),l[_].add(u))}let S=this.groups;S.length===0&&(S=[{start:0,count:t.count}]);for(let A=0,M=S.length;A<M;++A){let _=S[A],w=_.start,P=_.count;for(let E=w,F=w+P;E<F;E+=3)f(t.getX(E+0),t.getX(E+1),t.getX(E+2))}let y=new V,x=new V,L=new V,b=new V;function T(A){L.fromBufferAttribute(s,A),b.copy(L);let M=a[A];y.copy(M),y.sub(L.multiplyScalar(L.dot(M))).normalize(),x.crossVectors(b,M);let w=x.dot(l[A])<0?-1:1;o.setXYZW(A,y.x,y.y,y.z,w)}for(let A=0,M=S.length;A<M;++A){let _=S[A],w=_.start,P=_.count;for(let E=w,F=w+P;E<F;E+=3)T(t.getX(E+0)),T(t.getX(E+1)),T(t.getX(E+2))}}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new Qe(new Float32Array(e.count*3),3),this.setAttribute("normal",i);else for(let g=0,d=i.count;g<d;g++)i.setXYZ(g,0,0,0);let s=new V,r=new V,o=new V,a=new V,l=new V,c=new V,h=new V,m=new V;if(t)for(let g=0,d=t.count;g<d;g+=3){let p=t.getX(g+0),v=t.getX(g+1),u=t.getX(g+2);s.fromBufferAttribute(e,p),r.fromBufferAttribute(e,v),o.fromBufferAttribute(e,u),h.subVectors(o,r),m.subVectors(s,r),h.cross(m),a.fromBufferAttribute(i,p),l.fromBufferAttribute(i,v),c.fromBufferAttribute(i,u),a.add(h),l.add(h),c.add(h),i.setXYZ(p,a.x,a.y,a.z),i.setXYZ(v,l.x,l.y,l.z),i.setXYZ(u,c.x,c.y,c.z)}else for(let g=0,d=e.count;g<d;g+=3)s.fromBufferAttribute(e,g+0),r.fromBufferAttribute(e,g+1),o.fromBufferAttribute(e,g+2),h.subVectors(o,r),m.subVectors(s,r),h.cross(m),i.setXYZ(g+0,h.x,h.y,h.z),i.setXYZ(g+1,h.x,h.y,h.z),i.setXYZ(g+2,h.x,h.y,h.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,i=t.count;e<i;e++)bn.fromBufferAttribute(t,e),bn.normalize(),t.setXYZ(e,bn.x,bn.y,bn.z)}toNonIndexed(){function t(a,l){let c=a.array,h=a.itemSize,m=a.normalized,g=new c.constructor(l.length*h),d=0,p=0;for(let v=0,u=l.length;v<u;v++){a.isInterleavedBufferAttribute?d=l[v]*a.data.stride+a.offset:d=l[v]*h;for(let f=0;f<h;f++)g[p++]=c[d++]}return new Qe(g,h,m)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new n,i=this.index.array,s=this.attributes;for(let a in s){let l=s[a],c=t(l,i);e.setAttribute(a,c)}let r=this.morphAttributes;for(let a in r){let l=[],c=r[a];for(let h=0,m=c.length;h<m;h++){let g=c[h],d=t(g,i);l.push(d)}e.morphAttributes[a]=l}e.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let a=0,l=o.length;a<l;a++){let c=o[a];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){let t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let i=this.attributes;for(let l in i){let c=i[l];t.data.attributes[l]=c.toJSON(t.data)}let s={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],h=[];for(let m=0,g=c.length;m<g;m++){let d=c[m];h.push(d.toJSON(t.data))}h.length>0&&(s[l]=h,r=!0)}r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);let o=this.groups;o.length>0&&(t.data.groups=JSON.parse(JSON.stringify(o)));let a=this.boundingSphere;return a!==null&&(t.data.boundingSphere={center:a.center.toArray(),radius:a.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let i=t.index;i!==null&&this.setIndex(i.clone(e));let s=t.attributes;for(let c in s){let h=s[c];this.setAttribute(c,h.clone(e))}let r=t.morphAttributes;for(let c in r){let h=[],m=r[c];for(let g=0,d=m.length;g<d;g++)h.push(m[g].clone(e));this.morphAttributes[c]=h}this.morphTargetsRelative=t.morphTargetsRelative;let o=t.groups;for(let c=0,h=o.length;c<h;c++){let m=o[c];this.addGroup(m.start,m.count,m.materialIndex)}let a=t.boundingBox;a!==null&&(this.boundingBox=a.clone());let l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},uf=new Fe,as=new ra,Ro=new Ji,df=new V,Co=new V,Io=new V,Po=new V,bl=new V,Lo=new V,pf=new V,ko=new V,We=class extends qe{constructor(t=new Ye,e=new On){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,i=Object.keys(e);if(i.length>0){let s=e[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(t,e){let i=this.geometry,s=i.attributes.position,r=i.morphAttributes.position,o=i.morphTargetsRelative;e.fromBufferAttribute(s,t);let a=this.morphTargetInfluences;if(r&&a){Lo.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let h=a[l],m=r[l];h!==0&&(bl.fromBufferAttribute(m,t),o?Lo.addScaledVector(bl,h):Lo.addScaledVector(bl.sub(e),h))}e.add(Lo)}return e}raycast(t,e){let i=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),Ro.copy(i.boundingSphere),Ro.applyMatrix4(r),as.copy(t.ray).recast(t.near),!(Ro.containsPoint(as.origin)===!1&&(as.intersectSphere(Ro,df)===null||as.origin.distanceToSquared(df)>(t.far-t.near)**2))&&(uf.copy(r).invert(),as.copy(t.ray).applyMatrix4(uf),!(i.boundingBox!==null&&as.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(t,e,as)))}_computeIntersections(t,e,i){let s,r=this.geometry,o=this.material,a=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,m=r.attributes.normal,g=r.groups,d=r.drawRange;if(a!==null)if(Array.isArray(o))for(let p=0,v=g.length;p<v;p++){let u=g[p],f=o[u.materialIndex],S=Math.max(u.start,d.start),y=Math.min(a.count,Math.min(u.start+u.count,d.start+d.count));for(let x=S,L=y;x<L;x+=3){let b=a.getX(x),T=a.getX(x+1),A=a.getX(x+2);s=Do(this,f,t,i,c,h,m,b,T,A),s&&(s.faceIndex=Math.floor(x/3),s.face.materialIndex=u.materialIndex,e.push(s))}}else{let p=Math.max(0,d.start),v=Math.min(a.count,d.start+d.count);for(let u=p,f=v;u<f;u+=3){let S=a.getX(u),y=a.getX(u+1),x=a.getX(u+2);s=Do(this,o,t,i,c,h,m,S,y,x),s&&(s.faceIndex=Math.floor(u/3),e.push(s))}}else if(l!==void 0)if(Array.isArray(o))for(let p=0,v=g.length;p<v;p++){let u=g[p],f=o[u.materialIndex],S=Math.max(u.start,d.start),y=Math.min(l.count,Math.min(u.start+u.count,d.start+d.count));for(let x=S,L=y;x<L;x+=3){let b=x,T=x+1,A=x+2;s=Do(this,f,t,i,c,h,m,b,T,A),s&&(s.faceIndex=Math.floor(x/3),s.face.materialIndex=u.materialIndex,e.push(s))}}else{let p=Math.max(0,d.start),v=Math.min(l.count,d.start+d.count);for(let u=p,f=v;u<f;u+=3){let S=u,y=u+1,x=u+2;s=Do(this,o,t,i,c,h,m,S,y,x),s&&(s.faceIndex=Math.floor(u/3),e.push(s))}}}};function kp(n,t,e,i,s,r,o,a){let l;if(t.side===En?l=i.intersectTriangle(o,r,s,!0,a):l=i.intersectTriangle(s,r,o,t.side===Yi,a),l===null)return null;ko.copy(a),ko.applyMatrix4(n.matrixWorld);let c=e.ray.origin.distanceTo(ko);return c<e.near||c>e.far?null:{distance:c,point:ko.clone(),object:n}}function Do(n,t,e,i,s,r,o,a,l,c){n.getVertexPosition(a,Co),n.getVertexPosition(l,Io),n.getVertexPosition(c,Po);let h=kp(n,t,e,i,Co,Io,Po,pf);if(h){let m=new V;$i.getBarycoord(pf,Co,Io,Po,m),s&&(h.uv=$i.getInterpolatedAttribute(s,a,l,c,m,new Ht)),r&&(h.uv1=$i.getInterpolatedAttribute(r,a,l,c,m,new Ht)),o&&(h.normal=$i.getInterpolatedAttribute(o,a,l,c,m,new V),h.normal.dot(i.direction)>0&&h.normal.multiplyScalar(-1));let g={a,b:l,c,normal:new V,materialIndex:0};$i.getNormal(Co,Io,Po,g.normal),h.face=g,h.barycoord=m}return h}var ze=class n extends Ye{constructor(t=1,e=1,i=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:i,widthSegments:s,heightSegments:r,depthSegments:o};let a=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);let l=[],c=[],h=[],m=[],g=0,d=0;p("z","y","x",-1,-1,i,e,t,o,r,0),p("z","y","x",1,-1,i,e,-t,o,r,1),p("x","z","y",1,1,t,i,e,s,o,2),p("x","z","y",1,-1,t,i,-e,s,o,3),p("x","y","z",1,-1,t,e,i,s,r,4),p("x","y","z",-1,-1,t,e,-i,s,r,5),this.setIndex(l),this.setAttribute("position",new Te(c,3)),this.setAttribute("normal",new Te(h,3)),this.setAttribute("uv",new Te(m,2));function p(v,u,f,S,y,x,L,b,T,A,M){let _=x/T,w=L/A,P=x/2,E=L/2,F=b/2,R=T+1,N=A+1,U=0,z=0,Z=new V;for(let Y=0;Y<N;Y++){let k=Y*w-E;for(let mt=0;mt<R;mt++){let bt=mt*_-P;Z[v]=bt*S,Z[u]=k*y,Z[f]=F,c.push(Z.x,Z.y,Z.z),Z[v]=0,Z[u]=0,Z[f]=b>0?1:-1,h.push(Z.x,Z.y,Z.z),m.push(mt/T),m.push(1-Y/A),U+=1}}for(let Y=0;Y<A;Y++)for(let k=0;k<T;k++){let mt=g+k+R*Y,bt=g+k+R*(Y+1),D=g+(k+1)+R*(Y+1),G=g+(k+1)+R*Y;l.push(mt,bt,G),l.push(bt,D,G),z+=6}a.addGroup(d,z,M),d+=z,g+=U}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function rr(n){let t={};for(let e in n){t[e]={};for(let i in n[e]){let s=n[e][i];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][i]=null):t[e][i]=s.clone():Array.isArray(s)?t[e][i]=s.slice():t[e][i]=s}}return t}function kn(n){let t={};for(let e=0;e<n.length;e++){let i=rr(n[e]);for(let s in i)t[s]=i[s]}return t}function Dp(n){let t=[];for(let e=0;e<n.length;e++)t.push(n[e].clone());return t}function yu(n){let t=n.getRenderTarget();return t===null?n.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Be.workingColorSpace}var ph={clone:rr,merge:kn},Up=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Np=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,Nn=class extends Ii{static get type(){return"ShaderMaterial"}constructor(t){super(),this.isShaderMaterial=!0,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Up,this.fragmentShader=Np,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=rr(t.uniforms),this.uniformsGroups=Dp(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let s in this.uniforms){let o=this.uniforms[s].value;o&&o.isTexture?e.uniforms[s]={type:"t",value:o.toJSON(t).uuid}:o&&o.isColor?e.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?e.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?e.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?e.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?e.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?e.uniforms[s]={type:"m4",value:o.toArray()}:e.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let i={};for(let s in this.extensions)this.extensions[s]===!0&&(i[s]=!0);return Object.keys(i).length>0&&(e.extensions=i),e}},ca=class extends qe{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Fe,this.projectionMatrix=new Fe,this.projectionMatrixInverse=new Fe,this.coordinateSystem=Ei}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},Gi=new V,mf=new Ht,gf=new Ht,Dn=class extends ca{constructor(t=50,e=1,i=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=i,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=Br*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(Dr*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return Br*2*Math.atan(Math.tan(Dr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,i){Gi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(Gi.x,Gi.y).multiplyScalar(-t/Gi.z),Gi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(Gi.x,Gi.y).multiplyScalar(-t/Gi.z)}getViewSize(t,e){return this.getViewBounds(t,mf,gf),e.subVectors(gf,mf)}setViewOffset(t,e,i,s,r,o){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(Dr*.5*this.fov)/this.zoom,i=2*e,s=this.aspect*i,r=-.5*s,o=this.view;if(this.view!==null&&this.view.enabled){let l=o.fullWidth,c=o.fullHeight;r+=o.offsetX*s/l,e-=o.offsetY*i/c,s*=o.width/l,i*=o.height/c}let a=this.filmOffset;a!==0&&(r+=t*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-i,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}},Bs=-90,Hs=1,Ec=class extends qe{constructor(t,e,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;let s=new Dn(Bs,Hs,t,e);s.layers=this.layers,this.add(s);let r=new Dn(Bs,Hs,t,e);r.layers=this.layers,this.add(r);let o=new Dn(Bs,Hs,t,e);o.layers=this.layers,this.add(o);let a=new Dn(Bs,Hs,t,e);a.layers=this.layers,this.add(a);let l=new Dn(Bs,Hs,t,e);l.layers=this.layers,this.add(l);let c=new Dn(Bs,Hs,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[i,s,r,o,a,l]=e;for(let c of e)this.remove(c);if(t===Ei)i.up.set(0,1,0),i.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===ea)i.up.set(0,-1,0),i.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:i,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,o,a,l,c,h]=this.children,m=t.getRenderTarget(),g=t.getActiveCubeFace(),d=t.getActiveMipmapLevel(),p=t.xr.enabled;t.xr.enabled=!1;let v=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,t.setRenderTarget(i,0,s),t.render(e,r),t.setRenderTarget(i,1,s),t.render(e,o),t.setRenderTarget(i,2,s),t.render(e,a),t.setRenderTarget(i,3,s),t.render(e,l),t.setRenderTarget(i,4,s),t.render(e,c),i.texture.generateMipmaps=v,t.setRenderTarget(i,5,s),t.render(e,h),t.setRenderTarget(m,g,d),t.xr.enabled=p,i.texture.needsPMREMUpdate=!0}},ha=class extends Fn{constructor(t,e,i,s,r,o,a,l,c,h){t=t!==void 0?t:[],e=e!==void 0?e:er,super(t,e,i,s,r,o,a,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},Tc=class extends Ri{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let i={width:t,height:t,depth:1},s=[i,i,i,i,i,i];this.texture=new ha(s,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:ui}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new ze(5,5,5),r=new Nn({name:"CubemapFromEquirect",uniforms:rr(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:En,blending:Xi});r.uniforms.tEquirect.value=e;let o=new We(s,r),a=e.minFilter;return e.minFilter===ms&&(e.minFilter=ui),new Ec(1,10,this).update(t,o),e.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(t,e,i,s){let r=t.getRenderTarget();for(let o=0;o<6;o++)t.setRenderTarget(this,o),t.clear(e,i,s);t.setRenderTarget(r)}},Sl=new V,Fp=new V,Op=new De,wi=class{constructor(t=new V(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,i,s){return this.normal.set(t,e,i),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,i){let s=Sl.subVectors(i,e).cross(Fp.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){let i=t.delta(Sl),s=this.normal.dot(i);if(s===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let r=-(t.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:e.copy(t.start).addScaledVector(i,r)}intersectsLine(t){let e=this.distanceToPoint(t.start),i=this.distanceToPoint(t.end);return e<0&&i>0||i<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let i=e||Op.getNormalMatrix(t),s=this.coplanarPoint(Sl).applyMatrix4(t),r=this.normal.applyMatrix3(i).normalize();return this.constant=-s.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}},ls=new Ji,Uo=new V,Hr=class{constructor(t=new wi,e=new wi,i=new wi,s=new wi,r=new wi,o=new wi){this.planes=[t,e,i,s,r,o]}set(t,e,i,s,r,o){let a=this.planes;return a[0].copy(t),a[1].copy(e),a[2].copy(i),a[3].copy(s),a[4].copy(r),a[5].copy(o),this}copy(t){let e=this.planes;for(let i=0;i<6;i++)e[i].copy(t.planes[i]);return this}setFromProjectionMatrix(t,e=Ei){let i=this.planes,s=t.elements,r=s[0],o=s[1],a=s[2],l=s[3],c=s[4],h=s[5],m=s[6],g=s[7],d=s[8],p=s[9],v=s[10],u=s[11],f=s[12],S=s[13],y=s[14],x=s[15];if(i[0].setComponents(l-r,g-c,u-d,x-f).normalize(),i[1].setComponents(l+r,g+c,u+d,x+f).normalize(),i[2].setComponents(l+o,g+h,u+p,x+S).normalize(),i[3].setComponents(l-o,g-h,u-p,x-S).normalize(),i[4].setComponents(l-a,g-m,u-v,x-y).normalize(),e===Ei)i[5].setComponents(l+a,g+m,u+v,x+y).normalize();else if(e===ea)i[5].setComponents(a,m,v,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),ls.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),ls.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(ls)}intersectsSprite(t){return ls.center.set(0,0,0),ls.radius=.7071067811865476,ls.applyMatrix4(t.matrixWorld),this.intersectsSphere(ls)}intersectsSphere(t){let e=this.planes,i=t.center,s=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(i)<s)return!1;return!0}intersectsBox(t){let e=this.planes;for(let i=0;i<6;i++){let s=e[i];if(Uo.x=s.normal.x>0?t.max.x:t.min.x,Uo.y=s.normal.y>0?t.max.y:t.min.y,Uo.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(Uo)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let i=0;i<6;i++)if(e[i].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function vu(){let n=null,t=!1,e=null,i=null;function s(r,o){e(r,o),i=n.requestAnimationFrame(s)}return{start:function(){t!==!0&&e!==null&&(i=n.requestAnimationFrame(s),t=!0)},stop:function(){n.cancelAnimationFrame(i),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){n=r}}}function zp(n){let t=new WeakMap;function e(a,l){let c=a.array,h=a.usage,m=c.byteLength,g=n.createBuffer();n.bindBuffer(l,g),n.bufferData(l,c,h),a.onUploadCallback();let d;if(c instanceof Float32Array)d=n.FLOAT;else if(c instanceof Uint16Array)a.isFloat16BufferAttribute?d=n.HALF_FLOAT:d=n.UNSIGNED_SHORT;else if(c instanceof Int16Array)d=n.SHORT;else if(c instanceof Uint32Array)d=n.UNSIGNED_INT;else if(c instanceof Int32Array)d=n.INT;else if(c instanceof Int8Array)d=n.BYTE;else if(c instanceof Uint8Array)d=n.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)d=n.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:g,type:d,bytesPerElement:c.BYTES_PER_ELEMENT,version:a.version,size:m}}function i(a,l,c){let h=l.array,m=l.updateRanges;if(n.bindBuffer(c,a),m.length===0)n.bufferSubData(c,0,h);else{m.sort((d,p)=>d.start-p.start);let g=0;for(let d=1;d<m.length;d++){let p=m[g],v=m[d];v.start<=p.start+p.count+1?p.count=Math.max(p.count,v.start+v.count-p.start):(++g,m[g]=v)}m.length=g+1;for(let d=0,p=m.length;d<p;d++){let v=m[d];n.bufferSubData(c,v.start*h.BYTES_PER_ELEMENT,h,v.start,v.count)}l.clearUpdateRanges()}l.onUploadCallback()}function s(a){return a.isInterleavedBufferAttribute&&(a=a.data),t.get(a)}function r(a){a.isInterleavedBufferAttribute&&(a=a.data);let l=t.get(a);l&&(n.deleteBuffer(l.buffer),t.delete(a))}function o(a,l){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){let h=t.get(a);(!h||h.version<a.version)&&t.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}let c=t.get(a);if(c===void 0)t.set(a,e(a,l));else if(c.version<a.version){if(c.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");i(c.buffer,a,l),c.version=a.version}}return{get:s,remove:r,update:o}}var Tn=class n extends Ye{constructor(t=1,e=1,i=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:i,heightSegments:s};let r=t/2,o=e/2,a=Math.floor(i),l=Math.floor(s),c=a+1,h=l+1,m=t/a,g=e/l,d=[],p=[],v=[],u=[];for(let f=0;f<h;f++){let S=f*g-o;for(let y=0;y<c;y++){let x=y*m-r;p.push(x,-S,0),v.push(0,0,1),u.push(y/a),u.push(1-f/l)}}for(let f=0;f<l;f++)for(let S=0;S<a;S++){let y=S+c*f,x=S+c*(f+1),L=S+1+c*(f+1),b=S+1+c*f;d.push(y,x,b),d.push(x,L,b)}this.setIndex(d),this.setAttribute("position",new Te(p,3)),this.setAttribute("normal",new Te(v,3)),this.setAttribute("uv",new Te(u,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.width,t.height,t.widthSegments,t.heightSegments)}},Bp=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Hp=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Vp=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Gp=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Wp=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,$p=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Xp=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,qp=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Yp=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Zp=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Jp=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Kp=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,jp=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Qp=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,tm=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,em=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,nm=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,im=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,sm=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,rm=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,om=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,am=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,lm=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,cm=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,hm=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,fm=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,um=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,dm=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,pm=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,mm=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,gm="gl_FragColor = linearToOutputTexel( gl_FragColor );",ym=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,vm=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,xm=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,_m=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Mm=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,bm=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Sm=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,wm=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Em=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Tm=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Am=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Rm=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Cm=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Im=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Pm=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,Lm=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,km=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Dm=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Um=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Nm=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Fm=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Om=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,zm=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Bm=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Hm=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Vm=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Gm=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Wm=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,$m=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Xm=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,qm=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Ym=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Zm=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Jm=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Km=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,jm=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Qm=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,t0=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,e0=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,n0=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,i0=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,s0=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,r0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,o0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,a0=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,l0=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,c0=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,h0=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,f0=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,u0=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,d0=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,p0=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,m0=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,g0=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,y0=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,v0=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,x0=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,_0=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,M0=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,b0=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,S0=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,w0=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,E0=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,T0=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,A0=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,R0=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,C0=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,I0=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,P0=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,L0=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,k0=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,D0=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,U0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,N0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,F0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,O0=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,z0=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,B0=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,H0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,V0=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,G0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,W0=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,$0=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,X0=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,q0=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Y0=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Z0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,J0=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,K0=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,j0=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Q0=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,tg=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,eg=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ng=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ig=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,sg=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,rg=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,og=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,ag=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,lg=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,cg=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,hg=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,fg=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ug=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,dg=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,pg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,mg=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,gg=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,yg=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,vg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ce={alphahash_fragment:Bp,alphahash_pars_fragment:Hp,alphamap_fragment:Vp,alphamap_pars_fragment:Gp,alphatest_fragment:Wp,alphatest_pars_fragment:$p,aomap_fragment:Xp,aomap_pars_fragment:qp,batching_pars_vertex:Yp,batching_vertex:Zp,begin_vertex:Jp,beginnormal_vertex:Kp,bsdfs:jp,iridescence_fragment:Qp,bumpmap_pars_fragment:tm,clipping_planes_fragment:em,clipping_planes_pars_fragment:nm,clipping_planes_pars_vertex:im,clipping_planes_vertex:sm,color_fragment:rm,color_pars_fragment:om,color_pars_vertex:am,color_vertex:lm,common:cm,cube_uv_reflection_fragment:hm,defaultnormal_vertex:fm,displacementmap_pars_vertex:um,displacementmap_vertex:dm,emissivemap_fragment:pm,emissivemap_pars_fragment:mm,colorspace_fragment:gm,colorspace_pars_fragment:ym,envmap_fragment:vm,envmap_common_pars_fragment:xm,envmap_pars_fragment:_m,envmap_pars_vertex:Mm,envmap_physical_pars_fragment:Lm,envmap_vertex:bm,fog_vertex:Sm,fog_pars_vertex:wm,fog_fragment:Em,fog_pars_fragment:Tm,gradientmap_pars_fragment:Am,lightmap_pars_fragment:Rm,lights_lambert_fragment:Cm,lights_lambert_pars_fragment:Im,lights_pars_begin:Pm,lights_toon_fragment:km,lights_toon_pars_fragment:Dm,lights_phong_fragment:Um,lights_phong_pars_fragment:Nm,lights_physical_fragment:Fm,lights_physical_pars_fragment:Om,lights_fragment_begin:zm,lights_fragment_maps:Bm,lights_fragment_end:Hm,logdepthbuf_fragment:Vm,logdepthbuf_pars_fragment:Gm,logdepthbuf_pars_vertex:Wm,logdepthbuf_vertex:$m,map_fragment:Xm,map_pars_fragment:qm,map_particle_fragment:Ym,map_particle_pars_fragment:Zm,metalnessmap_fragment:Jm,metalnessmap_pars_fragment:Km,morphinstance_vertex:jm,morphcolor_vertex:Qm,morphnormal_vertex:t0,morphtarget_pars_vertex:e0,morphtarget_vertex:n0,normal_fragment_begin:i0,normal_fragment_maps:s0,normal_pars_fragment:r0,normal_pars_vertex:o0,normal_vertex:a0,normalmap_pars_fragment:l0,clearcoat_normal_fragment_begin:c0,clearcoat_normal_fragment_maps:h0,clearcoat_pars_fragment:f0,iridescence_pars_fragment:u0,opaque_fragment:d0,packing:p0,premultiplied_alpha_fragment:m0,project_vertex:g0,dithering_fragment:y0,dithering_pars_fragment:v0,roughnessmap_fragment:x0,roughnessmap_pars_fragment:_0,shadowmap_pars_fragment:M0,shadowmap_pars_vertex:b0,shadowmap_vertex:S0,shadowmask_pars_fragment:w0,skinbase_vertex:E0,skinning_pars_vertex:T0,skinning_vertex:A0,skinnormal_vertex:R0,specularmap_fragment:C0,specularmap_pars_fragment:I0,tonemapping_fragment:P0,tonemapping_pars_fragment:L0,transmission_fragment:k0,transmission_pars_fragment:D0,uv_pars_fragment:U0,uv_pars_vertex:N0,uv_vertex:F0,worldpos_vertex:O0,background_vert:z0,background_frag:B0,backgroundCube_vert:H0,backgroundCube_frag:V0,cube_vert:G0,cube_frag:W0,depth_vert:$0,depth_frag:X0,distanceRGBA_vert:q0,distanceRGBA_frag:Y0,equirect_vert:Z0,equirect_frag:J0,linedashed_vert:K0,linedashed_frag:j0,meshbasic_vert:Q0,meshbasic_frag:tg,meshlambert_vert:eg,meshlambert_frag:ng,meshmatcap_vert:ig,meshmatcap_frag:sg,meshnormal_vert:rg,meshnormal_frag:og,meshphong_vert:ag,meshphong_frag:lg,meshphysical_vert:cg,meshphysical_frag:hg,meshtoon_vert:fg,meshtoon_frag:ug,points_vert:dg,points_frag:pg,shadow_vert:mg,shadow_frag:gg,sprite_vert:yg,sprite_frag:vg},te={common:{diffuse:{value:new fe(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new De},alphaMap:{value:null},alphaMapTransform:{value:new De},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new De}},envmap:{envMap:{value:null},envMapRotation:{value:new De},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new De}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new De}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new De},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new De},normalScale:{value:new Ht(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new De},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new De}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new De}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new De}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new fe(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new fe(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new De},alphaTest:{value:0},uvTransform:{value:new De}},sprite:{diffuse:{value:new fe(16777215)},opacity:{value:1},center:{value:new Ht(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new De},alphaMap:{value:null},alphaMapTransform:{value:new De},alphaTest:{value:0}}},fi={basic:{uniforms:kn([te.common,te.specularmap,te.envmap,te.aomap,te.lightmap,te.fog]),vertexShader:Ce.meshbasic_vert,fragmentShader:Ce.meshbasic_frag},lambert:{uniforms:kn([te.common,te.specularmap,te.envmap,te.aomap,te.lightmap,te.emissivemap,te.bumpmap,te.normalmap,te.displacementmap,te.fog,te.lights,{emissive:{value:new fe(0)}}]),vertexShader:Ce.meshlambert_vert,fragmentShader:Ce.meshlambert_frag},phong:{uniforms:kn([te.common,te.specularmap,te.envmap,te.aomap,te.lightmap,te.emissivemap,te.bumpmap,te.normalmap,te.displacementmap,te.fog,te.lights,{emissive:{value:new fe(0)},specular:{value:new fe(1118481)},shininess:{value:30}}]),vertexShader:Ce.meshphong_vert,fragmentShader:Ce.meshphong_frag},standard:{uniforms:kn([te.common,te.envmap,te.aomap,te.lightmap,te.emissivemap,te.bumpmap,te.normalmap,te.displacementmap,te.roughnessmap,te.metalnessmap,te.fog,te.lights,{emissive:{value:new fe(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ce.meshphysical_vert,fragmentShader:Ce.meshphysical_frag},toon:{uniforms:kn([te.common,te.aomap,te.lightmap,te.emissivemap,te.bumpmap,te.normalmap,te.displacementmap,te.gradientmap,te.fog,te.lights,{emissive:{value:new fe(0)}}]),vertexShader:Ce.meshtoon_vert,fragmentShader:Ce.meshtoon_frag},matcap:{uniforms:kn([te.common,te.bumpmap,te.normalmap,te.displacementmap,te.fog,{matcap:{value:null}}]),vertexShader:Ce.meshmatcap_vert,fragmentShader:Ce.meshmatcap_frag},points:{uniforms:kn([te.points,te.fog]),vertexShader:Ce.points_vert,fragmentShader:Ce.points_frag},dashed:{uniforms:kn([te.common,te.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ce.linedashed_vert,fragmentShader:Ce.linedashed_frag},depth:{uniforms:kn([te.common,te.displacementmap]),vertexShader:Ce.depth_vert,fragmentShader:Ce.depth_frag},normal:{uniforms:kn([te.common,te.bumpmap,te.normalmap,te.displacementmap,{opacity:{value:1}}]),vertexShader:Ce.meshnormal_vert,fragmentShader:Ce.meshnormal_frag},sprite:{uniforms:kn([te.sprite,te.fog]),vertexShader:Ce.sprite_vert,fragmentShader:Ce.sprite_frag},background:{uniforms:{uvTransform:{value:new De},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ce.background_vert,fragmentShader:Ce.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new De}},vertexShader:Ce.backgroundCube_vert,fragmentShader:Ce.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ce.cube_vert,fragmentShader:Ce.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ce.equirect_vert,fragmentShader:Ce.equirect_frag},distanceRGBA:{uniforms:kn([te.common,te.displacementmap,{referencePosition:{value:new V},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ce.distanceRGBA_vert,fragmentShader:Ce.distanceRGBA_frag},shadow:{uniforms:kn([te.lights,te.fog,{color:{value:new fe(0)},opacity:{value:1}}]),vertexShader:Ce.shadow_vert,fragmentShader:Ce.shadow_frag}};fi.physical={uniforms:kn([fi.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new De},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new De},clearcoatNormalScale:{value:new Ht(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new De},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new De},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new De},sheen:{value:0},sheenColor:{value:new fe(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new De},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new De},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new De},transmissionSamplerSize:{value:new Ht},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new De},attenuationDistance:{value:0},attenuationColor:{value:new fe(0)},specularColor:{value:new fe(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new De},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new De},anisotropyVector:{value:new Ht},anisotropyMap:{value:null},anisotropyMapTransform:{value:new De}}]),vertexShader:Ce.meshphysical_vert,fragmentShader:Ce.meshphysical_frag};var No={r:0,b:0,g:0},cs=new ii,xg=new Fe;function _g(n,t,e,i,s,r,o){let a=new fe(0),l=r===!0?0:1,c,h,m=null,g=0,d=null;function p(S){let y=S.isScene===!0?S.background:null;return y&&y.isTexture&&(y=(S.backgroundBlurriness>0?e:t).get(y)),y}function v(S){let y=!1,x=p(S);x===null?f(a,l):x&&x.isColor&&(f(x,1),y=!0);let L=n.xr.getEnvironmentBlendMode();L==="additive"?i.buffers.color.setClear(0,0,0,1,o):L==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,o),(n.autoClear||y)&&(i.buffers.depth.setTest(!0),i.buffers.depth.setMask(!0),i.buffers.color.setMask(!0),n.clear(n.autoClearColor,n.autoClearDepth,n.autoClearStencil))}function u(S,y){let x=p(y);x&&(x.isCubeTexture||x.mapping===Ua)?(h===void 0&&(h=new We(new ze(1,1,1),new Nn({name:"BackgroundCubeMaterial",uniforms:rr(fi.backgroundCube.uniforms),vertexShader:fi.backgroundCube.vertexShader,fragmentShader:fi.backgroundCube.fragmentShader,side:En,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(L,b,T){this.matrixWorld.copyPosition(T.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),cs.copy(y.backgroundRotation),cs.x*=-1,cs.y*=-1,cs.z*=-1,x.isCubeTexture&&x.isRenderTargetTexture===!1&&(cs.y*=-1,cs.z*=-1),h.material.uniforms.envMap.value=x,h.material.uniforms.flipEnvMap.value=x.isCubeTexture&&x.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=y.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=y.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(xg.makeRotationFromEuler(cs)),h.material.toneMapped=Be.getTransfer(x.colorSpace)!==Xe,(m!==x||g!==x.version||d!==n.toneMapping)&&(h.material.needsUpdate=!0,m=x,g=x.version,d=n.toneMapping),h.layers.enableAll(),S.unshift(h,h.geometry,h.material,0,0,null)):x&&x.isTexture&&(c===void 0&&(c=new We(new Tn(2,2),new Nn({name:"BackgroundMaterial",uniforms:rr(fi.background.uniforms),vertexShader:fi.background.vertexShader,fragmentShader:fi.background.fragmentShader,side:Yi,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(c)),c.material.uniforms.t2D.value=x,c.material.uniforms.backgroundIntensity.value=y.backgroundIntensity,c.material.toneMapped=Be.getTransfer(x.colorSpace)!==Xe,x.matrixAutoUpdate===!0&&x.updateMatrix(),c.material.uniforms.uvTransform.value.copy(x.matrix),(m!==x||g!==x.version||d!==n.toneMapping)&&(c.material.needsUpdate=!0,m=x,g=x.version,d=n.toneMapping),c.layers.enableAll(),S.unshift(c,c.geometry,c.material,0,0,null))}function f(S,y){S.getRGB(No,yu(n)),i.buffers.color.setClear(No.r,No.g,No.b,y,o)}return{getClearColor:function(){return a},setClearColor:function(S,y=1){a.set(S),l=y,f(a,l)},getClearAlpha:function(){return l},setClearAlpha:function(S){l=S,f(a,l)},render:v,addToRenderList:u}}function Mg(n,t){let e=n.getParameter(n.MAX_VERTEX_ATTRIBS),i={},s=g(null),r=s,o=!1;function a(_,w,P,E,F){let R=!1,N=m(E,P,w);r!==N&&(r=N,c(r.object)),R=d(_,E,P,F),R&&p(_,E,P,F),F!==null&&t.update(F,n.ELEMENT_ARRAY_BUFFER),(R||o)&&(o=!1,x(_,w,P,E),F!==null&&n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,t.get(F).buffer))}function l(){return n.createVertexArray()}function c(_){return n.bindVertexArray(_)}function h(_){return n.deleteVertexArray(_)}function m(_,w,P){let E=P.wireframe===!0,F=i[_.id];F===void 0&&(F={},i[_.id]=F);let R=F[w.id];R===void 0&&(R={},F[w.id]=R);let N=R[E];return N===void 0&&(N=g(l()),R[E]=N),N}function g(_){let w=[],P=[],E=[];for(let F=0;F<e;F++)w[F]=0,P[F]=0,E[F]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:w,enabledAttributes:P,attributeDivisors:E,object:_,attributes:{},index:null}}function d(_,w,P,E){let F=r.attributes,R=w.attributes,N=0,U=P.getAttributes();for(let z in U)if(U[z].location>=0){let Y=F[z],k=R[z];if(k===void 0&&(z==="instanceMatrix"&&_.instanceMatrix&&(k=_.instanceMatrix),z==="instanceColor"&&_.instanceColor&&(k=_.instanceColor)),Y===void 0||Y.attribute!==k||k&&Y.data!==k.data)return!0;N++}return r.attributesNum!==N||r.index!==E}function p(_,w,P,E){let F={},R=w.attributes,N=0,U=P.getAttributes();for(let z in U)if(U[z].location>=0){let Y=R[z];Y===void 0&&(z==="instanceMatrix"&&_.instanceMatrix&&(Y=_.instanceMatrix),z==="instanceColor"&&_.instanceColor&&(Y=_.instanceColor));let k={};k.attribute=Y,Y&&Y.data&&(k.data=Y.data),F[z]=k,N++}r.attributes=F,r.attributesNum=N,r.index=E}function v(){let _=r.newAttributes;for(let w=0,P=_.length;w<P;w++)_[w]=0}function u(_){f(_,0)}function f(_,w){let P=r.newAttributes,E=r.enabledAttributes,F=r.attributeDivisors;P[_]=1,E[_]===0&&(n.enableVertexAttribArray(_),E[_]=1),F[_]!==w&&(n.vertexAttribDivisor(_,w),F[_]=w)}function S(){let _=r.newAttributes,w=r.enabledAttributes;for(let P=0,E=w.length;P<E;P++)w[P]!==_[P]&&(n.disableVertexAttribArray(P),w[P]=0)}function y(_,w,P,E,F,R,N){N===!0?n.vertexAttribIPointer(_,w,P,F,R):n.vertexAttribPointer(_,w,P,E,F,R)}function x(_,w,P,E){v();let F=E.attributes,R=P.getAttributes(),N=w.defaultAttributeValues;for(let U in R){let z=R[U];if(z.location>=0){let Z=F[U];if(Z===void 0&&(U==="instanceMatrix"&&_.instanceMatrix&&(Z=_.instanceMatrix),U==="instanceColor"&&_.instanceColor&&(Z=_.instanceColor)),Z!==void 0){let Y=Z.normalized,k=Z.itemSize,mt=t.get(Z);if(mt===void 0)continue;let bt=mt.buffer,D=mt.type,G=mt.bytesPerElement,q=D===n.INT||D===n.UNSIGNED_INT||Z.gpuType===oh;if(Z.isInterleavedBufferAttribute){let W=Z.data,J=W.stride,it=Z.offset;if(W.isInstancedInterleavedBuffer){for(let Mt=0;Mt<z.locationSize;Mt++)f(z.location+Mt,W.meshPerAttribute);_.isInstancedMesh!==!0&&E._maxInstanceCount===void 0&&(E._maxInstanceCount=W.meshPerAttribute*W.count)}else for(let Mt=0;Mt<z.locationSize;Mt++)u(z.location+Mt);n.bindBuffer(n.ARRAY_BUFFER,bt);for(let Mt=0;Mt<z.locationSize;Mt++)y(z.location+Mt,k/z.locationSize,D,Y,J*G,(it+k/z.locationSize*Mt)*G,q)}else{if(Z.isInstancedBufferAttribute){for(let W=0;W<z.locationSize;W++)f(z.location+W,Z.meshPerAttribute);_.isInstancedMesh!==!0&&E._maxInstanceCount===void 0&&(E._maxInstanceCount=Z.meshPerAttribute*Z.count)}else for(let W=0;W<z.locationSize;W++)u(z.location+W);n.bindBuffer(n.ARRAY_BUFFER,bt);for(let W=0;W<z.locationSize;W++)y(z.location+W,k/z.locationSize,D,Y,k*G,k/z.locationSize*W*G,q)}}else if(N!==void 0){let Y=N[U];if(Y!==void 0)switch(Y.length){case 2:n.vertexAttrib2fv(z.location,Y);break;case 3:n.vertexAttrib3fv(z.location,Y);break;case 4:n.vertexAttrib4fv(z.location,Y);break;default:n.vertexAttrib1fv(z.location,Y)}}}}S()}function L(){A();for(let _ in i){let w=i[_];for(let P in w){let E=w[P];for(let F in E)h(E[F].object),delete E[F];delete w[P]}delete i[_]}}function b(_){if(i[_.id]===void 0)return;let w=i[_.id];for(let P in w){let E=w[P];for(let F in E)h(E[F].object),delete E[F];delete w[P]}delete i[_.id]}function T(_){for(let w in i){let P=i[w];if(P[_.id]===void 0)continue;let E=P[_.id];for(let F in E)h(E[F].object),delete E[F];delete P[_.id]}}function A(){M(),o=!0,r!==s&&(r=s,c(r.object))}function M(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:a,reset:A,resetDefaultState:M,dispose:L,releaseStatesOfGeometry:b,releaseStatesOfProgram:T,initAttributes:v,enableAttribute:u,disableUnusedAttributes:S}}function bg(n,t,e){let i;function s(c){i=c}function r(c,h){n.drawArrays(i,c,h),e.update(h,i,1)}function o(c,h,m){m!==0&&(n.drawArraysInstanced(i,c,h,m),e.update(h,i,m))}function a(c,h,m){if(m===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(i,c,0,h,0,m);let d=0;for(let p=0;p<m;p++)d+=h[p];e.update(d,i,1)}function l(c,h,m,g){if(m===0)return;let d=t.get("WEBGL_multi_draw");if(d===null)for(let p=0;p<c.length;p++)o(c[p],h[p],g[p]);else{d.multiDrawArraysInstancedWEBGL(i,c,0,h,0,g,0,m);let p=0;for(let v=0;v<m;v++)p+=h[v]*g[v];e.update(p,i,1)}}this.setMode=s,this.render=r,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=l}function Sg(n,t,e,i){let s;function r(){if(s!==void 0)return s;if(t.has("EXT_texture_filter_anisotropic")===!0){let T=t.get("EXT_texture_filter_anisotropic");s=n.getParameter(T.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function o(T){return!(T!==Wn&&i.convert(T)!==n.getParameter(n.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(T){let A=T===Qr&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(T!==Ai&&i.convert(T)!==n.getParameter(n.IMPLEMENTATION_COLOR_READ_TYPE)&&T!==di&&!A)}function l(T){if(T==="highp"){if(n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.HIGH_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.HIGH_FLOAT).precision>0)return"highp";T="mediump"}return T==="mediump"&&n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.MEDIUM_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=e.precision!==void 0?e.precision:"highp",h=l(c);h!==c&&(console.warn("THREE.WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);let m=e.logarithmicDepthBuffer===!0,g=e.reverseDepthBuffer===!0&&t.has("EXT_clip_control"),d=n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS),p=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS),v=n.getParameter(n.MAX_TEXTURE_SIZE),u=n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE),f=n.getParameter(n.MAX_VERTEX_ATTRIBS),S=n.getParameter(n.MAX_VERTEX_UNIFORM_VECTORS),y=n.getParameter(n.MAX_VARYING_VECTORS),x=n.getParameter(n.MAX_FRAGMENT_UNIFORM_VECTORS),L=p>0,b=n.getParameter(n.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:l,textureFormatReadable:o,textureTypeReadable:a,precision:c,logarithmicDepthBuffer:m,reverseDepthBuffer:g,maxTextures:d,maxVertexTextures:p,maxTextureSize:v,maxCubemapSize:u,maxAttributes:f,maxVertexUniforms:S,maxVaryings:y,maxFragmentUniforms:x,vertexTextures:L,maxSamples:b}}function wg(n){let t=this,e=null,i=0,s=!1,r=!1,o=new wi,a=new De,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(m,g){let d=m.length!==0||g||i!==0||s;return s=g,i=m.length,d},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(m,g){e=h(m,g,0)},this.setState=function(m,g,d){let p=m.clippingPlanes,v=m.clipIntersection,u=m.clipShadows,f=n.get(m);if(!s||p===null||p.length===0||r&&!u)r?h(null):c();else{let S=r?0:i,y=S*4,x=f.clippingState||null;l.value=x,x=h(p,g,y,d);for(let L=0;L!==y;++L)x[L]=e[L];f.clippingState=x,this.numIntersection=v?this.numPlanes:0,this.numPlanes+=S}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=i>0),t.numPlanes=i,t.numIntersection=0}function h(m,g,d,p){let v=m!==null?m.length:0,u=null;if(v!==0){if(u=l.value,p!==!0||u===null){let f=d+v*4,S=g.matrixWorldInverse;a.getNormalMatrix(S),(u===null||u.length<f)&&(u=new Float32Array(f));for(let y=0,x=d;y!==v;++y,x+=4)o.copy(m[y]).applyMatrix4(S,a),o.normal.toArray(u,x),u[x+3]=o.constant}l.value=u,l.needsUpdate=!0}return t.numPlanes=v,t.numIntersection=0,u}}function Eg(n){let t=new WeakMap;function e(o,a){return a===$l?o.mapping=er:a===Xl&&(o.mapping=nr),o}function i(o){if(o&&o.isTexture){let a=o.mapping;if(a===$l||a===Xl)if(t.has(o)){let l=t.get(o).texture;return e(l,o.mapping)}else{let l=o.image;if(l&&l.height>0){let c=new Tc(l.height);return c.fromEquirectangularTexture(n,o),t.set(o,c),o.addEventListener("dispose",s),e(c.texture,o.mapping)}else return null}}return o}function s(o){let a=o.target;a.removeEventListener("dispose",s);let l=t.get(a);l!==void 0&&(t.delete(a),l.dispose())}function r(){t=new WeakMap}return{get:i,dispose:r}}var fa=class extends ca{constructor(t=-1,e=1,i=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=i,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,i,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=i-t,o=i+t,a=s+e,l=s-e;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,o=r+c*this.view.width,a-=h*this.view.offsetY,l=a-h*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},Ys=4,yf=[.125,.215,.35,.446,.526,.582],ds=20,wl=new fa,vf=new fe,El=null,Tl=0,Al=0,Rl=!1,fs=(1+Math.sqrt(5))/2,Vs=1/fs,xf=[new V(-fs,Vs,0),new V(fs,Vs,0),new V(-Vs,0,fs),new V(Vs,0,fs),new V(0,fs,-Vs),new V(0,fs,Vs),new V(-1,1,-1),new V(1,1,-1),new V(-1,1,1),new V(1,1,1)],ua=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,i=.1,s=100){El=this._renderer.getRenderTarget(),Tl=this._renderer.getActiveCubeFace(),Al=this._renderer.getActiveMipmapLevel(),Rl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(t,i,s,r),e>0&&this._blur(r,0,0,e),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=bf(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Mf(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(El,Tl,Al),this._renderer.xr.enabled=Rl,t.scissorTest=!1,Fo(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===er||t.mapping===nr?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),El=this._renderer.getRenderTarget(),Tl=this._renderer.getActiveCubeFace(),Al=this._renderer.getActiveMipmapLevel(),Rl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let i=e||this._allocateTargets();return this._textureToCubeUV(t,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,i={magFilter:ui,minFilter:ui,generateMipmaps:!1,type:Qr,format:Wn,colorSpace:hr,depthBuffer:!1},s=_f(t,e,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=_f(t,e,i);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Tg(r)),this._blurMaterial=Ag(r,t,e)}return s}_compileMaterial(t){let e=new We(this._lodPlanes[0],t);this._renderer.compile(e,wl)}_sceneToCubeUV(t,e,i,s){let a=new Dn(90,1,e,i),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],h=this._renderer,m=h.autoClear,g=h.toneMapping;h.getClearColor(vf),h.toneMapping=pi,h.autoClear=!1;let d=new On({name:"PMREM.Background",side:En,depthWrite:!1,depthTest:!1}),p=new We(new ze,d),v=!1,u=t.background;u?u.isColor&&(d.color.copy(u),t.background=null,v=!0):(d.color.copy(vf),v=!0);for(let f=0;f<6;f++){let S=f%3;S===0?(a.up.set(0,l[f],0),a.lookAt(c[f],0,0)):S===1?(a.up.set(0,0,l[f]),a.lookAt(0,c[f],0)):(a.up.set(0,l[f],0),a.lookAt(0,0,c[f]));let y=this._cubeSize;Fo(s,S*y,f>2?y:0,y,y),h.setRenderTarget(s),v&&h.render(p,a),h.render(t,a)}p.geometry.dispose(),p.material.dispose(),h.toneMapping=g,h.autoClear=m,t.background=u}_textureToCubeUV(t,e){let i=this._renderer,s=t.mapping===er||t.mapping===nr;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=bf()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Mf());let r=s?this._cubemapMaterial:this._equirectMaterial,o=new We(this._lodPlanes[0],r),a=r.uniforms;a.envMap.value=t;let l=this._cubeSize;Fo(e,0,0,3*l,2*l),i.setRenderTarget(e),i.render(o,wl)}_applyPMREM(t){let e=this._renderer,i=e.autoClear;e.autoClear=!1;let s=this._lodPlanes.length;for(let r=1;r<s;r++){let o=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),a=xf[(s-r-1)%xf.length];this._blur(t,r-1,r,o,a)}e.autoClear=i}_blur(t,e,i,s,r){let o=this._pingPongRenderTarget;this._halfBlur(t,o,e,i,s,"latitudinal",r),this._halfBlur(o,t,i,i,s,"longitudinal",r)}_halfBlur(t,e,i,s,r,o,a){let l=this._renderer,c=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=3,m=new We(this._lodPlanes[s],c),g=c.uniforms,d=this._sizeLods[i]-1,p=isFinite(r)?Math.PI/(2*d):2*Math.PI/(2*ds-1),v=r/p,u=isFinite(r)?1+Math.floor(h*v):ds;u>ds&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${u} samples when the maximum is set to ${ds}`);let f=[],S=0;for(let T=0;T<ds;++T){let A=T/v,M=Math.exp(-A*A/2);f.push(M),T===0?S+=M:T<u&&(S+=2*M)}for(let T=0;T<f.length;T++)f[T]=f[T]/S;g.envMap.value=t.texture,g.samples.value=u,g.weights.value=f,g.latitudinal.value=o==="latitudinal",a&&(g.poleAxis.value=a);let{_lodMax:y}=this;g.dTheta.value=p,g.mipInt.value=y-i;let x=this._sizeLods[s],L=3*x*(s>y-Ys?s-y+Ys:0),b=4*(this._cubeSize-x);Fo(e,L,b,3*x,2*x),l.setRenderTarget(e),l.render(m,wl)}};function Tg(n){let t=[],e=[],i=[],s=n,r=n-Ys+1+yf.length;for(let o=0;o<r;o++){let a=Math.pow(2,s);e.push(a);let l=1/a;o>n-Ys?l=yf[o-n+Ys-1]:o===0&&(l=0),i.push(l);let c=1/(a-2),h=-c,m=1+c,g=[h,h,m,h,m,m,h,h,m,m,h,m],d=6,p=6,v=3,u=2,f=1,S=new Float32Array(v*p*d),y=new Float32Array(u*p*d),x=new Float32Array(f*p*d);for(let b=0;b<d;b++){let T=b%3*2/3-1,A=b>2?0:-1,M=[T,A,0,T+2/3,A,0,T+2/3,A+1,0,T,A,0,T+2/3,A+1,0,T,A+1,0];S.set(M,v*p*b),y.set(g,u*p*b);let _=[b,b,b,b,b,b];x.set(_,f*p*b)}let L=new Ye;L.setAttribute("position",new Qe(S,v)),L.setAttribute("uv",new Qe(y,u)),L.setAttribute("faceIndex",new Qe(x,f)),t.push(L),s>Ys&&s--}return{lodPlanes:t,sizeLods:e,sigmas:i}}function _f(n,t,e){let i=new Ri(n,t,e);return i.texture.mapping=Ua,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function Fo(n,t,e,i,s){n.viewport.set(t,e,i,s),n.scissor.set(t,e,i,s)}function Ag(n,t,e){let i=new Float32Array(ds),s=new V(0,1,0);return new Nn({name:"SphericalGaussianBlur",defines:{n:ds,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:mh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Xi,depthTest:!1,depthWrite:!1})}function Mf(){return new Nn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:mh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Xi,depthTest:!1,depthWrite:!1})}function bf(){return new Nn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:mh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Xi,depthTest:!1,depthWrite:!1})}function mh(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Rg(n){let t=new WeakMap,e=null;function i(a){if(a&&a.isTexture){let l=a.mapping,c=l===$l||l===Xl,h=l===er||l===nr;if(c||h){let m=t.get(a),g=m!==void 0?m.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==g)return e===null&&(e=new ua(n)),m=c?e.fromEquirectangular(a,m):e.fromCubemap(a,m),m.texture.pmremVersion=a.pmremVersion,t.set(a,m),m.texture;if(m!==void 0)return m.texture;{let d=a.image;return c&&d&&d.height>0||h&&d&&s(d)?(e===null&&(e=new ua(n)),m=c?e.fromEquirectangular(a):e.fromCubemap(a),m.texture.pmremVersion=a.pmremVersion,t.set(a,m),a.addEventListener("dispose",r),m.texture):null}}}return a}function s(a){let l=0,c=6;for(let h=0;h<c;h++)a[h]!==void 0&&l++;return l===c}function r(a){let l=a.target;l.removeEventListener("dispose",r);let c=t.get(l);c!==void 0&&(t.delete(l),c.dispose())}function o(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:i,dispose:o}}function Cg(n){let t={};function e(i){if(t[i]!==void 0)return t[i];let s;switch(i){case"WEBGL_depth_texture":s=n.getExtension("WEBGL_depth_texture")||n.getExtension("MOZ_WEBGL_depth_texture")||n.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=n.getExtension("EXT_texture_filter_anisotropic")||n.getExtension("MOZ_EXT_texture_filter_anisotropic")||n.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=n.getExtension("WEBGL_compressed_texture_s3tc")||n.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=n.getExtension("WEBGL_compressed_texture_pvrtc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=n.getExtension(i)}return t[i]=s,s}return{has:function(i){return e(i)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(i){let s=e(i);return s===null&&Lr("THREE.WebGLRenderer: "+i+" extension not supported."),s}}}function Ig(n,t,e,i){let s={},r=new WeakMap;function o(m){let g=m.target;g.index!==null&&t.remove(g.index);for(let p in g.attributes)t.remove(g.attributes[p]);for(let p in g.morphAttributes){let v=g.morphAttributes[p];for(let u=0,f=v.length;u<f;u++)t.remove(v[u])}g.removeEventListener("dispose",o),delete s[g.id];let d=r.get(g);d&&(t.remove(d),r.delete(g)),i.releaseStatesOfGeometry(g),g.isInstancedBufferGeometry===!0&&delete g._maxInstanceCount,e.memory.geometries--}function a(m,g){return s[g.id]===!0||(g.addEventListener("dispose",o),s[g.id]=!0,e.memory.geometries++),g}function l(m){let g=m.attributes;for(let p in g)t.update(g[p],n.ARRAY_BUFFER);let d=m.morphAttributes;for(let p in d){let v=d[p];for(let u=0,f=v.length;u<f;u++)t.update(v[u],n.ARRAY_BUFFER)}}function c(m){let g=[],d=m.index,p=m.attributes.position,v=0;if(d!==null){let S=d.array;v=d.version;for(let y=0,x=S.length;y<x;y+=3){let L=S[y+0],b=S[y+1],T=S[y+2];g.push(L,b,b,T,T,L)}}else if(p!==void 0){let S=p.array;v=p.version;for(let y=0,x=S.length/3-1;y<x;y+=3){let L=y+0,b=y+1,T=y+2;g.push(L,b,b,T,T,L)}}else return;let u=new(mu(g)?la:aa)(g,1);u.version=v;let f=r.get(m);f&&t.remove(f),r.set(m,u)}function h(m){let g=r.get(m);if(g){let d=m.index;d!==null&&g.version<d.version&&c(m)}else c(m);return r.get(m)}return{get:a,update:l,getWireframeAttribute:h}}function Pg(n,t,e){let i;function s(g){i=g}let r,o;function a(g){r=g.type,o=g.bytesPerElement}function l(g,d){n.drawElements(i,d,r,g*o),e.update(d,i,1)}function c(g,d,p){p!==0&&(n.drawElementsInstanced(i,d,r,g*o,p),e.update(d,i,p))}function h(g,d,p){if(p===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(i,d,0,r,g,0,p);let u=0;for(let f=0;f<p;f++)u+=d[f];e.update(u,i,1)}function m(g,d,p,v){if(p===0)return;let u=t.get("WEBGL_multi_draw");if(u===null)for(let f=0;f<g.length;f++)c(g[f]/o,d[f],v[f]);else{u.multiDrawElementsInstancedWEBGL(i,d,0,r,g,0,v,0,p);let f=0;for(let S=0;S<p;S++)f+=d[S]*v[S];e.update(f,i,1)}}this.setMode=s,this.setIndex=a,this.render=l,this.renderInstances=c,this.renderMultiDraw=h,this.renderMultiDrawInstances=m}function Lg(n){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function i(r,o,a){switch(e.calls++,o){case n.TRIANGLES:e.triangles+=a*(r/3);break;case n.LINES:e.lines+=a*(r/2);break;case n.LINE_STRIP:e.lines+=a*(r-1);break;case n.LINE_LOOP:e.lines+=a*r;break;case n.POINTS:e.points+=a*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:i}}function kg(n,t,e){let i=new WeakMap,s=new an;function r(o,a,l){let c=o.morphTargetInfluences,h=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,m=h!==void 0?h.length:0,g=i.get(a);if(g===void 0||g.count!==m){let M=function(){T.dispose(),i.delete(a),a.removeEventListener("dispose",M)};g!==void 0&&g.texture.dispose();let d=a.morphAttributes.position!==void 0,p=a.morphAttributes.normal!==void 0,v=a.morphAttributes.color!==void 0,u=a.morphAttributes.position||[],f=a.morphAttributes.normal||[],S=a.morphAttributes.color||[],y=0;d===!0&&(y=1),p===!0&&(y=2),v===!0&&(y=3);let x=a.attributes.position.count*y,L=1;x>t.maxTextureSize&&(L=Math.ceil(x/t.maxTextureSize),x=t.maxTextureSize);let b=new Float32Array(x*L*4*m),T=new sa(b,x,L,m);T.type=di,T.needsUpdate=!0;let A=y*4;for(let _=0;_<m;_++){let w=u[_],P=f[_],E=S[_],F=x*L*4*_;for(let R=0;R<w.count;R++){let N=R*A;d===!0&&(s.fromBufferAttribute(w,R),b[F+N+0]=s.x,b[F+N+1]=s.y,b[F+N+2]=s.z,b[F+N+3]=0),p===!0&&(s.fromBufferAttribute(P,R),b[F+N+4]=s.x,b[F+N+5]=s.y,b[F+N+6]=s.z,b[F+N+7]=0),v===!0&&(s.fromBufferAttribute(E,R),b[F+N+8]=s.x,b[F+N+9]=s.y,b[F+N+10]=s.z,b[F+N+11]=E.itemSize===4?s.w:1)}}g={count:m,texture:T,size:new Ht(x,L)},i.set(a,g),a.addEventListener("dispose",M)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)l.getUniforms().setValue(n,"morphTexture",o.morphTexture,e);else{let d=0;for(let v=0;v<c.length;v++)d+=c[v];let p=a.morphTargetsRelative?1:1-d;l.getUniforms().setValue(n,"morphTargetBaseInfluence",p),l.getUniforms().setValue(n,"morphTargetInfluences",c)}l.getUniforms().setValue(n,"morphTargetsTexture",g.texture,e),l.getUniforms().setValue(n,"morphTargetsTextureSize",g.size)}return{update:r}}function Dg(n,t,e,i){let s=new WeakMap;function r(l){let c=i.render.frame,h=l.geometry,m=t.get(l,h);if(s.get(m)!==c&&(t.update(m),s.set(m,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",a)===!1&&l.addEventListener("dispose",a),s.get(l)!==c&&(e.update(l.instanceMatrix,n.ARRAY_BUFFER),l.instanceColor!==null&&e.update(l.instanceColor,n.ARRAY_BUFFER),s.set(l,c))),l.isSkinnedMesh){let g=l.skeleton;s.get(g)!==c&&(g.update(),s.set(g,c))}return m}function o(){s=new WeakMap}function a(l){let c=l.target;c.removeEventListener("dispose",a),e.remove(c.instanceMatrix),c.instanceColor!==null&&e.remove(c.instanceColor)}return{update:r,dispose:o}}var da=class extends Fn{constructor(t,e,i,s,r,o,a,l,c,h=Ks){if(h!==Ks&&h!==sr)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");i===void 0&&h===Ks&&(i=ys),i===void 0&&h===sr&&(i=ir),super(null,s,r,o,a,l,h,i,c),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=a!==void 0?a:Un,this.minFilter=l!==void 0?l:Un,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}},xu=new Fn,Sf=new da(1,1),_u=new sa,Mu=new wc,bu=new ha,wf=[],Ef=[],Tf=new Float32Array(16),Af=new Float32Array(9),Rf=new Float32Array(4);function fr(n,t,e){let i=n[0];if(i<=0||i>0)return n;let s=t*e,r=wf[s];if(r===void 0&&(r=new Float32Array(s),wf[s]=r),t!==0){i.toArray(r,0);for(let o=1,a=0;o!==t;++o)a+=e,n[o].toArray(r,a)}return r}function mn(n,t){if(n.length!==t.length)return!1;for(let e=0,i=n.length;e<i;e++)if(n[e]!==t[e])return!1;return!0}function gn(n,t){for(let e=0,i=t.length;e<i;e++)n[e]=t[e]}function Fa(n,t){let e=Ef[t];e===void 0&&(e=new Int32Array(t),Ef[t]=e);for(let i=0;i!==t;++i)e[i]=n.allocateTextureUnit();return e}function Ug(n,t){let e=this.cache;e[0]!==t&&(n.uniform1f(this.addr,t),e[0]=t)}function Ng(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(n.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(mn(e,t))return;n.uniform2fv(this.addr,t),gn(e,t)}}function Fg(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(n.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(n.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(mn(e,t))return;n.uniform3fv(this.addr,t),gn(e,t)}}function Og(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(n.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(mn(e,t))return;n.uniform4fv(this.addr,t),gn(e,t)}}function zg(n,t){let e=this.cache,i=t.elements;if(i===void 0){if(mn(e,t))return;n.uniformMatrix2fv(this.addr,!1,t),gn(e,t)}else{if(mn(e,i))return;Rf.set(i),n.uniformMatrix2fv(this.addr,!1,Rf),gn(e,i)}}function Bg(n,t){let e=this.cache,i=t.elements;if(i===void 0){if(mn(e,t))return;n.uniformMatrix3fv(this.addr,!1,t),gn(e,t)}else{if(mn(e,i))return;Af.set(i),n.uniformMatrix3fv(this.addr,!1,Af),gn(e,i)}}function Hg(n,t){let e=this.cache,i=t.elements;if(i===void 0){if(mn(e,t))return;n.uniformMatrix4fv(this.addr,!1,t),gn(e,t)}else{if(mn(e,i))return;Tf.set(i),n.uniformMatrix4fv(this.addr,!1,Tf),gn(e,i)}}function Vg(n,t){let e=this.cache;e[0]!==t&&(n.uniform1i(this.addr,t),e[0]=t)}function Gg(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(n.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(mn(e,t))return;n.uniform2iv(this.addr,t),gn(e,t)}}function Wg(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(n.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(mn(e,t))return;n.uniform3iv(this.addr,t),gn(e,t)}}function $g(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(n.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(mn(e,t))return;n.uniform4iv(this.addr,t),gn(e,t)}}function Xg(n,t){let e=this.cache;e[0]!==t&&(n.uniform1ui(this.addr,t),e[0]=t)}function qg(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(n.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(mn(e,t))return;n.uniform2uiv(this.addr,t),gn(e,t)}}function Yg(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(n.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(mn(e,t))return;n.uniform3uiv(this.addr,t),gn(e,t)}}function Zg(n,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(n.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(mn(e,t))return;n.uniform4uiv(this.addr,t),gn(e,t)}}function Jg(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s);let r;this.type===n.SAMPLER_2D_SHADOW?(Sf.compareFunction=pu,r=Sf):r=xu,e.setTexture2D(t||r,s)}function Kg(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),e.setTexture3D(t||Mu,s)}function jg(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),e.setTextureCube(t||bu,s)}function Qg(n,t,e){let i=this.cache,s=e.allocateTextureUnit();i[0]!==s&&(n.uniform1i(this.addr,s),i[0]=s),e.setTexture2DArray(t||_u,s)}function ty(n){switch(n){case 5126:return Ug;case 35664:return Ng;case 35665:return Fg;case 35666:return Og;case 35674:return zg;case 35675:return Bg;case 35676:return Hg;case 5124:case 35670:return Vg;case 35667:case 35671:return Gg;case 35668:case 35672:return Wg;case 35669:case 35673:return $g;case 5125:return Xg;case 36294:return qg;case 36295:return Yg;case 36296:return Zg;case 35678:case 36198:case 36298:case 36306:case 35682:return Jg;case 35679:case 36299:case 36307:return Kg;case 35680:case 36300:case 36308:case 36293:return jg;case 36289:case 36303:case 36311:case 36292:return Qg}}function ey(n,t){n.uniform1fv(this.addr,t)}function ny(n,t){let e=fr(t,this.size,2);n.uniform2fv(this.addr,e)}function iy(n,t){let e=fr(t,this.size,3);n.uniform3fv(this.addr,e)}function sy(n,t){let e=fr(t,this.size,4);n.uniform4fv(this.addr,e)}function ry(n,t){let e=fr(t,this.size,4);n.uniformMatrix2fv(this.addr,!1,e)}function oy(n,t){let e=fr(t,this.size,9);n.uniformMatrix3fv(this.addr,!1,e)}function ay(n,t){let e=fr(t,this.size,16);n.uniformMatrix4fv(this.addr,!1,e)}function ly(n,t){n.uniform1iv(this.addr,t)}function cy(n,t){n.uniform2iv(this.addr,t)}function hy(n,t){n.uniform3iv(this.addr,t)}function fy(n,t){n.uniform4iv(this.addr,t)}function uy(n,t){n.uniform1uiv(this.addr,t)}function dy(n,t){n.uniform2uiv(this.addr,t)}function py(n,t){n.uniform3uiv(this.addr,t)}function my(n,t){n.uniform4uiv(this.addr,t)}function gy(n,t,e){let i=this.cache,s=t.length,r=Fa(e,s);mn(i,r)||(n.uniform1iv(this.addr,r),gn(i,r));for(let o=0;o!==s;++o)e.setTexture2D(t[o]||xu,r[o])}function yy(n,t,e){let i=this.cache,s=t.length,r=Fa(e,s);mn(i,r)||(n.uniform1iv(this.addr,r),gn(i,r));for(let o=0;o!==s;++o)e.setTexture3D(t[o]||Mu,r[o])}function vy(n,t,e){let i=this.cache,s=t.length,r=Fa(e,s);mn(i,r)||(n.uniform1iv(this.addr,r),gn(i,r));for(let o=0;o!==s;++o)e.setTextureCube(t[o]||bu,r[o])}function xy(n,t,e){let i=this.cache,s=t.length,r=Fa(e,s);mn(i,r)||(n.uniform1iv(this.addr,r),gn(i,r));for(let o=0;o!==s;++o)e.setTexture2DArray(t[o]||_u,r[o])}function _y(n){switch(n){case 5126:return ey;case 35664:return ny;case 35665:return iy;case 35666:return sy;case 35674:return ry;case 35675:return oy;case 35676:return ay;case 5124:case 35670:return ly;case 35667:case 35671:return cy;case 35668:case 35672:return hy;case 35669:case 35673:return fy;case 5125:return uy;case 36294:return dy;case 36295:return py;case 36296:return my;case 35678:case 36198:case 36298:case 36306:case 35682:return gy;case 35679:case 36299:case 36307:return yy;case 35680:case 36300:case 36308:case 36293:return vy;case 36289:case 36303:case 36311:case 36292:return xy}}var Ac=class{constructor(t,e,i){this.id=t,this.addr=i,this.cache=[],this.type=e.type,this.setValue=ty(e.type)}},Rc=class{constructor(t,e,i){this.id=t,this.addr=i,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=_y(e.type)}},Cc=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,i){let s=this.seq;for(let r=0,o=s.length;r!==o;++r){let a=s[r];a.setValue(t,e[a.id],i)}}},Cl=/(\w+)(\])?(\[|\.)?/g;function Cf(n,t){n.seq.push(t),n.map[t.id]=t}function My(n,t,e){let i=n.name,s=i.length;for(Cl.lastIndex=0;;){let r=Cl.exec(i),o=Cl.lastIndex,a=r[1],l=r[2]==="]",c=r[3];if(l&&(a=a|0),c===void 0||c==="["&&o+2===s){Cf(e,c===void 0?new Ac(a,n,t):new Rc(a,n,t));break}else{let m=e.map[a];m===void 0&&(m=new Cc(a),Cf(e,m)),e=m}}}var Qs=class{constructor(t,e){this.seq=[],this.map={};let i=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let s=0;s<i;++s){let r=t.getActiveUniform(e,s),o=t.getUniformLocation(e,r.name);My(r,o,this)}}setValue(t,e,i,s){let r=this.map[e];r!==void 0&&r.setValue(t,i,s)}setOptional(t,e,i){let s=e[i];s!==void 0&&this.setValue(t,i,s)}static upload(t,e,i,s){for(let r=0,o=e.length;r!==o;++r){let a=e[r],l=i[a.id];l.needsUpdate!==!1&&a.setValue(t,l.value,s)}}static seqWithValue(t,e){let i=[];for(let s=0,r=t.length;s!==r;++s){let o=t[s];o.id in e&&i.push(o)}return i}};function If(n,t,e){let i=n.createShader(t);return n.shaderSource(i,e),n.compileShader(i),i}var by=37297,Sy=0;function wy(n,t){let e=n.split(`
`),i=[],s=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let o=s;o<r;o++){let a=o+1;i.push(`${a===t?">":" "} ${a}: ${e[o]}`)}return i.join(`
`)}var Pf=new De;function Ey(n){Be._getMatrix(Pf,Be.workingColorSpace,n);let t=`mat3( ${Pf.elements.map(e=>e.toFixed(4))} )`;switch(Be.getTransfer(n)){case Na:return[t,"LinearTransferOETF"];case Xe:return[t,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",n),[t,"LinearTransferOETF"]}}function Lf(n,t,e){let i=n.getShaderParameter(t,n.COMPILE_STATUS),s=n.getShaderInfoLog(t).trim();if(i&&s==="")return"";let r=/ERROR: 0:(\d+)/.exec(s);if(r){let o=parseInt(r[1]);return e.toUpperCase()+`

`+s+`

`+wy(n.getShaderSource(t),o)}else return s}function Ty(n,t){let e=Ey(t);return[`vec4 ${n}( vec4 value ) {`,`	return ${e[1]}( vec4( value.rgb * ${e[0]}, value.a ) );`,"}"].join(`
`)}function Ay(n,t){let e;switch(t){case Od:e="Linear";break;case zd:e="Reinhard";break;case Bd:e="Cineon";break;case Hd:e="ACESFilmic";break;case Gd:e="AgX";break;case Wd:e="Neutral";break;case Vd:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+n+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}var Oo=new V;function Ry(){Be.getLuminanceCoefficients(Oo);let n=Oo.x.toFixed(4),t=Oo.y.toFixed(4),e=Oo.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${n}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Cy(n){return[n.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",n.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(kr).join(`
`)}function Iy(n){let t=[];for(let e in n){let i=n[e];i!==!1&&t.push("#define "+e+" "+i)}return t.join(`
`)}function Py(n,t){let e={},i=n.getProgramParameter(t,n.ACTIVE_ATTRIBUTES);for(let s=0;s<i;s++){let r=n.getActiveAttrib(t,s),o=r.name,a=1;r.type===n.FLOAT_MAT2&&(a=2),r.type===n.FLOAT_MAT3&&(a=3),r.type===n.FLOAT_MAT4&&(a=4),e[o]={type:r.type,location:n.getAttribLocation(t,o),locationSize:a}}return e}function kr(n){return n!==""}function kf(n,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return n.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function Df(n,t){return n.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var Ly=/^[ \t]*#include +<([\w\d./]+)>/gm;function Ic(n){return n.replace(Ly,Dy)}var ky=new Map;function Dy(n,t){let e=Ce[t];if(e===void 0){let i=ky.get(t);if(i!==void 0)e=Ce[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,i);else throw new Error("Can not resolve #include <"+t+">")}return Ic(e)}var Uy=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Uf(n){return n.replace(Uy,Ny)}function Ny(n,t,e,i){let s="";for(let r=parseInt(t);r<parseInt(e);r++)s+=i.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Nf(n){let t=`precision ${n.precision} float;
	precision ${n.precision} int;
	precision ${n.precision} sampler2D;
	precision ${n.precision} samplerCube;
	precision ${n.precision} sampler3D;
	precision ${n.precision} sampler2DArray;
	precision ${n.precision} sampler2DShadow;
	precision ${n.precision} samplerCubeShadow;
	precision ${n.precision} sampler2DArrayShadow;
	precision ${n.precision} isampler2D;
	precision ${n.precision} isampler3D;
	precision ${n.precision} isamplerCube;
	precision ${n.precision} isampler2DArray;
	precision ${n.precision} usampler2D;
	precision ${n.precision} usampler3D;
	precision ${n.precision} usamplerCube;
	precision ${n.precision} usampler2DArray;
	`;return n.precision==="highp"?t+=`
#define HIGH_PRECISION`:n.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:n.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function Fy(n){let t="SHADOWMAP_TYPE_BASIC";return n.shadowMapType===eu?t="SHADOWMAP_TYPE_PCF":n.shadowMapType===rh?t="SHADOWMAP_TYPE_PCF_SOFT":n.shadowMapType===Si&&(t="SHADOWMAP_TYPE_VSM"),t}function Oy(n){let t="ENVMAP_TYPE_CUBE";if(n.envMap)switch(n.envMapMode){case er:case nr:t="ENVMAP_TYPE_CUBE";break;case Ua:t="ENVMAP_TYPE_CUBE_UV";break}return t}function zy(n){let t="ENVMAP_MODE_REFLECTION";if(n.envMap)switch(n.envMapMode){case nr:t="ENVMAP_MODE_REFRACTION";break}return t}function By(n){let t="ENVMAP_BLENDING_NONE";if(n.envMap)switch(n.combine){case nu:t="ENVMAP_BLENDING_MULTIPLY";break;case Nd:t="ENVMAP_BLENDING_MIX";break;case Fd:t="ENVMAP_BLENDING_ADD";break}return t}function Hy(n){let t=n.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,i=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),7*16)),texelHeight:i,maxMip:e}}function Vy(n,t,e,i){let s=n.getContext(),r=e.defines,o=e.vertexShader,a=e.fragmentShader,l=Fy(e),c=Oy(e),h=zy(e),m=By(e),g=Hy(e),d=Cy(e),p=Iy(r),v=s.createProgram(),u,f,S=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(u=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,p].filter(kr).join(`
`),u.length>0&&(u+=`
`),f=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,p].filter(kr).join(`
`),f.length>0&&(f+=`
`)):(u=[Nf(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,p,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(kr).join(`
`),f=[Nf(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,p,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+h:"",e.envMap?"#define "+m:"",g?"#define CUBEUV_TEXEL_WIDTH "+g.texelWidth:"",g?"#define CUBEUV_TEXEL_HEIGHT "+g.texelHeight:"",g?"#define CUBEUV_MAX_MIP "+g.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor||e.batchingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==pi?"#define TONE_MAPPING":"",e.toneMapping!==pi?Ce.tonemapping_pars_fragment:"",e.toneMapping!==pi?Ay("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Ce.colorspace_pars_fragment,Ty("linearToOutputTexel",e.outputColorSpace),Ry(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(kr).join(`
`)),o=Ic(o),o=kf(o,e),o=Df(o,e),a=Ic(a),a=kf(a,e),a=Df(a,e),o=Uf(o),a=Uf(a),e.isRawShaderMaterial!==!0&&(S=`#version 300 es
`,u=[d,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+u,f=["#define varying in",e.glslVersion===Yh?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Yh?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+f);let y=S+u+o,x=S+f+a,L=If(s,s.VERTEX_SHADER,y),b=If(s,s.FRAGMENT_SHADER,x);s.attachShader(v,L),s.attachShader(v,b),e.index0AttributeName!==void 0?s.bindAttribLocation(v,0,e.index0AttributeName):e.morphTargets===!0&&s.bindAttribLocation(v,0,"position"),s.linkProgram(v);function T(w){if(n.debug.checkShaderErrors){let P=s.getProgramInfoLog(v).trim(),E=s.getShaderInfoLog(L).trim(),F=s.getShaderInfoLog(b).trim(),R=!0,N=!0;if(s.getProgramParameter(v,s.LINK_STATUS)===!1)if(R=!1,typeof n.debug.onShaderError=="function")n.debug.onShaderError(s,v,L,b);else{let U=Lf(s,L,"vertex"),z=Lf(s,b,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(v,s.VALIDATE_STATUS)+`

Material Name: `+w.name+`
Material Type: `+w.type+`

Program Info Log: `+P+`
`+U+`
`+z)}else P!==""?console.warn("THREE.WebGLProgram: Program Info Log:",P):(E===""||F==="")&&(N=!1);N&&(w.diagnostics={runnable:R,programLog:P,vertexShader:{log:E,prefix:u},fragmentShader:{log:F,prefix:f}})}s.deleteShader(L),s.deleteShader(b),A=new Qs(s,v),M=Py(s,v)}let A;this.getUniforms=function(){return A===void 0&&T(this),A};let M;this.getAttributes=function(){return M===void 0&&T(this),M};let _=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return _===!1&&(_=s.getProgramParameter(v,by)),_},this.destroy=function(){i.releaseStatesOfProgram(this),s.deleteProgram(v),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=Sy++,this.cacheKey=t,this.usedTimes=1,this.program=v,this.vertexShader=L,this.fragmentShader=b,this}var Gy=0,Pc=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){let e=t.vertexShader,i=t.fragmentShader,s=this._getShaderStage(e),r=this._getShaderStage(i),o=this._getShaderCacheForMaterial(t);return o.has(s)===!1&&(o.add(s),s.usedTimes++),o.has(r)===!1&&(o.add(r),r.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let i of e)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,i=e.get(t);return i===void 0&&(i=new Set,e.set(t,i)),i}_getShaderStage(t){let e=this.shaderCache,i=e.get(t);return i===void 0&&(i=new Lc(t),e.set(t,i)),i}},Lc=class{constructor(t){this.id=Gy++,this.code=t,this.usedTimes=0}};function Wy(n,t,e,i,s,r,o){let a=new oa,l=new Pc,c=new Set,h=[],m=s.logarithmicDepthBuffer,g=s.vertexTextures,d=s.precision,p={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function v(M){return c.add(M),M===0?"uv":`uv${M}`}function u(M,_,w,P,E){let F=P.fog,R=E.geometry,N=M.isMeshStandardMaterial?P.environment:null,U=(M.isMeshStandardMaterial?e:t).get(M.envMap||N),z=U&&U.mapping===Ua?U.image.height:null,Z=p[M.type];M.precision!==null&&(d=s.getMaxPrecision(M.precision),d!==M.precision&&console.warn("THREE.WebGLProgram.getParameters:",M.precision,"not supported, using",d,"instead."));let Y=R.morphAttributes.position||R.morphAttributes.normal||R.morphAttributes.color,k=Y!==void 0?Y.length:0,mt=0;R.morphAttributes.position!==void 0&&(mt=1),R.morphAttributes.normal!==void 0&&(mt=2),R.morphAttributes.color!==void 0&&(mt=3);let bt,D,G,q;if(Z){let Q=fi[Z];bt=Q.vertexShader,D=Q.fragmentShader}else bt=M.vertexShader,D=M.fragmentShader,l.update(M),G=l.getVertexShaderID(M),q=l.getFragmentShaderID(M);let W=n.getRenderTarget(),J=n.state.buffers.depth.getReversed(),it=E.isInstancedMesh===!0,Mt=E.isBatchedMesh===!0,Ct=!!M.map,nt=!!M.matcap,pt=!!U,H=!!M.aoMap,qt=!!M.lightMap,tt=!!M.bumpMap,K=!!M.normalMap,Et=!!M.displacementMap,X=!!M.emissiveMap,Tt=!!M.metalnessMap,B=!!M.roughnessMap,I=M.anisotropy>0,ut=M.clearcoat>0,xt=M.dispersion>0,Pt=M.iridescence>0,At=M.sheen>0,jt=M.transmission>0,dt=I&&!!M.anisotropyMap,ot=ut&&!!M.clearcoatMap,St=ut&&!!M.clearcoatNormalMap,ht=ut&&!!M.clearcoatRoughnessMap,yt=Pt&&!!M.iridescenceMap,Yt=Pt&&!!M.iridescenceThicknessMap,Gt=At&&!!M.sheenColorMap,Wt=At&&!!M.sheenRoughnessMap,ae=!!M.specularMap,ge=!!M.specularColorMap,Ie=!!M.specularIntensityMap,et=jt&&!!M.transmissionMap,Kt=jt&&!!M.thicknessMap,Rt=!!M.gradientMap,Dt=!!M.alphaMap,ee=M.alphaTest>0,ne=!!M.alphaHash,we=!!M.extensions,Ve=pi;M.toneMapped&&(W===null||W.isXRRenderTarget===!0)&&(Ve=n.toneMapping);let C={shaderID:Z,shaderType:M.type,shaderName:M.name,vertexShader:bt,fragmentShader:D,defines:M.defines,customVertexShaderID:G,customFragmentShaderID:q,isRawShaderMaterial:M.isRawShaderMaterial===!0,glslVersion:M.glslVersion,precision:d,batching:Mt,batchingColor:Mt&&E._colorsTexture!==null,instancing:it,instancingColor:it&&E.instanceColor!==null,instancingMorph:it&&E.morphTexture!==null,supportsVertexTextures:g,outputColorSpace:W===null?n.outputColorSpace:W.isXRRenderTarget===!0?W.texture.colorSpace:hr,alphaToCoverage:!!M.alphaToCoverage,map:Ct,matcap:nt,envMap:pt,envMapMode:pt&&U.mapping,envMapCubeUVHeight:z,aoMap:H,lightMap:qt,bumpMap:tt,normalMap:K,displacementMap:g&&Et,emissiveMap:X,normalMapObjectSpace:K&&M.normalMapType===Yd,normalMapTangentSpace:K&&M.normalMapType===du,metalnessMap:Tt,roughnessMap:B,anisotropy:I,anisotropyMap:dt,clearcoat:ut,clearcoatMap:ot,clearcoatNormalMap:St,clearcoatRoughnessMap:ht,dispersion:xt,iridescence:Pt,iridescenceMap:yt,iridescenceThicknessMap:Yt,sheen:At,sheenColorMap:Gt,sheenRoughnessMap:Wt,specularMap:ae,specularColorMap:ge,specularIntensityMap:Ie,transmission:jt,transmissionMap:et,thicknessMap:Kt,gradientMap:Rt,opaque:M.transparent===!1&&M.blending===Js&&M.alphaToCoverage===!1,alphaMap:Dt,alphaTest:ee,alphaHash:ne,combine:M.combine,mapUv:Ct&&v(M.map.channel),aoMapUv:H&&v(M.aoMap.channel),lightMapUv:qt&&v(M.lightMap.channel),bumpMapUv:tt&&v(M.bumpMap.channel),normalMapUv:K&&v(M.normalMap.channel),displacementMapUv:Et&&v(M.displacementMap.channel),emissiveMapUv:X&&v(M.emissiveMap.channel),metalnessMapUv:Tt&&v(M.metalnessMap.channel),roughnessMapUv:B&&v(M.roughnessMap.channel),anisotropyMapUv:dt&&v(M.anisotropyMap.channel),clearcoatMapUv:ot&&v(M.clearcoatMap.channel),clearcoatNormalMapUv:St&&v(M.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:ht&&v(M.clearcoatRoughnessMap.channel),iridescenceMapUv:yt&&v(M.iridescenceMap.channel),iridescenceThicknessMapUv:Yt&&v(M.iridescenceThicknessMap.channel),sheenColorMapUv:Gt&&v(M.sheenColorMap.channel),sheenRoughnessMapUv:Wt&&v(M.sheenRoughnessMap.channel),specularMapUv:ae&&v(M.specularMap.channel),specularColorMapUv:ge&&v(M.specularColorMap.channel),specularIntensityMapUv:Ie&&v(M.specularIntensityMap.channel),transmissionMapUv:et&&v(M.transmissionMap.channel),thicknessMapUv:Kt&&v(M.thicknessMap.channel),alphaMapUv:Dt&&v(M.alphaMap.channel),vertexTangents:!!R.attributes.tangent&&(K||I),vertexColors:M.vertexColors,vertexAlphas:M.vertexColors===!0&&!!R.attributes.color&&R.attributes.color.itemSize===4,pointsUvs:E.isPoints===!0&&!!R.attributes.uv&&(Ct||Dt),fog:!!F,useFog:M.fog===!0,fogExp2:!!F&&F.isFogExp2,flatShading:M.flatShading===!0,sizeAttenuation:M.sizeAttenuation===!0,logarithmicDepthBuffer:m,reverseDepthBuffer:J,skinning:E.isSkinnedMesh===!0,morphTargets:R.morphAttributes.position!==void 0,morphNormals:R.morphAttributes.normal!==void 0,morphColors:R.morphAttributes.color!==void 0,morphTargetsCount:k,morphTextureStride:mt,numDirLights:_.directional.length,numPointLights:_.point.length,numSpotLights:_.spot.length,numSpotLightMaps:_.spotLightMap.length,numRectAreaLights:_.rectArea.length,numHemiLights:_.hemi.length,numDirLightShadows:_.directionalShadowMap.length,numPointLightShadows:_.pointShadowMap.length,numSpotLightShadows:_.spotShadowMap.length,numSpotLightShadowsWithMaps:_.numSpotLightShadowsWithMaps,numLightProbes:_.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:M.dithering,shadowMapEnabled:n.shadowMap.enabled&&w.length>0,shadowMapType:n.shadowMap.type,toneMapping:Ve,decodeVideoTexture:Ct&&M.map.isVideoTexture===!0&&Be.getTransfer(M.map.colorSpace)===Xe,decodeVideoTextureEmissive:X&&M.emissiveMap.isVideoTexture===!0&&Be.getTransfer(M.emissiveMap.colorSpace)===Xe,premultipliedAlpha:M.premultipliedAlpha,doubleSided:M.side===hn,flipSided:M.side===En,useDepthPacking:M.depthPacking>=0,depthPacking:M.depthPacking||0,index0AttributeName:M.index0AttributeName,extensionClipCullDistance:we&&M.extensions.clipCullDistance===!0&&i.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(we&&M.extensions.multiDraw===!0||Mt)&&i.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:M.customProgramCacheKey()};return C.vertexUv1s=c.has(1),C.vertexUv2s=c.has(2),C.vertexUv3s=c.has(3),c.clear(),C}function f(M){let _=[];if(M.shaderID?_.push(M.shaderID):(_.push(M.customVertexShaderID),_.push(M.customFragmentShaderID)),M.defines!==void 0)for(let w in M.defines)_.push(w),_.push(M.defines[w]);return M.isRawShaderMaterial===!1&&(S(_,M),y(_,M),_.push(n.outputColorSpace)),_.push(M.customProgramCacheKey),_.join()}function S(M,_){M.push(_.precision),M.push(_.outputColorSpace),M.push(_.envMapMode),M.push(_.envMapCubeUVHeight),M.push(_.mapUv),M.push(_.alphaMapUv),M.push(_.lightMapUv),M.push(_.aoMapUv),M.push(_.bumpMapUv),M.push(_.normalMapUv),M.push(_.displacementMapUv),M.push(_.emissiveMapUv),M.push(_.metalnessMapUv),M.push(_.roughnessMapUv),M.push(_.anisotropyMapUv),M.push(_.clearcoatMapUv),M.push(_.clearcoatNormalMapUv),M.push(_.clearcoatRoughnessMapUv),M.push(_.iridescenceMapUv),M.push(_.iridescenceThicknessMapUv),M.push(_.sheenColorMapUv),M.push(_.sheenRoughnessMapUv),M.push(_.specularMapUv),M.push(_.specularColorMapUv),M.push(_.specularIntensityMapUv),M.push(_.transmissionMapUv),M.push(_.thicknessMapUv),M.push(_.combine),M.push(_.fogExp2),M.push(_.sizeAttenuation),M.push(_.morphTargetsCount),M.push(_.morphAttributeCount),M.push(_.numDirLights),M.push(_.numPointLights),M.push(_.numSpotLights),M.push(_.numSpotLightMaps),M.push(_.numHemiLights),M.push(_.numRectAreaLights),M.push(_.numDirLightShadows),M.push(_.numPointLightShadows),M.push(_.numSpotLightShadows),M.push(_.numSpotLightShadowsWithMaps),M.push(_.numLightProbes),M.push(_.shadowMapType),M.push(_.toneMapping),M.push(_.numClippingPlanes),M.push(_.numClipIntersection),M.push(_.depthPacking)}function y(M,_){a.disableAll(),_.supportsVertexTextures&&a.enable(0),_.instancing&&a.enable(1),_.instancingColor&&a.enable(2),_.instancingMorph&&a.enable(3),_.matcap&&a.enable(4),_.envMap&&a.enable(5),_.normalMapObjectSpace&&a.enable(6),_.normalMapTangentSpace&&a.enable(7),_.clearcoat&&a.enable(8),_.iridescence&&a.enable(9),_.alphaTest&&a.enable(10),_.vertexColors&&a.enable(11),_.vertexAlphas&&a.enable(12),_.vertexUv1s&&a.enable(13),_.vertexUv2s&&a.enable(14),_.vertexUv3s&&a.enable(15),_.vertexTangents&&a.enable(16),_.anisotropy&&a.enable(17),_.alphaHash&&a.enable(18),_.batching&&a.enable(19),_.dispersion&&a.enable(20),_.batchingColor&&a.enable(21),M.push(a.mask),a.disableAll(),_.fog&&a.enable(0),_.useFog&&a.enable(1),_.flatShading&&a.enable(2),_.logarithmicDepthBuffer&&a.enable(3),_.reverseDepthBuffer&&a.enable(4),_.skinning&&a.enable(5),_.morphTargets&&a.enable(6),_.morphNormals&&a.enable(7),_.morphColors&&a.enable(8),_.premultipliedAlpha&&a.enable(9),_.shadowMapEnabled&&a.enable(10),_.doubleSided&&a.enable(11),_.flipSided&&a.enable(12),_.useDepthPacking&&a.enable(13),_.dithering&&a.enable(14),_.transmission&&a.enable(15),_.sheen&&a.enable(16),_.opaque&&a.enable(17),_.pointsUvs&&a.enable(18),_.decodeVideoTexture&&a.enable(19),_.decodeVideoTextureEmissive&&a.enable(20),_.alphaToCoverage&&a.enable(21),M.push(a.mask)}function x(M){let _=p[M.type],w;if(_){let P=fi[_];w=ph.clone(P.uniforms)}else w=M.uniforms;return w}function L(M,_){let w;for(let P=0,E=h.length;P<E;P++){let F=h[P];if(F.cacheKey===_){w=F,++w.usedTimes;break}}return w===void 0&&(w=new Vy(n,_,M,r),h.push(w)),w}function b(M){if(--M.usedTimes===0){let _=h.indexOf(M);h[_]=h[h.length-1],h.pop(),M.destroy()}}function T(M){l.remove(M)}function A(){l.dispose()}return{getParameters:u,getProgramCacheKey:f,getUniforms:x,acquireProgram:L,releaseProgram:b,releaseShaderCache:T,programs:h,dispose:A}}function $y(){let n=new WeakMap;function t(o){return n.has(o)}function e(o){let a=n.get(o);return a===void 0&&(a={},n.set(o,a)),a}function i(o){n.delete(o)}function s(o,a,l){n.get(o)[a]=l}function r(){n=new WeakMap}return{has:t,get:e,remove:i,update:s,dispose:r}}function Xy(n,t){return n.groupOrder!==t.groupOrder?n.groupOrder-t.groupOrder:n.renderOrder!==t.renderOrder?n.renderOrder-t.renderOrder:n.material.id!==t.material.id?n.material.id-t.material.id:n.z!==t.z?n.z-t.z:n.id-t.id}function Ff(n,t){return n.groupOrder!==t.groupOrder?n.groupOrder-t.groupOrder:n.renderOrder!==t.renderOrder?n.renderOrder-t.renderOrder:n.z!==t.z?t.z-n.z:n.id-t.id}function Of(){let n=[],t=0,e=[],i=[],s=[];function r(){t=0,e.length=0,i.length=0,s.length=0}function o(m,g,d,p,v,u){let f=n[t];return f===void 0?(f={id:m.id,object:m,geometry:g,material:d,groupOrder:p,renderOrder:m.renderOrder,z:v,group:u},n[t]=f):(f.id=m.id,f.object=m,f.geometry=g,f.material=d,f.groupOrder=p,f.renderOrder=m.renderOrder,f.z=v,f.group=u),t++,f}function a(m,g,d,p,v,u){let f=o(m,g,d,p,v,u);d.transmission>0?i.push(f):d.transparent===!0?s.push(f):e.push(f)}function l(m,g,d,p,v,u){let f=o(m,g,d,p,v,u);d.transmission>0?i.unshift(f):d.transparent===!0?s.unshift(f):e.unshift(f)}function c(m,g){e.length>1&&e.sort(m||Xy),i.length>1&&i.sort(g||Ff),s.length>1&&s.sort(g||Ff)}function h(){for(let m=t,g=n.length;m<g;m++){let d=n[m];if(d.id===null)break;d.id=null,d.object=null,d.geometry=null,d.material=null,d.group=null}}return{opaque:e,transmissive:i,transparent:s,init:r,push:a,unshift:l,finish:h,sort:c}}function qy(){let n=new WeakMap;function t(i,s){let r=n.get(i),o;return r===void 0?(o=new Of,n.set(i,[o])):s>=r.length?(o=new Of,r.push(o)):o=r[s],o}function e(){n=new WeakMap}return{get:t,dispose:e}}function Yy(){let n={};return{get:function(t){if(n[t.id]!==void 0)return n[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new V,color:new fe};break;case"SpotLight":e={position:new V,direction:new V,color:new fe,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new V,color:new fe,distance:0,decay:0};break;case"HemisphereLight":e={direction:new V,skyColor:new fe,groundColor:new fe};break;case"RectAreaLight":e={color:new fe,position:new V,halfWidth:new V,halfHeight:new V};break}return n[t.id]=e,e}}}function Zy(){let n={};return{get:function(t){if(n[t.id]!==void 0)return n[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ht};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ht};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ht,shadowCameraNear:1,shadowCameraFar:1e3};break}return n[t.id]=e,e}}}var Jy=0;function Ky(n,t){return(t.castShadow?2:0)-(n.castShadow?2:0)+(t.map?1:0)-(n.map?1:0)}function jy(n){let t=new Yy,e=Zy(),i={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)i.probe.push(new V);let s=new V,r=new Fe,o=new Fe;function a(c){let h=0,m=0,g=0;for(let M=0;M<9;M++)i.probe[M].set(0,0,0);let d=0,p=0,v=0,u=0,f=0,S=0,y=0,x=0,L=0,b=0,T=0;c.sort(Ky);for(let M=0,_=c.length;M<_;M++){let w=c[M],P=w.color,E=w.intensity,F=w.distance,R=w.shadow&&w.shadow.map?w.shadow.map.texture:null;if(w.isAmbientLight)h+=P.r*E,m+=P.g*E,g+=P.b*E;else if(w.isLightProbe){for(let N=0;N<9;N++)i.probe[N].addScaledVector(w.sh.coefficients[N],E);T++}else if(w.isDirectionalLight){let N=t.get(w);if(N.color.copy(w.color).multiplyScalar(w.intensity),w.castShadow){let U=w.shadow,z=e.get(w);z.shadowIntensity=U.intensity,z.shadowBias=U.bias,z.shadowNormalBias=U.normalBias,z.shadowRadius=U.radius,z.shadowMapSize=U.mapSize,i.directionalShadow[d]=z,i.directionalShadowMap[d]=R,i.directionalShadowMatrix[d]=w.shadow.matrix,S++}i.directional[d]=N,d++}else if(w.isSpotLight){let N=t.get(w);N.position.setFromMatrixPosition(w.matrixWorld),N.color.copy(P).multiplyScalar(E),N.distance=F,N.coneCos=Math.cos(w.angle),N.penumbraCos=Math.cos(w.angle*(1-w.penumbra)),N.decay=w.decay,i.spot[v]=N;let U=w.shadow;if(w.map&&(i.spotLightMap[L]=w.map,L++,U.updateMatrices(w),w.castShadow&&b++),i.spotLightMatrix[v]=U.matrix,w.castShadow){let z=e.get(w);z.shadowIntensity=U.intensity,z.shadowBias=U.bias,z.shadowNormalBias=U.normalBias,z.shadowRadius=U.radius,z.shadowMapSize=U.mapSize,i.spotShadow[v]=z,i.spotShadowMap[v]=R,x++}v++}else if(w.isRectAreaLight){let N=t.get(w);N.color.copy(P).multiplyScalar(E),N.halfWidth.set(w.width*.5,0,0),N.halfHeight.set(0,w.height*.5,0),i.rectArea[u]=N,u++}else if(w.isPointLight){let N=t.get(w);if(N.color.copy(w.color).multiplyScalar(w.intensity),N.distance=w.distance,N.decay=w.decay,w.castShadow){let U=w.shadow,z=e.get(w);z.shadowIntensity=U.intensity,z.shadowBias=U.bias,z.shadowNormalBias=U.normalBias,z.shadowRadius=U.radius,z.shadowMapSize=U.mapSize,z.shadowCameraNear=U.camera.near,z.shadowCameraFar=U.camera.far,i.pointShadow[p]=z,i.pointShadowMap[p]=R,i.pointShadowMatrix[p]=w.shadow.matrix,y++}i.point[p]=N,p++}else if(w.isHemisphereLight){let N=t.get(w);N.skyColor.copy(w.color).multiplyScalar(E),N.groundColor.copy(w.groundColor).multiplyScalar(E),i.hemi[f]=N,f++}}u>0&&(n.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=te.LTC_FLOAT_1,i.rectAreaLTC2=te.LTC_FLOAT_2):(i.rectAreaLTC1=te.LTC_HALF_1,i.rectAreaLTC2=te.LTC_HALF_2)),i.ambient[0]=h,i.ambient[1]=m,i.ambient[2]=g;let A=i.hash;(A.directionalLength!==d||A.pointLength!==p||A.spotLength!==v||A.rectAreaLength!==u||A.hemiLength!==f||A.numDirectionalShadows!==S||A.numPointShadows!==y||A.numSpotShadows!==x||A.numSpotMaps!==L||A.numLightProbes!==T)&&(i.directional.length=d,i.spot.length=v,i.rectArea.length=u,i.point.length=p,i.hemi.length=f,i.directionalShadow.length=S,i.directionalShadowMap.length=S,i.pointShadow.length=y,i.pointShadowMap.length=y,i.spotShadow.length=x,i.spotShadowMap.length=x,i.directionalShadowMatrix.length=S,i.pointShadowMatrix.length=y,i.spotLightMatrix.length=x+L-b,i.spotLightMap.length=L,i.numSpotLightShadowsWithMaps=b,i.numLightProbes=T,A.directionalLength=d,A.pointLength=p,A.spotLength=v,A.rectAreaLength=u,A.hemiLength=f,A.numDirectionalShadows=S,A.numPointShadows=y,A.numSpotShadows=x,A.numSpotMaps=L,A.numLightProbes=T,i.version=Jy++)}function l(c,h){let m=0,g=0,d=0,p=0,v=0,u=h.matrixWorldInverse;for(let f=0,S=c.length;f<S;f++){let y=c[f];if(y.isDirectionalLight){let x=i.directional[m];x.direction.setFromMatrixPosition(y.matrixWorld),s.setFromMatrixPosition(y.target.matrixWorld),x.direction.sub(s),x.direction.transformDirection(u),m++}else if(y.isSpotLight){let x=i.spot[d];x.position.setFromMatrixPosition(y.matrixWorld),x.position.applyMatrix4(u),x.direction.setFromMatrixPosition(y.matrixWorld),s.setFromMatrixPosition(y.target.matrixWorld),x.direction.sub(s),x.direction.transformDirection(u),d++}else if(y.isRectAreaLight){let x=i.rectArea[p];x.position.setFromMatrixPosition(y.matrixWorld),x.position.applyMatrix4(u),o.identity(),r.copy(y.matrixWorld),r.premultiply(u),o.extractRotation(r),x.halfWidth.set(y.width*.5,0,0),x.halfHeight.set(0,y.height*.5,0),x.halfWidth.applyMatrix4(o),x.halfHeight.applyMatrix4(o),p++}else if(y.isPointLight){let x=i.point[g];x.position.setFromMatrixPosition(y.matrixWorld),x.position.applyMatrix4(u),g++}else if(y.isHemisphereLight){let x=i.hemi[v];x.direction.setFromMatrixPosition(y.matrixWorld),x.direction.transformDirection(u),v++}}}return{setup:a,setupView:l,state:i}}function zf(n){let t=new jy(n),e=[],i=[];function s(h){c.camera=h,e.length=0,i.length=0}function r(h){e.push(h)}function o(h){i.push(h)}function a(){t.setup(e)}function l(h){t.setupView(e,h)}let c={lightsArray:e,shadowsArray:i,camera:null,lights:t,transmissionRenderTarget:{}};return{init:s,state:c,setupLights:a,setupLightsView:l,pushLight:r,pushShadow:o}}function Qy(n){let t=new WeakMap;function e(s,r=0){let o=t.get(s),a;return o===void 0?(a=new zf(n),t.set(s,[a])):r>=o.length?(a=new zf(n),o.push(a)):a=o[r],a}function i(){t=new WeakMap}return{get:e,dispose:i}}var kc=class extends Ii{static get type(){return"MeshDepthMaterial"}constructor(t){super(),this.isMeshDepthMaterial=!0,this.depthPacking=Xd,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},Dc=class extends Ii{static get type(){return"MeshDistanceMaterial"}constructor(t){super(),this.isMeshDistanceMaterial=!0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}},tv=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,ev=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function nv(n,t,e){let i=new Hr,s=new Ht,r=new Ht,o=new an,a=new kc({depthPacking:qd}),l=new Dc,c={},h=e.maxTextureSize,m={[Yi]:En,[En]:Yi,[hn]:hn},g=new Nn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Ht},radius:{value:4}},vertexShader:tv,fragmentShader:ev}),d=g.clone();d.defines.HORIZONTAL_PASS=1;let p=new Ye;p.setAttribute("position",new Qe(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let v=new We(p,g),u=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=eu;let f=this.type;this.render=function(b,T,A){if(u.enabled===!1||u.autoUpdate===!1&&u.needsUpdate===!1||b.length===0)return;let M=n.getRenderTarget(),_=n.getActiveCubeFace(),w=n.getActiveMipmapLevel(),P=n.state;P.setBlending(Xi),P.buffers.color.setClear(1,1,1,1),P.buffers.depth.setTest(!0),P.setScissorTest(!1);let E=f!==Si&&this.type===Si,F=f===Si&&this.type!==Si;for(let R=0,N=b.length;R<N;R++){let U=b[R],z=U.shadow;if(z===void 0){console.warn("THREE.WebGLShadowMap:",U,"has no shadow.");continue}if(z.autoUpdate===!1&&z.needsUpdate===!1)continue;s.copy(z.mapSize);let Z=z.getFrameExtents();if(s.multiply(Z),r.copy(z.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(r.x=Math.floor(h/Z.x),s.x=r.x*Z.x,z.mapSize.x=r.x),s.y>h&&(r.y=Math.floor(h/Z.y),s.y=r.y*Z.y,z.mapSize.y=r.y)),z.map===null||E===!0||F===!0){let k=this.type!==Si?{minFilter:Un,magFilter:Un}:{};z.map!==null&&z.map.dispose(),z.map=new Ri(s.x,s.y,k),z.map.texture.name=U.name+".shadowMap",z.camera.updateProjectionMatrix()}n.setRenderTarget(z.map),n.clear();let Y=z.getViewportCount();for(let k=0;k<Y;k++){let mt=z.getViewport(k);o.set(r.x*mt.x,r.y*mt.y,r.x*mt.z,r.y*mt.w),P.viewport(o),z.updateMatrices(U,k),i=z.getFrustum(),x(T,A,z.camera,U,this.type)}z.isPointLightShadow!==!0&&this.type===Si&&S(z,A),z.needsUpdate=!1}f=this.type,u.needsUpdate=!1,n.setRenderTarget(M,_,w)};function S(b,T){let A=t.update(v);g.defines.VSM_SAMPLES!==b.blurSamples&&(g.defines.VSM_SAMPLES=b.blurSamples,d.defines.VSM_SAMPLES=b.blurSamples,g.needsUpdate=!0,d.needsUpdate=!0),b.mapPass===null&&(b.mapPass=new Ri(s.x,s.y)),g.uniforms.shadow_pass.value=b.map.texture,g.uniforms.resolution.value=b.mapSize,g.uniforms.radius.value=b.radius,n.setRenderTarget(b.mapPass),n.clear(),n.renderBufferDirect(T,null,A,g,v,null),d.uniforms.shadow_pass.value=b.mapPass.texture,d.uniforms.resolution.value=b.mapSize,d.uniforms.radius.value=b.radius,n.setRenderTarget(b.map),n.clear(),n.renderBufferDirect(T,null,A,d,v,null)}function y(b,T,A,M){let _=null,w=A.isPointLight===!0?b.customDistanceMaterial:b.customDepthMaterial;if(w!==void 0)_=w;else if(_=A.isPointLight===!0?l:a,n.localClippingEnabled&&T.clipShadows===!0&&Array.isArray(T.clippingPlanes)&&T.clippingPlanes.length!==0||T.displacementMap&&T.displacementScale!==0||T.alphaMap&&T.alphaTest>0||T.map&&T.alphaTest>0){let P=_.uuid,E=T.uuid,F=c[P];F===void 0&&(F={},c[P]=F);let R=F[E];R===void 0&&(R=_.clone(),F[E]=R,T.addEventListener("dispose",L)),_=R}if(_.visible=T.visible,_.wireframe=T.wireframe,M===Si?_.side=T.shadowSide!==null?T.shadowSide:T.side:_.side=T.shadowSide!==null?T.shadowSide:m[T.side],_.alphaMap=T.alphaMap,_.alphaTest=T.alphaTest,_.map=T.map,_.clipShadows=T.clipShadows,_.clippingPlanes=T.clippingPlanes,_.clipIntersection=T.clipIntersection,_.displacementMap=T.displacementMap,_.displacementScale=T.displacementScale,_.displacementBias=T.displacementBias,_.wireframeLinewidth=T.wireframeLinewidth,_.linewidth=T.linewidth,A.isPointLight===!0&&_.isMeshDistanceMaterial===!0){let P=n.properties.get(_);P.light=A}return _}function x(b,T,A,M,_){if(b.visible===!1)return;if(b.layers.test(T.layers)&&(b.isMesh||b.isLine||b.isPoints)&&(b.castShadow||b.receiveShadow&&_===Si)&&(!b.frustumCulled||i.intersectsObject(b))){b.modelViewMatrix.multiplyMatrices(A.matrixWorldInverse,b.matrixWorld);let E=t.update(b),F=b.material;if(Array.isArray(F)){let R=E.groups;for(let N=0,U=R.length;N<U;N++){let z=R[N],Z=F[z.materialIndex];if(Z&&Z.visible){let Y=y(b,Z,M,_);b.onBeforeShadow(n,b,T,A,E,Y,z),n.renderBufferDirect(A,null,E,Y,b,z),b.onAfterShadow(n,b,T,A,E,Y,z)}}}else if(F.visible){let R=y(b,F,M,_);b.onBeforeShadow(n,b,T,A,E,R,null),n.renderBufferDirect(A,null,E,R,b,null),b.onAfterShadow(n,b,T,A,E,R,null)}}let P=b.children;for(let E=0,F=P.length;E<F;E++)x(P[E],T,A,M,_)}function L(b){b.target.removeEventListener("dispose",L);for(let A in c){let M=c[A],_=b.target.uuid;_ in M&&(M[_].dispose(),delete M[_])}}}var iv={[Ol]:zl,[Bl]:Gl,[Hl]:Wl,[tr]:Vl,[zl]:Ol,[Gl]:Bl,[Wl]:Hl,[Vl]:tr};function sv(n,t){function e(){let et=!1,Kt=new an,Rt=null,Dt=new an(0,0,0,0);return{setMask:function(ee){Rt!==ee&&!et&&(n.colorMask(ee,ee,ee,ee),Rt=ee)},setLocked:function(ee){et=ee},setClear:function(ee,ne,we,Ve,C){C===!0&&(ee*=Ve,ne*=Ve,we*=Ve),Kt.set(ee,ne,we,Ve),Dt.equals(Kt)===!1&&(n.clearColor(ee,ne,we,Ve),Dt.copy(Kt))},reset:function(){et=!1,Rt=null,Dt.set(-1,0,0,0)}}}function i(){let et=!1,Kt=!1,Rt=null,Dt=null,ee=null;return{setReversed:function(ne){if(Kt!==ne){let we=t.get("EXT_clip_control");Kt?we.clipControlEXT(we.LOWER_LEFT_EXT,we.ZERO_TO_ONE_EXT):we.clipControlEXT(we.LOWER_LEFT_EXT,we.NEGATIVE_ONE_TO_ONE_EXT);let Ve=ee;ee=null,this.setClear(Ve)}Kt=ne},getReversed:function(){return Kt},setTest:function(ne){ne?W(n.DEPTH_TEST):J(n.DEPTH_TEST)},setMask:function(ne){Rt!==ne&&!et&&(n.depthMask(ne),Rt=ne)},setFunc:function(ne){if(Kt&&(ne=iv[ne]),Dt!==ne){switch(ne){case Ol:n.depthFunc(n.NEVER);break;case zl:n.depthFunc(n.ALWAYS);break;case Bl:n.depthFunc(n.LESS);break;case tr:n.depthFunc(n.LEQUAL);break;case Hl:n.depthFunc(n.EQUAL);break;case Vl:n.depthFunc(n.GEQUAL);break;case Gl:n.depthFunc(n.GREATER);break;case Wl:n.depthFunc(n.NOTEQUAL);break;default:n.depthFunc(n.LEQUAL)}Dt=ne}},setLocked:function(ne){et=ne},setClear:function(ne){ee!==ne&&(Kt&&(ne=1-ne),n.clearDepth(ne),ee=ne)},reset:function(){et=!1,Rt=null,Dt=null,ee=null,Kt=!1}}}function s(){let et=!1,Kt=null,Rt=null,Dt=null,ee=null,ne=null,we=null,Ve=null,C=null;return{setTest:function(Q){et||(Q?W(n.STENCIL_TEST):J(n.STENCIL_TEST))},setMask:function(Q){Kt!==Q&&!et&&(n.stencilMask(Q),Kt=Q)},setFunc:function(Q,at,lt){(Rt!==Q||Dt!==at||ee!==lt)&&(n.stencilFunc(Q,at,lt),Rt=Q,Dt=at,ee=lt)},setOp:function(Q,at,lt){(ne!==Q||we!==at||Ve!==lt)&&(n.stencilOp(Q,at,lt),ne=Q,we=at,Ve=lt)},setLocked:function(Q){et=Q},setClear:function(Q){C!==Q&&(n.clearStencil(Q),C=Q)},reset:function(){et=!1,Kt=null,Rt=null,Dt=null,ee=null,ne=null,we=null,Ve=null,C=null}}}let r=new e,o=new i,a=new s,l=new WeakMap,c=new WeakMap,h={},m={},g=new WeakMap,d=[],p=null,v=!1,u=null,f=null,S=null,y=null,x=null,L=null,b=null,T=new fe(0,0,0),A=0,M=!1,_=null,w=null,P=null,E=null,F=null,R=n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS),N=!1,U=0,z=n.getParameter(n.VERSION);z.indexOf("WebGL")!==-1?(U=parseFloat(/^WebGL (\d)/.exec(z)[1]),N=U>=1):z.indexOf("OpenGL ES")!==-1&&(U=parseFloat(/^OpenGL ES (\d)/.exec(z)[1]),N=U>=2);let Z=null,Y={},k=n.getParameter(n.SCISSOR_BOX),mt=n.getParameter(n.VIEWPORT),bt=new an().fromArray(k),D=new an().fromArray(mt);function G(et,Kt,Rt,Dt){let ee=new Uint8Array(4),ne=n.createTexture();n.bindTexture(et,ne),n.texParameteri(et,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(et,n.TEXTURE_MAG_FILTER,n.NEAREST);for(let we=0;we<Rt;we++)et===n.TEXTURE_3D||et===n.TEXTURE_2D_ARRAY?n.texImage3D(Kt,0,n.RGBA,1,1,Dt,0,n.RGBA,n.UNSIGNED_BYTE,ee):n.texImage2D(Kt+we,0,n.RGBA,1,1,0,n.RGBA,n.UNSIGNED_BYTE,ee);return ne}let q={};q[n.TEXTURE_2D]=G(n.TEXTURE_2D,n.TEXTURE_2D,1),q[n.TEXTURE_CUBE_MAP]=G(n.TEXTURE_CUBE_MAP,n.TEXTURE_CUBE_MAP_POSITIVE_X,6),q[n.TEXTURE_2D_ARRAY]=G(n.TEXTURE_2D_ARRAY,n.TEXTURE_2D_ARRAY,1,1),q[n.TEXTURE_3D]=G(n.TEXTURE_3D,n.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),a.setClear(0),W(n.DEPTH_TEST),o.setFunc(tr),tt(!1),K(Bh),W(n.CULL_FACE),H(Xi);function W(et){h[et]!==!0&&(n.enable(et),h[et]=!0)}function J(et){h[et]!==!1&&(n.disable(et),h[et]=!1)}function it(et,Kt){return m[et]!==Kt?(n.bindFramebuffer(et,Kt),m[et]=Kt,et===n.DRAW_FRAMEBUFFER&&(m[n.FRAMEBUFFER]=Kt),et===n.FRAMEBUFFER&&(m[n.DRAW_FRAMEBUFFER]=Kt),!0):!1}function Mt(et,Kt){let Rt=d,Dt=!1;if(et){Rt=g.get(Kt),Rt===void 0&&(Rt=[],g.set(Kt,Rt));let ee=et.textures;if(Rt.length!==ee.length||Rt[0]!==n.COLOR_ATTACHMENT0){for(let ne=0,we=ee.length;ne<we;ne++)Rt[ne]=n.COLOR_ATTACHMENT0+ne;Rt.length=ee.length,Dt=!0}}else Rt[0]!==n.BACK&&(Rt[0]=n.BACK,Dt=!0);Dt&&n.drawBuffers(Rt)}function Ct(et){return p!==et?(n.useProgram(et),p=et,!0):!1}let nt={[us]:n.FUNC_ADD,[xd]:n.FUNC_SUBTRACT,[_d]:n.FUNC_REVERSE_SUBTRACT};nt[Md]=n.MIN,nt[bd]=n.MAX;let pt={[Sd]:n.ZERO,[wd]:n.ONE,[Ed]:n.SRC_COLOR,[Nl]:n.SRC_ALPHA,[Pd]:n.SRC_ALPHA_SATURATE,[Cd]:n.DST_COLOR,[Ad]:n.DST_ALPHA,[Td]:n.ONE_MINUS_SRC_COLOR,[Fl]:n.ONE_MINUS_SRC_ALPHA,[Id]:n.ONE_MINUS_DST_COLOR,[Rd]:n.ONE_MINUS_DST_ALPHA,[Ld]:n.CONSTANT_COLOR,[kd]:n.ONE_MINUS_CONSTANT_COLOR,[Dd]:n.CONSTANT_ALPHA,[Ud]:n.ONE_MINUS_CONSTANT_ALPHA};function H(et,Kt,Rt,Dt,ee,ne,we,Ve,C,Q){if(et===Xi){v===!0&&(J(n.BLEND),v=!1);return}if(v===!1&&(W(n.BLEND),v=!0),et!==vd){if(et!==u||Q!==M){if((f!==us||x!==us)&&(n.blendEquation(n.FUNC_ADD),f=us,x=us),Q)switch(et){case Js:n.blendFuncSeparate(n.ONE,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Hh:n.blendFunc(n.ONE,n.ONE);break;case Vh:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case Gh:n.blendFuncSeparate(n.ZERO,n.SRC_COLOR,n.ZERO,n.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",et);break}else switch(et){case Js:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Hh:n.blendFunc(n.SRC_ALPHA,n.ONE);break;case Vh:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case Gh:n.blendFunc(n.ZERO,n.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",et);break}S=null,y=null,L=null,b=null,T.set(0,0,0),A=0,u=et,M=Q}return}ee=ee||Kt,ne=ne||Rt,we=we||Dt,(Kt!==f||ee!==x)&&(n.blendEquationSeparate(nt[Kt],nt[ee]),f=Kt,x=ee),(Rt!==S||Dt!==y||ne!==L||we!==b)&&(n.blendFuncSeparate(pt[Rt],pt[Dt],pt[ne],pt[we]),S=Rt,y=Dt,L=ne,b=we),(Ve.equals(T)===!1||C!==A)&&(n.blendColor(Ve.r,Ve.g,Ve.b,C),T.copy(Ve),A=C),u=et,M=!1}function qt(et,Kt){et.side===hn?J(n.CULL_FACE):W(n.CULL_FACE);let Rt=et.side===En;Kt&&(Rt=!Rt),tt(Rt),et.blending===Js&&et.transparent===!1?H(Xi):H(et.blending,et.blendEquation,et.blendSrc,et.blendDst,et.blendEquationAlpha,et.blendSrcAlpha,et.blendDstAlpha,et.blendColor,et.blendAlpha,et.premultipliedAlpha),o.setFunc(et.depthFunc),o.setTest(et.depthTest),o.setMask(et.depthWrite),r.setMask(et.colorWrite);let Dt=et.stencilWrite;a.setTest(Dt),Dt&&(a.setMask(et.stencilWriteMask),a.setFunc(et.stencilFunc,et.stencilRef,et.stencilFuncMask),a.setOp(et.stencilFail,et.stencilZFail,et.stencilZPass)),X(et.polygonOffset,et.polygonOffsetFactor,et.polygonOffsetUnits),et.alphaToCoverage===!0?W(n.SAMPLE_ALPHA_TO_COVERAGE):J(n.SAMPLE_ALPHA_TO_COVERAGE)}function tt(et){_!==et&&(et?n.frontFace(n.CW):n.frontFace(n.CCW),_=et)}function K(et){et!==gd?(W(n.CULL_FACE),et!==w&&(et===Bh?n.cullFace(n.BACK):et===yd?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK))):J(n.CULL_FACE),w=et}function Et(et){et!==P&&(N&&n.lineWidth(et),P=et)}function X(et,Kt,Rt){et?(W(n.POLYGON_OFFSET_FILL),(E!==Kt||F!==Rt)&&(n.polygonOffset(Kt,Rt),E=Kt,F=Rt)):J(n.POLYGON_OFFSET_FILL)}function Tt(et){et?W(n.SCISSOR_TEST):J(n.SCISSOR_TEST)}function B(et){et===void 0&&(et=n.TEXTURE0+R-1),Z!==et&&(n.activeTexture(et),Z=et)}function I(et,Kt,Rt){Rt===void 0&&(Z===null?Rt=n.TEXTURE0+R-1:Rt=Z);let Dt=Y[Rt];Dt===void 0&&(Dt={type:void 0,texture:void 0},Y[Rt]=Dt),(Dt.type!==et||Dt.texture!==Kt)&&(Z!==Rt&&(n.activeTexture(Rt),Z=Rt),n.bindTexture(et,Kt||q[et]),Dt.type=et,Dt.texture=Kt)}function ut(){let et=Y[Z];et!==void 0&&et.type!==void 0&&(n.bindTexture(et.type,null),et.type=void 0,et.texture=void 0)}function xt(){try{n.compressedTexImage2D.apply(n,arguments)}catch(et){console.error("THREE.WebGLState:",et)}}function Pt(){try{n.compressedTexImage3D.apply(n,arguments)}catch(et){console.error("THREE.WebGLState:",et)}}function At(){try{n.texSubImage2D.apply(n,arguments)}catch(et){console.error("THREE.WebGLState:",et)}}function jt(){try{n.texSubImage3D.apply(n,arguments)}catch(et){console.error("THREE.WebGLState:",et)}}function dt(){try{n.compressedTexSubImage2D.apply(n,arguments)}catch(et){console.error("THREE.WebGLState:",et)}}function ot(){try{n.compressedTexSubImage3D.apply(n,arguments)}catch(et){console.error("THREE.WebGLState:",et)}}function St(){try{n.texStorage2D.apply(n,arguments)}catch(et){console.error("THREE.WebGLState:",et)}}function ht(){try{n.texStorage3D.apply(n,arguments)}catch(et){console.error("THREE.WebGLState:",et)}}function yt(){try{n.texImage2D.apply(n,arguments)}catch(et){console.error("THREE.WebGLState:",et)}}function Yt(){try{n.texImage3D.apply(n,arguments)}catch(et){console.error("THREE.WebGLState:",et)}}function Gt(et){bt.equals(et)===!1&&(n.scissor(et.x,et.y,et.z,et.w),bt.copy(et))}function Wt(et){D.equals(et)===!1&&(n.viewport(et.x,et.y,et.z,et.w),D.copy(et))}function ae(et,Kt){let Rt=c.get(Kt);Rt===void 0&&(Rt=new WeakMap,c.set(Kt,Rt));let Dt=Rt.get(et);Dt===void 0&&(Dt=n.getUniformBlockIndex(Kt,et.name),Rt.set(et,Dt))}function ge(et,Kt){let Dt=c.get(Kt).get(et);l.get(Kt)!==Dt&&(n.uniformBlockBinding(Kt,Dt,et.__bindingPointIndex),l.set(Kt,Dt))}function Ie(){n.disable(n.BLEND),n.disable(n.CULL_FACE),n.disable(n.DEPTH_TEST),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SCISSOR_TEST),n.disable(n.STENCIL_TEST),n.disable(n.SAMPLE_ALPHA_TO_COVERAGE),n.blendEquation(n.FUNC_ADD),n.blendFunc(n.ONE,n.ZERO),n.blendFuncSeparate(n.ONE,n.ZERO,n.ONE,n.ZERO),n.blendColor(0,0,0,0),n.colorMask(!0,!0,!0,!0),n.clearColor(0,0,0,0),n.depthMask(!0),n.depthFunc(n.LESS),o.setReversed(!1),n.clearDepth(1),n.stencilMask(4294967295),n.stencilFunc(n.ALWAYS,0,4294967295),n.stencilOp(n.KEEP,n.KEEP,n.KEEP),n.clearStencil(0),n.cullFace(n.BACK),n.frontFace(n.CCW),n.polygonOffset(0,0),n.activeTexture(n.TEXTURE0),n.bindFramebuffer(n.FRAMEBUFFER,null),n.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),n.bindFramebuffer(n.READ_FRAMEBUFFER,null),n.useProgram(null),n.lineWidth(1),n.scissor(0,0,n.canvas.width,n.canvas.height),n.viewport(0,0,n.canvas.width,n.canvas.height),h={},Z=null,Y={},m={},g=new WeakMap,d=[],p=null,v=!1,u=null,f=null,S=null,y=null,x=null,L=null,b=null,T=new fe(0,0,0),A=0,M=!1,_=null,w=null,P=null,E=null,F=null,bt.set(0,0,n.canvas.width,n.canvas.height),D.set(0,0,n.canvas.width,n.canvas.height),r.reset(),o.reset(),a.reset()}return{buffers:{color:r,depth:o,stencil:a},enable:W,disable:J,bindFramebuffer:it,drawBuffers:Mt,useProgram:Ct,setBlending:H,setMaterial:qt,setFlipSided:tt,setCullFace:K,setLineWidth:Et,setPolygonOffset:X,setScissorTest:Tt,activeTexture:B,bindTexture:I,unbindTexture:ut,compressedTexImage2D:xt,compressedTexImage3D:Pt,texImage2D:yt,texImage3D:Yt,updateUBOMapping:ae,uniformBlockBinding:ge,texStorage2D:St,texStorage3D:ht,texSubImage2D:At,texSubImage3D:jt,compressedTexSubImage2D:dt,compressedTexSubImage3D:ot,scissor:Gt,viewport:Wt,reset:Ie}}function Bf(n,t,e,i){let s=rv(i);switch(e){case au:return n*t;case cu:return n*t;case hu:return n*t*2;case ch:return n*t/s.components*s.byteLength;case hh:return n*t/s.components*s.byteLength;case fu:return n*t*2/s.components*s.byteLength;case fh:return n*t*2/s.components*s.byteLength;case lu:return n*t*3/s.components*s.byteLength;case Wn:return n*t*4/s.components*s.byteLength;case uh:return n*t*4/s.components*s.byteLength;case Zo:case Jo:return Math.floor((n+3)/4)*Math.floor((t+3)/4)*8;case Ko:case jo:return Math.floor((n+3)/4)*Math.floor((t+3)/4)*16;case Zl:case Kl:return Math.max(n,16)*Math.max(t,8)/4;case Yl:case Jl:return Math.max(n,8)*Math.max(t,8)/2;case jl:case Ql:return Math.floor((n+3)/4)*Math.floor((t+3)/4)*8;case tc:return Math.floor((n+3)/4)*Math.floor((t+3)/4)*16;case ec:return Math.floor((n+3)/4)*Math.floor((t+3)/4)*16;case nc:return Math.floor((n+4)/5)*Math.floor((t+3)/4)*16;case ic:return Math.floor((n+4)/5)*Math.floor((t+4)/5)*16;case sc:return Math.floor((n+5)/6)*Math.floor((t+4)/5)*16;case rc:return Math.floor((n+5)/6)*Math.floor((t+5)/6)*16;case oc:return Math.floor((n+7)/8)*Math.floor((t+4)/5)*16;case ac:return Math.floor((n+7)/8)*Math.floor((t+5)/6)*16;case lc:return Math.floor((n+7)/8)*Math.floor((t+7)/8)*16;case cc:return Math.floor((n+9)/10)*Math.floor((t+4)/5)*16;case hc:return Math.floor((n+9)/10)*Math.floor((t+5)/6)*16;case fc:return Math.floor((n+9)/10)*Math.floor((t+7)/8)*16;case uc:return Math.floor((n+9)/10)*Math.floor((t+9)/10)*16;case dc:return Math.floor((n+11)/12)*Math.floor((t+9)/10)*16;case pc:return Math.floor((n+11)/12)*Math.floor((t+11)/12)*16;case Qo:case mc:case gc:return Math.ceil(n/4)*Math.ceil(t/4)*16;case uu:case yc:return Math.ceil(n/4)*Math.ceil(t/4)*8;case vc:case xc:return Math.ceil(n/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function rv(n){switch(n){case Ai:case su:return{byteLength:1,components:1};case zr:case ru:case Qr:return{byteLength:2,components:1};case ah:case lh:return{byteLength:2,components:4};case ys:case oh:case di:return{byteLength:4,components:1};case ou:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${n}.`)}function ov(n,t,e,i,s,r,o){let a=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new Ht,h=new WeakMap,m,g=new WeakMap,d=!1;try{d=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function p(B,I){return d?new OffscreenCanvas(B,I):na("canvas")}function v(B,I,ut){let xt=1,Pt=Tt(B);if((Pt.width>ut||Pt.height>ut)&&(xt=ut/Math.max(Pt.width,Pt.height)),xt<1)if(typeof HTMLImageElement<"u"&&B instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&B instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&B instanceof ImageBitmap||typeof VideoFrame<"u"&&B instanceof VideoFrame){let At=Math.floor(xt*Pt.width),jt=Math.floor(xt*Pt.height);m===void 0&&(m=p(At,jt));let dt=I?p(At,jt):m;return dt.width=At,dt.height=jt,dt.getContext("2d").drawImage(B,0,0,At,jt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+Pt.width+"x"+Pt.height+") to ("+At+"x"+jt+")."),dt}else return"data"in B&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+Pt.width+"x"+Pt.height+")."),B;return B}function u(B){return B.generateMipmaps}function f(B){n.generateMipmap(B)}function S(B){return B.isWebGLCubeRenderTarget?n.TEXTURE_CUBE_MAP:B.isWebGL3DRenderTarget?n.TEXTURE_3D:B.isWebGLArrayRenderTarget||B.isCompressedArrayTexture?n.TEXTURE_2D_ARRAY:n.TEXTURE_2D}function y(B,I,ut,xt,Pt=!1){if(B!==null){if(n[B]!==void 0)return n[B];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+B+"'")}let At=I;if(I===n.RED&&(ut===n.FLOAT&&(At=n.R32F),ut===n.HALF_FLOAT&&(At=n.R16F),ut===n.UNSIGNED_BYTE&&(At=n.R8)),I===n.RED_INTEGER&&(ut===n.UNSIGNED_BYTE&&(At=n.R8UI),ut===n.UNSIGNED_SHORT&&(At=n.R16UI),ut===n.UNSIGNED_INT&&(At=n.R32UI),ut===n.BYTE&&(At=n.R8I),ut===n.SHORT&&(At=n.R16I),ut===n.INT&&(At=n.R32I)),I===n.RG&&(ut===n.FLOAT&&(At=n.RG32F),ut===n.HALF_FLOAT&&(At=n.RG16F),ut===n.UNSIGNED_BYTE&&(At=n.RG8)),I===n.RG_INTEGER&&(ut===n.UNSIGNED_BYTE&&(At=n.RG8UI),ut===n.UNSIGNED_SHORT&&(At=n.RG16UI),ut===n.UNSIGNED_INT&&(At=n.RG32UI),ut===n.BYTE&&(At=n.RG8I),ut===n.SHORT&&(At=n.RG16I),ut===n.INT&&(At=n.RG32I)),I===n.RGB_INTEGER&&(ut===n.UNSIGNED_BYTE&&(At=n.RGB8UI),ut===n.UNSIGNED_SHORT&&(At=n.RGB16UI),ut===n.UNSIGNED_INT&&(At=n.RGB32UI),ut===n.BYTE&&(At=n.RGB8I),ut===n.SHORT&&(At=n.RGB16I),ut===n.INT&&(At=n.RGB32I)),I===n.RGBA_INTEGER&&(ut===n.UNSIGNED_BYTE&&(At=n.RGBA8UI),ut===n.UNSIGNED_SHORT&&(At=n.RGBA16UI),ut===n.UNSIGNED_INT&&(At=n.RGBA32UI),ut===n.BYTE&&(At=n.RGBA8I),ut===n.SHORT&&(At=n.RGBA16I),ut===n.INT&&(At=n.RGBA32I)),I===n.RGB&&ut===n.UNSIGNED_INT_5_9_9_9_REV&&(At=n.RGB9_E5),I===n.RGBA){let jt=Pt?Na:Be.getTransfer(xt);ut===n.FLOAT&&(At=n.RGBA32F),ut===n.HALF_FLOAT&&(At=n.RGBA16F),ut===n.UNSIGNED_BYTE&&(At=jt===Xe?n.SRGB8_ALPHA8:n.RGBA8),ut===n.UNSIGNED_SHORT_4_4_4_4&&(At=n.RGBA4),ut===n.UNSIGNED_SHORT_5_5_5_1&&(At=n.RGB5_A1)}return(At===n.R16F||At===n.R32F||At===n.RG16F||At===n.RG32F||At===n.RGBA16F||At===n.RGBA32F)&&t.get("EXT_color_buffer_float"),At}function x(B,I){let ut;return B?I===null||I===ys||I===ir?ut=n.DEPTH24_STENCIL8:I===di?ut=n.DEPTH32F_STENCIL8:I===zr&&(ut=n.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):I===null||I===ys||I===ir?ut=n.DEPTH_COMPONENT24:I===di?ut=n.DEPTH_COMPONENT32F:I===zr&&(ut=n.DEPTH_COMPONENT16),ut}function L(B,I){return u(B)===!0||B.isFramebufferTexture&&B.minFilter!==Un&&B.minFilter!==ui?Math.log2(Math.max(I.width,I.height))+1:B.mipmaps!==void 0&&B.mipmaps.length>0?B.mipmaps.length:B.isCompressedTexture&&Array.isArray(B.image)?I.mipmaps.length:1}function b(B){let I=B.target;I.removeEventListener("dispose",b),A(I),I.isVideoTexture&&h.delete(I)}function T(B){let I=B.target;I.removeEventListener("dispose",T),_(I)}function A(B){let I=i.get(B);if(I.__webglInit===void 0)return;let ut=B.source,xt=g.get(ut);if(xt){let Pt=xt[I.__cacheKey];Pt.usedTimes--,Pt.usedTimes===0&&M(B),Object.keys(xt).length===0&&g.delete(ut)}i.remove(B)}function M(B){let I=i.get(B);n.deleteTexture(I.__webglTexture);let ut=B.source,xt=g.get(ut);delete xt[I.__cacheKey],o.memory.textures--}function _(B){let I=i.get(B);if(B.depthTexture&&(B.depthTexture.dispose(),i.remove(B.depthTexture)),B.isWebGLCubeRenderTarget)for(let xt=0;xt<6;xt++){if(Array.isArray(I.__webglFramebuffer[xt]))for(let Pt=0;Pt<I.__webglFramebuffer[xt].length;Pt++)n.deleteFramebuffer(I.__webglFramebuffer[xt][Pt]);else n.deleteFramebuffer(I.__webglFramebuffer[xt]);I.__webglDepthbuffer&&n.deleteRenderbuffer(I.__webglDepthbuffer[xt])}else{if(Array.isArray(I.__webglFramebuffer))for(let xt=0;xt<I.__webglFramebuffer.length;xt++)n.deleteFramebuffer(I.__webglFramebuffer[xt]);else n.deleteFramebuffer(I.__webglFramebuffer);if(I.__webglDepthbuffer&&n.deleteRenderbuffer(I.__webglDepthbuffer),I.__webglMultisampledFramebuffer&&n.deleteFramebuffer(I.__webglMultisampledFramebuffer),I.__webglColorRenderbuffer)for(let xt=0;xt<I.__webglColorRenderbuffer.length;xt++)I.__webglColorRenderbuffer[xt]&&n.deleteRenderbuffer(I.__webglColorRenderbuffer[xt]);I.__webglDepthRenderbuffer&&n.deleteRenderbuffer(I.__webglDepthRenderbuffer)}let ut=B.textures;for(let xt=0,Pt=ut.length;xt<Pt;xt++){let At=i.get(ut[xt]);At.__webglTexture&&(n.deleteTexture(At.__webglTexture),o.memory.textures--),i.remove(ut[xt])}i.remove(B)}let w=0;function P(){w=0}function E(){let B=w;return B>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+B+" texture units while this GPU supports only "+s.maxTextures),w+=1,B}function F(B){let I=[];return I.push(B.wrapS),I.push(B.wrapT),I.push(B.wrapR||0),I.push(B.magFilter),I.push(B.minFilter),I.push(B.anisotropy),I.push(B.internalFormat),I.push(B.format),I.push(B.type),I.push(B.generateMipmaps),I.push(B.premultiplyAlpha),I.push(B.flipY),I.push(B.unpackAlignment),I.push(B.colorSpace),I.join()}function R(B,I){let ut=i.get(B);if(B.isVideoTexture&&Et(B),B.isRenderTargetTexture===!1&&B.version>0&&ut.__version!==B.version){let xt=B.image;if(xt===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(xt.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{D(ut,B,I);return}}e.bindTexture(n.TEXTURE_2D,ut.__webglTexture,n.TEXTURE0+I)}function N(B,I){let ut=i.get(B);if(B.version>0&&ut.__version!==B.version){D(ut,B,I);return}e.bindTexture(n.TEXTURE_2D_ARRAY,ut.__webglTexture,n.TEXTURE0+I)}function U(B,I){let ut=i.get(B);if(B.version>0&&ut.__version!==B.version){D(ut,B,I);return}e.bindTexture(n.TEXTURE_3D,ut.__webglTexture,n.TEXTURE0+I)}function z(B,I){let ut=i.get(B);if(B.version>0&&ut.__version!==B.version){G(ut,B,I);return}e.bindTexture(n.TEXTURE_CUBE_MAP,ut.__webglTexture,n.TEXTURE0+I)}let Z={[gs]:n.REPEAT,[ps]:n.CLAMP_TO_EDGE,[ql]:n.MIRRORED_REPEAT},Y={[Un]:n.NEAREST,[$d]:n.NEAREST_MIPMAP_NEAREST,[vo]:n.NEAREST_MIPMAP_LINEAR,[ui]:n.LINEAR,[nl]:n.LINEAR_MIPMAP_NEAREST,[ms]:n.LINEAR_MIPMAP_LINEAR},k={[Zd]:n.NEVER,[ep]:n.ALWAYS,[Jd]:n.LESS,[pu]:n.LEQUAL,[Kd]:n.EQUAL,[tp]:n.GEQUAL,[jd]:n.GREATER,[Qd]:n.NOTEQUAL};function mt(B,I){if(I.type===di&&t.has("OES_texture_float_linear")===!1&&(I.magFilter===ui||I.magFilter===nl||I.magFilter===vo||I.magFilter===ms||I.minFilter===ui||I.minFilter===nl||I.minFilter===vo||I.minFilter===ms)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),n.texParameteri(B,n.TEXTURE_WRAP_S,Z[I.wrapS]),n.texParameteri(B,n.TEXTURE_WRAP_T,Z[I.wrapT]),(B===n.TEXTURE_3D||B===n.TEXTURE_2D_ARRAY)&&n.texParameteri(B,n.TEXTURE_WRAP_R,Z[I.wrapR]),n.texParameteri(B,n.TEXTURE_MAG_FILTER,Y[I.magFilter]),n.texParameteri(B,n.TEXTURE_MIN_FILTER,Y[I.minFilter]),I.compareFunction&&(n.texParameteri(B,n.TEXTURE_COMPARE_MODE,n.COMPARE_REF_TO_TEXTURE),n.texParameteri(B,n.TEXTURE_COMPARE_FUNC,k[I.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(I.magFilter===Un||I.minFilter!==vo&&I.minFilter!==ms||I.type===di&&t.has("OES_texture_float_linear")===!1)return;if(I.anisotropy>1||i.get(I).__currentAnisotropy){let ut=t.get("EXT_texture_filter_anisotropic");n.texParameterf(B,ut.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(I.anisotropy,s.getMaxAnisotropy())),i.get(I).__currentAnisotropy=I.anisotropy}}}function bt(B,I){let ut=!1;B.__webglInit===void 0&&(B.__webglInit=!0,I.addEventListener("dispose",b));let xt=I.source,Pt=g.get(xt);Pt===void 0&&(Pt={},g.set(xt,Pt));let At=F(I);if(At!==B.__cacheKey){Pt[At]===void 0&&(Pt[At]={texture:n.createTexture(),usedTimes:0},o.memory.textures++,ut=!0),Pt[At].usedTimes++;let jt=Pt[B.__cacheKey];jt!==void 0&&(Pt[B.__cacheKey].usedTimes--,jt.usedTimes===0&&M(I)),B.__cacheKey=At,B.__webglTexture=Pt[At].texture}return ut}function D(B,I,ut){let xt=n.TEXTURE_2D;(I.isDataArrayTexture||I.isCompressedArrayTexture)&&(xt=n.TEXTURE_2D_ARRAY),I.isData3DTexture&&(xt=n.TEXTURE_3D);let Pt=bt(B,I),At=I.source;e.bindTexture(xt,B.__webglTexture,n.TEXTURE0+ut);let jt=i.get(At);if(At.version!==jt.__version||Pt===!0){e.activeTexture(n.TEXTURE0+ut);let dt=Be.getPrimaries(Be.workingColorSpace),ot=I.colorSpace===Wi?null:Be.getPrimaries(I.colorSpace),St=I.colorSpace===Wi||dt===ot?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,I.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,I.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,I.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,St);let ht=v(I.image,!1,s.maxTextureSize);ht=X(I,ht);let yt=r.convert(I.format,I.colorSpace),Yt=r.convert(I.type),Gt=y(I.internalFormat,yt,Yt,I.colorSpace,I.isVideoTexture);mt(xt,I);let Wt,ae=I.mipmaps,ge=I.isVideoTexture!==!0,Ie=jt.__version===void 0||Pt===!0,et=At.dataReady,Kt=L(I,ht);if(I.isDepthTexture)Gt=x(I.format===sr,I.type),Ie&&(ge?e.texStorage2D(n.TEXTURE_2D,1,Gt,ht.width,ht.height):e.texImage2D(n.TEXTURE_2D,0,Gt,ht.width,ht.height,0,yt,Yt,null));else if(I.isDataTexture)if(ae.length>0){ge&&Ie&&e.texStorage2D(n.TEXTURE_2D,Kt,Gt,ae[0].width,ae[0].height);for(let Rt=0,Dt=ae.length;Rt<Dt;Rt++)Wt=ae[Rt],ge?et&&e.texSubImage2D(n.TEXTURE_2D,Rt,0,0,Wt.width,Wt.height,yt,Yt,Wt.data):e.texImage2D(n.TEXTURE_2D,Rt,Gt,Wt.width,Wt.height,0,yt,Yt,Wt.data);I.generateMipmaps=!1}else ge?(Ie&&e.texStorage2D(n.TEXTURE_2D,Kt,Gt,ht.width,ht.height),et&&e.texSubImage2D(n.TEXTURE_2D,0,0,0,ht.width,ht.height,yt,Yt,ht.data)):e.texImage2D(n.TEXTURE_2D,0,Gt,ht.width,ht.height,0,yt,Yt,ht.data);else if(I.isCompressedTexture)if(I.isCompressedArrayTexture){ge&&Ie&&e.texStorage3D(n.TEXTURE_2D_ARRAY,Kt,Gt,ae[0].width,ae[0].height,ht.depth);for(let Rt=0,Dt=ae.length;Rt<Dt;Rt++)if(Wt=ae[Rt],I.format!==Wn)if(yt!==null)if(ge){if(et)if(I.layerUpdates.size>0){let ee=Bf(Wt.width,Wt.height,I.format,I.type);for(let ne of I.layerUpdates){let we=Wt.data.subarray(ne*ee/Wt.data.BYTES_PER_ELEMENT,(ne+1)*ee/Wt.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,Rt,0,0,ne,Wt.width,Wt.height,1,yt,we)}I.clearLayerUpdates()}else e.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,Rt,0,0,0,Wt.width,Wt.height,ht.depth,yt,Wt.data)}else e.compressedTexImage3D(n.TEXTURE_2D_ARRAY,Rt,Gt,Wt.width,Wt.height,ht.depth,0,Wt.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else ge?et&&e.texSubImage3D(n.TEXTURE_2D_ARRAY,Rt,0,0,0,Wt.width,Wt.height,ht.depth,yt,Yt,Wt.data):e.texImage3D(n.TEXTURE_2D_ARRAY,Rt,Gt,Wt.width,Wt.height,ht.depth,0,yt,Yt,Wt.data)}else{ge&&Ie&&e.texStorage2D(n.TEXTURE_2D,Kt,Gt,ae[0].width,ae[0].height);for(let Rt=0,Dt=ae.length;Rt<Dt;Rt++)Wt=ae[Rt],I.format!==Wn?yt!==null?ge?et&&e.compressedTexSubImage2D(n.TEXTURE_2D,Rt,0,0,Wt.width,Wt.height,yt,Wt.data):e.compressedTexImage2D(n.TEXTURE_2D,Rt,Gt,Wt.width,Wt.height,0,Wt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ge?et&&e.texSubImage2D(n.TEXTURE_2D,Rt,0,0,Wt.width,Wt.height,yt,Yt,Wt.data):e.texImage2D(n.TEXTURE_2D,Rt,Gt,Wt.width,Wt.height,0,yt,Yt,Wt.data)}else if(I.isDataArrayTexture)if(ge){if(Ie&&e.texStorage3D(n.TEXTURE_2D_ARRAY,Kt,Gt,ht.width,ht.height,ht.depth),et)if(I.layerUpdates.size>0){let Rt=Bf(ht.width,ht.height,I.format,I.type);for(let Dt of I.layerUpdates){let ee=ht.data.subarray(Dt*Rt/ht.data.BYTES_PER_ELEMENT,(Dt+1)*Rt/ht.data.BYTES_PER_ELEMENT);e.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,Dt,ht.width,ht.height,1,yt,Yt,ee)}I.clearLayerUpdates()}else e.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,0,ht.width,ht.height,ht.depth,yt,Yt,ht.data)}else e.texImage3D(n.TEXTURE_2D_ARRAY,0,Gt,ht.width,ht.height,ht.depth,0,yt,Yt,ht.data);else if(I.isData3DTexture)ge?(Ie&&e.texStorage3D(n.TEXTURE_3D,Kt,Gt,ht.width,ht.height,ht.depth),et&&e.texSubImage3D(n.TEXTURE_3D,0,0,0,0,ht.width,ht.height,ht.depth,yt,Yt,ht.data)):e.texImage3D(n.TEXTURE_3D,0,Gt,ht.width,ht.height,ht.depth,0,yt,Yt,ht.data);else if(I.isFramebufferTexture){if(Ie)if(ge)e.texStorage2D(n.TEXTURE_2D,Kt,Gt,ht.width,ht.height);else{let Rt=ht.width,Dt=ht.height;for(let ee=0;ee<Kt;ee++)e.texImage2D(n.TEXTURE_2D,ee,Gt,Rt,Dt,0,yt,Yt,null),Rt>>=1,Dt>>=1}}else if(ae.length>0){if(ge&&Ie){let Rt=Tt(ae[0]);e.texStorage2D(n.TEXTURE_2D,Kt,Gt,Rt.width,Rt.height)}for(let Rt=0,Dt=ae.length;Rt<Dt;Rt++)Wt=ae[Rt],ge?et&&e.texSubImage2D(n.TEXTURE_2D,Rt,0,0,yt,Yt,Wt):e.texImage2D(n.TEXTURE_2D,Rt,Gt,yt,Yt,Wt);I.generateMipmaps=!1}else if(ge){if(Ie){let Rt=Tt(ht);e.texStorage2D(n.TEXTURE_2D,Kt,Gt,Rt.width,Rt.height)}et&&e.texSubImage2D(n.TEXTURE_2D,0,0,0,yt,Yt,ht)}else e.texImage2D(n.TEXTURE_2D,0,Gt,yt,Yt,ht);u(I)&&f(xt),jt.__version=At.version,I.onUpdate&&I.onUpdate(I)}B.__version=I.version}function G(B,I,ut){if(I.image.length!==6)return;let xt=bt(B,I),Pt=I.source;e.bindTexture(n.TEXTURE_CUBE_MAP,B.__webglTexture,n.TEXTURE0+ut);let At=i.get(Pt);if(Pt.version!==At.__version||xt===!0){e.activeTexture(n.TEXTURE0+ut);let jt=Be.getPrimaries(Be.workingColorSpace),dt=I.colorSpace===Wi?null:Be.getPrimaries(I.colorSpace),ot=I.colorSpace===Wi||jt===dt?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,I.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,I.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,I.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,ot);let St=I.isCompressedTexture||I.image[0].isCompressedTexture,ht=I.image[0]&&I.image[0].isDataTexture,yt=[];for(let Dt=0;Dt<6;Dt++)!St&&!ht?yt[Dt]=v(I.image[Dt],!0,s.maxCubemapSize):yt[Dt]=ht?I.image[Dt].image:I.image[Dt],yt[Dt]=X(I,yt[Dt]);let Yt=yt[0],Gt=r.convert(I.format,I.colorSpace),Wt=r.convert(I.type),ae=y(I.internalFormat,Gt,Wt,I.colorSpace),ge=I.isVideoTexture!==!0,Ie=At.__version===void 0||xt===!0,et=Pt.dataReady,Kt=L(I,Yt);mt(n.TEXTURE_CUBE_MAP,I);let Rt;if(St){ge&&Ie&&e.texStorage2D(n.TEXTURE_CUBE_MAP,Kt,ae,Yt.width,Yt.height);for(let Dt=0;Dt<6;Dt++){Rt=yt[Dt].mipmaps;for(let ee=0;ee<Rt.length;ee++){let ne=Rt[ee];I.format!==Wn?Gt!==null?ge?et&&e.compressedTexSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Dt,ee,0,0,ne.width,ne.height,Gt,ne.data):e.compressedTexImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Dt,ee,ae,ne.width,ne.height,0,ne.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):ge?et&&e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Dt,ee,0,0,ne.width,ne.height,Gt,Wt,ne.data):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Dt,ee,ae,ne.width,ne.height,0,Gt,Wt,ne.data)}}}else{if(Rt=I.mipmaps,ge&&Ie){Rt.length>0&&Kt++;let Dt=Tt(yt[0]);e.texStorage2D(n.TEXTURE_CUBE_MAP,Kt,ae,Dt.width,Dt.height)}for(let Dt=0;Dt<6;Dt++)if(ht){ge?et&&e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Dt,0,0,0,yt[Dt].width,yt[Dt].height,Gt,Wt,yt[Dt].data):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Dt,0,ae,yt[Dt].width,yt[Dt].height,0,Gt,Wt,yt[Dt].data);for(let ee=0;ee<Rt.length;ee++){let we=Rt[ee].image[Dt].image;ge?et&&e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Dt,ee+1,0,0,we.width,we.height,Gt,Wt,we.data):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Dt,ee+1,ae,we.width,we.height,0,Gt,Wt,we.data)}}else{ge?et&&e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Dt,0,0,0,Gt,Wt,yt[Dt]):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Dt,0,ae,Gt,Wt,yt[Dt]);for(let ee=0;ee<Rt.length;ee++){let ne=Rt[ee];ge?et&&e.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Dt,ee+1,0,0,Gt,Wt,ne.image[Dt]):e.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Dt,ee+1,ae,Gt,Wt,ne.image[Dt])}}}u(I)&&f(n.TEXTURE_CUBE_MAP),At.__version=Pt.version,I.onUpdate&&I.onUpdate(I)}B.__version=I.version}function q(B,I,ut,xt,Pt,At){let jt=r.convert(ut.format,ut.colorSpace),dt=r.convert(ut.type),ot=y(ut.internalFormat,jt,dt,ut.colorSpace),St=i.get(I),ht=i.get(ut);if(ht.__renderTarget=I,!St.__hasExternalTextures){let yt=Math.max(1,I.width>>At),Yt=Math.max(1,I.height>>At);Pt===n.TEXTURE_3D||Pt===n.TEXTURE_2D_ARRAY?e.texImage3D(Pt,At,ot,yt,Yt,I.depth,0,jt,dt,null):e.texImage2D(Pt,At,ot,yt,Yt,0,jt,dt,null)}e.bindFramebuffer(n.FRAMEBUFFER,B),K(I)?a.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,xt,Pt,ht.__webglTexture,0,tt(I)):(Pt===n.TEXTURE_2D||Pt>=n.TEXTURE_CUBE_MAP_POSITIVE_X&&Pt<=n.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&n.framebufferTexture2D(n.FRAMEBUFFER,xt,Pt,ht.__webglTexture,At),e.bindFramebuffer(n.FRAMEBUFFER,null)}function W(B,I,ut){if(n.bindRenderbuffer(n.RENDERBUFFER,B),I.depthBuffer){let xt=I.depthTexture,Pt=xt&&xt.isDepthTexture?xt.type:null,At=x(I.stencilBuffer,Pt),jt=I.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,dt=tt(I);K(I)?a.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,dt,At,I.width,I.height):ut?n.renderbufferStorageMultisample(n.RENDERBUFFER,dt,At,I.width,I.height):n.renderbufferStorage(n.RENDERBUFFER,At,I.width,I.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,jt,n.RENDERBUFFER,B)}else{let xt=I.textures;for(let Pt=0;Pt<xt.length;Pt++){let At=xt[Pt],jt=r.convert(At.format,At.colorSpace),dt=r.convert(At.type),ot=y(At.internalFormat,jt,dt,At.colorSpace),St=tt(I);ut&&K(I)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,St,ot,I.width,I.height):K(I)?a.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,St,ot,I.width,I.height):n.renderbufferStorage(n.RENDERBUFFER,ot,I.width,I.height)}}n.bindRenderbuffer(n.RENDERBUFFER,null)}function J(B,I){if(I&&I.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(n.FRAMEBUFFER,B),!(I.depthTexture&&I.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");let xt=i.get(I.depthTexture);xt.__renderTarget=I,(!xt.__webglTexture||I.depthTexture.image.width!==I.width||I.depthTexture.image.height!==I.height)&&(I.depthTexture.image.width=I.width,I.depthTexture.image.height=I.height,I.depthTexture.needsUpdate=!0),R(I.depthTexture,0);let Pt=xt.__webglTexture,At=tt(I);if(I.depthTexture.format===Ks)K(I)?a.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,Pt,0,At):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,Pt,0);else if(I.depthTexture.format===sr)K(I)?a.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,Pt,0,At):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,Pt,0);else throw new Error("Unknown depthTexture format")}function it(B){let I=i.get(B),ut=B.isWebGLCubeRenderTarget===!0;if(I.__boundDepthTexture!==B.depthTexture){let xt=B.depthTexture;if(I.__depthDisposeCallback&&I.__depthDisposeCallback(),xt){let Pt=()=>{delete I.__boundDepthTexture,delete I.__depthDisposeCallback,xt.removeEventListener("dispose",Pt)};xt.addEventListener("dispose",Pt),I.__depthDisposeCallback=Pt}I.__boundDepthTexture=xt}if(B.depthTexture&&!I.__autoAllocateDepthBuffer){if(ut)throw new Error("target.depthTexture not supported in Cube render targets");J(I.__webglFramebuffer,B)}else if(ut){I.__webglDepthbuffer=[];for(let xt=0;xt<6;xt++)if(e.bindFramebuffer(n.FRAMEBUFFER,I.__webglFramebuffer[xt]),I.__webglDepthbuffer[xt]===void 0)I.__webglDepthbuffer[xt]=n.createRenderbuffer(),W(I.__webglDepthbuffer[xt],B,!1);else{let Pt=B.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,At=I.__webglDepthbuffer[xt];n.bindRenderbuffer(n.RENDERBUFFER,At),n.framebufferRenderbuffer(n.FRAMEBUFFER,Pt,n.RENDERBUFFER,At)}}else if(e.bindFramebuffer(n.FRAMEBUFFER,I.__webglFramebuffer),I.__webglDepthbuffer===void 0)I.__webglDepthbuffer=n.createRenderbuffer(),W(I.__webglDepthbuffer,B,!1);else{let xt=B.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,Pt=I.__webglDepthbuffer;n.bindRenderbuffer(n.RENDERBUFFER,Pt),n.framebufferRenderbuffer(n.FRAMEBUFFER,xt,n.RENDERBUFFER,Pt)}e.bindFramebuffer(n.FRAMEBUFFER,null)}function Mt(B,I,ut){let xt=i.get(B);I!==void 0&&q(xt.__webglFramebuffer,B,B.texture,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,0),ut!==void 0&&it(B)}function Ct(B){let I=B.texture,ut=i.get(B),xt=i.get(I);B.addEventListener("dispose",T);let Pt=B.textures,At=B.isWebGLCubeRenderTarget===!0,jt=Pt.length>1;if(jt||(xt.__webglTexture===void 0&&(xt.__webglTexture=n.createTexture()),xt.__version=I.version,o.memory.textures++),At){ut.__webglFramebuffer=[];for(let dt=0;dt<6;dt++)if(I.mipmaps&&I.mipmaps.length>0){ut.__webglFramebuffer[dt]=[];for(let ot=0;ot<I.mipmaps.length;ot++)ut.__webglFramebuffer[dt][ot]=n.createFramebuffer()}else ut.__webglFramebuffer[dt]=n.createFramebuffer()}else{if(I.mipmaps&&I.mipmaps.length>0){ut.__webglFramebuffer=[];for(let dt=0;dt<I.mipmaps.length;dt++)ut.__webglFramebuffer[dt]=n.createFramebuffer()}else ut.__webglFramebuffer=n.createFramebuffer();if(jt)for(let dt=0,ot=Pt.length;dt<ot;dt++){let St=i.get(Pt[dt]);St.__webglTexture===void 0&&(St.__webglTexture=n.createTexture(),o.memory.textures++)}if(B.samples>0&&K(B)===!1){ut.__webglMultisampledFramebuffer=n.createFramebuffer(),ut.__webglColorRenderbuffer=[],e.bindFramebuffer(n.FRAMEBUFFER,ut.__webglMultisampledFramebuffer);for(let dt=0;dt<Pt.length;dt++){let ot=Pt[dt];ut.__webglColorRenderbuffer[dt]=n.createRenderbuffer(),n.bindRenderbuffer(n.RENDERBUFFER,ut.__webglColorRenderbuffer[dt]);let St=r.convert(ot.format,ot.colorSpace),ht=r.convert(ot.type),yt=y(ot.internalFormat,St,ht,ot.colorSpace,B.isXRRenderTarget===!0),Yt=tt(B);n.renderbufferStorageMultisample(n.RENDERBUFFER,Yt,yt,B.width,B.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+dt,n.RENDERBUFFER,ut.__webglColorRenderbuffer[dt])}n.bindRenderbuffer(n.RENDERBUFFER,null),B.depthBuffer&&(ut.__webglDepthRenderbuffer=n.createRenderbuffer(),W(ut.__webglDepthRenderbuffer,B,!0)),e.bindFramebuffer(n.FRAMEBUFFER,null)}}if(At){e.bindTexture(n.TEXTURE_CUBE_MAP,xt.__webglTexture),mt(n.TEXTURE_CUBE_MAP,I);for(let dt=0;dt<6;dt++)if(I.mipmaps&&I.mipmaps.length>0)for(let ot=0;ot<I.mipmaps.length;ot++)q(ut.__webglFramebuffer[dt][ot],B,I,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+dt,ot);else q(ut.__webglFramebuffer[dt],B,I,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+dt,0);u(I)&&f(n.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(jt){for(let dt=0,ot=Pt.length;dt<ot;dt++){let St=Pt[dt],ht=i.get(St);e.bindTexture(n.TEXTURE_2D,ht.__webglTexture),mt(n.TEXTURE_2D,St),q(ut.__webglFramebuffer,B,St,n.COLOR_ATTACHMENT0+dt,n.TEXTURE_2D,0),u(St)&&f(n.TEXTURE_2D)}e.unbindTexture()}else{let dt=n.TEXTURE_2D;if((B.isWebGL3DRenderTarget||B.isWebGLArrayRenderTarget)&&(dt=B.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY),e.bindTexture(dt,xt.__webglTexture),mt(dt,I),I.mipmaps&&I.mipmaps.length>0)for(let ot=0;ot<I.mipmaps.length;ot++)q(ut.__webglFramebuffer[ot],B,I,n.COLOR_ATTACHMENT0,dt,ot);else q(ut.__webglFramebuffer,B,I,n.COLOR_ATTACHMENT0,dt,0);u(I)&&f(dt),e.unbindTexture()}B.depthBuffer&&it(B)}function nt(B){let I=B.textures;for(let ut=0,xt=I.length;ut<xt;ut++){let Pt=I[ut];if(u(Pt)){let At=S(B),jt=i.get(Pt).__webglTexture;e.bindTexture(At,jt),f(At),e.unbindTexture()}}}let pt=[],H=[];function qt(B){if(B.samples>0){if(K(B)===!1){let I=B.textures,ut=B.width,xt=B.height,Pt=n.COLOR_BUFFER_BIT,At=B.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,jt=i.get(B),dt=I.length>1;if(dt)for(let ot=0;ot<I.length;ot++)e.bindFramebuffer(n.FRAMEBUFFER,jt.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+ot,n.RENDERBUFFER,null),e.bindFramebuffer(n.FRAMEBUFFER,jt.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+ot,n.TEXTURE_2D,null,0);e.bindFramebuffer(n.READ_FRAMEBUFFER,jt.__webglMultisampledFramebuffer),e.bindFramebuffer(n.DRAW_FRAMEBUFFER,jt.__webglFramebuffer);for(let ot=0;ot<I.length;ot++){if(B.resolveDepthBuffer&&(B.depthBuffer&&(Pt|=n.DEPTH_BUFFER_BIT),B.stencilBuffer&&B.resolveStencilBuffer&&(Pt|=n.STENCIL_BUFFER_BIT)),dt){n.framebufferRenderbuffer(n.READ_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.RENDERBUFFER,jt.__webglColorRenderbuffer[ot]);let St=i.get(I[ot]).__webglTexture;n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,St,0)}n.blitFramebuffer(0,0,ut,xt,0,0,ut,xt,Pt,n.NEAREST),l===!0&&(pt.length=0,H.length=0,pt.push(n.COLOR_ATTACHMENT0+ot),B.depthBuffer&&B.resolveDepthBuffer===!1&&(pt.push(At),H.push(At),n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,H)),n.invalidateFramebuffer(n.READ_FRAMEBUFFER,pt))}if(e.bindFramebuffer(n.READ_FRAMEBUFFER,null),e.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),dt)for(let ot=0;ot<I.length;ot++){e.bindFramebuffer(n.FRAMEBUFFER,jt.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+ot,n.RENDERBUFFER,jt.__webglColorRenderbuffer[ot]);let St=i.get(I[ot]).__webglTexture;e.bindFramebuffer(n.FRAMEBUFFER,jt.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+ot,n.TEXTURE_2D,St,0)}e.bindFramebuffer(n.DRAW_FRAMEBUFFER,jt.__webglMultisampledFramebuffer)}else if(B.depthBuffer&&B.resolveDepthBuffer===!1&&l){let I=B.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT;n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,[I])}}}function tt(B){return Math.min(s.maxSamples,B.samples)}function K(B){let I=i.get(B);return B.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&I.__useRenderToTexture!==!1}function Et(B){let I=o.render.frame;h.get(B)!==I&&(h.set(B,I),B.update())}function X(B,I){let ut=B.colorSpace,xt=B.format,Pt=B.type;return B.isCompressedTexture===!0||B.isVideoTexture===!0||ut!==hr&&ut!==Wi&&(Be.getTransfer(ut)===Xe?(xt!==Wn||Pt!==Ai)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",ut)),I}function Tt(B){return typeof HTMLImageElement<"u"&&B instanceof HTMLImageElement?(c.width=B.naturalWidth||B.width,c.height=B.naturalHeight||B.height):typeof VideoFrame<"u"&&B instanceof VideoFrame?(c.width=B.displayWidth,c.height=B.displayHeight):(c.width=B.width,c.height=B.height),c}this.allocateTextureUnit=E,this.resetTextureUnits=P,this.setTexture2D=R,this.setTexture2DArray=N,this.setTexture3D=U,this.setTextureCube=z,this.rebindTextures=Mt,this.setupRenderTarget=Ct,this.updateRenderTargetMipmap=nt,this.updateMultisampleRenderTarget=qt,this.setupDepthRenderbuffer=it,this.setupFrameBufferTexture=q,this.useMultisampledRTT=K}function av(n,t){function e(i,s=Wi){let r,o=Be.getTransfer(s);if(i===Ai)return n.UNSIGNED_BYTE;if(i===ah)return n.UNSIGNED_SHORT_4_4_4_4;if(i===lh)return n.UNSIGNED_SHORT_5_5_5_1;if(i===ou)return n.UNSIGNED_INT_5_9_9_9_REV;if(i===su)return n.BYTE;if(i===ru)return n.SHORT;if(i===zr)return n.UNSIGNED_SHORT;if(i===oh)return n.INT;if(i===ys)return n.UNSIGNED_INT;if(i===di)return n.FLOAT;if(i===Qr)return n.HALF_FLOAT;if(i===au)return n.ALPHA;if(i===lu)return n.RGB;if(i===Wn)return n.RGBA;if(i===cu)return n.LUMINANCE;if(i===hu)return n.LUMINANCE_ALPHA;if(i===Ks)return n.DEPTH_COMPONENT;if(i===sr)return n.DEPTH_STENCIL;if(i===ch)return n.RED;if(i===hh)return n.RED_INTEGER;if(i===fu)return n.RG;if(i===fh)return n.RG_INTEGER;if(i===uh)return n.RGBA_INTEGER;if(i===Zo||i===Jo||i===Ko||i===jo)if(o===Xe)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(i===Zo)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(i===Jo)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(i===Ko)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(i===jo)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(i===Zo)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(i===Jo)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(i===Ko)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(i===jo)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(i===Yl||i===Zl||i===Jl||i===Kl)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(i===Yl)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(i===Zl)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(i===Jl)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(i===Kl)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(i===jl||i===Ql||i===tc)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(i===jl||i===Ql)return o===Xe?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(i===tc)return o===Xe?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(i===ec||i===nc||i===ic||i===sc||i===rc||i===oc||i===ac||i===lc||i===cc||i===hc||i===fc||i===uc||i===dc||i===pc)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(i===ec)return o===Xe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(i===nc)return o===Xe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(i===ic)return o===Xe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(i===sc)return o===Xe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(i===rc)return o===Xe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(i===oc)return o===Xe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(i===ac)return o===Xe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(i===lc)return o===Xe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(i===cc)return o===Xe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(i===hc)return o===Xe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(i===fc)return o===Xe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(i===uc)return o===Xe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(i===dc)return o===Xe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(i===pc)return o===Xe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(i===Qo||i===mc||i===gc)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(i===Qo)return o===Xe?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(i===mc)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(i===gc)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(i===uu||i===yc||i===vc||i===xc)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(i===Qo)return r.COMPRESSED_RED_RGTC1_EXT;if(i===yc)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(i===vc)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(i===xc)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return i===ir?n.UNSIGNED_INT_24_8:n[i]!==void 0?n[i]:null}return{convert:e}}var Uc=class extends Dn{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}},_e=class extends qe{constructor(){super(),this.isGroup=!0,this.type="Group"}},lv={type:"move"},Nr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new _e,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new _e,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new V,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new V),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new _e,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new V,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new V),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let i of t.hand.values())this._getHandJoint(e,i)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,i){let s=null,r=null,o=null,a=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){o=!0;for(let v of t.hand.values()){let u=e.getJointPose(v,i),f=this._getHandJoint(c,v);u!==null&&(f.matrix.fromArray(u.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=u.radius),f.visible=u!==null}let h=c.joints["index-finger-tip"],m=c.joints["thumb-tip"],g=h.position.distanceTo(m.position),d=.02,p=.005;c.inputState.pinching&&g>d+p?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&g<=d-p&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,i),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));a!==null&&(s=e.getPose(t.targetRaySpace,i),s===null&&r!==null&&(s=r),s!==null&&(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity)):a.hasLinearVelocity=!1,s.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(lv)))}return a!==null&&(a.visible=s!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let i=new _e;i.matrixAutoUpdate=!1,i.visible=!1,t.joints[e.jointName]=i,t.add(i)}return t.joints[e.jointName]}},cv=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,hv=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,Nc=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e,i){if(this.texture===null){let s=new Fn,r=t.properties.get(s);r.__webglTexture=e.texture,(e.depthNear!=i.depthNear||e.depthFar!=i.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=s}}getMesh(t){if(this.texture!==null&&this.mesh===null){let e=t.cameras[0].viewport,i=new Nn({vertexShader:cv,fragmentShader:hv,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new We(new Tn(20,20),i)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},Fc=class extends Zi{constructor(t,e){super();let i=this,s=null,r=1,o=null,a="local-floor",l=1,c=null,h=null,m=null,g=null,d=null,p=null,v=new Nc,u=e.getContextAttributes(),f=null,S=null,y=[],x=[],L=new Ht,b=null,T=new Dn;T.viewport=new an;let A=new Dn;A.viewport=new an;let M=[T,A],_=new Uc,w=null,P=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(D){let G=y[D];return G===void 0&&(G=new Nr,y[D]=G),G.getTargetRaySpace()},this.getControllerGrip=function(D){let G=y[D];return G===void 0&&(G=new Nr,y[D]=G),G.getGripSpace()},this.getHand=function(D){let G=y[D];return G===void 0&&(G=new Nr,y[D]=G),G.getHandSpace()};function E(D){let G=x.indexOf(D.inputSource);if(G===-1)return;let q=y[G];q!==void 0&&(q.update(D.inputSource,D.frame,c||o),q.dispatchEvent({type:D.type,data:D.inputSource}))}function F(){s.removeEventListener("select",E),s.removeEventListener("selectstart",E),s.removeEventListener("selectend",E),s.removeEventListener("squeeze",E),s.removeEventListener("squeezestart",E),s.removeEventListener("squeezeend",E),s.removeEventListener("end",F),s.removeEventListener("inputsourceschange",R);for(let D=0;D<y.length;D++){let G=x[D];G!==null&&(x[D]=null,y[D].disconnect(G))}w=null,P=null,v.reset(),t.setRenderTarget(f),d=null,g=null,m=null,s=null,S=null,bt.stop(),i.isPresenting=!1,t.setPixelRatio(b),t.setSize(L.width,L.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(D){r=D,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(D){a=D,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function(D){c=D},this.getBaseLayer=function(){return g!==null?g:d},this.getBinding=function(){return m},this.getFrame=function(){return p},this.getSession=function(){return s},this.setSession=async function(D){if(s=D,s!==null){if(f=t.getRenderTarget(),s.addEventListener("select",E),s.addEventListener("selectstart",E),s.addEventListener("selectend",E),s.addEventListener("squeeze",E),s.addEventListener("squeezestart",E),s.addEventListener("squeezeend",E),s.addEventListener("end",F),s.addEventListener("inputsourceschange",R),u.xrCompatible!==!0&&await e.makeXRCompatible(),b=t.getPixelRatio(),t.getSize(L),s.renderState.layers===void 0){let G={antialias:u.antialias,alpha:!0,depth:u.depth,stencil:u.stencil,framebufferScaleFactor:r};d=new XRWebGLLayer(s,e,G),s.updateRenderState({baseLayer:d}),t.setPixelRatio(1),t.setSize(d.framebufferWidth,d.framebufferHeight,!1),S=new Ri(d.framebufferWidth,d.framebufferHeight,{format:Wn,type:Ai,colorSpace:t.outputColorSpace,stencilBuffer:u.stencil})}else{let G=null,q=null,W=null;u.depth&&(W=u.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,G=u.stencil?sr:Ks,q=u.stencil?ir:ys);let J={colorFormat:e.RGBA8,depthFormat:W,scaleFactor:r};m=new XRWebGLBinding(s,e),g=m.createProjectionLayer(J),s.updateRenderState({layers:[g]}),t.setPixelRatio(1),t.setSize(g.textureWidth,g.textureHeight,!1),S=new Ri(g.textureWidth,g.textureHeight,{format:Wn,type:Ai,depthTexture:new da(g.textureWidth,g.textureHeight,q,void 0,void 0,void 0,void 0,void 0,void 0,G),stencilBuffer:u.stencil,colorSpace:t.outputColorSpace,samples:u.antialias?4:0,resolveDepthBuffer:g.ignoreDepthValues===!1})}S.isXRRenderTarget=!0,this.setFoveation(l),c=null,o=await s.requestReferenceSpace(a),bt.setContext(s),bt.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return v.getDepthTexture()};function R(D){for(let G=0;G<D.removed.length;G++){let q=D.removed[G],W=x.indexOf(q);W>=0&&(x[W]=null,y[W].disconnect(q))}for(let G=0;G<D.added.length;G++){let q=D.added[G],W=x.indexOf(q);if(W===-1){for(let it=0;it<y.length;it++)if(it>=x.length){x.push(q),W=it;break}else if(x[it]===null){x[it]=q,W=it;break}if(W===-1)break}let J=y[W];J&&J.connect(q)}}let N=new V,U=new V;function z(D,G,q){N.setFromMatrixPosition(G.matrixWorld),U.setFromMatrixPosition(q.matrixWorld);let W=N.distanceTo(U),J=G.projectionMatrix.elements,it=q.projectionMatrix.elements,Mt=J[14]/(J[10]-1),Ct=J[14]/(J[10]+1),nt=(J[9]+1)/J[5],pt=(J[9]-1)/J[5],H=(J[8]-1)/J[0],qt=(it[8]+1)/it[0],tt=Mt*H,K=Mt*qt,Et=W/(-H+qt),X=Et*-H;if(G.matrixWorld.decompose(D.position,D.quaternion,D.scale),D.translateX(X),D.translateZ(Et),D.matrixWorld.compose(D.position,D.quaternion,D.scale),D.matrixWorldInverse.copy(D.matrixWorld).invert(),J[10]===-1)D.projectionMatrix.copy(G.projectionMatrix),D.projectionMatrixInverse.copy(G.projectionMatrixInverse);else{let Tt=Mt+Et,B=Ct+Et,I=tt-X,ut=K+(W-X),xt=nt*Ct/B*Tt,Pt=pt*Ct/B*Tt;D.projectionMatrix.makePerspective(I,ut,xt,Pt,Tt,B),D.projectionMatrixInverse.copy(D.projectionMatrix).invert()}}function Z(D,G){G===null?D.matrixWorld.copy(D.matrix):D.matrixWorld.multiplyMatrices(G.matrixWorld,D.matrix),D.matrixWorldInverse.copy(D.matrixWorld).invert()}this.updateCamera=function(D){if(s===null)return;let G=D.near,q=D.far;v.texture!==null&&(v.depthNear>0&&(G=v.depthNear),v.depthFar>0&&(q=v.depthFar)),_.near=A.near=T.near=G,_.far=A.far=T.far=q,(w!==_.near||P!==_.far)&&(s.updateRenderState({depthNear:_.near,depthFar:_.far}),w=_.near,P=_.far),T.layers.mask=D.layers.mask|2,A.layers.mask=D.layers.mask|4,_.layers.mask=T.layers.mask|A.layers.mask;let W=D.parent,J=_.cameras;Z(_,W);for(let it=0;it<J.length;it++)Z(J[it],W);J.length===2?z(_,T,A):_.projectionMatrix.copy(T.projectionMatrix),Y(D,_,W)};function Y(D,G,q){q===null?D.matrix.copy(G.matrixWorld):(D.matrix.copy(q.matrixWorld),D.matrix.invert(),D.matrix.multiply(G.matrixWorld)),D.matrix.decompose(D.position,D.quaternion,D.scale),D.updateMatrixWorld(!0),D.projectionMatrix.copy(G.projectionMatrix),D.projectionMatrixInverse.copy(G.projectionMatrixInverse),D.isPerspectiveCamera&&(D.fov=Br*2*Math.atan(1/D.projectionMatrix.elements[5]),D.zoom=1)}this.getCamera=function(){return _},this.getFoveation=function(){if(!(g===null&&d===null))return l},this.setFoveation=function(D){l=D,g!==null&&(g.fixedFoveation=D),d!==null&&d.fixedFoveation!==void 0&&(d.fixedFoveation=D)},this.hasDepthSensing=function(){return v.texture!==null},this.getDepthSensingMesh=function(){return v.getMesh(_)};let k=null;function mt(D,G){if(h=G.getViewerPose(c||o),p=G,h!==null){let q=h.views;d!==null&&(t.setRenderTargetFramebuffer(S,d.framebuffer),t.setRenderTarget(S));let W=!1;q.length!==_.cameras.length&&(_.cameras.length=0,W=!0);for(let it=0;it<q.length;it++){let Mt=q[it],Ct=null;if(d!==null)Ct=d.getViewport(Mt);else{let pt=m.getViewSubImage(g,Mt);Ct=pt.viewport,it===0&&(t.setRenderTargetTextures(S,pt.colorTexture,g.ignoreDepthValues?void 0:pt.depthStencilTexture),t.setRenderTarget(S))}let nt=M[it];nt===void 0&&(nt=new Dn,nt.layers.enable(it),nt.viewport=new an,M[it]=nt),nt.matrix.fromArray(Mt.transform.matrix),nt.matrix.decompose(nt.position,nt.quaternion,nt.scale),nt.projectionMatrix.fromArray(Mt.projectionMatrix),nt.projectionMatrixInverse.copy(nt.projectionMatrix).invert(),nt.viewport.set(Ct.x,Ct.y,Ct.width,Ct.height),it===0&&(_.matrix.copy(nt.matrix),_.matrix.decompose(_.position,_.quaternion,_.scale)),W===!0&&_.cameras.push(nt)}let J=s.enabledFeatures;if(J&&J.includes("depth-sensing")){let it=m.getDepthInformation(q[0]);it&&it.isValid&&it.texture&&v.init(t,it,s.renderState)}}for(let q=0;q<y.length;q++){let W=x[q],J=y[q];W!==null&&J!==void 0&&J.update(W,G,c||o)}k&&k(D,G),G.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:G}),p=null}let bt=new vu;bt.setAnimationLoop(mt),this.setAnimationLoop=function(D){k=D},this.dispose=function(){}}},hs=new ii,fv=new Fe;function uv(n,t){function e(u,f){u.matrixAutoUpdate===!0&&u.updateMatrix(),f.value.copy(u.matrix)}function i(u,f){f.color.getRGB(u.fogColor.value,yu(n)),f.isFog?(u.fogNear.value=f.near,u.fogFar.value=f.far):f.isFogExp2&&(u.fogDensity.value=f.density)}function s(u,f,S,y,x){f.isMeshBasicMaterial||f.isMeshLambertMaterial?r(u,f):f.isMeshToonMaterial?(r(u,f),m(u,f)):f.isMeshPhongMaterial?(r(u,f),h(u,f)):f.isMeshStandardMaterial?(r(u,f),g(u,f),f.isMeshPhysicalMaterial&&d(u,f,x)):f.isMeshMatcapMaterial?(r(u,f),p(u,f)):f.isMeshDepthMaterial?r(u,f):f.isMeshDistanceMaterial?(r(u,f),v(u,f)):f.isMeshNormalMaterial?r(u,f):f.isLineBasicMaterial?(o(u,f),f.isLineDashedMaterial&&a(u,f)):f.isPointsMaterial?l(u,f,S,y):f.isSpriteMaterial?c(u,f):f.isShadowMaterial?(u.color.value.copy(f.color),u.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function r(u,f){u.opacity.value=f.opacity,f.color&&u.diffuse.value.copy(f.color),f.emissive&&u.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(u.map.value=f.map,e(f.map,u.mapTransform)),f.alphaMap&&(u.alphaMap.value=f.alphaMap,e(f.alphaMap,u.alphaMapTransform)),f.bumpMap&&(u.bumpMap.value=f.bumpMap,e(f.bumpMap,u.bumpMapTransform),u.bumpScale.value=f.bumpScale,f.side===En&&(u.bumpScale.value*=-1)),f.normalMap&&(u.normalMap.value=f.normalMap,e(f.normalMap,u.normalMapTransform),u.normalScale.value.copy(f.normalScale),f.side===En&&u.normalScale.value.negate()),f.displacementMap&&(u.displacementMap.value=f.displacementMap,e(f.displacementMap,u.displacementMapTransform),u.displacementScale.value=f.displacementScale,u.displacementBias.value=f.displacementBias),f.emissiveMap&&(u.emissiveMap.value=f.emissiveMap,e(f.emissiveMap,u.emissiveMapTransform)),f.specularMap&&(u.specularMap.value=f.specularMap,e(f.specularMap,u.specularMapTransform)),f.alphaTest>0&&(u.alphaTest.value=f.alphaTest);let S=t.get(f),y=S.envMap,x=S.envMapRotation;y&&(u.envMap.value=y,hs.copy(x),hs.x*=-1,hs.y*=-1,hs.z*=-1,y.isCubeTexture&&y.isRenderTargetTexture===!1&&(hs.y*=-1,hs.z*=-1),u.envMapRotation.value.setFromMatrix4(fv.makeRotationFromEuler(hs)),u.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,u.reflectivity.value=f.reflectivity,u.ior.value=f.ior,u.refractionRatio.value=f.refractionRatio),f.lightMap&&(u.lightMap.value=f.lightMap,u.lightMapIntensity.value=f.lightMapIntensity,e(f.lightMap,u.lightMapTransform)),f.aoMap&&(u.aoMap.value=f.aoMap,u.aoMapIntensity.value=f.aoMapIntensity,e(f.aoMap,u.aoMapTransform))}function o(u,f){u.diffuse.value.copy(f.color),u.opacity.value=f.opacity,f.map&&(u.map.value=f.map,e(f.map,u.mapTransform))}function a(u,f){u.dashSize.value=f.dashSize,u.totalSize.value=f.dashSize+f.gapSize,u.scale.value=f.scale}function l(u,f,S,y){u.diffuse.value.copy(f.color),u.opacity.value=f.opacity,u.size.value=f.size*S,u.scale.value=y*.5,f.map&&(u.map.value=f.map,e(f.map,u.uvTransform)),f.alphaMap&&(u.alphaMap.value=f.alphaMap,e(f.alphaMap,u.alphaMapTransform)),f.alphaTest>0&&(u.alphaTest.value=f.alphaTest)}function c(u,f){u.diffuse.value.copy(f.color),u.opacity.value=f.opacity,u.rotation.value=f.rotation,f.map&&(u.map.value=f.map,e(f.map,u.mapTransform)),f.alphaMap&&(u.alphaMap.value=f.alphaMap,e(f.alphaMap,u.alphaMapTransform)),f.alphaTest>0&&(u.alphaTest.value=f.alphaTest)}function h(u,f){u.specular.value.copy(f.specular),u.shininess.value=Math.max(f.shininess,1e-4)}function m(u,f){f.gradientMap&&(u.gradientMap.value=f.gradientMap)}function g(u,f){u.metalness.value=f.metalness,f.metalnessMap&&(u.metalnessMap.value=f.metalnessMap,e(f.metalnessMap,u.metalnessMapTransform)),u.roughness.value=f.roughness,f.roughnessMap&&(u.roughnessMap.value=f.roughnessMap,e(f.roughnessMap,u.roughnessMapTransform)),f.envMap&&(u.envMapIntensity.value=f.envMapIntensity)}function d(u,f,S){u.ior.value=f.ior,f.sheen>0&&(u.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),u.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(u.sheenColorMap.value=f.sheenColorMap,e(f.sheenColorMap,u.sheenColorMapTransform)),f.sheenRoughnessMap&&(u.sheenRoughnessMap.value=f.sheenRoughnessMap,e(f.sheenRoughnessMap,u.sheenRoughnessMapTransform))),f.clearcoat>0&&(u.clearcoat.value=f.clearcoat,u.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(u.clearcoatMap.value=f.clearcoatMap,e(f.clearcoatMap,u.clearcoatMapTransform)),f.clearcoatRoughnessMap&&(u.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap,e(f.clearcoatRoughnessMap,u.clearcoatRoughnessMapTransform)),f.clearcoatNormalMap&&(u.clearcoatNormalMap.value=f.clearcoatNormalMap,e(f.clearcoatNormalMap,u.clearcoatNormalMapTransform),u.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),f.side===En&&u.clearcoatNormalScale.value.negate())),f.dispersion>0&&(u.dispersion.value=f.dispersion),f.iridescence>0&&(u.iridescence.value=f.iridescence,u.iridescenceIOR.value=f.iridescenceIOR,u.iridescenceThicknessMinimum.value=f.iridescenceThicknessRange[0],u.iridescenceThicknessMaximum.value=f.iridescenceThicknessRange[1],f.iridescenceMap&&(u.iridescenceMap.value=f.iridescenceMap,e(f.iridescenceMap,u.iridescenceMapTransform)),f.iridescenceThicknessMap&&(u.iridescenceThicknessMap.value=f.iridescenceThicknessMap,e(f.iridescenceThicknessMap,u.iridescenceThicknessMapTransform))),f.transmission>0&&(u.transmission.value=f.transmission,u.transmissionSamplerMap.value=S.texture,u.transmissionSamplerSize.value.set(S.width,S.height),f.transmissionMap&&(u.transmissionMap.value=f.transmissionMap,e(f.transmissionMap,u.transmissionMapTransform)),u.thickness.value=f.thickness,f.thicknessMap&&(u.thicknessMap.value=f.thicknessMap,e(f.thicknessMap,u.thicknessMapTransform)),u.attenuationDistance.value=f.attenuationDistance,u.attenuationColor.value.copy(f.attenuationColor)),f.anisotropy>0&&(u.anisotropyVector.value.set(f.anisotropy*Math.cos(f.anisotropyRotation),f.anisotropy*Math.sin(f.anisotropyRotation)),f.anisotropyMap&&(u.anisotropyMap.value=f.anisotropyMap,e(f.anisotropyMap,u.anisotropyMapTransform))),u.specularIntensity.value=f.specularIntensity,u.specularColor.value.copy(f.specularColor),f.specularColorMap&&(u.specularColorMap.value=f.specularColorMap,e(f.specularColorMap,u.specularColorMapTransform)),f.specularIntensityMap&&(u.specularIntensityMap.value=f.specularIntensityMap,e(f.specularIntensityMap,u.specularIntensityMapTransform))}function p(u,f){f.matcap&&(u.matcap.value=f.matcap)}function v(u,f){let S=t.get(f).light;u.referencePosition.value.setFromMatrixPosition(S.matrixWorld),u.nearDistance.value=S.shadow.camera.near,u.farDistance.value=S.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:s}}function dv(n,t,e,i){let s={},r={},o=[],a=n.getParameter(n.MAX_UNIFORM_BUFFER_BINDINGS);function l(S,y){let x=y.program;i.uniformBlockBinding(S,x)}function c(S,y){let x=s[S.id];x===void 0&&(p(S),x=h(S),s[S.id]=x,S.addEventListener("dispose",u));let L=y.program;i.updateUBOMapping(S,L);let b=t.render.frame;r[S.id]!==b&&(g(S),r[S.id]=b)}function h(S){let y=m();S.__bindingPointIndex=y;let x=n.createBuffer(),L=S.__size,b=S.usage;return n.bindBuffer(n.UNIFORM_BUFFER,x),n.bufferData(n.UNIFORM_BUFFER,L,b),n.bindBuffer(n.UNIFORM_BUFFER,null),n.bindBufferBase(n.UNIFORM_BUFFER,y,x),x}function m(){for(let S=0;S<a;S++)if(o.indexOf(S)===-1)return o.push(S),S;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function g(S){let y=s[S.id],x=S.uniforms,L=S.__cache;n.bindBuffer(n.UNIFORM_BUFFER,y);for(let b=0,T=x.length;b<T;b++){let A=Array.isArray(x[b])?x[b]:[x[b]];for(let M=0,_=A.length;M<_;M++){let w=A[M];if(d(w,b,M,L)===!0){let P=w.__offset,E=Array.isArray(w.value)?w.value:[w.value],F=0;for(let R=0;R<E.length;R++){let N=E[R],U=v(N);typeof N=="number"||typeof N=="boolean"?(w.__data[0]=N,n.bufferSubData(n.UNIFORM_BUFFER,P+F,w.__data)):N.isMatrix3?(w.__data[0]=N.elements[0],w.__data[1]=N.elements[1],w.__data[2]=N.elements[2],w.__data[3]=0,w.__data[4]=N.elements[3],w.__data[5]=N.elements[4],w.__data[6]=N.elements[5],w.__data[7]=0,w.__data[8]=N.elements[6],w.__data[9]=N.elements[7],w.__data[10]=N.elements[8],w.__data[11]=0):(N.toArray(w.__data,F),F+=U.storage/Float32Array.BYTES_PER_ELEMENT)}n.bufferSubData(n.UNIFORM_BUFFER,P,w.__data)}}}n.bindBuffer(n.UNIFORM_BUFFER,null)}function d(S,y,x,L){let b=S.value,T=y+"_"+x;if(L[T]===void 0)return typeof b=="number"||typeof b=="boolean"?L[T]=b:L[T]=b.clone(),!0;{let A=L[T];if(typeof b=="number"||typeof b=="boolean"){if(A!==b)return L[T]=b,!0}else if(A.equals(b)===!1)return A.copy(b),!0}return!1}function p(S){let y=S.uniforms,x=0,L=16;for(let T=0,A=y.length;T<A;T++){let M=Array.isArray(y[T])?y[T]:[y[T]];for(let _=0,w=M.length;_<w;_++){let P=M[_],E=Array.isArray(P.value)?P.value:[P.value];for(let F=0,R=E.length;F<R;F++){let N=E[F],U=v(N),z=x%L,Z=z%U.boundary,Y=z+Z;x+=Z,Y!==0&&L-Y<U.storage&&(x+=L-Y),P.__data=new Float32Array(U.storage/Float32Array.BYTES_PER_ELEMENT),P.__offset=x,x+=U.storage}}}let b=x%L;return b>0&&(x+=L-b),S.__size=x,S.__cache={},this}function v(S){let y={boundary:0,storage:0};return typeof S=="number"||typeof S=="boolean"?(y.boundary=4,y.storage=4):S.isVector2?(y.boundary=8,y.storage=8):S.isVector3||S.isColor?(y.boundary=16,y.storage=12):S.isVector4?(y.boundary=16,y.storage=16):S.isMatrix3?(y.boundary=48,y.storage=48):S.isMatrix4?(y.boundary=64,y.storage=64):S.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",S),y}function u(S){let y=S.target;y.removeEventListener("dispose",u);let x=o.indexOf(y.__bindingPointIndex);o.splice(x,1),n.deleteBuffer(s[y.id]),delete s[y.id],delete r[y.id]}function f(){for(let S in s)n.deleteBuffer(s[S]);o=[],s={},r={}}return{bind:l,update:c,dispose:f}}var pa=class{constructor(t={}){let{canvas:e=vp(),context:i=null,depth:s=!0,stencil:r=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:m=!1,reverseDepthBuffer:g=!1}=t;this.isWebGLRenderer=!0;let d;if(i!==null){if(typeof WebGLRenderingContext<"u"&&i instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");d=i.getContextAttributes().alpha}else d=o;let p=new Uint32Array(4),v=new Int32Array(4),u=null,f=null,S=[],y=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=Sn,this.toneMapping=pi,this.toneMappingExposure=1;let x=this,L=!1,b=0,T=0,A=null,M=-1,_=null,w=new an,P=new an,E=null,F=new fe(0),R=0,N=e.width,U=e.height,z=1,Z=null,Y=null,k=new an(0,0,N,U),mt=new an(0,0,N,U),bt=!1,D=new Hr,G=!1,q=!1,W=new Fe,J=new Fe,it=new V,Mt=new an,Ct={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},nt=!1;function pt(){return A===null?z:1}let H=i;function qt(O,rt){return e.getContext(O,rt)}try{let O={alpha:!0,depth:s,stencil:r,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:m};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${sh}`),e.addEventListener("webglcontextlost",Dt,!1),e.addEventListener("webglcontextrestored",ee,!1),e.addEventListener("webglcontextcreationerror",ne,!1),H===null){let rt="webgl2";if(H=qt(rt,O),H===null)throw qt(rt)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(O){throw console.error("THREE.WebGLRenderer: "+O.message),O}let tt,K,Et,X,Tt,B,I,ut,xt,Pt,At,jt,dt,ot,St,ht,yt,Yt,Gt,Wt,ae,ge,Ie,et;function Kt(){tt=new Cg(H),tt.init(),ge=new av(H,tt),K=new Sg(H,tt,t,ge),Et=new sv(H,tt),K.reverseDepthBuffer&&g&&Et.buffers.depth.setReversed(!0),X=new Lg(H),Tt=new $y,B=new ov(H,tt,Et,Tt,K,ge,X),I=new Eg(x),ut=new Rg(x),xt=new zp(H),Ie=new Mg(H,xt),Pt=new Ig(H,xt,X,Ie),At=new Dg(H,Pt,xt,X),Gt=new kg(H,K,B),ht=new wg(Tt),jt=new Wy(x,I,ut,tt,K,Ie,ht),dt=new uv(x,Tt),ot=new qy,St=new Qy(tt),Yt=new _g(x,I,ut,Et,At,d,l),yt=new nv(x,At,K),et=new dv(H,X,K,Et),Wt=new bg(H,tt,X),ae=new Pg(H,tt,X),X.programs=jt.programs,x.capabilities=K,x.extensions=tt,x.properties=Tt,x.renderLists=ot,x.shadowMap=yt,x.state=Et,x.info=X}Kt();let Rt=new Fc(x,H);this.xr=Rt,this.getContext=function(){return H},this.getContextAttributes=function(){return H.getContextAttributes()},this.forceContextLoss=function(){let O=tt.get("WEBGL_lose_context");O&&O.loseContext()},this.forceContextRestore=function(){let O=tt.get("WEBGL_lose_context");O&&O.restoreContext()},this.getPixelRatio=function(){return z},this.setPixelRatio=function(O){O!==void 0&&(z=O,this.setSize(N,U,!1))},this.getSize=function(O){return O.set(N,U)},this.setSize=function(O,rt,vt=!0){if(Rt.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}N=O,U=rt,e.width=Math.floor(O*z),e.height=Math.floor(rt*z),vt===!0&&(e.style.width=O+"px",e.style.height=rt+"px"),this.setViewport(0,0,O,rt)},this.getDrawingBufferSize=function(O){return O.set(N*z,U*z).floor()},this.setDrawingBufferSize=function(O,rt,vt){N=O,U=rt,z=vt,e.width=Math.floor(O*vt),e.height=Math.floor(rt*vt),this.setViewport(0,0,O,rt)},this.getCurrentViewport=function(O){return O.copy(w)},this.getViewport=function(O){return O.copy(k)},this.setViewport=function(O,rt,vt,_t){O.isVector4?k.set(O.x,O.y,O.z,O.w):k.set(O,rt,vt,_t),Et.viewport(w.copy(k).multiplyScalar(z).round())},this.getScissor=function(O){return O.copy(mt)},this.setScissor=function(O,rt,vt,_t){O.isVector4?mt.set(O.x,O.y,O.z,O.w):mt.set(O,rt,vt,_t),Et.scissor(P.copy(mt).multiplyScalar(z).round())},this.getScissorTest=function(){return bt},this.setScissorTest=function(O){Et.setScissorTest(bt=O)},this.setOpaqueSort=function(O){Z=O},this.setTransparentSort=function(O){Y=O},this.getClearColor=function(O){return O.copy(Yt.getClearColor())},this.setClearColor=function(){Yt.setClearColor.apply(Yt,arguments)},this.getClearAlpha=function(){return Yt.getClearAlpha()},this.setClearAlpha=function(){Yt.setClearAlpha.apply(Yt,arguments)},this.clear=function(O=!0,rt=!0,vt=!0){let _t=0;if(O){let ct=!1;if(A!==null){let Zt=A.texture.format;ct=Zt===uh||Zt===fh||Zt===hh}if(ct){let Zt=A.texture.type,re=Zt===Ai||Zt===ys||Zt===zr||Zt===ir||Zt===ah||Zt===lh,ue=Yt.getClearColor(),de=Yt.getClearAlpha(),Ee=ue.r,$=ue.g,j=ue.b;re?(p[0]=Ee,p[1]=$,p[2]=j,p[3]=de,H.clearBufferuiv(H.COLOR,0,p)):(v[0]=Ee,v[1]=$,v[2]=j,v[3]=de,H.clearBufferiv(H.COLOR,0,v))}else _t|=H.COLOR_BUFFER_BIT}rt&&(_t|=H.DEPTH_BUFFER_BIT),vt&&(_t|=H.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),H.clear(_t)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",Dt,!1),e.removeEventListener("webglcontextrestored",ee,!1),e.removeEventListener("webglcontextcreationerror",ne,!1),ot.dispose(),St.dispose(),Tt.dispose(),I.dispose(),ut.dispose(),At.dispose(),Ie.dispose(),et.dispose(),jt.dispose(),Rt.dispose(),Rt.removeEventListener("sessionstart",wt),Rt.removeEventListener("sessionend",ft),It.stop()};function Dt(O){O.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),L=!0}function ee(){console.log("THREE.WebGLRenderer: Context Restored."),L=!1;let O=X.autoReset,rt=yt.enabled,vt=yt.autoUpdate,_t=yt.needsUpdate,ct=yt.type;Kt(),X.autoReset=O,yt.enabled=rt,yt.autoUpdate=vt,yt.needsUpdate=_t,yt.type=ct}function ne(O){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",O.statusMessage)}function we(O){let rt=O.target;rt.removeEventListener("dispose",we),Ve(rt)}function Ve(O){C(O),Tt.remove(O)}function C(O){let rt=Tt.get(O).programs;rt!==void 0&&(rt.forEach(function(vt){jt.releaseProgram(vt)}),O.isShaderMaterial&&jt.releaseShaderCache(O))}this.renderBufferDirect=function(O,rt,vt,_t,ct,Zt){rt===null&&(rt=Ct);let re=ct.isMesh&&ct.matrixWorld.determinant()<0,ue=Me(O,rt,vt,_t,ct);Et.setMaterial(_t,re);let de=vt.index,Ee=1;if(_t.wireframe===!0){if(de=Pt.getWireframeAttribute(vt),de===void 0)return;Ee=2}let $=vt.drawRange,j=vt.attributes.position,kt=$.start*Ee,Lt=($.start+$.count)*Ee;Zt!==null&&(kt=Math.max(kt,Zt.start*Ee),Lt=Math.min(Lt,(Zt.start+Zt.count)*Ee)),de!==null?(kt=Math.max(kt,0),Lt=Math.min(Lt,de.count)):j!=null&&(kt=Math.max(kt,0),Lt=Math.min(Lt,j.count));let Bt=Lt-kt;if(Bt<0||Bt===1/0)return;Ie.setup(ct,_t,ue,vt,de);let me,Xt=Wt;if(de!==null&&(me=xt.get(de),Xt=ae,Xt.setIndex(me)),ct.isMesh)_t.wireframe===!0?(Et.setLineWidth(_t.wireframeLinewidth*pt()),Xt.setMode(H.LINES)):Xt.setMode(H.TRIANGLES);else if(ct.isLine){let Vt=_t.linewidth;Vt===void 0&&(Vt=1),Et.setLineWidth(Vt*pt()),ct.isLineSegments?Xt.setMode(H.LINES):ct.isLineLoop?Xt.setMode(H.LINE_LOOP):Xt.setMode(H.LINE_STRIP)}else ct.isPoints?Xt.setMode(H.POINTS):ct.isSprite&&Xt.setMode(H.TRIANGLES);if(ct.isBatchedMesh)if(ct._multiDrawInstances!==null)Xt.renderMultiDrawInstances(ct._multiDrawStarts,ct._multiDrawCounts,ct._multiDrawCount,ct._multiDrawInstances);else if(tt.get("WEBGL_multi_draw"))Xt.renderMultiDraw(ct._multiDrawStarts,ct._multiDrawCounts,ct._multiDrawCount);else{let Vt=ct._multiDrawStarts,Ke=ct._multiDrawCounts,Ae=ct._multiDrawCount,ye=de?xt.get(de).bytesPerElement:1,ve=Tt.get(_t).currentProgram.getUniforms();for(let be=0;be<Ae;be++)ve.setValue(H,"_gl_DrawID",be),Xt.render(Vt[be]/ye,Ke[be])}else if(ct.isInstancedMesh)Xt.renderInstances(kt,Bt,ct.count);else if(vt.isInstancedBufferGeometry){let Vt=vt._maxInstanceCount!==void 0?vt._maxInstanceCount:1/0,Ke=Math.min(vt.instanceCount,Vt);Xt.renderInstances(kt,Bt,Ke)}else Xt.render(kt,Bt)};function Q(O,rt,vt){O.transparent===!0&&O.side===hn&&O.forceSinglePass===!1?(O.side=En,O.needsUpdate=!0,Nt(O,rt,vt),O.side=Yi,O.needsUpdate=!0,Nt(O,rt,vt),O.side=hn):Nt(O,rt,vt)}this.compile=function(O,rt,vt=null){vt===null&&(vt=O),f=St.get(vt),f.init(rt),y.push(f),vt.traverseVisible(function(ct){ct.isLight&&ct.layers.test(rt.layers)&&(f.pushLight(ct),ct.castShadow&&f.pushShadow(ct))}),O!==vt&&O.traverseVisible(function(ct){ct.isLight&&ct.layers.test(rt.layers)&&(f.pushLight(ct),ct.castShadow&&f.pushShadow(ct))}),f.setupLights();let _t=new Set;return O.traverse(function(ct){if(!(ct.isMesh||ct.isPoints||ct.isLine||ct.isSprite))return;let Zt=ct.material;if(Zt)if(Array.isArray(Zt))for(let re=0;re<Zt.length;re++){let ue=Zt[re];Q(ue,vt,ct),_t.add(ue)}else Q(Zt,vt,ct),_t.add(Zt)}),y.pop(),f=null,_t},this.compileAsync=function(O,rt,vt=null){let _t=this.compile(O,rt,vt);return new Promise(ct=>{function Zt(){if(_t.forEach(function(re){Tt.get(re).currentProgram.isReady()&&_t.delete(re)}),_t.size===0){ct(O);return}setTimeout(Zt,10)}tt.get("KHR_parallel_shader_compile")!==null?Zt():setTimeout(Zt,10)})};let at=null;function lt(O){at&&at(O)}function wt(){It.stop()}function ft(){It.start()}let It=new vu;It.setAnimationLoop(lt),typeof self<"u"&&It.setContext(self),this.setAnimationLoop=function(O){at=O,Rt.setAnimationLoop(O),O===null?It.stop():It.start()},Rt.addEventListener("sessionstart",wt),Rt.addEventListener("sessionend",ft),this.render=function(O,rt){if(rt!==void 0&&rt.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(L===!0)return;if(O.matrixWorldAutoUpdate===!0&&O.updateMatrixWorld(),rt.parent===null&&rt.matrixWorldAutoUpdate===!0&&rt.updateMatrixWorld(),Rt.enabled===!0&&Rt.isPresenting===!0&&(Rt.cameraAutoUpdate===!0&&Rt.updateCamera(rt),rt=Rt.getCamera()),O.isScene===!0&&O.onBeforeRender(x,O,rt,A),f=St.get(O,y.length),f.init(rt),y.push(f),J.multiplyMatrices(rt.projectionMatrix,rt.matrixWorldInverse),D.setFromProjectionMatrix(J),q=this.localClippingEnabled,G=ht.init(this.clippingPlanes,q),u=ot.get(O,S.length),u.init(),S.push(u),Rt.enabled===!0&&Rt.isPresenting===!0){let Zt=x.xr.getDepthSensingMesh();Zt!==null&&Jt(Zt,rt,-1/0,x.sortObjects)}Jt(O,rt,0,x.sortObjects),u.finish(),x.sortObjects===!0&&u.sort(Z,Y),nt=Rt.enabled===!1||Rt.isPresenting===!1||Rt.hasDepthSensing()===!1,nt&&Yt.addToRenderList(u,O),this.info.render.frame++,G===!0&&ht.beginShadows();let vt=f.state.shadowsArray;yt.render(vt,O,rt),G===!0&&ht.endShadows(),this.info.autoReset===!0&&this.info.reset();let _t=u.opaque,ct=u.transmissive;if(f.setupLights(),rt.isArrayCamera){let Zt=rt.cameras;if(ct.length>0)for(let re=0,ue=Zt.length;re<ue;re++){let de=Zt[re];Ft(_t,ct,O,de)}nt&&Yt.render(O);for(let re=0,ue=Zt.length;re<ue;re++){let de=Zt[re];zt(u,O,de,de.viewport)}}else ct.length>0&&Ft(_t,ct,O,rt),nt&&Yt.render(O),zt(u,O,rt);A!==null&&(B.updateMultisampleRenderTarget(A),B.updateRenderTargetMipmap(A)),O.isScene===!0&&O.onAfterRender(x,O,rt),Ie.resetDefaultState(),M=-1,_=null,y.pop(),y.length>0?(f=y[y.length-1],G===!0&&ht.setGlobalState(x.clippingPlanes,f.state.camera)):f=null,S.pop(),S.length>0?u=S[S.length-1]:u=null};function Jt(O,rt,vt,_t){if(O.visible===!1)return;if(O.layers.test(rt.layers)){if(O.isGroup)vt=O.renderOrder;else if(O.isLOD)O.autoUpdate===!0&&O.update(rt);else if(O.isLight)f.pushLight(O),O.castShadow&&f.pushShadow(O);else if(O.isSprite){if(!O.frustumCulled||D.intersectsSprite(O)){_t&&Mt.setFromMatrixPosition(O.matrixWorld).applyMatrix4(J);let re=At.update(O),ue=O.material;ue.visible&&u.push(O,re,ue,vt,Mt.z,null)}}else if((O.isMesh||O.isLine||O.isPoints)&&(!O.frustumCulled||D.intersectsObject(O))){let re=At.update(O),ue=O.material;if(_t&&(O.boundingSphere!==void 0?(O.boundingSphere===null&&O.computeBoundingSphere(),Mt.copy(O.boundingSphere.center)):(re.boundingSphere===null&&re.computeBoundingSphere(),Mt.copy(re.boundingSphere.center)),Mt.applyMatrix4(O.matrixWorld).applyMatrix4(J)),Array.isArray(ue)){let de=re.groups;for(let Ee=0,$=de.length;Ee<$;Ee++){let j=de[Ee],kt=ue[j.materialIndex];kt&&kt.visible&&u.push(O,re,kt,vt,Mt.z,j)}}else ue.visible&&u.push(O,re,ue,vt,Mt.z,null)}}let Zt=O.children;for(let re=0,ue=Zt.length;re<ue;re++)Jt(Zt[re],rt,vt,_t)}function zt(O,rt,vt,_t){let ct=O.opaque,Zt=O.transmissive,re=O.transparent;f.setupLightsView(vt),G===!0&&ht.setGlobalState(x.clippingPlanes,vt),_t&&Et.viewport(w.copy(_t)),ct.length>0&&Ut(ct,rt,vt),Zt.length>0&&Ut(Zt,rt,vt),re.length>0&&Ut(re,rt,vt),Et.buffers.depth.setTest(!0),Et.buffers.depth.setMask(!0),Et.buffers.color.setMask(!0),Et.setPolygonOffset(!1)}function Ft(O,rt,vt,_t){if((vt.isScene===!0?vt.overrideMaterial:null)!==null)return;f.state.transmissionRenderTarget[_t.id]===void 0&&(f.state.transmissionRenderTarget[_t.id]=new Ri(1,1,{generateMipmaps:!0,type:tt.has("EXT_color_buffer_half_float")||tt.has("EXT_color_buffer_float")?Qr:Ai,minFilter:ms,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Be.workingColorSpace}));let Zt=f.state.transmissionRenderTarget[_t.id],re=_t.viewport||w;Zt.setSize(re.z,re.w);let ue=x.getRenderTarget();x.setRenderTarget(Zt),x.getClearColor(F),R=x.getClearAlpha(),R<1&&x.setClearColor(16777215,.5),x.clear(),nt&&Yt.render(vt);let de=x.toneMapping;x.toneMapping=pi;let Ee=_t.viewport;if(_t.viewport!==void 0&&(_t.viewport=void 0),f.setupLightsView(_t),G===!0&&ht.setGlobalState(x.clippingPlanes,_t),Ut(O,vt,_t),B.updateMultisampleRenderTarget(Zt),B.updateRenderTargetMipmap(Zt),tt.has("WEBGL_multisampled_render_to_texture")===!1){let $=!1;for(let j=0,kt=rt.length;j<kt;j++){let Lt=rt[j],Bt=Lt.object,me=Lt.geometry,Xt=Lt.material,Vt=Lt.group;if(Xt.side===hn&&Bt.layers.test(_t.layers)){let Ke=Xt.side;Xt.side=En,Xt.needsUpdate=!0,st(Bt,vt,_t,me,Xt,Vt),Xt.side=Ke,Xt.needsUpdate=!0,$=!0}}$===!0&&(B.updateMultisampleRenderTarget(Zt),B.updateRenderTargetMipmap(Zt))}x.setRenderTarget(ue),x.setClearColor(F,R),Ee!==void 0&&(_t.viewport=Ee),x.toneMapping=de}function Ut(O,rt,vt){let _t=rt.isScene===!0?rt.overrideMaterial:null;for(let ct=0,Zt=O.length;ct<Zt;ct++){let re=O[ct],ue=re.object,de=re.geometry,Ee=_t===null?re.material:_t,$=re.group;ue.layers.test(vt.layers)&&st(ue,rt,vt,de,Ee,$)}}function st(O,rt,vt,_t,ct,Zt){O.onBeforeRender(x,rt,vt,_t,ct,Zt),O.modelViewMatrix.multiplyMatrices(vt.matrixWorldInverse,O.matrixWorld),O.normalMatrix.getNormalMatrix(O.modelViewMatrix),ct.onBeforeRender(x,rt,vt,_t,O,Zt),ct.transparent===!0&&ct.side===hn&&ct.forceSinglePass===!1?(ct.side=En,ct.needsUpdate=!0,x.renderBufferDirect(vt,rt,_t,ct,O,Zt),ct.side=Yi,ct.needsUpdate=!0,x.renderBufferDirect(vt,rt,_t,ct,O,Zt),ct.side=hn):x.renderBufferDirect(vt,rt,_t,ct,O,Zt),O.onAfterRender(x,rt,vt,_t,ct,Zt)}function Nt(O,rt,vt){rt.isScene!==!0&&(rt=Ct);let _t=Tt.get(O),ct=f.state.lights,Zt=f.state.shadowsArray,re=ct.state.version,ue=jt.getParameters(O,ct.state,Zt,rt,vt),de=jt.getProgramCacheKey(ue),Ee=_t.programs;_t.environment=O.isMeshStandardMaterial?rt.environment:null,_t.fog=rt.fog,_t.envMap=(O.isMeshStandardMaterial?ut:I).get(O.envMap||_t.environment),_t.envMapRotation=_t.environment!==null&&O.envMap===null?rt.environmentRotation:O.envMapRotation,Ee===void 0&&(O.addEventListener("dispose",we),Ee=new Map,_t.programs=Ee);let $=Ee.get(de);if($!==void 0){if(_t.currentProgram===$&&_t.lightsStateVersion===re)return ie(O,ue),$}else ue.uniforms=jt.getUniforms(O),O.onBeforeCompile(ue,x),$=jt.acquireProgram(ue,de),Ee.set(de,$),_t.uniforms=ue.uniforms;let j=_t.uniforms;return(!O.isShaderMaterial&&!O.isRawShaderMaterial||O.clipping===!0)&&(j.clippingPlanes=ht.uniform),ie(O,ue),_t.needsLights=He(O),_t.lightsStateVersion=re,_t.needsLights&&(j.ambientLightColor.value=ct.state.ambient,j.lightProbe.value=ct.state.probe,j.directionalLights.value=ct.state.directional,j.directionalLightShadows.value=ct.state.directionalShadow,j.spotLights.value=ct.state.spot,j.spotLightShadows.value=ct.state.spotShadow,j.rectAreaLights.value=ct.state.rectArea,j.ltc_1.value=ct.state.rectAreaLTC1,j.ltc_2.value=ct.state.rectAreaLTC2,j.pointLights.value=ct.state.point,j.pointLightShadows.value=ct.state.pointShadow,j.hemisphereLights.value=ct.state.hemi,j.directionalShadowMap.value=ct.state.directionalShadowMap,j.directionalShadowMatrix.value=ct.state.directionalShadowMatrix,j.spotShadowMap.value=ct.state.spotShadowMap,j.spotLightMatrix.value=ct.state.spotLightMatrix,j.spotLightMap.value=ct.state.spotLightMap,j.pointShadowMap.value=ct.state.pointShadowMap,j.pointShadowMatrix.value=ct.state.pointShadowMatrix),_t.currentProgram=$,_t.uniformsList=null,$}function $t(O){if(O.uniformsList===null){let rt=O.currentProgram.getUniforms();O.uniformsList=Qs.seqWithValue(rt.seq,O.uniforms)}return O.uniformsList}function ie(O,rt){let vt=Tt.get(O);vt.outputColorSpace=rt.outputColorSpace,vt.batching=rt.batching,vt.batchingColor=rt.batchingColor,vt.instancing=rt.instancing,vt.instancingColor=rt.instancingColor,vt.instancingMorph=rt.instancingMorph,vt.skinning=rt.skinning,vt.morphTargets=rt.morphTargets,vt.morphNormals=rt.morphNormals,vt.morphColors=rt.morphColors,vt.morphTargetsCount=rt.morphTargetsCount,vt.numClippingPlanes=rt.numClippingPlanes,vt.numIntersection=rt.numClipIntersection,vt.vertexAlphas=rt.vertexAlphas,vt.vertexTangents=rt.vertexTangents,vt.toneMapping=rt.toneMapping}function Me(O,rt,vt,_t,ct){rt.isScene!==!0&&(rt=Ct),B.resetTextureUnits();let Zt=rt.fog,re=_t.isMeshStandardMaterial?rt.environment:null,ue=A===null?x.outputColorSpace:A.isXRRenderTarget===!0?A.texture.colorSpace:hr,de=(_t.isMeshStandardMaterial?ut:I).get(_t.envMap||re),Ee=_t.vertexColors===!0&&!!vt.attributes.color&&vt.attributes.color.itemSize===4,$=!!vt.attributes.tangent&&(!!_t.normalMap||_t.anisotropy>0),j=!!vt.morphAttributes.position,kt=!!vt.morphAttributes.normal,Lt=!!vt.morphAttributes.color,Bt=pi;_t.toneMapped&&(A===null||A.isXRRenderTarget===!0)&&(Bt=x.toneMapping);let me=vt.morphAttributes.position||vt.morphAttributes.normal||vt.morphAttributes.color,Xt=me!==void 0?me.length:0,Vt=Tt.get(_t),Ke=f.state.lights;if(G===!0&&(q===!0||O!==_)){let Ne=O===_&&_t.id===M;ht.setState(_t,O,Ne)}let Ae=!1;_t.version===Vt.__version?(Vt.needsLights&&Vt.lightsStateVersion!==Ke.state.version||Vt.outputColorSpace!==ue||ct.isBatchedMesh&&Vt.batching===!1||!ct.isBatchedMesh&&Vt.batching===!0||ct.isBatchedMesh&&Vt.batchingColor===!0&&ct.colorTexture===null||ct.isBatchedMesh&&Vt.batchingColor===!1&&ct.colorTexture!==null||ct.isInstancedMesh&&Vt.instancing===!1||!ct.isInstancedMesh&&Vt.instancing===!0||ct.isSkinnedMesh&&Vt.skinning===!1||!ct.isSkinnedMesh&&Vt.skinning===!0||ct.isInstancedMesh&&Vt.instancingColor===!0&&ct.instanceColor===null||ct.isInstancedMesh&&Vt.instancingColor===!1&&ct.instanceColor!==null||ct.isInstancedMesh&&Vt.instancingMorph===!0&&ct.morphTexture===null||ct.isInstancedMesh&&Vt.instancingMorph===!1&&ct.morphTexture!==null||Vt.envMap!==de||_t.fog===!0&&Vt.fog!==Zt||Vt.numClippingPlanes!==void 0&&(Vt.numClippingPlanes!==ht.numPlanes||Vt.numIntersection!==ht.numIntersection)||Vt.vertexAlphas!==Ee||Vt.vertexTangents!==$||Vt.morphTargets!==j||Vt.morphNormals!==kt||Vt.morphColors!==Lt||Vt.toneMapping!==Bt||Vt.morphTargetsCount!==Xt)&&(Ae=!0):(Ae=!0,Vt.__version=_t.version);let ye=Vt.currentProgram;Ae===!0&&(ye=Nt(_t,rt,ct));let ve=!1,be=!1,Qt=!1,xe=ye.getUniforms(),ce=Vt.uniforms;if(Et.useProgram(ye.program)&&(ve=!0,be=!0,Qt=!0),_t.id!==M&&(M=_t.id,be=!0),ve||_!==O){Et.buffers.depth.getReversed()?(W.copy(O.projectionMatrix),_p(W),Mp(W),xe.setValue(H,"projectionMatrix",W)):xe.setValue(H,"projectionMatrix",O.projectionMatrix),xe.setValue(H,"viewMatrix",O.matrixWorldInverse);let je=xe.map.cameraPosition;je!==void 0&&je.setValue(H,it.setFromMatrixPosition(O.matrixWorld)),K.logarithmicDepthBuffer&&xe.setValue(H,"logDepthBufFC",2/(Math.log(O.far+1)/Math.LN2)),(_t.isMeshPhongMaterial||_t.isMeshToonMaterial||_t.isMeshLambertMaterial||_t.isMeshBasicMaterial||_t.isMeshStandardMaterial||_t.isShaderMaterial)&&xe.setValue(H,"isOrthographic",O.isOrthographicCamera===!0),_!==O&&(_=O,be=!0,Qt=!0)}if(ct.isSkinnedMesh){xe.setOptional(H,ct,"bindMatrix"),xe.setOptional(H,ct,"bindMatrixInverse");let Ne=ct.skeleton;Ne&&(Ne.boneTexture===null&&Ne.computeBoneTexture(),xe.setValue(H,"boneTexture",Ne.boneTexture,B))}ct.isBatchedMesh&&(xe.setOptional(H,ct,"batchingTexture"),xe.setValue(H,"batchingTexture",ct._matricesTexture,B),xe.setOptional(H,ct,"batchingIdTexture"),xe.setValue(H,"batchingIdTexture",ct._indirectTexture,B),xe.setOptional(H,ct,"batchingColorTexture"),ct._colorsTexture!==null&&xe.setValue(H,"batchingColorTexture",ct._colorsTexture,B));let Re=vt.morphAttributes;if((Re.position!==void 0||Re.normal!==void 0||Re.color!==void 0)&&Gt.update(ct,vt,ye),(be||Vt.receiveShadow!==ct.receiveShadow)&&(Vt.receiveShadow=ct.receiveShadow,xe.setValue(H,"receiveShadow",ct.receiveShadow)),_t.isMeshGouraudMaterial&&_t.envMap!==null&&(ce.envMap.value=de,ce.flipEnvMap.value=de.isCubeTexture&&de.isRenderTargetTexture===!1?-1:1),_t.isMeshStandardMaterial&&_t.envMap===null&&rt.environment!==null&&(ce.envMapIntensity.value=rt.environmentIntensity),be&&(xe.setValue(H,"toneMappingExposure",x.toneMappingExposure),Vt.needsLights&&ke(ce,Qt),Zt&&_t.fog===!0&&dt.refreshFogUniforms(ce,Zt),dt.refreshMaterialUniforms(ce,_t,z,U,f.state.transmissionRenderTarget[O.id]),Qs.upload(H,$t(Vt),ce,B)),_t.isShaderMaterial&&_t.uniformsNeedUpdate===!0&&(Qs.upload(H,$t(Vt),ce,B),_t.uniformsNeedUpdate=!1),_t.isSpriteMaterial&&xe.setValue(H,"center",ct.center),xe.setValue(H,"modelViewMatrix",ct.modelViewMatrix),xe.setValue(H,"normalMatrix",ct.normalMatrix),xe.setValue(H,"modelMatrix",ct.matrixWorld),_t.isShaderMaterial||_t.isRawShaderMaterial){let Ne=_t.uniformsGroups;for(let je=0,Ze=Ne.length;je<Ze;je++){let Cn=Ne[je];et.update(Cn,ye),et.bind(Cn,ye)}}return ye}function ke(O,rt){O.ambientLightColor.needsUpdate=rt,O.lightProbe.needsUpdate=rt,O.directionalLights.needsUpdate=rt,O.directionalLightShadows.needsUpdate=rt,O.pointLights.needsUpdate=rt,O.pointLightShadows.needsUpdate=rt,O.spotLights.needsUpdate=rt,O.spotLightShadows.needsUpdate=rt,O.rectAreaLights.needsUpdate=rt,O.hemisphereLights.needsUpdate=rt}function He(O){return O.isMeshLambertMaterial||O.isMeshToonMaterial||O.isMeshPhongMaterial||O.isMeshStandardMaterial||O.isShadowMaterial||O.isShaderMaterial&&O.lights===!0}this.getActiveCubeFace=function(){return b},this.getActiveMipmapLevel=function(){return T},this.getRenderTarget=function(){return A},this.setRenderTargetTextures=function(O,rt,vt){Tt.get(O.texture).__webglTexture=rt,Tt.get(O.depthTexture).__webglTexture=vt;let _t=Tt.get(O);_t.__hasExternalTextures=!0,_t.__autoAllocateDepthBuffer=vt===void 0,_t.__autoAllocateDepthBuffer||tt.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),_t.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(O,rt){let vt=Tt.get(O);vt.__webglFramebuffer=rt,vt.__useDefaultFramebuffer=rt===void 0},this.setRenderTarget=function(O,rt=0,vt=0){A=O,b=rt,T=vt;let _t=!0,ct=null,Zt=!1,re=!1;if(O){let de=Tt.get(O);if(de.__useDefaultFramebuffer!==void 0)Et.bindFramebuffer(H.FRAMEBUFFER,null),_t=!1;else if(de.__webglFramebuffer===void 0)B.setupRenderTarget(O);else if(de.__hasExternalTextures)B.rebindTextures(O,Tt.get(O.texture).__webglTexture,Tt.get(O.depthTexture).__webglTexture);else if(O.depthBuffer){let j=O.depthTexture;if(de.__boundDepthTexture!==j){if(j!==null&&Tt.has(j)&&(O.width!==j.image.width||O.height!==j.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");B.setupDepthRenderbuffer(O)}}let Ee=O.texture;(Ee.isData3DTexture||Ee.isDataArrayTexture||Ee.isCompressedArrayTexture)&&(re=!0);let $=Tt.get(O).__webglFramebuffer;O.isWebGLCubeRenderTarget?(Array.isArray($[rt])?ct=$[rt][vt]:ct=$[rt],Zt=!0):O.samples>0&&B.useMultisampledRTT(O)===!1?ct=Tt.get(O).__webglMultisampledFramebuffer:Array.isArray($)?ct=$[vt]:ct=$,w.copy(O.viewport),P.copy(O.scissor),E=O.scissorTest}else w.copy(k).multiplyScalar(z).floor(),P.copy(mt).multiplyScalar(z).floor(),E=bt;if(Et.bindFramebuffer(H.FRAMEBUFFER,ct)&&_t&&Et.drawBuffers(O,ct),Et.viewport(w),Et.scissor(P),Et.setScissorTest(E),Zt){let de=Tt.get(O.texture);H.framebufferTexture2D(H.FRAMEBUFFER,H.COLOR_ATTACHMENT0,H.TEXTURE_CUBE_MAP_POSITIVE_X+rt,de.__webglTexture,vt)}else if(re){let de=Tt.get(O.texture),Ee=rt||0;H.framebufferTextureLayer(H.FRAMEBUFFER,H.COLOR_ATTACHMENT0,de.__webglTexture,vt||0,Ee)}M=-1},this.readRenderTargetPixels=function(O,rt,vt,_t,ct,Zt,re){if(!(O&&O.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let ue=Tt.get(O).__webglFramebuffer;if(O.isWebGLCubeRenderTarget&&re!==void 0&&(ue=ue[re]),ue){Et.bindFramebuffer(H.FRAMEBUFFER,ue);try{let de=O.texture,Ee=de.format,$=de.type;if(!K.textureFormatReadable(Ee)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!K.textureTypeReadable($)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}rt>=0&&rt<=O.width-_t&&vt>=0&&vt<=O.height-ct&&H.readPixels(rt,vt,_t,ct,ge.convert(Ee),ge.convert($),Zt)}finally{let de=A!==null?Tt.get(A).__webglFramebuffer:null;Et.bindFramebuffer(H.FRAMEBUFFER,de)}}},this.readRenderTargetPixelsAsync=async function(O,rt,vt,_t,ct,Zt,re){if(!(O&&O.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let ue=Tt.get(O).__webglFramebuffer;if(O.isWebGLCubeRenderTarget&&re!==void 0&&(ue=ue[re]),ue){let de=O.texture,Ee=de.format,$=de.type;if(!K.textureFormatReadable(Ee))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!K.textureTypeReadable($))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(rt>=0&&rt<=O.width-_t&&vt>=0&&vt<=O.height-ct){Et.bindFramebuffer(H.FRAMEBUFFER,ue);let j=H.createBuffer();H.bindBuffer(H.PIXEL_PACK_BUFFER,j),H.bufferData(H.PIXEL_PACK_BUFFER,Zt.byteLength,H.STREAM_READ),H.readPixels(rt,vt,_t,ct,ge.convert(Ee),ge.convert($),0);let kt=A!==null?Tt.get(A).__webglFramebuffer:null;Et.bindFramebuffer(H.FRAMEBUFFER,kt);let Lt=H.fenceSync(H.SYNC_GPU_COMMANDS_COMPLETE,0);return H.flush(),await xp(H,Lt,4),H.bindBuffer(H.PIXEL_PACK_BUFFER,j),H.getBufferSubData(H.PIXEL_PACK_BUFFER,0,Zt),H.deleteBuffer(j),H.deleteSync(Lt),Zt}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(O,rt=null,vt=0){O.isTexture!==!0&&(Lr("WebGLRenderer: copyFramebufferToTexture function signature has changed."),rt=arguments[0]||null,O=arguments[1]);let _t=Math.pow(2,-vt),ct=Math.floor(O.image.width*_t),Zt=Math.floor(O.image.height*_t),re=rt!==null?rt.x:0,ue=rt!==null?rt.y:0;B.setTexture2D(O,0),H.copyTexSubImage2D(H.TEXTURE_2D,vt,0,0,re,ue,ct,Zt),Et.unbindTexture()},this.copyTextureToTexture=function(O,rt,vt=null,_t=null,ct=0){O.isTexture!==!0&&(Lr("WebGLRenderer: copyTextureToTexture function signature has changed."),_t=arguments[0]||null,O=arguments[1],rt=arguments[2],ct=arguments[3]||0,vt=null);let Zt,re,ue,de,Ee,$,j,kt,Lt,Bt=O.isCompressedTexture?O.mipmaps[ct]:O.image;vt!==null?(Zt=vt.max.x-vt.min.x,re=vt.max.y-vt.min.y,ue=vt.isBox3?vt.max.z-vt.min.z:1,de=vt.min.x,Ee=vt.min.y,$=vt.isBox3?vt.min.z:0):(Zt=Bt.width,re=Bt.height,ue=Bt.depth||1,de=0,Ee=0,$=0),_t!==null?(j=_t.x,kt=_t.y,Lt=_t.z):(j=0,kt=0,Lt=0);let me=ge.convert(rt.format),Xt=ge.convert(rt.type),Vt;rt.isData3DTexture?(B.setTexture3D(rt,0),Vt=H.TEXTURE_3D):rt.isDataArrayTexture||rt.isCompressedArrayTexture?(B.setTexture2DArray(rt,0),Vt=H.TEXTURE_2D_ARRAY):(B.setTexture2D(rt,0),Vt=H.TEXTURE_2D),H.pixelStorei(H.UNPACK_FLIP_Y_WEBGL,rt.flipY),H.pixelStorei(H.UNPACK_PREMULTIPLY_ALPHA_WEBGL,rt.premultiplyAlpha),H.pixelStorei(H.UNPACK_ALIGNMENT,rt.unpackAlignment);let Ke=H.getParameter(H.UNPACK_ROW_LENGTH),Ae=H.getParameter(H.UNPACK_IMAGE_HEIGHT),ye=H.getParameter(H.UNPACK_SKIP_PIXELS),ve=H.getParameter(H.UNPACK_SKIP_ROWS),be=H.getParameter(H.UNPACK_SKIP_IMAGES);H.pixelStorei(H.UNPACK_ROW_LENGTH,Bt.width),H.pixelStorei(H.UNPACK_IMAGE_HEIGHT,Bt.height),H.pixelStorei(H.UNPACK_SKIP_PIXELS,de),H.pixelStorei(H.UNPACK_SKIP_ROWS,Ee),H.pixelStorei(H.UNPACK_SKIP_IMAGES,$);let Qt=O.isDataArrayTexture||O.isData3DTexture,xe=rt.isDataArrayTexture||rt.isData3DTexture;if(O.isRenderTargetTexture||O.isDepthTexture){let ce=Tt.get(O),Re=Tt.get(rt),Ne=Tt.get(ce.__renderTarget),je=Tt.get(Re.__renderTarget);Et.bindFramebuffer(H.READ_FRAMEBUFFER,Ne.__webglFramebuffer),Et.bindFramebuffer(H.DRAW_FRAMEBUFFER,je.__webglFramebuffer);for(let Ze=0;Ze<ue;Ze++)Qt&&H.framebufferTextureLayer(H.READ_FRAMEBUFFER,H.COLOR_ATTACHMENT0,Tt.get(O).__webglTexture,ct,$+Ze),O.isDepthTexture?(xe&&H.framebufferTextureLayer(H.DRAW_FRAMEBUFFER,H.COLOR_ATTACHMENT0,Tt.get(rt).__webglTexture,ct,Lt+Ze),H.blitFramebuffer(de,Ee,Zt,re,j,kt,Zt,re,H.DEPTH_BUFFER_BIT,H.NEAREST)):xe?H.copyTexSubImage3D(Vt,ct,j,kt,Lt+Ze,de,Ee,Zt,re):H.copyTexSubImage2D(Vt,ct,j,kt,Lt+Ze,de,Ee,Zt,re);Et.bindFramebuffer(H.READ_FRAMEBUFFER,null),Et.bindFramebuffer(H.DRAW_FRAMEBUFFER,null)}else xe?O.isDataTexture||O.isData3DTexture?H.texSubImage3D(Vt,ct,j,kt,Lt,Zt,re,ue,me,Xt,Bt.data):rt.isCompressedArrayTexture?H.compressedTexSubImage3D(Vt,ct,j,kt,Lt,Zt,re,ue,me,Bt.data):H.texSubImage3D(Vt,ct,j,kt,Lt,Zt,re,ue,me,Xt,Bt):O.isDataTexture?H.texSubImage2D(H.TEXTURE_2D,ct,j,kt,Zt,re,me,Xt,Bt.data):O.isCompressedTexture?H.compressedTexSubImage2D(H.TEXTURE_2D,ct,j,kt,Bt.width,Bt.height,me,Bt.data):H.texSubImage2D(H.TEXTURE_2D,ct,j,kt,Zt,re,me,Xt,Bt);H.pixelStorei(H.UNPACK_ROW_LENGTH,Ke),H.pixelStorei(H.UNPACK_IMAGE_HEIGHT,Ae),H.pixelStorei(H.UNPACK_SKIP_PIXELS,ye),H.pixelStorei(H.UNPACK_SKIP_ROWS,ve),H.pixelStorei(H.UNPACK_SKIP_IMAGES,be),ct===0&&rt.generateMipmaps&&H.generateMipmap(Vt),Et.unbindTexture()},this.copyTextureToTexture3D=function(O,rt,vt=null,_t=null,ct=0){return O.isTexture!==!0&&(Lr("WebGLRenderer: copyTextureToTexture3D function signature has changed."),vt=arguments[0]||null,_t=arguments[1]||null,O=arguments[2],rt=arguments[3],ct=arguments[4]||0),Lr('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(O,rt,vt,_t,ct)},this.initRenderTarget=function(O){Tt.get(O).__webglFramebuffer===void 0&&B.setupRenderTarget(O)},this.initTexture=function(O){O.isCubeTexture?B.setTextureCube(O,0):O.isData3DTexture?B.setTexture3D(O,0):O.isDataArrayTexture||O.isCompressedArrayTexture?B.setTexture2DArray(O,0):B.setTexture2D(O,0),Et.unbindTexture()},this.resetState=function(){b=0,T=0,A=null,Et.reset(),Ie.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Ei}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorspace=Be._getDrawingBufferColorSpace(t),e.unpackColorSpace=Be._getUnpackColorSpace()}};var ma=class n{constructor(t,e=1,i=1e3){this.isFog=!0,this.name="",this.color=new fe(t),this.near=e,this.far=i}clone(){return new n(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},ga=class extends qe{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new ii,this.environmentIntensity=1,this.environmentRotation=new ii,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(e.object.environmentIntensity=this.environmentIntensity),e.object.environmentRotation=this.environmentRotation.toArray(),e}},ya=class{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=Mc,this.updateRanges=[],this.version=0,this.uuid=mi()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,i){t*=this.stride,i*=e.stride;for(let s=0,r=this.stride;s<r;s++)this.array[t+s]=e.array[i+s];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=mi()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(e,this.stride);return i.setUsage(this.usage),i}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){return t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=mi()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},Ln=new V,Vr=class n{constructor(t,e,i,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=i,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,i=this.data.count;e<i;e++)Ln.fromBufferAttribute(this,e),Ln.applyMatrix4(t),this.setXYZ(e,Ln.x,Ln.y,Ln.z);return this}applyNormalMatrix(t){for(let e=0,i=this.count;e<i;e++)Ln.fromBufferAttribute(this,e),Ln.applyNormalMatrix(t),this.setXYZ(e,Ln.x,Ln.y,Ln.z);return this}transformDirection(t){for(let e=0,i=this.count;e<i;e++)Ln.fromBufferAttribute(this,e),Ln.transformDirection(t),this.setXYZ(e,Ln.x,Ln.y,Ln.z);return this}getComponent(t,e){let i=this.array[t*this.data.stride+this.offset+e];return this.normalized&&(i=ni(i,this.array)),i}setComponent(t,e,i){return this.normalized&&(i=Ge(i,this.array)),this.data.array[t*this.data.stride+this.offset+e]=i,this}setX(t,e){return this.normalized&&(e=Ge(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=Ge(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=Ge(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=Ge(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=ni(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=ni(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=ni(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=ni(e,this.array)),e}setXY(t,e,i){return t=t*this.data.stride+this.offset,this.normalized&&(e=Ge(e,this.array),i=Ge(i,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this}setXYZ(t,e,i,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=Ge(e,this.array),i=Ge(i,this.array),s=Ge(s,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this.data.array[t+2]=s,this}setXYZW(t,e,i,s,r){return t=t*this.data.stride+this.offset,this.normalized&&(e=Ge(e,this.array),i=Ge(i,this.array),s=Ge(s,this.array),r=Ge(r,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this.data.array[t+2]=s,this.data.array[t+3]=r,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let i=0;i<this.count;i++){let s=i*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return new Qe(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new n(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let i=0;i<this.count;i++){let s=i*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},Gr=class extends Ii{static get type(){return"SpriteMaterial"}constructor(t){super(),this.isSpriteMaterial=!0,this.color=new fe(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Gs,Tr=new V,Ws=new V,$s=new V,Xs=new Ht,Ar=new Ht,Su=new Fe,zo=new V,Rr=new V,Bo=new V,Hf=new Ht,Il=new Ht,Vf=new Ht,va=class extends qe{constructor(t=new Gr){if(super(),this.isSprite=!0,this.type="Sprite",Gs===void 0){Gs=new Ye;let e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),i=new ya(e,5);Gs.setIndex([0,1,2,0,2,3]),Gs.setAttribute("position",new Vr(i,3,0,!1)),Gs.setAttribute("uv",new Vr(i,2,3,!1))}this.geometry=Gs,this.material=t,this.center=new Ht(.5,.5)}raycast(t,e){t.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Ws.setFromMatrixScale(this.matrixWorld),Su.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),$s.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Ws.multiplyScalar(-$s.z);let i=this.material.rotation,s,r;i!==0&&(r=Math.cos(i),s=Math.sin(i));let o=this.center;Ho(zo.set(-.5,-.5,0),$s,o,Ws,s,r),Ho(Rr.set(.5,-.5,0),$s,o,Ws,s,r),Ho(Bo.set(.5,.5,0),$s,o,Ws,s,r),Hf.set(0,0),Il.set(1,0),Vf.set(1,1);let a=t.ray.intersectTriangle(zo,Rr,Bo,!1,Tr);if(a===null&&(Ho(Rr.set(-.5,.5,0),$s,o,Ws,s,r),Il.set(0,1),a=t.ray.intersectTriangle(zo,Bo,Rr,!1,Tr),a===null))return;let l=t.ray.origin.distanceTo(Tr);l<t.near||l>t.far||e.push({distance:l,point:Tr.clone(),uv:$i.getInterpolation(Tr,zo,Rr,Bo,Hf,Il,Vf,new Ht),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}};function Ho(n,t,e,i,s,r){Xs.subVectors(n,e).addScalar(.5).multiply(i),s!==void 0?(Ar.x=r*Xs.x-s*Xs.y,Ar.y=s*Xs.x+r*Xs.y):Ar.copy(Xs),n.copy(t),n.x+=Ar.x,n.y+=Ar.y,n.applyMatrix4(Su)}var Wr=class extends Fn{constructor(t=null,e=1,i=1,s,r,o,a,l,c=Un,h=Un,m,g){super(null,o,a,l,c,h,s,r,m,g),this.isDataTexture=!0,this.image={data:t,width:e,height:i},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var $r=class extends Qe{constructor(t,e,i,s=1){super(t,e,i),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){let t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}},qs=new Fe,Gf=new Fe,Vo=[],Wf=new Ci,pv=new Fe,Cr=new We,Ir=new Ji,dn=class extends We{constructor(t,e,i){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new $r(new Float32Array(i*16),16),this.instanceColor=null,this.morphTexture=null,this.count=i,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<i;s++)this.setMatrixAt(s,pv)}computeBoundingBox(){let t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new Ci),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let i=0;i<e;i++)this.getMatrixAt(i,qs),Wf.copy(t.boundingBox).applyMatrix4(qs),this.boundingBox.union(Wf)}computeBoundingSphere(){let t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new Ji),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let i=0;i<e;i++)this.getMatrixAt(i,qs),Ir.copy(t.boundingSphere).applyMatrix4(qs),this.boundingSphere.union(Ir)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.morphTexture!==null&&(this.morphTexture=t.morphTexture.clone()),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,e){let i=e.morphTargetInfluences,s=this.morphTexture.source.data.data,r=i.length+1,o=t*r+1;for(let a=0;a<i.length;a++)i[a]=s[o+a]}raycast(t,e){let i=this.matrixWorld,s=this.count;if(Cr.geometry=this.geometry,Cr.material=this.material,Cr.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Ir.copy(this.boundingSphere),Ir.applyMatrix4(i),t.ray.intersectsSphere(Ir)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,qs),Gf.multiplyMatrices(i,qs),Cr.matrixWorld=Gf,Cr.raycast(t,Vo);for(let o=0,a=Vo.length;o<a;o++){let l=Vo[o];l.instanceId=r,l.object=this,e.push(l)}Vo.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new $r(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}setMorphAt(t,e){let i=e.morphTargetInfluences,s=i.length+1;this.morphTexture===null&&(this.morphTexture=new Wr(new Float32Array(s*this.count),s,this.count,ch,di));let r=this.morphTexture.source.data.data,o=0;for(let c=0;c<i.length;c++)o+=i[c];let a=this.geometry.morphTargetsRelative?1:1-o,l=s*t;r[l]=a,r.set(i,l+1)}updateMorphTargets(){}dispose(){return this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null),this}};var vs=class extends Ii{static get type(){return"LineBasicMaterial"}constructor(t){super(),this.isLineBasicMaterial=!0,this.color=new fe(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}},xa=new V,_a=new V,$f=new Fe,Pr=new ra,Go=new Ji,Pl=new V,Xf=new V,Oc=class extends qe{constructor(t=new Ye,e=new vs){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){let t=this.geometry;if(t.index===null){let e=t.attributes.position,i=[0];for(let s=1,r=e.count;s<r;s++)xa.fromBufferAttribute(e,s-1),_a.fromBufferAttribute(e,s),i[s]=i[s-1],i[s]+=xa.distanceTo(_a);t.setAttribute("lineDistance",new Te(i,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(t,e){let i=this.geometry,s=this.matrixWorld,r=t.params.Line.threshold,o=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),Go.copy(i.boundingSphere),Go.applyMatrix4(s),Go.radius+=r,t.ray.intersectsSphere(Go)===!1)return;$f.copy(s).invert(),Pr.copy(t.ray).applyMatrix4($f);let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=this.isLineSegments?2:1,h=i.index,g=i.attributes.position;if(h!==null){let d=Math.max(0,o.start),p=Math.min(h.count,o.start+o.count);for(let v=d,u=p-1;v<u;v+=c){let f=h.getX(v),S=h.getX(v+1),y=Wo(this,t,Pr,l,f,S);y&&e.push(y)}if(this.isLineLoop){let v=h.getX(p-1),u=h.getX(d),f=Wo(this,t,Pr,l,v,u);f&&e.push(f)}}else{let d=Math.max(0,o.start),p=Math.min(g.count,o.start+o.count);for(let v=d,u=p-1;v<u;v+=c){let f=Wo(this,t,Pr,l,v,v+1);f&&e.push(f)}if(this.isLineLoop){let v=Wo(this,t,Pr,l,p-1,d);v&&e.push(v)}}}updateMorphTargets(){let e=this.geometry.morphAttributes,i=Object.keys(e);if(i.length>0){let s=e[i[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}};function Wo(n,t,e,i,s,r){let o=n.geometry.attributes.position;if(xa.fromBufferAttribute(o,s),_a.fromBufferAttribute(o,r),e.distanceSqToSegment(xa,_a,Pl,Xf)>i)return;Pl.applyMatrix4(n.matrixWorld);let l=t.ray.origin.distanceTo(Pl);if(!(l<t.near||l>t.far))return{distance:l,point:Xf.clone().applyMatrix4(n.matrixWorld),index:s,face:null,faceIndex:null,barycoord:null,object:n}}var qf=new V,Yf=new V,or=class extends Oc{constructor(t,e){super(t,e),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let t=this.geometry;if(t.index===null){let e=t.attributes.position,i=[];for(let s=0,r=e.count;s<r;s+=2)qf.fromBufferAttribute(e,s),Yf.fromBufferAttribute(e,s+1),i[s]=s===0?0:i[s-1],i[s+1]=i[s]+qf.distanceTo(Yf);t.setAttribute("lineDistance",new Te(i,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}};var ar=class extends Fn{constructor(t,e,i,s,r,o,a,l,c){super(t,e,i,s,r,o,a,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},Yn=class{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(t,e){let i=this.getUtoTmapping(t);return this.getPoint(i,e)}getPoints(t=5){let e=[];for(let i=0;i<=t;i++)e.push(this.getPoint(i/t));return e}getSpacedPoints(t=5){let e=[];for(let i=0;i<=t;i++)e.push(this.getPointAt(i/t));return e}getLength(){let t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let e=[],i,s=this.getPoint(0),r=0;e.push(0);for(let o=1;o<=t;o++)i=this.getPoint(o/t),r+=i.distanceTo(s),e.push(r),s=i;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e){let i=this.getLengths(),s=0,r=i.length,o;e?o=e:o=t*i[r-1];let a=0,l=r-1,c;for(;a<=l;)if(s=Math.floor(a+(l-a)/2),c=i[s]-o,c<0)a=s+1;else if(c>0)l=s-1;else{l=s;break}if(s=l,i[s]===o)return s/(r-1);let h=i[s],g=i[s+1]-h,d=(o-h)/g;return(s+d)/(r-1)}getTangent(t,e){let s=t-1e-4,r=t+1e-4;s<0&&(s=0),r>1&&(r=1);let o=this.getPoint(s),a=this.getPoint(r),l=e||(o.isVector2?new Ht:new V);return l.copy(a).sub(o).normalize(),l}getTangentAt(t,e){let i=this.getUtoTmapping(t);return this.getTangent(i,e)}computeFrenetFrames(t,e){let i=new V,s=[],r=[],o=[],a=new V,l=new Fe;for(let d=0;d<=t;d++){let p=d/t;s[d]=this.getTangentAt(p,new V)}r[0]=new V,o[0]=new V;let c=Number.MAX_VALUE,h=Math.abs(s[0].x),m=Math.abs(s[0].y),g=Math.abs(s[0].z);h<=c&&(c=h,i.set(1,0,0)),m<=c&&(c=m,i.set(0,1,0)),g<=c&&i.set(0,0,1),a.crossVectors(s[0],i).normalize(),r[0].crossVectors(s[0],a),o[0].crossVectors(s[0],r[0]);for(let d=1;d<=t;d++){if(r[d]=r[d-1].clone(),o[d]=o[d-1].clone(),a.crossVectors(s[d-1],s[d]),a.length()>Number.EPSILON){a.normalize();let p=Math.acos(wn(s[d-1].dot(s[d]),-1,1));r[d].applyMatrix4(l.makeRotationAxis(a,p))}o[d].crossVectors(s[d],r[d])}if(e===!0){let d=Math.acos(wn(r[0].dot(r[t]),-1,1));d/=t,s[0].dot(a.crossVectors(r[0],r[t]))>0&&(d=-d);for(let p=1;p<=t;p++)r[p].applyMatrix4(l.makeRotationAxis(s[p],d*p)),o[p].crossVectors(s[p],r[p])}return{tangents:s,normals:r,binormals:o}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){let t={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}},Xr=class extends Yn{constructor(t=0,e=0,i=1,s=1,r=0,o=Math.PI*2,a=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=i,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=o,this.aClockwise=a,this.aRotation=l}getPoint(t,e=new Ht){let i=e,s=Math.PI*2,r=this.aEndAngle-this.aStartAngle,o=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(o?r=0:r=s),this.aClockwise===!0&&!o&&(r===s?r=-s:r=r-s);let a=this.aStartAngle+t*r,l=this.aX+this.xRadius*Math.cos(a),c=this.aY+this.yRadius*Math.sin(a);if(this.aRotation!==0){let h=Math.cos(this.aRotation),m=Math.sin(this.aRotation),g=l-this.aX,d=c-this.aY;l=g*h-d*m+this.aX,c=g*m+d*h+this.aY}return i.set(l,c)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){let t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}},zc=class extends Xr{constructor(t,e,i,s,r,o){super(t,e,i,i,s,r,o),this.isArcCurve=!0,this.type="ArcCurve"}};function gh(){let n=0,t=0,e=0,i=0;function s(r,o,a,l){n=r,t=a,e=-3*r+3*o-2*a-l,i=2*r-2*o+a+l}return{initCatmullRom:function(r,o,a,l,c){s(o,a,c*(a-r),c*(l-o))},initNonuniformCatmullRom:function(r,o,a,l,c,h,m){let g=(o-r)/c-(a-r)/(c+h)+(a-o)/h,d=(a-o)/h-(l-o)/(h+m)+(l-a)/m;g*=h,d*=h,s(o,a,g,d)},calc:function(r){let o=r*r,a=o*r;return n+t*r+e*o+i*a}}}var $o=new V,Ll=new gh,kl=new gh,Dl=new gh,qr=class extends Yn{constructor(t=[],e=!1,i="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=i,this.tension=s}getPoint(t,e=new V){let i=e,s=this.points,r=s.length,o=(r-(this.closed?0:1))*t,a=Math.floor(o),l=o-a;this.closed?a+=a>0?0:(Math.floor(Math.abs(a)/r)+1)*r:l===0&&a===r-1&&(a=r-2,l=1);let c,h;this.closed||a>0?c=s[(a-1)%r]:($o.subVectors(s[0],s[1]).add(s[0]),c=$o);let m=s[a%r],g=s[(a+1)%r];if(this.closed||a+2<r?h=s[(a+2)%r]:($o.subVectors(s[r-1],s[r-2]).add(s[r-1]),h=$o),this.curveType==="centripetal"||this.curveType==="chordal"){let d=this.curveType==="chordal"?.5:.25,p=Math.pow(c.distanceToSquared(m),d),v=Math.pow(m.distanceToSquared(g),d),u=Math.pow(g.distanceToSquared(h),d);v<1e-4&&(v=1),p<1e-4&&(p=v),u<1e-4&&(u=v),Ll.initNonuniformCatmullRom(c.x,m.x,g.x,h.x,p,v,u),kl.initNonuniformCatmullRom(c.y,m.y,g.y,h.y,p,v,u),Dl.initNonuniformCatmullRom(c.z,m.z,g.z,h.z,p,v,u)}else this.curveType==="catmullrom"&&(Ll.initCatmullRom(c.x,m.x,g.x,h.x,this.tension),kl.initCatmullRom(c.y,m.y,g.y,h.y,this.tension),Dl.initCatmullRom(c.z,m.z,g.z,h.z,this.tension));return i.set(Ll.calc(l),kl.calc(l),Dl.calc(l)),i}copy(t){super.copy(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(s.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,i=this.points.length;e<i;e++){let s=this.points[e];t.points.push(s.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(new V().fromArray(s))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}};function Zf(n,t,e,i,s){let r=(i-t)*.5,o=(s-e)*.5,a=n*n,l=n*a;return(2*e-2*i+r+o)*l+(-3*e+3*i-2*r-o)*a+r*n+e}function mv(n,t){let e=1-n;return e*e*t}function gv(n,t){return 2*(1-n)*n*t}function yv(n,t){return n*n*t}function Fr(n,t,e,i){return mv(n,t)+gv(n,e)+yv(n,i)}function vv(n,t){let e=1-n;return e*e*e*t}function xv(n,t){let e=1-n;return 3*e*e*n*t}function _v(n,t){return 3*(1-n)*n*n*t}function Mv(n,t){return n*n*n*t}function Or(n,t,e,i,s){return vv(n,t)+xv(n,e)+_v(n,i)+Mv(n,s)}var Ma=class extends Yn{constructor(t=new Ht,e=new Ht,i=new Ht,s=new Ht){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=i,this.v3=s}getPoint(t,e=new Ht){let i=e,s=this.v0,r=this.v1,o=this.v2,a=this.v3;return i.set(Or(t,s.x,r.x,o.x,a.x),Or(t,s.y,r.y,o.y,a.y)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},Bc=class extends Yn{constructor(t=new V,e=new V,i=new V,s=new V){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=i,this.v3=s}getPoint(t,e=new V){let i=e,s=this.v0,r=this.v1,o=this.v2,a=this.v3;return i.set(Or(t,s.x,r.x,o.x,a.x),Or(t,s.y,r.y,o.y,a.y),Or(t,s.z,r.z,o.z,a.z)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},ba=class extends Yn{constructor(t=new Ht,e=new Ht){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e}getPoint(t,e=new Ht){let i=e;return t===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(t).add(this.v1)),i}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new Ht){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Hc=class extends Yn{constructor(t=new V,e=new V){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e}getPoint(t,e=new V){let i=e;return t===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(t).add(this.v1)),i}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new V){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Sa=class extends Yn{constructor(t=new Ht,e=new Ht,i=new Ht){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=i}getPoint(t,e=new Ht){let i=e,s=this.v0,r=this.v1,o=this.v2;return i.set(Fr(t,s.x,r.x,o.x),Fr(t,s.y,r.y,o.y)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},wa=class extends Yn{constructor(t=new V,e=new V,i=new V){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=i}getPoint(t,e=new V){let i=e,s=this.v0,r=this.v1,o=this.v2;return i.set(Fr(t,s.x,r.x,o.x),Fr(t,s.y,r.y,o.y),Fr(t,s.z,r.z,o.z)),i}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Ea=class extends Yn{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,e=new Ht){let i=e,s=this.points,r=(s.length-1)*t,o=Math.floor(r),a=r-o,l=s[o===0?o:o-1],c=s[o],h=s[o>s.length-2?s.length-1:o+1],m=s[o>s.length-3?s.length-1:o+2];return i.set(Zf(a,l.x,c.x,h.x,m.x),Zf(a,l.y,c.y,h.y,m.y)),i}copy(t){super.copy(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(s.clone())}return this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,i=this.points.length;e<i;e++){let s=this.points[e];t.points.push(s.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,i=t.points.length;e<i;e++){let s=t.points[e];this.points.push(new Ht().fromArray(s))}return this}},Ta=Object.freeze({__proto__:null,ArcCurve:zc,CatmullRomCurve3:qr,CubicBezierCurve:Ma,CubicBezierCurve3:Bc,EllipseCurve:Xr,LineCurve:ba,LineCurve3:Hc,QuadraticBezierCurve:Sa,QuadraticBezierCurve3:wa,SplineCurve:Ea}),Vc=class extends Yn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(t){this.curves.push(t)}closePath(){let t=this.curves[0].getPoint(0),e=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(e)){let i=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Ta[i](e,t))}return this}getPoint(t,e){let i=t*this.getLength(),s=this.getCurveLengths(),r=0;for(;r<s.length;){if(s[r]>=i){let o=s[r]-i,a=this.curves[r],l=a.getLength(),c=l===0?0:1-o/l;return a.getPointAt(c,e)}r++}return null}getLength(){let t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let t=[],e=0;for(let i=0,s=this.curves.length;i<s;i++)e+=this.curves[i].getLength(),t.push(e);return this.cacheLengths=t,t}getSpacedPoints(t=40){let e=[];for(let i=0;i<=t;i++)e.push(this.getPoint(i/t));return this.autoClose&&e.push(e[0]),e}getPoints(t=12){let e=[],i;for(let s=0,r=this.curves;s<r.length;s++){let o=r[s],a=o.isEllipseCurve?t*2:o.isLineCurve||o.isLineCurve3?1:o.isSplineCurve?t*o.points.length:t,l=o.getPoints(a);for(let c=0;c<l.length;c++){let h=l[c];i&&i.equals(h)||(e.push(h),i=h)}}return this.autoClose&&e.length>1&&!e[e.length-1].equals(e[0])&&e.push(e[0]),e}copy(t){super.copy(t),this.curves=[];for(let e=0,i=t.curves.length;e<i;e++){let s=t.curves[e];this.curves.push(s.clone())}return this.autoClose=t.autoClose,this}toJSON(){let t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let e=0,i=this.curves.length;e<i;e++){let s=this.curves[e];t.curves.push(s.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let e=0,i=t.curves.length;e<i;e++){let s=t.curves[e];this.curves.push(new Ta[s.type]().fromJSON(s))}return this}},Yr=class extends Vc{constructor(t){super(),this.type="Path",this.currentPoint=new Ht,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let e=1,i=t.length;e<i;e++)this.lineTo(t[e].x,t[e].y);return this}moveTo(t,e){return this.currentPoint.set(t,e),this}lineTo(t,e){let i=new ba(this.currentPoint.clone(),new Ht(t,e));return this.curves.push(i),this.currentPoint.set(t,e),this}quadraticCurveTo(t,e,i,s){let r=new Sa(this.currentPoint.clone(),new Ht(t,e),new Ht(i,s));return this.curves.push(r),this.currentPoint.set(i,s),this}bezierCurveTo(t,e,i,s,r,o){let a=new Ma(this.currentPoint.clone(),new Ht(t,e),new Ht(i,s),new Ht(r,o));return this.curves.push(a),this.currentPoint.set(r,o),this}splineThru(t){let e=[this.currentPoint.clone()].concat(t),i=new Ea(e);return this.curves.push(i),this.currentPoint.copy(t[t.length-1]),this}arc(t,e,i,s,r,o){let a=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(t+a,e+l,i,s,r,o),this}absarc(t,e,i,s,r,o){return this.absellipse(t,e,i,i,s,r,o),this}ellipse(t,e,i,s,r,o,a,l){let c=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(t+c,e+h,i,s,r,o,a,l),this}absellipse(t,e,i,s,r,o,a,l){let c=new Xr(t,e,i,s,r,o,a,l);if(this.curves.length>0){let m=c.getPoint(0);m.equals(this.currentPoint)||this.lineTo(m.x,m.y)}this.curves.push(c);let h=c.getPoint(1);return this.currentPoint.copy(h),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){let t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}},Zr=class n extends Ye{constructor(t=[new Ht(0,-.5),new Ht(.5,0),new Ht(0,.5)],e=12,i=0,s=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:t,segments:e,phiStart:i,phiLength:s},e=Math.floor(e),s=wn(s,0,Math.PI*2);let r=[],o=[],a=[],l=[],c=[],h=1/e,m=new V,g=new Ht,d=new V,p=new V,v=new V,u=0,f=0;for(let S=0;S<=t.length-1;S++)switch(S){case 0:u=t[S+1].x-t[S].x,f=t[S+1].y-t[S].y,d.x=f*1,d.y=-u,d.z=f*0,v.copy(d),d.normalize(),l.push(d.x,d.y,d.z);break;case t.length-1:l.push(v.x,v.y,v.z);break;default:u=t[S+1].x-t[S].x,f=t[S+1].y-t[S].y,d.x=f*1,d.y=-u,d.z=f*0,p.copy(d),d.x+=v.x,d.y+=v.y,d.z+=v.z,d.normalize(),l.push(d.x,d.y,d.z),v.copy(p)}for(let S=0;S<=e;S++){let y=i+S*h*s,x=Math.sin(y),L=Math.cos(y);for(let b=0;b<=t.length-1;b++){m.x=t[b].x*x,m.y=t[b].y,m.z=t[b].x*L,o.push(m.x,m.y,m.z),g.x=S/e,g.y=b/(t.length-1),a.push(g.x,g.y);let T=l[3*b+0]*x,A=l[3*b+1],M=l[3*b+0]*L;c.push(T,A,M)}}for(let S=0;S<e;S++)for(let y=0;y<t.length-1;y++){let x=y+S*t.length,L=x,b=x+t.length,T=x+t.length+1,A=x+1;r.push(L,b,A),r.push(T,A,b)}this.setIndex(r),this.setAttribute("position",new Te(o,3)),this.setAttribute("uv",new Te(a,2)),this.setAttribute("normal",new Te(c,3))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.points,t.segments,t.phiStart,t.phiLength)}},si=class n extends Zr{constructor(t=1,e=1,i=4,s=8){let r=new Yr;r.absarc(0,-e/2,t,Math.PI*1.5,0),r.absarc(0,e/2,t,0,Math.PI*.5),super(r.getPoints(i),s),this.type="CapsuleGeometry",this.parameters={radius:t,length:e,capSegments:i,radialSegments:s}}static fromJSON(t){return new n(t.radius,t.length,t.capSegments,t.radialSegments)}};var pe=class n extends Ye{constructor(t=1,e=1,i=1,s=32,r=1,o=!1,a=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:i,radialSegments:s,heightSegments:r,openEnded:o,thetaStart:a,thetaLength:l};let c=this;s=Math.floor(s),r=Math.floor(r);let h=[],m=[],g=[],d=[],p=0,v=[],u=i/2,f=0;S(),o===!1&&(t>0&&y(!0),e>0&&y(!1)),this.setIndex(h),this.setAttribute("position",new Te(m,3)),this.setAttribute("normal",new Te(g,3)),this.setAttribute("uv",new Te(d,2));function S(){let x=new V,L=new V,b=0,T=(e-t)/i;for(let A=0;A<=r;A++){let M=[],_=A/r,w=_*(e-t)+t;for(let P=0;P<=s;P++){let E=P/s,F=E*l+a,R=Math.sin(F),N=Math.cos(F);L.x=w*R,L.y=-_*i+u,L.z=w*N,m.push(L.x,L.y,L.z),x.set(R,T,N).normalize(),g.push(x.x,x.y,x.z),d.push(E,1-_),M.push(p++)}v.push(M)}for(let A=0;A<s;A++)for(let M=0;M<r;M++){let _=v[M][A],w=v[M+1][A],P=v[M+1][A+1],E=v[M][A+1];(t>0||M!==0)&&(h.push(_,w,E),b+=3),(e>0||M!==r-1)&&(h.push(w,P,E),b+=3)}c.addGroup(f,b,0),f+=b}function y(x){let L=p,b=new Ht,T=new V,A=0,M=x===!0?t:e,_=x===!0?1:-1;for(let P=1;P<=s;P++)m.push(0,u*_,0),g.push(0,_,0),d.push(.5,.5),p++;let w=p;for(let P=0;P<=s;P++){let F=P/s*l+a,R=Math.cos(F),N=Math.sin(F);T.x=M*N,T.y=u*_,T.z=M*R,m.push(T.x,T.y,T.z),g.push(0,_,0),b.x=R*.5+.5,b.y=N*.5*_+.5,d.push(b.x,b.y),p++}for(let P=0;P<s;P++){let E=L+P,F=w+P;x===!0?h.push(F,F+1,E):h.push(F+1,F,E),A+=3}c.addGroup(f,A,x===!0?1:2),f+=A}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},rn=class n extends pe{constructor(t=1,e=1,i=32,s=1,r=!1,o=0,a=Math.PI*2){super(0,t,e,i,s,r,o,a),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:i,heightSegments:s,openEnded:r,thetaStart:o,thetaLength:a}}static fromJSON(t){return new n(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Gc=class n extends Ye{constructor(t=[],e=[],i=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:i,detail:s};let r=[],o=[];a(s),c(i),h(),this.setAttribute("position",new Te(r,3)),this.setAttribute("normal",new Te(r.slice(),3)),this.setAttribute("uv",new Te(o,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function a(S){let y=new V,x=new V,L=new V;for(let b=0;b<e.length;b+=3)d(e[b+0],y),d(e[b+1],x),d(e[b+2],L),l(y,x,L,S)}function l(S,y,x,L){let b=L+1,T=[];for(let A=0;A<=b;A++){T[A]=[];let M=S.clone().lerp(x,A/b),_=y.clone().lerp(x,A/b),w=b-A;for(let P=0;P<=w;P++)P===0&&A===b?T[A][P]=M:T[A][P]=M.clone().lerp(_,P/w)}for(let A=0;A<b;A++)for(let M=0;M<2*(b-A)-1;M++){let _=Math.floor(M/2);M%2===0?(g(T[A][_+1]),g(T[A+1][_]),g(T[A][_])):(g(T[A][_+1]),g(T[A+1][_+1]),g(T[A+1][_]))}}function c(S){let y=new V;for(let x=0;x<r.length;x+=3)y.x=r[x+0],y.y=r[x+1],y.z=r[x+2],y.normalize().multiplyScalar(S),r[x+0]=y.x,r[x+1]=y.y,r[x+2]=y.z}function h(){let S=new V;for(let y=0;y<r.length;y+=3){S.x=r[y+0],S.y=r[y+1],S.z=r[y+2];let x=u(S)/2/Math.PI+.5,L=f(S)/Math.PI+.5;o.push(x,1-L)}p(),m()}function m(){for(let S=0;S<o.length;S+=6){let y=o[S+0],x=o[S+2],L=o[S+4],b=Math.max(y,x,L),T=Math.min(y,x,L);b>.9&&T<.1&&(y<.2&&(o[S+0]+=1),x<.2&&(o[S+2]+=1),L<.2&&(o[S+4]+=1))}}function g(S){r.push(S.x,S.y,S.z)}function d(S,y){let x=S*3;y.x=t[x+0],y.y=t[x+1],y.z=t[x+2]}function p(){let S=new V,y=new V,x=new V,L=new V,b=new Ht,T=new Ht,A=new Ht;for(let M=0,_=0;M<r.length;M+=9,_+=6){S.set(r[M+0],r[M+1],r[M+2]),y.set(r[M+3],r[M+4],r[M+5]),x.set(r[M+6],r[M+7],r[M+8]),b.set(o[_+0],o[_+1]),T.set(o[_+2],o[_+3]),A.set(o[_+4],o[_+5]),L.copy(S).add(y).add(x).divideScalar(3);let w=u(L);v(b,_+0,S,w),v(T,_+2,y,w),v(A,_+4,x,w)}}function v(S,y,x,L){L<0&&S.x===1&&(o[y]=S.x-1),x.x===0&&x.z===0&&(o[y]=L/2/Math.PI+.5)}function u(S){return Math.atan2(S.z,-S.x)}function f(S){return Math.atan2(-S.y,Math.sqrt(S.x*S.x+S.z*S.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.vertices,t.indices,t.radius,t.details)}};var xs=class extends Yr{constructor(t){super(t),this.uuid=mi(),this.type="Shape",this.holes=[]}getPointsHoles(t){let e=[];for(let i=0,s=this.holes.length;i<s;i++)e[i]=this.holes[i].getPoints(t);return e}extractPoints(t){return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}}copy(t){super.copy(t),this.holes=[];for(let e=0,i=t.holes.length;e<i;e++){let s=t.holes[e];this.holes.push(s.clone())}return this}toJSON(){let t=super.toJSON();t.uuid=this.uuid,t.holes=[];for(let e=0,i=this.holes.length;e<i;e++){let s=this.holes[e];t.holes.push(s.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.uuid=t.uuid,this.holes=[];for(let e=0,i=t.holes.length;e<i;e++){let s=t.holes[e];this.holes.push(new Yr().fromJSON(s))}return this}},bv={triangulate:function(n,t,e=2){let i=t&&t.length,s=i?t[0]*e:n.length,r=wu(n,0,s,e,!0),o=[];if(!r||r.next===r.prev)return o;let a,l,c,h,m,g,d;if(i&&(r=Av(n,t,r,e)),n.length>80*e){a=c=n[0],l=h=n[1];for(let p=e;p<s;p+=e)m=n[p],g=n[p+1],m<a&&(a=m),g<l&&(l=g),m>c&&(c=m),g>h&&(h=g);d=Math.max(c-a,h-l),d=d!==0?32767/d:0}return Jr(r,o,e,a,l,d,0),o}};function wu(n,t,e,i,s){let r,o;if(s===Ov(n,t,e,i)>0)for(r=t;r<e;r+=i)o=Jf(r,n[r],n[r+1],o);else for(r=e-i;r>=t;r-=i)o=Jf(r,n[r],n[r+1],o);return o&&Oa(o,o.next)&&(jr(o),o=o.next),o}function _s(n,t){if(!n)return n;t||(t=n);let e=n,i;do if(i=!1,!e.steiner&&(Oa(e,e.next)||sn(e.prev,e,e.next)===0)){if(jr(e),e=t=e.prev,e===e.next)break;i=!0}else e=e.next;while(i||e!==t);return t}function Jr(n,t,e,i,s,r,o){if(!n)return;!o&&r&&Lv(n,i,s,r);let a=n,l,c;for(;n.prev!==n.next;){if(l=n.prev,c=n.next,r?wv(n,i,s,r):Sv(n)){t.push(l.i/e|0),t.push(n.i/e|0),t.push(c.i/e|0),jr(n),n=c.next,a=c.next;continue}if(n=c,n===a){o?o===1?(n=Ev(_s(n),t,e),Jr(n,t,e,i,s,r,2)):o===2&&Tv(n,t,e,i,s,r):Jr(_s(n),t,e,i,s,r,1);break}}}function Sv(n){let t=n.prev,e=n,i=n.next;if(sn(t,e,i)>=0)return!1;let s=t.x,r=e.x,o=i.x,a=t.y,l=e.y,c=i.y,h=s<r?s<o?s:o:r<o?r:o,m=a<l?a<c?a:c:l<c?l:c,g=s>r?s>o?s:o:r>o?r:o,d=a>l?a>c?a:c:l>c?l:c,p=i.next;for(;p!==t;){if(p.x>=h&&p.x<=g&&p.y>=m&&p.y<=d&&Zs(s,a,r,l,o,c,p.x,p.y)&&sn(p.prev,p,p.next)>=0)return!1;p=p.next}return!0}function wv(n,t,e,i){let s=n.prev,r=n,o=n.next;if(sn(s,r,o)>=0)return!1;let a=s.x,l=r.x,c=o.x,h=s.y,m=r.y,g=o.y,d=a<l?a<c?a:c:l<c?l:c,p=h<m?h<g?h:g:m<g?m:g,v=a>l?a>c?a:c:l>c?l:c,u=h>m?h>g?h:g:m>g?m:g,f=Wc(d,p,t,e,i),S=Wc(v,u,t,e,i),y=n.prevZ,x=n.nextZ;for(;y&&y.z>=f&&x&&x.z<=S;){if(y.x>=d&&y.x<=v&&y.y>=p&&y.y<=u&&y!==s&&y!==o&&Zs(a,h,l,m,c,g,y.x,y.y)&&sn(y.prev,y,y.next)>=0||(y=y.prevZ,x.x>=d&&x.x<=v&&x.y>=p&&x.y<=u&&x!==s&&x!==o&&Zs(a,h,l,m,c,g,x.x,x.y)&&sn(x.prev,x,x.next)>=0))return!1;x=x.nextZ}for(;y&&y.z>=f;){if(y.x>=d&&y.x<=v&&y.y>=p&&y.y<=u&&y!==s&&y!==o&&Zs(a,h,l,m,c,g,y.x,y.y)&&sn(y.prev,y,y.next)>=0)return!1;y=y.prevZ}for(;x&&x.z<=S;){if(x.x>=d&&x.x<=v&&x.y>=p&&x.y<=u&&x!==s&&x!==o&&Zs(a,h,l,m,c,g,x.x,x.y)&&sn(x.prev,x,x.next)>=0)return!1;x=x.nextZ}return!0}function Ev(n,t,e){let i=n;do{let s=i.prev,r=i.next.next;!Oa(s,r)&&Eu(s,i,i.next,r)&&Kr(s,r)&&Kr(r,s)&&(t.push(s.i/e|0),t.push(i.i/e|0),t.push(r.i/e|0),jr(i),jr(i.next),i=n=r),i=i.next}while(i!==n);return _s(i)}function Tv(n,t,e,i,s,r){let o=n;do{let a=o.next.next;for(;a!==o.prev;){if(o.i!==a.i&&Uv(o,a)){let l=Tu(o,a);o=_s(o,o.next),l=_s(l,l.next),Jr(o,t,e,i,s,r,0),Jr(l,t,e,i,s,r,0);return}a=a.next}o=o.next}while(o!==n)}function Av(n,t,e,i){let s=[],r,o,a,l,c;for(r=0,o=t.length;r<o;r++)a=t[r]*i,l=r<o-1?t[r+1]*i:n.length,c=wu(n,a,l,i,!1),c===c.next&&(c.steiner=!0),s.push(Dv(c));for(s.sort(Rv),r=0;r<s.length;r++)e=Cv(s[r],e);return e}function Rv(n,t){return n.x-t.x}function Cv(n,t){let e=Iv(n,t);if(!e)return t;let i=Tu(e,n);return _s(i,i.next),_s(e,e.next)}function Iv(n,t){let e=t,i=-1/0,s,r=n.x,o=n.y;do{if(o<=e.y&&o>=e.next.y&&e.next.y!==e.y){let g=e.x+(o-e.y)*(e.next.x-e.x)/(e.next.y-e.y);if(g<=r&&g>i&&(i=g,s=e.x<e.next.x?e:e.next,g===r))return s}e=e.next}while(e!==t);if(!s)return null;let a=s,l=s.x,c=s.y,h=1/0,m;e=s;do r>=e.x&&e.x>=l&&r!==e.x&&Zs(o<c?r:i,o,l,c,o<c?i:r,o,e.x,e.y)&&(m=Math.abs(o-e.y)/(r-e.x),Kr(e,n)&&(m<h||m===h&&(e.x>s.x||e.x===s.x&&Pv(s,e)))&&(s=e,h=m)),e=e.next;while(e!==a);return s}function Pv(n,t){return sn(n.prev,n,t.prev)<0&&sn(t.next,n,n.next)<0}function Lv(n,t,e,i){let s=n;do s.z===0&&(s.z=Wc(s.x,s.y,t,e,i)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==n);s.prevZ.nextZ=null,s.prevZ=null,kv(s)}function kv(n){let t,e,i,s,r,o,a,l,c=1;do{for(e=n,n=null,r=null,o=0;e;){for(o++,i=e,a=0,t=0;t<c&&(a++,i=i.nextZ,!!i);t++);for(l=c;a>0||l>0&&i;)a!==0&&(l===0||!i||e.z<=i.z)?(s=e,e=e.nextZ,a--):(s=i,i=i.nextZ,l--),r?r.nextZ=s:n=s,s.prevZ=r,r=s;e=i}r.nextZ=null,c*=2}while(o>1);return n}function Wc(n,t,e,i,s){return n=(n-e)*s|0,t=(t-i)*s|0,n=(n|n<<8)&16711935,n=(n|n<<4)&252645135,n=(n|n<<2)&858993459,n=(n|n<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,n|t<<1}function Dv(n){let t=n,e=n;do(t.x<e.x||t.x===e.x&&t.y<e.y)&&(e=t),t=t.next;while(t!==n);return e}function Zs(n,t,e,i,s,r,o,a){return(s-o)*(t-a)>=(n-o)*(r-a)&&(n-o)*(i-a)>=(e-o)*(t-a)&&(e-o)*(r-a)>=(s-o)*(i-a)}function Uv(n,t){return n.next.i!==t.i&&n.prev.i!==t.i&&!Nv(n,t)&&(Kr(n,t)&&Kr(t,n)&&Fv(n,t)&&(sn(n.prev,n,t.prev)||sn(n,t.prev,t))||Oa(n,t)&&sn(n.prev,n,n.next)>0&&sn(t.prev,t,t.next)>0)}function sn(n,t,e){return(t.y-n.y)*(e.x-t.x)-(t.x-n.x)*(e.y-t.y)}function Oa(n,t){return n.x===t.x&&n.y===t.y}function Eu(n,t,e,i){let s=qo(sn(n,t,e)),r=qo(sn(n,t,i)),o=qo(sn(e,i,n)),a=qo(sn(e,i,t));return!!(s!==r&&o!==a||s===0&&Xo(n,e,t)||r===0&&Xo(n,i,t)||o===0&&Xo(e,n,i)||a===0&&Xo(e,t,i))}function Xo(n,t,e){return t.x<=Math.max(n.x,e.x)&&t.x>=Math.min(n.x,e.x)&&t.y<=Math.max(n.y,e.y)&&t.y>=Math.min(n.y,e.y)}function qo(n){return n>0?1:n<0?-1:0}function Nv(n,t){let e=n;do{if(e.i!==n.i&&e.next.i!==n.i&&e.i!==t.i&&e.next.i!==t.i&&Eu(e,e.next,n,t))return!0;e=e.next}while(e!==n);return!1}function Kr(n,t){return sn(n.prev,n,n.next)<0?sn(n,t,n.next)>=0&&sn(n,n.prev,t)>=0:sn(n,t,n.prev)<0||sn(n,n.next,t)<0}function Fv(n,t){let e=n,i=!1,s=(n.x+t.x)/2,r=(n.y+t.y)/2;do e.y>r!=e.next.y>r&&e.next.y!==e.y&&s<(e.next.x-e.x)*(r-e.y)/(e.next.y-e.y)+e.x&&(i=!i),e=e.next;while(e!==n);return i}function Tu(n,t){let e=new $c(n.i,n.x,n.y),i=new $c(t.i,t.x,t.y),s=n.next,r=t.prev;return n.next=t,t.prev=n,e.next=s,s.prev=e,i.next=e,e.prev=i,r.next=i,i.prev=r,i}function Jf(n,t,e,i){let s=new $c(n,t,e);return i?(s.next=i.next,s.prev=i,i.next.prev=s,i.next=s):(s.prev=s,s.next=s),s}function jr(n){n.next.prev=n.prev,n.prev.next=n.next,n.prevZ&&(n.prevZ.nextZ=n.nextZ),n.nextZ&&(n.nextZ.prevZ=n.prevZ)}function $c(n,t,e){this.i=n,this.x=t,this.y=e,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function Ov(n,t,e,i){let s=0;for(let r=t,o=e-i;r<e;r+=i)s+=(n[o]-n[r])*(n[r+1]+n[o+1]),o=r;return s}var qi=class n{static area(t){let e=t.length,i=0;for(let s=e-1,r=0;r<e;s=r++)i+=t[s].x*t[r].y-t[r].x*t[s].y;return i*.5}static isClockWise(t){return n.area(t)<0}static triangulateShape(t,e){let i=[],s=[],r=[];Kf(t),jf(i,t);let o=t.length;e.forEach(Kf);for(let l=0;l<e.length;l++)s.push(o),o+=e[l].length,jf(i,e[l]);let a=bv.triangulate(i,s);for(let l=0;l<a.length;l+=3)r.push(a.slice(l,l+3));return r}};function Kf(n){let t=n.length;t>2&&n[t-1].equals(n[0])&&n.pop()}function jf(n,t){for(let e=0;e<t.length;e++)n.push(t[e].x),n.push(t[e].y)}var Aa=class n extends Ye{constructor(t=new xs([new Ht(.5,.5),new Ht(-.5,.5),new Ht(-.5,-.5),new Ht(.5,-.5)]),e={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:t,options:e},t=Array.isArray(t)?t:[t];let i=this,s=[],r=[];for(let a=0,l=t.length;a<l;a++){let c=t[a];o(c)}this.setAttribute("position",new Te(s,3)),this.setAttribute("uv",new Te(r,2)),this.computeVertexNormals();function o(a){let l=[],c=e.curveSegments!==void 0?e.curveSegments:12,h=e.steps!==void 0?e.steps:1,m=e.depth!==void 0?e.depth:1,g=e.bevelEnabled!==void 0?e.bevelEnabled:!0,d=e.bevelThickness!==void 0?e.bevelThickness:.2,p=e.bevelSize!==void 0?e.bevelSize:d-.1,v=e.bevelOffset!==void 0?e.bevelOffset:0,u=e.bevelSegments!==void 0?e.bevelSegments:3,f=e.extrudePath,S=e.UVGenerator!==void 0?e.UVGenerator:zv,y,x=!1,L,b,T,A;f&&(y=f.getSpacedPoints(h),x=!0,g=!1,L=f.computeFrenetFrames(h,!1),b=new V,T=new V,A=new V),g||(u=0,d=0,p=0,v=0);let M=a.extractPoints(c),_=M.shape,w=M.holes;if(!qi.isClockWise(_)){_=_.reverse();for(let nt=0,pt=w.length;nt<pt;nt++){let H=w[nt];qi.isClockWise(H)&&(w[nt]=H.reverse())}}let E=qi.triangulateShape(_,w),F=_;for(let nt=0,pt=w.length;nt<pt;nt++){let H=w[nt];_=_.concat(H)}function R(nt,pt,H){return pt||console.error("THREE.ExtrudeGeometry: vec does not exist"),nt.clone().addScaledVector(pt,H)}let N=_.length,U=E.length;function z(nt,pt,H){let qt,tt,K,Et=nt.x-pt.x,X=nt.y-pt.y,Tt=H.x-nt.x,B=H.y-nt.y,I=Et*Et+X*X,ut=Et*B-X*Tt;if(Math.abs(ut)>Number.EPSILON){let xt=Math.sqrt(I),Pt=Math.sqrt(Tt*Tt+B*B),At=pt.x-X/xt,jt=pt.y+Et/xt,dt=H.x-B/Pt,ot=H.y+Tt/Pt,St=((dt-At)*B-(ot-jt)*Tt)/(Et*B-X*Tt);qt=At+Et*St-nt.x,tt=jt+X*St-nt.y;let ht=qt*qt+tt*tt;if(ht<=2)return new Ht(qt,tt);K=Math.sqrt(ht/2)}else{let xt=!1;Et>Number.EPSILON?Tt>Number.EPSILON&&(xt=!0):Et<-Number.EPSILON?Tt<-Number.EPSILON&&(xt=!0):Math.sign(X)===Math.sign(B)&&(xt=!0),xt?(qt=-X,tt=Et,K=Math.sqrt(I)):(qt=Et,tt=X,K=Math.sqrt(I/2))}return new Ht(qt/K,tt/K)}let Z=[];for(let nt=0,pt=F.length,H=pt-1,qt=nt+1;nt<pt;nt++,H++,qt++)H===pt&&(H=0),qt===pt&&(qt=0),Z[nt]=z(F[nt],F[H],F[qt]);let Y=[],k,mt=Z.concat();for(let nt=0,pt=w.length;nt<pt;nt++){let H=w[nt];k=[];for(let qt=0,tt=H.length,K=tt-1,Et=qt+1;qt<tt;qt++,K++,Et++)K===tt&&(K=0),Et===tt&&(Et=0),k[qt]=z(H[qt],H[K],H[Et]);Y.push(k),mt=mt.concat(k)}for(let nt=0;nt<u;nt++){let pt=nt/u,H=d*Math.cos(pt*Math.PI/2),qt=p*Math.sin(pt*Math.PI/2)+v;for(let tt=0,K=F.length;tt<K;tt++){let Et=R(F[tt],Z[tt],qt);W(Et.x,Et.y,-H)}for(let tt=0,K=w.length;tt<K;tt++){let Et=w[tt];k=Y[tt];for(let X=0,Tt=Et.length;X<Tt;X++){let B=R(Et[X],k[X],qt);W(B.x,B.y,-H)}}}let bt=p+v;for(let nt=0;nt<N;nt++){let pt=g?R(_[nt],mt[nt],bt):_[nt];x?(T.copy(L.normals[0]).multiplyScalar(pt.x),b.copy(L.binormals[0]).multiplyScalar(pt.y),A.copy(y[0]).add(T).add(b),W(A.x,A.y,A.z)):W(pt.x,pt.y,0)}for(let nt=1;nt<=h;nt++)for(let pt=0;pt<N;pt++){let H=g?R(_[pt],mt[pt],bt):_[pt];x?(T.copy(L.normals[nt]).multiplyScalar(H.x),b.copy(L.binormals[nt]).multiplyScalar(H.y),A.copy(y[nt]).add(T).add(b),W(A.x,A.y,A.z)):W(H.x,H.y,m/h*nt)}for(let nt=u-1;nt>=0;nt--){let pt=nt/u,H=d*Math.cos(pt*Math.PI/2),qt=p*Math.sin(pt*Math.PI/2)+v;for(let tt=0,K=F.length;tt<K;tt++){let Et=R(F[tt],Z[tt],qt);W(Et.x,Et.y,m+H)}for(let tt=0,K=w.length;tt<K;tt++){let Et=w[tt];k=Y[tt];for(let X=0,Tt=Et.length;X<Tt;X++){let B=R(Et[X],k[X],qt);x?W(B.x,B.y+y[h-1].y,y[h-1].x+H):W(B.x,B.y,m+H)}}}D(),G();function D(){let nt=s.length/3;if(g){let pt=0,H=N*pt;for(let qt=0;qt<U;qt++){let tt=E[qt];J(tt[2]+H,tt[1]+H,tt[0]+H)}pt=h+u*2,H=N*pt;for(let qt=0;qt<U;qt++){let tt=E[qt];J(tt[0]+H,tt[1]+H,tt[2]+H)}}else{for(let pt=0;pt<U;pt++){let H=E[pt];J(H[2],H[1],H[0])}for(let pt=0;pt<U;pt++){let H=E[pt];J(H[0]+N*h,H[1]+N*h,H[2]+N*h)}}i.addGroup(nt,s.length/3-nt,0)}function G(){let nt=s.length/3,pt=0;q(F,pt),pt+=F.length;for(let H=0,qt=w.length;H<qt;H++){let tt=w[H];q(tt,pt),pt+=tt.length}i.addGroup(nt,s.length/3-nt,1)}function q(nt,pt){let H=nt.length;for(;--H>=0;){let qt=H,tt=H-1;tt<0&&(tt=nt.length-1);for(let K=0,Et=h+u*2;K<Et;K++){let X=N*K,Tt=N*(K+1),B=pt+qt+X,I=pt+tt+X,ut=pt+tt+Tt,xt=pt+qt+Tt;it(B,I,ut,xt)}}}function W(nt,pt,H){l.push(nt),l.push(pt),l.push(H)}function J(nt,pt,H){Mt(nt),Mt(pt),Mt(H);let qt=s.length/3,tt=S.generateTopUV(i,s,qt-3,qt-2,qt-1);Ct(tt[0]),Ct(tt[1]),Ct(tt[2])}function it(nt,pt,H,qt){Mt(nt),Mt(pt),Mt(qt),Mt(pt),Mt(H),Mt(qt);let tt=s.length/3,K=S.generateSideWallUV(i,s,tt-6,tt-3,tt-2,tt-1);Ct(K[0]),Ct(K[1]),Ct(K[3]),Ct(K[1]),Ct(K[2]),Ct(K[3])}function Mt(nt){s.push(l[nt*3+0]),s.push(l[nt*3+1]),s.push(l[nt*3+2])}function Ct(nt){r.push(nt.x),r.push(nt.y)}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){let t=super.toJSON(),e=this.parameters.shapes,i=this.parameters.options;return Bv(e,i,t)}static fromJSON(t,e){let i=[];for(let r=0,o=t.shapes.length;r<o;r++){let a=e[t.shapes[r]];i.push(a)}let s=t.options.extrudePath;return s!==void 0&&(t.options.extrudePath=new Ta[s.type]().fromJSON(s)),new n(i,t.options)}},zv={generateTopUV:function(n,t,e,i,s){let r=t[e*3],o=t[e*3+1],a=t[i*3],l=t[i*3+1],c=t[s*3],h=t[s*3+1];return[new Ht(r,o),new Ht(a,l),new Ht(c,h)]},generateSideWallUV:function(n,t,e,i,s,r){let o=t[e*3],a=t[e*3+1],l=t[e*3+2],c=t[i*3],h=t[i*3+1],m=t[i*3+2],g=t[s*3],d=t[s*3+1],p=t[s*3+2],v=t[r*3],u=t[r*3+1],f=t[r*3+2];return Math.abs(a-h)<Math.abs(o-c)?[new Ht(o,1-l),new Ht(c,1-m),new Ht(g,1-p),new Ht(v,1-f)]:[new Ht(a,1-l),new Ht(h,1-m),new Ht(d,1-p),new Ht(u,1-f)]}};function Bv(n,t,e){if(e.shapes=[],Array.isArray(n))for(let i=0,s=n.length;i<s;i++){let r=n[i];e.shapes.push(r.uuid)}else e.shapes.push(n.uuid);return e.options=Object.assign({},t),t.extrudePath!==void 0&&(e.options.extrudePath=t.extrudePath.toJSON()),e}var pn=class n extends Gc{constructor(t=1,e=0){let i=(1+Math.sqrt(5))/2,s=[-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,r,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new n(t.radius,t.detail)}};var lr=class n extends Ye{constructor(t=.5,e=1,i=32,s=1,r=0,o=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:i,phiSegments:s,thetaStart:r,thetaLength:o},i=Math.max(3,i),s=Math.max(1,s);let a=[],l=[],c=[],h=[],m=t,g=(e-t)/s,d=new V,p=new Ht;for(let v=0;v<=s;v++){for(let u=0;u<=i;u++){let f=r+u/i*o;d.x=m*Math.cos(f),d.y=m*Math.sin(f),l.push(d.x,d.y,d.z),c.push(0,0,1),p.x=(d.x/e+1)/2,p.y=(d.y/e+1)/2,h.push(p.x,p.y)}m+=g}for(let v=0;v<s;v++){let u=v*(i+1);for(let f=0;f<i;f++){let S=f+u,y=S,x=S+i+1,L=S+i+2,b=S+1;a.push(y,x,b),a.push(x,L,b)}}this.setIndex(a),this.setAttribute("position",new Te(l,3)),this.setAttribute("normal",new Te(c,3)),this.setAttribute("uv",new Te(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}},Ra=class n extends Ye{constructor(t=new xs([new Ht(0,.5),new Ht(-.5,-.5),new Ht(.5,-.5)]),e=12){super(),this.type="ShapeGeometry",this.parameters={shapes:t,curveSegments:e};let i=[],s=[],r=[],o=[],a=0,l=0;if(Array.isArray(t)===!1)c(t);else for(let h=0;h<t.length;h++)c(t[h]),this.addGroup(a,l,h),a+=l,l=0;this.setIndex(i),this.setAttribute("position",new Te(s,3)),this.setAttribute("normal",new Te(r,3)),this.setAttribute("uv",new Te(o,2));function c(h){let m=s.length/3,g=h.extractPoints(e),d=g.shape,p=g.holes;qi.isClockWise(d)===!1&&(d=d.reverse());for(let u=0,f=p.length;u<f;u++){let S=p[u];qi.isClockWise(S)===!0&&(p[u]=S.reverse())}let v=qi.triangulateShape(d,p);for(let u=0,f=p.length;u<f;u++){let S=p[u];d=d.concat(S)}for(let u=0,f=d.length;u<f;u++){let S=d[u];s.push(S.x,S.y,0),r.push(0,0,1),o.push(S.x,S.y)}for(let u=0,f=v.length;u<f;u++){let S=v[u],y=S[0]+m,x=S[1]+m,L=S[2]+m;i.push(y,x,L),l+=3}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){let t=super.toJSON(),e=this.parameters.shapes;return Hv(e,t)}static fromJSON(t,e){let i=[];for(let s=0,r=t.shapes.length;s<r;s++){let o=e[t.shapes[s]];i.push(o)}return new n(i,t.curveSegments)}};function Hv(n,t){if(t.shapes=[],Array.isArray(n))for(let e=0,i=n.length;e<i;e++){let s=n[e];t.shapes.push(s.uuid)}else t.shapes.push(n.uuid);return t}var Pe=class n extends Ye{constructor(t=1,e=32,i=16,s=0,r=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:i,phiStart:s,phiLength:r,thetaStart:o,thetaLength:a},e=Math.max(3,Math.floor(e)),i=Math.max(2,Math.floor(i));let l=Math.min(o+a,Math.PI),c=0,h=[],m=new V,g=new V,d=[],p=[],v=[],u=[];for(let f=0;f<=i;f++){let S=[],y=f/i,x=0;f===0&&o===0?x=.5/e:f===i&&l===Math.PI&&(x=-.5/e);for(let L=0;L<=e;L++){let b=L/e;m.x=-t*Math.cos(s+b*r)*Math.sin(o+y*a),m.y=t*Math.cos(o+y*a),m.z=t*Math.sin(s+b*r)*Math.sin(o+y*a),p.push(m.x,m.y,m.z),g.copy(m).normalize(),v.push(g.x,g.y,g.z),u.push(b+x,1-y),S.push(c++)}h.push(S)}for(let f=0;f<i;f++)for(let S=0;S<e;S++){let y=h[f][S+1],x=h[f][S],L=h[f+1][S],b=h[f+1][S+1];(f!==0||o>0)&&d.push(y,x,b),(f!==i-1||l<Math.PI)&&d.push(x,L,b)}this.setIndex(d),this.setAttribute("position",new Te(p,3)),this.setAttribute("normal",new Te(v,3)),this.setAttribute("uv",new Te(u,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};var ln=class n extends Ye{constructor(t=1,e=.4,i=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:i,tubularSegments:s,arc:r},i=Math.floor(i),s=Math.floor(s);let o=[],a=[],l=[],c=[],h=new V,m=new V,g=new V;for(let d=0;d<=i;d++)for(let p=0;p<=s;p++){let v=p/s*r,u=d/i*Math.PI*2;m.x=(t+e*Math.cos(u))*Math.cos(v),m.y=(t+e*Math.cos(u))*Math.sin(v),m.z=e*Math.sin(u),a.push(m.x,m.y,m.z),h.x=t*Math.cos(v),h.y=t*Math.sin(v),g.subVectors(m,h).normalize(),l.push(g.x,g.y,g.z),c.push(p/s),c.push(d/i)}for(let d=1;d<=i;d++)for(let p=1;p<=s;p++){let v=(s+1)*d+p-1,u=(s+1)*(d-1)+p-1,f=(s+1)*(d-1)+p,S=(s+1)*d+p;o.push(v,u,S),o.push(u,f,S)}this.setIndex(o),this.setAttribute("position",new Te(a,3)),this.setAttribute("normal",new Te(l,3)),this.setAttribute("uv",new Te(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new n(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}};var Ca=class n extends Ye{constructor(t=new wa(new V(-1,-1,0),new V(-1,1,0),new V(1,1,0)),e=64,i=1,s=8,r=!1){super(),this.type="TubeGeometry",this.parameters={path:t,tubularSegments:e,radius:i,radialSegments:s,closed:r};let o=t.computeFrenetFrames(e,r);this.tangents=o.tangents,this.normals=o.normals,this.binormals=o.binormals;let a=new V,l=new V,c=new Ht,h=new V,m=[],g=[],d=[],p=[];v(),this.setIndex(p),this.setAttribute("position",new Te(m,3)),this.setAttribute("normal",new Te(g,3)),this.setAttribute("uv",new Te(d,2));function v(){for(let y=0;y<e;y++)u(y);u(r===!1?e:0),S(),f()}function u(y){h=t.getPointAt(y/e,h);let x=o.normals[y],L=o.binormals[y];for(let b=0;b<=s;b++){let T=b/s*Math.PI*2,A=Math.sin(T),M=-Math.cos(T);l.x=M*x.x+A*L.x,l.y=M*x.y+A*L.y,l.z=M*x.z+A*L.z,l.normalize(),g.push(l.x,l.y,l.z),a.x=h.x+i*l.x,a.y=h.y+i*l.y,a.z=h.z+i*l.z,m.push(a.x,a.y,a.z)}}function f(){for(let y=1;y<=e;y++)for(let x=1;x<=s;x++){let L=(s+1)*(y-1)+(x-1),b=(s+1)*y+(x-1),T=(s+1)*y+x,A=(s+1)*(y-1)+x;p.push(L,b,A),p.push(b,T,A)}}function S(){for(let y=0;y<=e;y++)for(let x=0;x<=s;x++)c.x=y/e,c.y=x/s,d.push(c.x,c.y)}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){let t=super.toJSON();return t.path=this.parameters.path.toJSON(),t}static fromJSON(t){return new n(new Ta[t.path.type]().fromJSON(t.path),t.tubularSegments,t.radius,t.radialSegments,t.closed)}};var Ia=class extends Ii{static get type(){return"MeshToonMaterial"}constructor(t){super(),this.isMeshToonMaterial=!0,this.defines={TOON:""},this.color=new fe(16777215),this.map=null,this.gradientMap=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new fe(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=du,this.normalScale=new Ht(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.alphaMap=null,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.gradientMap=t.gradientMap,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.alphaMap=t.alphaMap,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};function Yo(n,t,e){return!n||!e&&n.constructor===t?n:typeof t.BYTES_PER_ELEMENT=="number"?new t(n):Array.prototype.slice.call(n)}function Vv(n){return ArrayBuffer.isView(n)&&!(n instanceof DataView)}var cr=class{constructor(t,e,i,s){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new e.constructor(i),this.sampleValues=e,this.valueSize=i,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,i=this._cachedIndex,s=e[i],r=e[i-1];n:{t:{let o;e:{i:if(!(t<s)){for(let a=i+2;;){if(s===void 0){if(t<r)break i;return i=e.length,this._cachedIndex=i,this.copySampleValue_(i-1)}if(i===a)break;if(r=s,s=e[++i],t<s)break t}o=e.length;break e}if(!(t>=r)){let a=e[1];t<a&&(i=2,r=a);for(let l=i-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===l)break;if(s=r,r=e[--i-1],t>=r)break t}o=i,i=0;break e}break n}for(;i<o;){let a=i+o>>>1;t<e[a]?o=a:i=a+1}if(s=e[i],r=e[i-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return i=e.length,this._cachedIndex=i,this.copySampleValue_(i-1)}this._cachedIndex=i,this.intervalChanged_(i,r,s)}return this.interpolate_(i,r,t,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,i=this.sampleValues,s=this.valueSize,r=t*s;for(let o=0;o!==s;++o)e[o]=i[r+o];return e}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},Xc=class extends cr{constructor(t,e,i,s){super(t,e,i,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Wh,endingEnd:Wh}}intervalChanged_(t,e,i){let s=this.parameterPositions,r=t-2,o=t+1,a=s[r],l=s[o];if(a===void 0)switch(this.getSettings_().endingStart){case $h:r=t,a=2*e-i;break;case Xh:r=s.length-2,a=e+s[r]-s[r+1];break;default:r=t,a=i}if(l===void 0)switch(this.getSettings_().endingEnd){case $h:o=t,l=2*i-e;break;case Xh:o=1,l=i+s[1]-s[0];break;default:o=t-1,l=e}let c=(i-e)*.5,h=this.valueSize;this._weightPrev=c/(e-a),this._weightNext=c/(l-i),this._offsetPrev=r*h,this._offsetNext=o*h}interpolate_(t,e,i,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=t*a,c=l-a,h=this._offsetPrev,m=this._offsetNext,g=this._weightPrev,d=this._weightNext,p=(i-e)/(s-e),v=p*p,u=v*p,f=-g*u+2*g*v-g*p,S=(1+g)*u+(-1.5-2*g)*v+(-.5+g)*p+1,y=(-1-d)*u+(1.5+d)*v+.5*p,x=d*u-d*v;for(let L=0;L!==a;++L)r[L]=f*o[h+L]+S*o[c+L]+y*o[l+L]+x*o[m+L];return r}},qc=class extends cr{constructor(t,e,i,s){super(t,e,i,s)}interpolate_(t,e,i,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=t*a,c=l-a,h=(i-e)/(s-e),m=1-h;for(let g=0;g!==a;++g)r[g]=o[c+g]*m+o[l+g]*h;return r}},Yc=class extends cr{constructor(t,e,i,s){super(t,e,i,s)}interpolate_(t){return this.copySampleValue_(t-1)}},ri=class{constructor(t,e,i,s){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=Yo(e,this.TimeBufferType),this.values=Yo(i,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,i;if(e.toJSON!==this.toJSON)i=e.toJSON(t);else{i={name:t.name,times:Yo(t.times,Array),values:Yo(t.values,Array)};let s=t.getInterpolation();s!==t.DefaultInterpolation&&(i.interpolation=s)}return i.type=t.ValueTypeName,i}InterpolantFactoryMethodDiscrete(t){return new Yc(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new qc(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new Xc(this.times,this.values,this.getValueSize(),t)}setInterpolation(t){let e;switch(t){case ta:e=this.InterpolantFactoryMethodDiscrete;break;case _c:e=this.InterpolantFactoryMethodLinear;break;case il:e=this.InterpolantFactoryMethodSmooth;break}if(e===void 0){let i="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(i);return console.warn("THREE.KeyframeTrack:",i),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return ta;case this.InterpolantFactoryMethodLinear:return _c;case this.InterpolantFactoryMethodSmooth:return il}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let i=0,s=e.length;i!==s;++i)e[i]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let i=0,s=e.length;i!==s;++i)e[i]*=t}return this}trim(t,e){let i=this.times,s=i.length,r=0,o=s-1;for(;r!==s&&i[r]<t;)++r;for(;o!==-1&&i[o]>e;)--o;if(++o,r!==0||o!==s){r>=o&&(o=Math.max(o,1),r=o-1);let a=this.getValueSize();this.times=i.slice(r,o),this.values=this.values.slice(r*a,o*a)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),t=!1);let i=this.times,s=this.values,r=i.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),t=!1);let o=null;for(let a=0;a!==r;a++){let l=i[a];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,a,l),t=!1;break}if(o!==null&&o>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,a,l,o),t=!1;break}o=l}if(s!==void 0&&Vv(s))for(let a=0,l=s.length;a!==l;++a){let c=s[a];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,a,c),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),i=this.getValueSize(),s=this.getInterpolation()===il,r=t.length-1,o=1;for(let a=1;a<r;++a){let l=!1,c=t[a],h=t[a+1];if(c!==h&&(a!==1||c!==t[0]))if(s)l=!0;else{let m=a*i,g=m-i,d=m+i;for(let p=0;p!==i;++p){let v=e[m+p];if(v!==e[g+p]||v!==e[d+p]){l=!0;break}}}if(l){if(a!==o){t[o]=t[a];let m=a*i,g=o*i;for(let d=0;d!==i;++d)e[g+d]=e[m+d]}++o}}if(r>0){t[o]=t[r];for(let a=r*i,l=o*i,c=0;c!==i;++c)e[l+c]=e[a+c];++o}return o!==t.length?(this.times=t.slice(0,o),this.values=e.slice(0,o*i)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),i=this.constructor,s=new i(this.name,t,e);return s.createInterpolant=this.createInterpolant,s}};ri.prototype.TimeBufferType=Float32Array;ri.prototype.ValueBufferType=Float32Array;ri.prototype.DefaultInterpolation=_c;var Ms=class extends ri{constructor(t,e,i){super(t,e,i)}};Ms.prototype.ValueTypeName="bool";Ms.prototype.ValueBufferType=Array;Ms.prototype.DefaultInterpolation=ta;Ms.prototype.InterpolantFactoryMethodLinear=void 0;Ms.prototype.InterpolantFactoryMethodSmooth=void 0;var Zc=class extends ri{};Zc.prototype.ValueTypeName="color";var Jc=class extends ri{};Jc.prototype.ValueTypeName="number";var Kc=class extends cr{constructor(t,e,i,s){super(t,e,i,s)}interpolate_(t,e,i,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=(i-e)/(s-e),c=t*a;for(let h=c+a;c!==h;c+=4)$n.slerpFlat(r,0,o,c-a,o,c,l);return r}},Pa=class extends ri{InterpolantFactoryMethodLinear(t){return new Kc(this.times,this.values,this.getValueSize(),t)}};Pa.prototype.ValueTypeName="quaternion";Pa.prototype.InterpolantFactoryMethodSmooth=void 0;var bs=class extends ri{constructor(t,e,i){super(t,e,i)}};bs.prototype.ValueTypeName="string";bs.prototype.ValueBufferType=Array;bs.prototype.DefaultInterpolation=ta;bs.prototype.InterpolantFactoryMethodLinear=void 0;bs.prototype.InterpolantFactoryMethodSmooth=void 0;var jc=class extends ri{};jc.prototype.ValueTypeName="vector";var Qc=class{constructor(t,e,i){let s=this,r=!1,o=0,a=0,l,c=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=i,this.itemStart=function(h){a++,r===!1&&s.onStart!==void 0&&s.onStart(h,o,a),r=!0},this.itemEnd=function(h){o++,s.onProgress!==void 0&&s.onProgress(h,o,a),o===a&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(h){s.onError!==void 0&&s.onError(h)},this.resolveURL=function(h){return l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,m){return c.push(h,m),this},this.removeHandler=function(h){let m=c.indexOf(h);return m!==-1&&c.splice(m,2),this},this.getHandler=function(h){for(let m=0,g=c.length;m<g;m+=2){let d=c[m],p=c[m+1];if(d.global&&(d.lastIndex=0),d.test(h))return p}return null}}},Gv=new Qc,th=class{constructor(t){this.manager=t!==void 0?t:Gv,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,e){let i=this;return new Promise(function(s,r){i.load(t,s,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}};th.DEFAULT_MATERIAL_NAME="__DEFAULT";var La=class extends qe{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new fe(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(e.object.target=this.target.uuid),e}},ka=class extends La{constructor(t,e,i){super(t,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(qe.DEFAULT_UP),this.updateMatrix(),this.groundColor=new fe(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}},Ul=new Fe,Qf=new V,tu=new V,eh=class{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Ht(512,512),this.map=null,this.mapPass=null,this.matrix=new Fe,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Hr,this._frameExtents=new Ht(1,1),this._viewportCount=1,this._viewports=[new an(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera,i=this.matrix;Qf.setFromMatrixPosition(t.matrixWorld),e.position.copy(Qf),tu.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(tu),e.updateMatrixWorld(),Ul.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Ul),i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(Ul)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return this.intensity!==1&&(t.intensity=this.intensity),this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}};var nh=class extends eh{constructor(){super(new fa(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Da=class extends La{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(qe.DEFAULT_UP),this.updateMatrix(),this.target=new qe,this.shadow=new nh}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}};var yh="\\[\\]\\.:\\/",Wv=new RegExp("["+yh+"]","g"),vh="[^"+yh+"]",$v="[^"+yh.replace("\\.","")+"]",Xv=/((?:WC+[\/:])*)/.source.replace("WC",vh),qv=/(WCOD+)?/.source.replace("WCOD",$v),Yv=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",vh),Zv=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",vh),Jv=new RegExp("^"+Xv+qv+Yv+Zv+"$"),Kv=["material","materials","bones","map"],ih=class{constructor(t,e,i){let s=i||nn.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,s)}getValue(t,e){this.bind();let i=this._targetGroup.nCachedObjects_,s=this._bindings[i];s!==void 0&&s.getValue(t,e)}setValue(t,e){let i=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=i.length;s!==r;++s)i[s].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,i=t.length;e!==i;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,i=t.length;e!==i;++e)t[e].unbind()}},nn=class n{constructor(t,e,i){this.path=e,this.parsedPath=i||n.parseTrackName(e),this.node=n.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,i){return t&&t.isAnimationObjectGroup?new n.Composite(t,e,i):new n(t,e,i)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(Wv,"")}static parseTrackName(t){let e=Jv.exec(t);if(e===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let i={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},s=i.nodeName&&i.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){let r=i.nodeName.substring(s+1);Kv.indexOf(r)!==-1&&(i.nodeName=i.nodeName.substring(0,s),i.objectName=r)}if(i.propertyName===null||i.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return i}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let i=t.skeleton.getBoneByName(e);if(i!==void 0)return i}if(t.children){let i=function(r){for(let o=0;o<r.length;o++){let a=r[o];if(a.name===e||a.uuid===e)return a;let l=i(a.children);if(l)return l}return null},s=i(t.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)t[e++]=i[s]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)i[s]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)i[s]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let i=this.resolvedProperty;for(let s=0,r=i.length;s!==r;++s)i[s]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,i=e.objectName,s=e.propertyName,r=e.propertyIndex;if(t||(t=n.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(i){let c=e.objectIndex;switch(i){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let h=0;h<t.length;h++)if(t[h].name===c){c=h;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[i]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[i]}if(c!==void 0){if(t[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[c]}}let o=t[s];if(o===void 0){let c=e.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+s+" but it wasn't found.",t);return}let a=this.Versioning.None;this.targetObject=t,t.needsUpdate!==void 0?a=this.Versioning.NeedsUpdate:t.matrixWorldNeedsUpdate!==void 0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=r}else o.fromArray!==void 0&&o.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(l=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=s;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};nn.Composite=ih;nn.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};nn.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};nn.prototype.GetterByBindingType=[nn.prototype._getValue_direct,nn.prototype._getValue_array,nn.prototype._getValue_arrayElement,nn.prototype._getValue_toArray];nn.prototype.SetterByBindingTypeAndVersioning=[[nn.prototype._setValue_direct,nn.prototype._setValue_direct_setNeedsUpdate,nn.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[nn.prototype._setValue_array,nn.prototype._setValue_array_setNeedsUpdate,nn.prototype._setValue_array_setMatrixWorldNeedsUpdate],[nn.prototype._setValue_arrayElement,nn.prototype._setValue_arrayElement_setNeedsUpdate,nn.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[nn.prototype._setValue_fromArray,nn.prototype._setValue_fromArray_setNeedsUpdate,nn.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var s_=new Float32Array(1);typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:sh}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=sh);var jv=2.3,tn=7.2,za=.16,ji=(n,t,e)=>{let i=Math.max(0,Math.min(1,(e-n)/(t-n)));return i*i*(3-2*i)};function Au(n,t,e){let i=n.points,s=i.length-1,r=n.lengthM/s,o=D=>{let G=Math.max(0,Math.min(s,D/r)),q=Math.min(s-1,Math.floor(G)),W=G-q,J=i[Math.max(0,q-1)],it=i[q],Mt=i[q+1],Ct=i[Math.min(s,q+2)],nt=pt=>.5*(2*it[pt]+(-J[pt]+Mt[pt])*W+(2*J[pt]-5*it[pt]+4*Mt[pt]-Ct[pt])*W*W+(-J[pt]+3*it[pt]-3*Mt[pt]+Ct[pt])*W*W*W);return[nt(0),nt(2),it[1]+(Mt[1]-it[1])*W]},a=D=>{if(D<=n.lengthM)return o(D);let G=o(n.lengthM-20),q=o(n.lengthM),W=(D-n.lengthM)/20;return[q[0]+(q[0]-G[0])*W,q[1]+(q[1]-G[1])*W,q[2]]},l=2700,c=2585,h=n.overlaps.filter(([D,G])=>G>D).sort((D,G)=>D[1]-G[1]),m=D=>{for(let W=0;W<h.length-1;W++){let[J,it]=h[W],[Mt,Ct]=h[W+1];if(D<=Ct)return J+(D-it)*(Mt-J)/(Ct-it)}let[G,q]=h.at(-1);return G+(D-q)},g=[];for(let D=0;D<=l;D+=2)g.push([D,...o(D)]);let d=2600,p=4900,v=[];for(let D=d;D<=p;D+=10){let G=o(D),q=m(D),W=q,J=1e9;for(let it of g){if(Math.abs(it[0]-q)>60)continue;let Mt=(it[1]-G[0])**2+(it[2]-G[1])**2;Mt<J&&(J=Mt,W=it[0])}v.push(W)}let u=v.map((D,G)=>{let q=0,W=0;for(let J=-3;J<=3;J++){let it=G+J;it>=0&&it<v.length&&(q+=v[it],W++)}return q/W});for(let D=1;D<u.length;D++)u[D]=Math.max(u[D],u[D-1]+.5);let f=D=>{let G=(D-d)/10,q=Math.max(0,Math.min(u.length-2,Math.floor(G))),W=G-q;return u[q]+(u[q+1]-u[q])*W},S={};function y(D){for(let G of Object.keys(S))delete S[G];for(let G of(D==null?void 0:D.runners)||[])!G.diversions||!G.diversions.length||(S[G.id]=G.diversions.map(q=>{let W=q.path,J=[0];for(let it=1;it<W.length;it++)J.push(J[it-1]+Math.hypot(W[it][0]-W[it-1][0],W[it][1]-W[it-1][1]));return{...q,cum:J,len:J.at(-1)}}))}y(e);let x=(D,G)=>{let q=Math.max(0,Math.min(1,(G-D.fromM)/(D.toM-D.fromM)))*D.len,W=0;for(;W<D.cum.length-2&&D.cum[W+1]<q;)W++;let J=(q-D.cum[W])/Math.max(1e-6,D.cum[W+1]-D.cum[W]);return[D.path[W][0]+(D.path[W+1][0]-D.path[W][0])*J,D.path[W][1]+(D.path[W+1][1]-D.path[W][1])*J]};function L(D){if(D<d-60){let J=a(D);return[J[0],J[1]]}let G=a(D);if(D>=p+40)return[G[0],G[1]];let q=ji(d-60,d+60,D)*(1-ji(p-60,p,D));if(q<=0)return[G[0],G[1]];let W=o(Math.min(l,f(Math.max(d,Math.min(p,D)))));return[G[0]+(W[0]-G[0])*q,G[1]+(W[1]-G[1])*q]}function b(D,G){let q=L(D),W=G&&S[G];if(W){for(let J of W)if(D>J.fromM&&D<J.toM){let it=ji(J.fromM,J.fromM+30,D)*(1-ji(J.toM-30,J.toM,D)),Mt=x(J,D);return q=[q[0]+(Mt[0]-q[0])*it,q[1]+(Mt[1]-q[1])*it],{x:q[0],z:q[1],div:it,divInfo:J}}}return{x:q[0],z:q[1],div:0,divInfo:null}}let[T,A,M,_]=t.bounds,w={x0:T-60,z0:A-60,cell:5};w.nx=Math.ceil((M+60-w.x0)/w.cell)+1,w.nz=Math.ceil((_+60-w.z0)/w.cell)+1,w.h=new Float32Array(w.nx*w.nz);let P=[];for(let D=0;D<=s;D+=2)P.push(i[D]);let E=0;for(let D of P)E+=D[1];E/=P.length;let F=(D,G)=>Math.sin(D*.011+1.3)*Math.cos(G*.009-.4)*2.2+Math.sin(D*.027+G*.019)*.9;for(let D=0;D<w.nz;D++)for(let G=0;G<w.nx;G++){let q=w.x0+G*w.cell,W=w.z0+D*w.cell,J=0,it=0,Mt=1e9;for(let pt of P){let H=(pt[0]-q)**2+(pt[2]-W)**2;H<Mt&&(Mt=H);let qt=1/(H+400),tt=qt*qt;J+=tt,it+=tt*pt[1]}let Ct=ji(30,160,Math.sqrt(Mt)),nt=it/J*(1-Ct*.4)+E*Ct*.4+F(q,W)*Ct;w.h[D*w.nx+G]=nt*jv}let R=t.features.filter(D=>D.closed&&["water","track","tennis","pitch"].includes(D.kind)&&D.pts.length>3);for(let D of R){let G=Zn(D.pts),q=[];for(let it=Math.max(0,Math.floor((G[1]-12-w.z0)/w.cell));it<=Math.min(w.nz-1,Math.ceil((G[3]+12-w.z0)/w.cell));it++)for(let Mt=Math.max(0,Math.floor((G[0]-12-w.x0)/w.cell));Mt<=Math.min(w.nx-1,Math.ceil((G[2]+12-w.x0)/w.cell));Mt++){let Ct=w.x0+Mt*w.cell,nt=w.z0+it*w.cell,pt=to(D.pts,Ct,nt);pt<12&&q.push([it*w.nx+Mt,pt])}let W=0,J=0;for(let[it,Mt]of q)Mt<0&&(W+=w.h[it],J++);if(J){W/=J,D.kind==="water"&&(W=Math.min(...q.filter(it=>it[1]<0).map(it=>w.h[it[0]]))-.2),D._level=W;for(let[it,Mt]of q){let Ct=1-ji(0,12,Mt);w.h[it]=w.h[it]*(1-Ct)+W*Ct-(D.kind==="water"?1.6*(1-ji(-6,0,Mt)):0)}}}{for(let nt=0;nt<3;nt++){let pt=new Float32Array(w.h);for(let H=1;H<w.nz-1;H++)for(let qt=1;qt<w.nx-1;qt++){let tt=H*w.nx+qt;pt[tt]=(w.h[tt]*4+w.h[tt-1]+w.h[tt+1]+w.h[tt-w.nx]+w.h[tt+w.nx])/8}w.h.set(pt)}let D=new Float32Array(w.nx*w.nz).fill(1e9),G=new Float32Array(w.nx*w.nz),q=new Float32Array(w.nx*w.nz),W=(nt,pt)=>w.h[pt*w.nx+nt],J=(nt,pt)=>{let H=Math.round((nt-w.x0)/w.cell),qt=Math.round((pt-w.z0)/w.cell);return W(Math.max(0,Math.min(w.nx-1,H)),Math.max(0,Math.min(w.nz-1,qt)))},it=[[0,c],[2540,2690],[p-80,n.lengthM+45]],Mt=[];for(let[nt,pt]of it)for(let H=nt;H<=pt;H+=2){let qt=L(H);Mt.push([qt[0],qt[1],J(qt[0],qt[1])])}for(let nt=0;nt<4;nt++)for(let pt=1;pt<Mt.length-1;pt++)Mt[pt][2]=(Mt[pt-1][2]+Mt[pt][2]*2+Mt[pt+1][2])/4;let Ct=tn/2+7;for(let[nt,pt,H]of Mt){let qt=Math.floor((nt-Ct-w.x0)/w.cell),tt=Math.ceil((nt+Ct-w.x0)/w.cell),K=Math.floor((pt-Ct-w.z0)/w.cell),Et=Math.ceil((pt+Ct-w.z0)/w.cell);for(let X=Math.max(0,K);X<=Math.min(w.nz-1,Et);X++)for(let Tt=Math.max(0,qt);Tt<=Math.min(w.nx-1,tt);Tt++){let B=Math.hypot(w.x0+Tt*w.cell-nt,w.z0+X*w.cell-pt);if(B>Ct)continue;let I=X*w.nx+Tt,ut=(1-B/Ct)**2;G[I]+=ut,q[I]+=ut*H,B<D[I]&&(D[I]=B)}}for(let nt=0;nt<D.length;nt++)if(D[nt]<Ct&&G[nt]>0){let pt=1-ji(tn/2+.5,Ct,D[nt]);w.h[nt]=w.h[nt]*(1-pt)+q[nt]/G[nt]*pt}w.pathSamples=Mt}let N=R.filter(D=>D.kind==="water").sort((D,G)=>G.pts.length-D.pts.length)[0];function U(D,G){let q=(D-w.x0)/w.cell,W=(G-w.z0)/w.cell,J=Math.max(0,Math.min(w.nx-2,Math.floor(q))),it=Math.max(0,Math.min(w.nz-2,Math.floor(W))),Mt=Math.max(0,Math.min(1,q-J)),Ct=Math.max(0,Math.min(1,W-it)),nt=w.h[it*w.nx+J],pt=w.h[it*w.nx+J+1],H=w.h[(it+1)*w.nx+J],qt=w.h[(it+1)*w.nx+J+1];return Mt+Ct<=1?nt+(pt-nt)*Mt+(H-nt)*Ct:qt+(H-qt)*(1-Mt)+(pt-qt)*(1-Ct)}let z=new V;function Z(D,G,q={}){let W=b(D,G),J=Math.max(0,D-4),it=J+8,Mt=b(J,G),Ct=b(it,G),nt=Ct.x-Mt.x,pt=Ct.z-Mt.z,H=Math.hypot(nt,pt)||1;return nt/=H,pt/=H,q.x=W.x,q.z=W.z,q.y=U(W.x,W.z)+za,q.tx=nt,q.tz=pt,q.rx=-pt,q.rz=nt,q.slope=(U(Ct.x,Ct.z)-U(Mt.x,Mt.z))/Math.max(1,H),q.div=W.div,q.divInfo=W.divInfo,q}function Y(D,G=25){let q=Math.max(0,D-G),W=L(q),J=L(q+2*G),it=Math.hypot(J[0]-W[0],J[1]-W[1])||1;return z.set((J[0]-W[0])/it,0,(J[1]-W[1])/it).clone()}let k=[{from:0,to:c,lift:0},{from:2540,to:2690,lift:.02},{from:p-80,to:n.lengthM+45,lift:.035}],mt=n.lengthM;return{P:i,raw:o,rawExt:a,baseXZ:L,LAP1_END_DRAW:c,xzAt:b,sample:Z,heading:Y,heightAt:U,terrain:w,ribbons:k,finishM:mt,lake:N,flat:R,geoOf:D=>D>=d&&D<=p?f(D):D,diversions:S,setPlan:y,LAP1_END:l,MAP_FROM:d,MAP_TO:p}}function Zn(n){let t=[1e9,1e9,-1e9,-1e9];for(let e of n)t[0]=Math.min(t[0],e[0]),t[1]=Math.min(t[1],e[1]),t[2]=Math.max(t[2],e[0]),t[3]=Math.max(t[3],e[1]);return t}function ur(n,t,e){let i=!1;for(let s=0,r=n.length-1;s<n.length;r=s++){let[o,a]=n[s],[l,c]=n[r];a>e!=c>e&&t<(l-o)*(e-a)/(c-a)+o&&(i=!i)}return i}function to(n,t,e){let i=1e9;for(let s=0,r=n.length-1;s<n.length;r=s++){let[o,a]=n[r],[l,c]=n[s],h=l-o,m=c-a,g=h*h+m*m||1,d=Math.max(0,Math.min(1,((t-o)*h+(e-a)*m)/g));i=Math.min(i,Math.hypot(t-o-h*d,e-a-m*d))}return ur(n,t,e)?-i:i}function fn(n,t=!1){let e=n[0].index!==null,i=new Set(Object.keys(n[0].attributes)),s=new Set(Object.keys(n[0].morphAttributes)),r={},o={},a=n[0].morphTargetsRelative,l=new Ye,c=0;for(let h=0;h<n.length;++h){let m=n[h],g=0;if(e!==(m.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(let d in m.attributes){if(!i.has(d))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have compatible attributes; make sure "'+d+'" attribute exists among all geometries, or in none of them.'),null;r[d]===void 0&&(r[d]=[]),r[d].push(m.attributes[d]),g++}if(g!==i.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of attributes."),null;if(a!==m.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(let d in m.morphAttributes){if(!s.has(d))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+".  .morphAttributes must be consistent throughout all geometries."),null;o[d]===void 0&&(o[d]=[]),o[d].push(m.morphAttributes[d])}if(t){let d;if(e)d=m.index.count;else if(m.attributes.position!==void 0)d=m.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". The geometry must have either an index or a position attribute"),null;l.addGroup(c,d,h),c+=d}}if(e){let h=0,m=[];for(let g=0;g<n.length;++g){let d=n[g].index;for(let p=0;p<d.count;++p)m.push(d.getX(p)+h);h+=n[g].attributes.position.count}l.setIndex(m)}for(let h in r){let m=Ru(r[h]);if(!m)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" attribute."),null;l.setAttribute(h,m)}for(let h in o){let m=o[h][0].length;if(m===0)break;l.morphAttributes=l.morphAttributes||{},l.morphAttributes[h]=[];for(let g=0;g<m;++g){let d=[];for(let v=0;v<o[h].length;++v)d.push(o[h][v][g]);let p=Ru(d);if(!p)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" morphAttribute."),null;l.morphAttributes[h].push(p)}}return l}function Ru(n){let t,e,i,s=-1,r=0;for(let c=0;c<n.length;++c){let h=n[c];if(t===void 0&&(t=h.array.constructor),t!==h.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(e===void 0&&(e=h.itemSize),e!==h.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(i===void 0&&(i=h.normalized),i!==h.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(s===-1&&(s=h.gpuType),s!==h.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;r+=h.count*e}let o=new t(r),a=new Qe(o,e,i),l=0;for(let c=0;c<n.length;++c){let h=n[c];if(h.isInterleavedBufferAttribute){let m=l/e;for(let g=0,d=h.count;g<d;g++)for(let p=0;p<e;p++){let v=h.getComponent(g,p);a.setComponent(g+m,p,v)}}else o.set(h.array,l);l+=h.count*e}return s!==void 0&&(a.gpuType=s),a}var eo=new V;function Jn(n,t,e,i,s,r){let o=2*Math.PI*s/4,a=Math.max(r-2*s,0),l=Math.PI/4;eo.copy(t),eo[i]=0,eo.normalize();let c=.5*o/(o+a),h=1-eo.angleTo(n)/l;return Math.sign(eo[e])===1?h*c:a/(o+a)+c+c*(1-h)}var Ue=class extends ze{constructor(t=1,e=1,i=1,s=2,r=.1){if(s=s*2+1,r=Math.min(t/2,e/2,i/2,r),super(1,1,1,s,s,s),s===1)return;let o=this.toNonIndexed();this.index=null,this.attributes.position=o.attributes.position,this.attributes.normal=o.attributes.normal,this.attributes.uv=o.attributes.uv;let a=new V,l=new V,c=new V(t,e,i).divideScalar(2).subScalar(r),h=this.attributes.position.array,m=this.attributes.normal.array,g=this.attributes.uv.array,d=h.length/6,p=new V,v=.5/s;for(let u=0,f=0;u<h.length;u+=3,f+=2)switch(a.fromArray(h,u),l.copy(a),l.x-=Math.sign(l.x)*v,l.y-=Math.sign(l.y)*v,l.z-=Math.sign(l.z)*v,l.normalize(),h[u+0]=c.x*Math.sign(a.x)+l.x*r,h[u+1]=c.y*Math.sign(a.y)+l.y*r,h[u+2]=c.z*Math.sign(a.z)+l.z*r,m[u+0]=l.x,m[u+1]=l.y,m[u+2]=l.z,Math.floor(u/d)){case 0:p.set(1,0,0),g[f+0]=Jn(p,l,"z","y",r,i),g[f+1]=1-Jn(p,l,"y","z",r,e);break;case 1:p.set(-1,0,0),g[f+0]=1-Jn(p,l,"z","y",r,i),g[f+1]=1-Jn(p,l,"y","z",r,e);break;case 2:p.set(0,1,0),g[f+0]=1-Jn(p,l,"x","z",r,t),g[f+1]=Jn(p,l,"z","x",r,i);break;case 3:p.set(0,-1,0),g[f+0]=1-Jn(p,l,"x","z",r,t),g[f+1]=1-Jn(p,l,"z","x",r,i);break;case 4:p.set(0,0,1),g[f+0]=1-Jn(p,l,"x","y",r,t),g[f+1]=1-Jn(p,l,"y","x",r,e);break;case 5:p.set(0,0,-1),g[f+0]=Jn(p,l,"x","y",r,t),g[f+1]=1-Jn(p,l,"y","x",r,e);break}}};var Qi=null;function Qv(){if(Qi)return Qi;let n=[118,172,228,255],t=new Uint8Array(n.length*4);return n.forEach((e,i)=>t.set([e,e,e,255],i*4)),Qi=new Wr(t,n.length,1,Wn),Qi.minFilter=Qi.magFilter=Un,Qi.generateMipmaps=!1,Qi.needsUpdate=!0,Qi}var no=new Map;function gt(n,t={}){let e=!t.map&&(typeof n=="number"||typeof n=="string")?`${n}|${JSON.stringify(t)}`:null;if(e&&!t.map&&no.has(e))return no.get(e);let i=new Ia({color:new fe(n??16777215),gradientMap:Qv(),...t});return e&&!t.map&&no.set(e,i),i}function Cu(){for(let n of no.values())n.dispose();no.clear(),io.forEach(n=>n.dispose()),io.clear()}var xh={uRes:{value:new Ht(1920,1080)}},io=new Map;function tx(n=3,t=1709088,e=14){let i=`${n}|${t}|${e}`;if(io.has(i))return io.get(i);let s=new Nn({uniforms:{...ph.clone(te.fog),uRes:xh.uRes,uWidth:{value:n},uRef:{value:e},uColor:{value:new fe(t)}},vertexShader:`
      attribute vec3 onormal;
      uniform vec2 uRes; uniform float uWidth; uniform float uRef;
      #include <fog_pars_vertex>
      void main() {
        mat4 m = modelMatrix;
        #ifdef USE_INSTANCING
          m = modelMatrix * instanceMatrix;
        #endif
        vec4 wp = m * vec4(position, 1.0);
        vec3 wn = normalize(mat3(m) * onormal);
        vec4 clip = projectionMatrix * viewMatrix * wp;
        vec4 clipN = projectionMatrix * viewMatrix * vec4(wp.xyz + wn * 0.05, 1.0);
        vec2 dir = clipN.xy / clipN.w - clip.xy / clip.w;
        float l = length(dir);
        dir = l > 1e-6 ? dir / l : vec2(0.0);
        float k = clamp(uRef / max(clip.w, 0.1), 0.18, 1.0);
        float px = uWidth * k * (uRes.y / 1080.0);
        clip.xy += dir * px * 2.0 / uRes * clip.w;
        clip.z += 0.0004 * clip.w;
        gl_Position = clip;
        vec4 mvPosition = viewMatrix * wp;
        #include <fog_vertex>
      }`,fragmentShader:`
      uniform vec3 uColor;
      #include <fog_pars_fragment>
      void main() { gl_FragColor = vec4(uColor, 1.0);
        #include <fog_fragment>
      }`,side:En,fog:!0});return io.set(i,s),s}function _h(n){if(n.getAttribute("onormal"))return n;n.getAttribute("normal")||n.computeVertexNormals();let t=n.getAttribute("position"),e=n.getAttribute("normal"),i=new Map,s=a=>`${Math.round(t.getX(a)*1e3)},${Math.round(t.getY(a)*1e3)},${Math.round(t.getZ(a)*1e3)}`,r=[];for(let a=0;a<t.count;a++){let l=s(a),c=i.get(l);c||(c=[0,0,0],i.set(l,c)),c[0]+=e.getX(a),c[1]+=e.getY(a),c[2]+=e.getZ(a),r.push(c)}let o=new Float32Array(t.count*3);for(let a=0;a<t.count;a++){let l=r[a],c=Math.hypot(l[0],l[1],l[2])||1;o[a*3]=l[0]/c,o[a*3+1]=l[1]/c,o[a*3+2]=l[2]/c}return n.setAttribute("onormal",new Qe(o,3)),n}function oi(n,t=3,e,i){_h(n.geometry);let s=tx(t,e,i),r;return n.isInstancedMesh?(r=new dn(n.geometry,s,n.count),r.instanceMatrix=n.instanceMatrix,r.count=n.count,n.frustumCulled&&n.boundingSphere?(r.boundingSphere=n.boundingSphere,r.frustumCulled=!0):(r.frustumCulled=!1,n.frustumCulled=!1),n.userData.outline=r):(r=new We(n.geometry,s),r.frustumCulled=n.frustumCulled),r.castShadow=!1,r.receiveShadow=!1,r.userData.isOutline=!0,r.renderOrder=n.renderOrder,n.add(r),r}function Le(n,t,{cast:e=!0,receive:i=!0,ol:s=0,olColor:r,olRef:o}={}){let a=new We(n,t);return a.castShadow=e,a.receiveShadow=i,s&&oi(a,s,r,o),a}function yn(n,t,e,{repeat:i=!1,srgb:s=!0,aniso:r=8}={}){let o=document.createElement("canvas");o.width=n,o.height=t;let a=o.getContext("2d");e(a,n,t);let l=new ar(o);return s&&(l.colorSpace=Sn),i&&(l.wrapS=l.wrapT=gs),l.anisotropy=r,l}var Mh='"Lilita One", "Arial Black", "Arial Rounded MT Bold", Impact, sans-serif',he=zn(20240817);function zn(n){return()=>{n|=0,n=n+1831565813|0;let t=Math.imul(n^n>>>15,1|n);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}function ai(n,t,e,i){let s=yn(n,t,e);return document.fonts&&document.fonts.load&&document.fonts.load('64px "Lilita One"').then(()=>{let r=s.image.getContext("2d");r.clearRect(0,0,n,t),e(r,n,t),s.needsUpdate=!0}).catch(()=>{}),i==null||i.push(s),s}function vn(n,t,e,i,s,r="#fff",o="#1a1420",a=.16,l="center"){n.font=`${s}px ${Mh}`,n.textAlign=l,n.textBaseline="middle",n.lineJoin="round",n.lineWidth=s*a,n.strokeStyle=o,n.strokeText(t,e,i),n.fillStyle=r,n.fillText(t,e,i)}function Pu(n,t,e){var Ve;let{course:i,park:s,hasFunfair:r}=e,o=[],a=new _e;n.add(a);let l=C=>(a.add(C),C),c=t.terrain,h=(c.nx-1)*c.cell,m=(c.nz-1)*c.cell,g=new Map,d=6,p=(C,Q)=>`${Math.floor(C/d)},${Math.floor(Q/d)}`,v=(C,Q,at)=>{let lt=p(C,Q),wt=g.get(lt);wt||g.set(lt,wt=[]),wt.push([C,Q,at])},u=(C,Q,at)=>{let lt=Math.floor(C/d),wt=Math.floor(Q/d),ft=Math.ceil((at+30)/d);for(let It=-ft;It<=ft;It++)for(let Jt=-ft;Jt<=ft;Jt++){let zt=g.get(`${lt+It},${wt+Jt}`);if(zt){for(let[Ft,Ut,st]of zt)if((Ft-C)**2+(Ut-Q)**2<(st+at)**2)return!1}}return!0},f=[];for(let C of t.ribbons)for(let Q=C.from;Q<=C.to;Q+=3){let at=t.baseXZ(Q);f.push(at),v(at[0],at[1],tn/2+1.5)}for(let C in t.diversions)for(let Q of t.diversions[C])for(let at of Q.path)v(at[0],at[1],4);let S=s.features.filter(C=>C.kind==="park").sort((C,Q)=>Q.pts.length-C.pts.length)[0].pts,y=(C,Q)=>ur(S,C,Q),L=s.features.filter(C=>C.closed&&["water","track","tennis","pitch","playground","building"].includes(C.kind)).map(C=>[Zn(C.pts),C]),b=(C,Q,at=2)=>L.some(([lt,wt])=>C>lt[0]-at&&C<lt[2]+at&&Q>lt[1]-at&&Q<lt[3]+at&&to(wt.pts,C,Q)<at),T=1.7,A=[];function M(C,Q,at=!1){A.push({im:C,list:Q,occluder:at})}let _=new Set,w=new Fe;function P(C,Q,at=5){let lt=new Set,wt=C?C.x:0,ft=C?C.z:0,It=Q?Q.x:0,Jt=Q?Q.z:0,zt=It-wt,Ft=Jt-ft,Ut=zt*zt+Ft*Ft||1;for(let st of A)st.occluder&&st.list.forEach((Nt,$t)=>{let ie=!1;if(C&&!Nt.cleared){let ke=((Nt.x-wt)*zt+(Nt.z-ft)*Ft)/Ut;if(ke>.02&&ke<1){let He=wt+zt*ke-Nt.x,O=ft+Ft*ke-Nt.z;ie=!((1-ke)*Math.sqrt(Ut)<6)&&He*He+O*O<(at*(Nt.s||1))**2}}let Me=st.im.id*1e5+$t;ie&&!_.has(Me)?(_.add(Me),st.im.setMatrixAt($t,E),lt.add(st.im)):!ie&&_.has(Me)&&(_.delete(Me),st.im.setMatrixAt($t,Nt._m||w.identity()),lt.add(st.im))});for(let st of lt)st.instanceMatrix.needsUpdate=!0}let E=new Fe().makeScale(0,0,0);function F(C){for(let{im:Q,list:at}of A){let lt=!1;at.forEach((wt,ft)=>{!wt.cleared&&C(wt.x,wt.z)&&(wt.cleared=!0,Q.setMatrixAt(ft,E),lt=!0)}),lt&&(Q.instanceMatrix.needsUpdate=!0)}}function R(){let C=N.image.getContext("2d");U(C,N.image.width,N.image.height),N.needsUpdate=!0}let N=yn(Math.round(h*T),Math.round(m*T),(C,Q,at)=>U(C,Q,at),{aniso:8});o.push(N);function U(C,Q,at){var Ft,Ut;let lt=st=>(st-c.x0)*T,wt=st=>(st-c.z0)*T,ft=(st,Nt=!0)=>{C.beginPath(),st.forEach(($t,ie)=>ie?C.lineTo(lt($t[0]),wt($t[1])):C.moveTo(lt($t[0]),wt($t[1]))),Nt&&C.closePath()};C.fillStyle="#d8d2c2",C.fillRect(0,0,Q,at);for(let st=0;st<9e3;st++)C.fillStyle=he()<.5?"#cfc8b6":"#e2dccd",C.fillRect(he()*Q,he()*at,3,3);ft(S),C.fillStyle="#66cf45",C.fill(),C.save(),ft(S),C.clip(),C.translate(Q/2,at/2),C.rotate(-.62);for(let st=-2e3;st<2e3;st+=2*14*T)C.fillStyle="rgba(255,255,140,0.10)",C.fillRect(st,-2500,14*T,5e3);C.setTransform(1,0,0,1,0,0);for(let st=0;st<26e3;st++){let Nt=he()*Q,$t=he()*at;C.fillStyle=he()<.6?"rgba(40,140,40,0.35)":"rgba(190,255,120,0.35)",C.fillRect(Nt,$t,2+he()*2,2+he()*3)}C.restore();let It=(st,Nt,$t)=>{for(let ie of s.features)ie.kind===st&&ie.closed&&(ft(ie.pts),C.fillStyle=Nt,C.fill(),$t&&(C.strokeStyle=$t,C.lineWidth=2,C.stroke()))};It("grass","#72d64e"),It("garden","#86dc5c"),It("wood","#3f9e3a"),It("scrub","#5cb544");for(let st of s.features)if(st.kind==="pitch"&&st.closed){C.save(),ft(st.pts),C.clip(),C.fillStyle="#5ccc3f",C.fill();let Nt=Zn(st.pts);for(let $t=Nt[0];$t<Nt[2];$t+=8)C.fillStyle="rgba(255,255,255,0.10)",C.fillRect(lt($t),wt(Nt[1]),4*T,(Nt[3]-Nt[1])*T);C.restore(),ft(st.pts),C.strokeStyle="#ffffff",C.lineWidth=2.2,C.stroke()}for(let st of s.features)if(st.kind==="playground"&&st.closed){ft(st.pts),C.fillStyle="#7fcfb4",C.fill(),C.save(),ft(st.pts),C.clip();let Nt=Zn(st.pts);for(let $t=0;$t<260;$t++)C.fillStyle=he()<.5?"rgba(20,80,70,0.18)":"rgba(255,255,255,0.22)",C.fillRect(lt(Nt[0]+he()*(Nt[2]-Nt[0])),wt(Nt[1]+he()*(Nt[3]-Nt[1])),3,3);for(let $t=0;$t<(Nt[2]-Nt[0])*(Nt[3]-Nt[1])/400;$t++)C.beginPath(),C.arc(lt(Nt[0]+he()*(Nt[2]-Nt[0])),wt(Nt[1]+he()*(Nt[3]-Nt[1])),1.6*T,0,7),C.fillStyle=["#ffd93b","#57c7ff","#ff6f91"][$t%3],C.fill();C.restore(),ft(st.pts),C.strokeStyle="#ffffff",C.lineWidth=.8*T,C.stroke()}let Jt=st=>{let Nt=0;for(let $t=0,ie=st.pts.length-1;$t<st.pts.length;ie=$t++)Nt+=(st.pts[ie][0]+st.pts[$t][0])*(st.pts[ie][1]-st.pts[$t][1]);return Math.abs(Nt/2)};for(let st of s.features)if(st.kind==="track"&&st.closed&&Jt(st)>5e3){C.save(),ft(st.pts),C.clip(),C.fillStyle="#e2523a",C.fill();let Nt=9*T,$t=Ba(st.pts),ie=Zn(st.pts),Me=ie[2]-ie[0],ke=ie[3]-ie[1],He=rt=>st.pts.map(vt=>[$t[0]+(vt[0]-$t[0])*rt,$t[1]+(vt[1]-$t[1])*rt]),O=1-2*9/Math.min(Me,ke);for(let rt=1;rt<=5;rt++)ft(He(1-(1-O)*(rt/6))),C.strokeStyle="rgba(255,255,255,0.9)",C.lineWidth=1.6,C.stroke();ft(He(O)),C.fillStyle="#5ccc3f",C.fill(),C.strokeStyle="#ffffff",C.lineWidth=3,C.stroke(),C.restore(),ft(st.pts),C.strokeStyle="#ffffff",C.lineWidth=3,C.stroke()}for(let st of s.features)if(st.kind==="track"&&st.closed&&Jt(st)<=5e3){let Nt=((Ft=st.tags)==null?void 0:Ft.surface)==="sand";if(!((Ut=st.tags)!=null&&Ut.surface))continue;ft(st.pts),C.fillStyle=Nt?"#f2d58f":"#e2523a",C.fill(),C.strokeStyle="#ffffff",C.lineWidth=1.5,C.stroke()}for(let st of s.features)if(st.kind==="tennis"&&st.closed){ft(st.pts),C.fillStyle="#3f9fd1",C.fill(),C.strokeStyle="#ffffff",C.lineWidth=2.5,C.stroke();let Nt=Ba(st.pts),$t=Zn(st.pts);C.save(),ft(st.pts),C.clip(),C.strokeStyle="rgba(255,255,255,0.9)",C.lineWidth=1.5,C.beginPath(),C.moveTo(lt(Nt[0]),wt($t[1])),C.lineTo(lt(Nt[0]),wt($t[3])),C.stroke(),C.restore()}for(let st of s.features)st.kind==="water"&&st.closed&&(ft(st.pts),C.strokeStyle="#f4efe0",C.lineWidth=3.4*T,C.lineJoin="round",C.stroke(),C.fillStyle="#2f8fe0",C.fill());for(let st of s.features)st.kind==="path"&&(ft(st.pts,!1),C.lineCap="round",C.lineJoin="round",C.strokeStyle="#c9ad78",C.lineWidth=3.6*T,C.stroke());for(let st of s.features)st.kind==="path"&&(ft(st.pts,!1),C.strokeStyle="#ecd8a6",C.lineWidth=2.6*T,C.stroke());let zt=st=>{var Nt;return{primary:15,secondary:12,tertiary:11,residential:8,unclassified:8,service:5,trunk:16}[(Nt=st.tags)==null?void 0:Nt.highway]||7};for(let st of s.features)st.kind==="road"&&(ft(st.pts,st.closed),C.lineCap="round",C.lineJoin="round",C.strokeStyle="#ece6d6",C.lineWidth=(zt(st)+4)*T,C.stroke());for(let st of s.features)st.kind==="road"&&(ft(st.pts,st.closed),C.strokeStyle="#7f8597",C.lineWidth=zt(st)*T,C.stroke());for(let st of s.features)st.kind==="road"&&zt(st)>=11&&(ft(st.pts,!1),C.setLineDash([5*T,5*T]),C.strokeStyle="#f4f1e6",C.lineWidth=.5*T,C.stroke(),C.setLineDash([]));for(let st of s.features)st.kind==="rail"&&(ft(st.pts,!1),C.strokeStyle="#9b8f84",C.lineWidth=5*T,C.stroke());for(let st of s.features)st.kind==="rail"&&(ft(st.pts,!1),C.setLineDash([1,2]),C.strokeStyle="#5b4f46",C.lineWidth=3*T,C.stroke(),C.setLineDash([]),ft(st.pts,!1),C.strokeStyle="#c9ccd6",C.lineWidth=.8,C.stroke());for(let st of s.features)st.kind==="building"&&st.closed&&(ft(st.pts),C.fillStyle="#9c968a",C.fill());for(let st in t.diversions)for(let Nt of t.diversions[st])C.beginPath(),Nt.path.forEach(($t,ie)=>ie?C.lineTo(lt($t[0]),wt($t[1])):C.moveTo(lt($t[0]),wt($t[1]))),C.lineCap="round",C.lineJoin="round",C.strokeStyle="rgba(196,160,96,0.85)",C.lineWidth=4*T,C.stroke(),C.setLineDash([2*T,3*T]),C.strokeStyle="rgba(255,240,200,0.8)",C.lineWidth=.6*T,C.stroke(),C.setLineDash([])}{let C=c.nx*c.nz,Q=new Float32Array(C*3),at=new Float32Array(C*2);for(let st=0;st<c.nz;st++)for(let Nt=0;Nt<c.nx;Nt++){let $t=st*c.nx+Nt;Q[$t*3]=c.x0+Nt*c.cell,Q[$t*3+1]=c.h[$t],Q[$t*3+2]=c.z0+st*c.cell,at[$t*2]=Nt/(c.nx-1),at[$t*2+1]=1-st/(c.nz-1)}let lt=new Uint32Array((c.nx-1)*(c.nz-1)*6),wt=0;for(let st=0;st<c.nz-1;st++)for(let Nt=0;Nt<c.nx-1;Nt++){let $t=st*c.nx+Nt,ie=$t+1,Me=$t+c.nx,ke=Me+1;lt[wt++]=$t,lt[wt++]=Me,lt[wt++]=ie,lt[wt++]=ie,lt[wt++]=Me,lt[wt++]=ke}let ft=new Ye;ft.setAttribute("position",new Qe(Q,3)),ft.setAttribute("uv",new Qe(at,2)),ft.setIndex(new Qe(lt,1)),ft.computeVertexNormals();let It=gt(16777215,{map:N}),Jt=yn(256,256,(st,Nt,$t)=>{st.fillStyle="#808080",st.fillRect(0,0,Nt,$t);for(let ie=0;ie<1800;ie++){let Me=100+Math.floor(he()*70);st.fillStyle=`rgb(${Me},${Me},${Me})`;let ke=he()*Nt,He=he()*$t;st.fillRect(ke,He,2,3+he()*5)}for(let ie=0;ie<500;ie++)st.fillStyle="rgba(255,255,255,0.18)",st.fillRect(he()*Nt,he()*$t,2,2)},{repeat:!0,srgb:!1});o.push(Jt),It.onBeforeCompile=st=>{st.uniforms.uDetail={value:Jt},st.vertexShader=st.vertexShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;`).replace("#include <worldpos_vertex>",`#include <worldpos_vertex>
vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`),st.fragmentShader=st.fragmentShader.replace("#include <common>",`#include <common>
varying vec3 vWPos; uniform sampler2D uDetail;`).replace("#include <map_fragment>",`#include <map_fragment>
          float dd = length(vWPos - cameraPosition);
          float d1 = texture2D(uDetail, vWPos.xz / 3.0).r, d2 = texture2D(uDetail, vWPos.xz / 11.0).r;
          float fade = 1.0 - smoothstep(25.0, 140.0, dd);
          diffuseColor.rgb *= mix(1.0, 0.8 + 0.4 * mix(d2, d1, fade), 0.55);`)},It.customProgramCacheKey=()=>"terrain-detail";let zt=Le(ft,It,{cast:!1});zt.name="terrain",l(zt);let Ft=new We(new lr(700,5200,48,1),gt(13227680));Ft.rotation.x=-Math.PI/2,Ft.position.set(c.x0+h/2,-2,c.z0+m/2),Ft.receiveShadow=!1,l(Ft);let Ut=new We(new Tn(h+1800,m+1800),gt(13686197));Ut.rotation.x=-Math.PI/2,Ut.position.set(c.x0+h/2,-3,c.z0+m/2),l(Ut)}let z=yn(256,256,(C,Q,at)=>{C.fillStyle="#7f8fb0",C.fillRect(0,0,Q,at);for(let lt=0;lt<1600;lt++)C.fillStyle=he()<.5?"rgba(255,255,255,0.07)":"rgba(30,40,70,0.08)",C.fillRect(he()*Q,he()*at,2,2);C.fillStyle="#6b7a9b",C.fillRect(0,0,Q*.035,at),C.fillRect(Q*.965,0,Q*.035,at),C.fillStyle="#ffffff",C.fillRect(Q*.06,0,Q*.045,at),C.fillRect(Q*.895,0,Q*.045,at),C.fillStyle="rgba(255,255,255,0.35)",C.fillRect(Q*.49,0,Q*.02,at*.5)},{repeat:!0});o.push(z);{let C=[];for(let ft of t.ribbons)C.push(Z(ft));let Q=fn(C),at=Le(Q,gt(16777215,{map:z}),{cast:!1});at.name="path",l(at);let lt=fn(t.ribbons.map(ft=>Z(ft,!0))),wt=Le(lt,gt(5924226),{cast:!1});l(wt)}function Z(C,Q=!1){let at=[];for(let Ft=C.from;Ft<=C.to+.01;Ft+=2)at.push(t.baseXZ(Ft));let lt=[],wt=[],ft=[],It=0;for(let Ft=0;Ft<at.length;Ft++){let Ut=at[Math.max(0,Ft-1)],st=at[Math.min(at.length-1,Ft+1)],Nt=st[0]-Ut[0],$t=st[1]-Ut[1],ie=Math.hypot(Nt,$t)||1;Nt/=ie,$t/=ie;let Me=-$t,ke=Nt,He=tn/2,O=[at[Ft][0]-Me*He,at[Ft][1]-ke*He],rt=[at[Ft][0]+Me*He,at[Ft][1]+ke*He],vt=t.heightAt(at[Ft][0],at[Ft][1]),_t=Math.max(t.heightAt(O[0],O[1]),vt-.05)+za+C.lift,ct=Math.max(t.heightAt(rt[0],rt[1]),vt-.05)+za+C.lift;Q?(lt.push(O[0]-Me*.15,_t-.45,O[1]-ke*.15,O[0],_t,O[1],rt[0],ct,rt[1],rt[0]+Me*.15,ct-.45,rt[1]+ke*.15),wt.push(0,0,0,1,0,1,0,0)):(lt.push(O[0],_t,O[1],rt[0],ct,rt[1]),wt.push(0,It/8,1,It/8)),Ft&&(It+=2)}let Jt=Q?4:2;for(let Ft=0;Ft<at.length-1;Ft++){let Ut=Ft*Jt,st=(Ft+1)*Jt;Q?(ft.push(Ut,st,Ut+1,Ut+1,st,st+1),ft.push(Ut+2,st+2,Ut+3,Ut+3,st+2,st+3)):ft.push(Ut,st,Ut+1,Ut+1,st,st+1)}let zt=new Ye;if(zt.setAttribute("position",new Te(lt,3)),zt.setAttribute("uv",new Te(wt,2)),zt.setIndex(ft),zt.computeVertexNormals(),zt.getAttribute("normal").getY(0)<0&&!Q){let Ft=zt.index.array;for(let Ut=0;Ut<Ft.length;Ut+=3){let st=Ft[Ut+1];Ft[Ut+1]=Ft[Ut+2],Ft[Ut+2]=st}zt.computeVertexNormals()}return zt}let Y={uTime:{value:0}},k=s.features.filter(C=>C.kind==="water"&&C.closed);for(let C of k){let Q=(C._level??Math.min(...C.pts.map(It=>t.heightAt(It[0],It[1]))))+.05,at=new xs(C.pts.map(It=>new Ht(It[0],-It[1]))),lt=new Ra(at,4);lt.rotateX(-Math.PI/2),lt.translate(0,Q,0);let wt=new Nn({uniforms:{...Y,...te.fog},vertexShader:`varying vec3 vW;
${Ce.fog_pars_vertex}
        void main(){ vec4 w = modelMatrix*vec4(position,1.); vW=w.xyz; vec4 mvPosition = viewMatrix*w; gl_Position=projectionMatrix*mvPosition;
${Ce.fog_vertex}
}`,fragmentShader:`uniform float uTime; varying vec3 vW;
${Ce.fog_pars_fragment}
        void main(){
          vec2 p = vW.xz*0.09;
          float w1 = sin(p.x*3.1 + uTime*1.3 + sin(p.y*2.3+uTime*0.7)*1.7);
          float w2 = sin(p.y*2.7 - uTime*1.1 + sin(p.x*1.9-uTime*0.5)*1.9);
          float r = smoothstep(0.86,0.9, w1*w2);
          vec3 c = mix(vec3(0.16,0.55,0.93), vec3(0.24,0.70,1.0), smoothstep(-0.6,0.8,w1*0.5+w2*0.5));
          c = mix(c, vec3(0.92,0.98,1.0), r);
          gl_FragColor = vec4(c,1.);
          #include <colorspace_fragment>

${Ce.fog_fragment}
        }`,fog:!0}),ft=new We(lt,wt);ft.name="water",l(ft),o.push(wt),C._waterLevel=Q}let mt=[];if(t.lake){let C=t.lake,Q=Zn(C.pts),at=[16767291,16735581,5752831,16777215,16748497,8257418],lt=new Ue(2,.7,3.6,2,.32),wt=new Ue(1.2,.5,.8,2,.2);for(let ft=0,It=0;ft<9&&It<300;It++){let Jt=Q[0]+he()*(Q[2]-Q[0]),zt=Q[1]+he()*(Q[3]-Q[1]);if(to(C.pts,Jt,zt)>-7)continue;let Ft=new _e,Ut=Le(lt,gt(at[ft%at.length]),{ol:2.5});Ft.add(Ut);let st=Le(wt,gt(16777215),{ol:2});st.position.y=.45,Ft.add(st);let Nt=Le(new Pe(.42,12,8),gt(at[(ft+2)%at.length]),{ol:2});Nt.position.set(0,.9,.7),Ft.add(Nt),Ft.position.set(Jt,(C._waterLevel??0)+.1,zt),Ft.rotation.y=he()*6.28,l(Ft),mt.push({g:Ft,ph:he()*6.28,x:Jt,z:zt,a:Ft.rotation.y}),ft++}}{let C=yn(128,128,(ft,It,Jt)=>{ft.fillStyle="#ffffff",ft.fillRect(0,0,It,Jt),ft.fillStyle="#ffffff",ft.fillRect(0,0,14,14),ft.fillStyle="#3b4a6b",ft.fillRect(34,30,60,58),ft.fillStyle="#9ec9ff",ft.fillRect(38,34,52,50),ft.fillStyle="#ffffff",ft.fillRect(62,34,4,50),ft.fillRect(38,56,52,4),ft.fillStyle="rgba(0,0,0,0.08)",ft.fillRect(0,118,It,10)},{repeat:!0});o.push(C);let Q={generateTopUV:(ft,It,Jt,zt,Ft)=>[new Ht(.02,.98),new Ht(.02,.98),new Ht(.02,.98)],generateSideWallUV:(ft,It,Jt,zt,Ft,Ut)=>{let st=It[Jt*3],Nt=It[Jt*3+1],$t=It[Jt*3+2],ie=It[zt*3],Me=It[zt*3+1],ke=It[zt*3+2],He=It[Ft*3+2],O=It[Ut*3+2],rt=(Math.abs(Nt-Me)<Math.abs(st-ie)?st:Nt)/4.2,vt=(Math.abs(Nt-Me)<Math.abs(st-ie)?ie:Me)/4.2;return[new Ht(rt,$t/3.2),new Ht(vt,ke/3.2),new Ht(vt,He/3.2),new Ht(rt,O/3.2)]}},at=["#e98a64","#f3d9a6","#d86f5a","#f6efe0","#a8c8e6","#f2b5a0","#c9b6e4","#f4c46a"],lt=["#5d6488","#7a5d6c","#4f6b78"],wt=[];for(let ft of s.features){if(ft.kind!=="building"||!ft.closed||ft.pts.length<4)continue;let It=Ba(ft.pts);if(y(It[0],It[1]))continue;let Jt=parseFloat((Ve=ft.tags)==null?void 0:Ve["building:levels"])||(he()<.7?3:4),zt=Math.min(30,Jt*3.1),Ft=new xs(ft.pts.map(He=>new Ht(He[0],-He[1]))),Ut;try{Ut=new Aa(Ft,{depth:zt,bevelEnabled:!1,UVGenerator:Q})}catch{continue}Ut.rotateX(-Math.PI/2);let st=Math.min(...ft.pts.map(He=>t.heightAt(He[0],He[1])))-1.5;Ut.translate(0,st,0);let Nt=Ut.getAttribute("normal"),$t=Nt.count,ie=new Float32Array($t*3),Me=new fe(at[Math.floor(he()*at.length)]).convertSRGBToLinear(),ke=new fe(lt[Math.floor(he()*lt.length)]).convertSRGBToLinear();for(let He=0;He<$t;He++){let O=Nt.getY(He)>.5?ke:Me;ie[He*3]=O.r,ie[He*3+1]=O.g,ie[He*3+2]=O.b}Ut.setAttribute("color",new Qe(ie,3)),wt.push(Ut.index?Ut.toNonIndexed():Ut)}if(wt.length){let ft=fn(wt),It=Le(ft,gt(16777215,{map:C,vertexColors:!0}),{cast:!0,ol:1.6,olRef:60});It.name="buildings",l(It)}}let bt=t.sample(t.finishM),D=t.sample(0),G={start:D,finish:bt},q=new _e;l(q);function W(C,Q,at,lt){let wt=new _e,ft=tn/2+1.4,It=.85,Jt=yn(256,32,($t,ie,Me)=>{for(let ke=0;ke<16;ke++)$t.fillStyle=ke%2?at:lt,$t.fillRect(ke*ie/16,0,ie/16+1,Me)},{repeat:!1});o.push(Jt);let zt=new ln(ft,It,14,40,Math.PI);zt.scale(1,1.25,1);let Ft=Le(zt,gt(16777215,{map:Jt}),{ol:3.5});wt.add(Ft);let Ut=new pe(It*1.4,It*1.6,.8,16);for(let $t of[-1,1]){let ie=Le(Ut,gt(lt),{ol:3});ie.position.set($t*ft,.3,0),wt.add(ie)}let st=ai(1024,256,($t,ie,Me)=>{$t.fillStyle="#1b1b3a",on($t,0,0,ie,Me,60),$t.fill(),$t.fillStyle=at,on($t,12,12,ie-24,Me-24,50),$t.fill(),vn($t,"MARKRUN",ie/2,Me*.42,150,"#ffffff","#1b1b3a",.18),vn($t,Q,ie/2,Me*.83,56,"#ffe14d","#1b1b3a",.2)},o),Nt=Le(new Ue(ft*1.55,ft*.4,.7,3,.25),[gt(lt),gt(lt),gt(lt),gt(lt),gt(16777215,{map:st}),gt(16777215,{map:st})],{ol:3.5});return Nt.position.y=ft*1.25+It*1.25+ft*.2-.15,wt.add(Nt),wt.position.set(C.x,C.y-.1,C.z),wt.rotation.y=Math.atan2(-C.rz,C.rx),q.add(wt),wt}G.finishArch=W(bt,"FINISH","#ff3d8b","#ffd23f"),W(D,"START","#2e9bff","#ffd23f");let J=yn(256,64,(C,Q,at)=>{let wt=Q/16;for(let ft=0;ft<16;ft++)for(let It=0;It<4;It++)C.fillStyle=(ft+It)%2?"#111":"#fff",C.fillRect(ft*wt,It*wt,wt,wt)});o.push(J);function it(C,Q,at,lt=.03){let wt=new Tn(tn,at);wt.rotateX(-Math.PI/2);let ft=new We(wt,gt(16777215,{map:Q,transparent:!0,alphaTest:.3,polygonOffset:!0,polygonOffsetFactor:-2}));return ft.position.set(C.x,C.y+lt,C.z),ft.rotation.y=Math.atan2(-C.rz,C.rx),ft.receiveShadow=!0,l(ft),ft}it(bt,J,2.2,.05);let Mt=ai(512,128,(C,Q,at)=>{C.fillStyle="#ffffff",C.fillRect(0,0,Q,22),vn(C,"START",Q/2,80,72,"#ffffff","rgba(0,0,0,0)",0)},o);{let C=t.sample(2.5);it(C,Mt,3,.05).rotation.y+=Math.PI}let Ct=new qe;function nt(C,Q,at,{ol:lt=0,olRef:wt,cast:ft=!0,colors:It,chunk:Jt=0,occluder:zt=!1}={}){if(!at.length)return null;if(Jt){let Ut=new Map;at.forEach((Nt,$t)=>{let ie=`${Math.floor(Nt.x/Jt)},${Math.floor(Nt.z/Jt)}`,Me=Ut.get(ie);Me||Ut.set(ie,Me={l:[],c:[]}),Me.l.push(Nt),It&&Me.c.push(It[$t])});let st=null;for(let{l:Nt,c:$t}of Ut.values()){let ie=nt(C,Q,Nt,{ol:lt,olRef:wt,cast:ft,colors:It?$t:null,occluder:zt});st=st||ie}return st}let Ft=new dn(C,Q,at.length);return at.forEach((Ut,st)=>{Ct.position.set(Ut.x,Ut.y,Ut.z),Ct.rotation.set(Ut.rx||0,Ut.ry||0,Ut.rz||0),Ct.scale.set(Ut.sx??Ut.s??1,Ut.sy??Ut.s??1,Ut.sz??Ut.s??1),Ct.updateMatrix(),Ft.setMatrixAt(st,Ct.matrix),zt&&(Ut._m=Ct.matrix.clone()),It&&Ft.setColorAt(st,new fe(It[st]))}),Ft.castShadow=ft,Ft.receiveShadow=!0,Ft.computeBoundingSphere(),lt&&oi(Ft,lt,void 0,wt),M(Ft,at,zt),l(Ft),Ft}let pt=[];{let C=at=>{let lt=t.rawExt(at-12),wt=t.rawExt(at),ft=t.rawExt(at+12),It=Math.atan2(wt[1]-lt[1],wt[0]-lt[0]),zt=Math.atan2(ft[1]-wt[1],ft[0]-wt[0])-It;for(;zt>Math.PI;)zt-=2*Math.PI;for(;zt<-Math.PI;)zt+=2*Math.PI;return zt},Q=[[20,t.LAP1_END_DRAW-20],[t.MAP_TO-40,t.finishM-10]];for(let[at,lt]of Q){let wt=null;for(let ft=at;ft<lt;ft+=4){let It=C(ft);Math.abs(It)>.45?(!wt||Math.abs(It)>Math.abs(wt.d))&&(wt={m:ft,d:It}):wt&&(pt.some(Jt=>Math.abs(Jt.m-wt.m)<50)||pt.push(wt),wt=null)}}}let H=[],qt=[],tt=[],K=[];for(let C of pt){let Q=C.d>0;for(let at=-2;at<=2;at++){let lt=t.sample(C.m+at*5),wt=Q?-1:1,ft=tn/2+1.6,It=lt.x+lt.rx*ft*wt,Jt=lt.z+lt.rz*ft*wt;u(It,Jt,.3),(Q?qt:H).push({x:It,y:t.heightAt(It,Jt),z:Jt,ry:Math.atan2(-lt.tz,lt.tx)+(wt>0?Math.PI:0)})}for(let at=-3;at<=3;at++){let lt=t.sample(C.m+at*3.5),wt=Q?1:-1,ft=tn/2+.7;tt.push({x:lt.x+lt.rx*ft*wt,y:t.heightAt(lt.x+lt.rx*ft*wt,lt.z+lt.rz*ft*wt),z:lt.z+lt.rz*ft*wt,ry:he()*6});for(let It=0;It<2;It++){let Jt=t.sample(C.m+at*3.5+It*1.75),zt=tn/2+.1;K.push({x:Jt.x+Jt.rx*zt*wt,y:Jt.y-.05,z:Jt.z+Jt.rz*zt*wt,ry:Math.atan2(Jt.tx,Jt.tz),red:(at*2+It)%2===0})}}}G.corners=pt;{let C=yn(256,96,(zt,Ft,Ut)=>{zt.fillStyle="#2f6fe0",zt.fillRect(0,0,Ft,Ut),zt.fillStyle="#ffffff";for(let st=0;st<4;st++){let Nt=18+st*60;zt.beginPath(),zt.moveTo(Nt,12),zt.lineTo(Nt+26,12),zt.lineTo(Nt+54,Ut/2),zt.lineTo(Nt+26,Ut-12),zt.lineTo(Nt,Ut-12),zt.lineTo(Nt+28,Ut/2),zt.closePath(),zt.fill()}zt.strokeStyle="#1b3f8f",zt.lineWidth=8,zt.strokeRect(0,0,Ft,Ut)}),Q=C.clone();Q.repeat.x=-1,Q.offset.x=1,Q.wrapS=gs,Q.needsUpdate=!0,o.push(C,Q);let lt=(zt=>{let Ft=new ze(3.2,1.2,.12);Ft.rotateX(-.32),Ft.translate(0,.62,.22);let Ut=new ze(3.2,1.2,.12);return Ut.rotateX(.32),Ut.translate(0,.62,-.22),Ut.rotateY(Math.PI),fn([Ft,Ut])})();_h(lt),nt(lt,gt(16777215,{map:C}),qt,{ol:2.5}),nt(lt,gt(16777215,{map:Q}),H,{ol:2.5});let wt=yn(16,64,(zt,Ft,Ut)=>{for(let st=0;st<4;st++)zt.fillStyle=st%2?"#ffffff":"#ff6a2b",zt.fillRect(0,st*Ut/4,Ft,Ut/4)});o.push(wt);let ft=new pe(.06,.32,.9,12,1);ft.translate(0,.5,0);let It=new ze(.8,.08,.8);It.translate(0,.04,0),nt(ft,gt(16777215,{map:wt}),tt,{ol:2}),nt(It,gt(16738859),tt,{ol:1.5});let Jt=new ze(.5,.22,1.75);Jt.translate(0,.11,0),nt(Jt,gt(16777215),K.map(zt=>zt),{ol:1.5,colors:K.map(zt=>zt.red?15216959:16777215)})}let Et=new _e;l(Et);function X(C,Q,at,lt,wt,{postH:ft=1.6,face:It=0,scale:Jt=1}={}){let zt=ai(512,Math.round(512*lt/at),wt,o),Ft=new _e,Ut=Le(new Ue(at,lt,.25,2,.08),[gt(5978660),gt(5978660),gt(5978660),gt(5978660),gt(16777215,{map:zt}),gt(16777215,{map:zt})],{ol:3});Ut.position.y=ft+lt/2,Ft.add(Ut);let st=new ze(.25,ft+lt*.5,.25);for(let Me of[-1,1]){let ke=Le(st,gt(9067062),{ol:2});ke.position.set(Me*at*.35,(ft+lt*.5)/2,-.1),Ft.add(ke)}let Nt=tn/2+2.2+at*.15,$t=C.x+C.rx*Nt*Q,ie=C.z+C.rz*Nt*Q;return Ft.position.set($t,t.heightAt($t,ie)-.1,ie),Ft.rotation.y=Math.atan2(-C.tx,-C.tz)+Q*.5+It,Ft.scale.setScalar(Jt),Et.add(Ft),Ft}let Tt=1720,B=t.sample(Tt-10);G.hillSign=X(B,1,6,3.2,(C,Q,at)=>{C.fillStyle="#ffd23f",on(C,0,0,Q,at,40),C.fill(),C.lineWidth=16,C.strokeStyle="#1b1b3a",on(C,8,8,Q-16,at-16,34),C.stroke(),C.fillStyle="#3aa845",C.beginPath(),C.moveTo(40,at-40),C.lineTo(150,70),C.lineTo(260,at-40),C.closePath(),C.fill(),C.strokeStyle="#1b1b3a",C.lineWidth=8,C.stroke(),C.fillStyle="#fff",C.beginPath(),C.moveTo(118,118),C.lineTo(150,70),C.lineTo(182,118),C.closePath(),C.fill(),vn(C,"THE",380,at*.3,72,"#ffffff","#1b1b3a",.2),vn(C,"HILL",370,at*.66,120,"#ff3d8b","#1b1b3a",.16)},{postH:1.4}),G.hillM=Tt;for(let C of[1,2,3,4]){let Q=C*1e3,at=t.sample(t.geoOf(Q));X(at,-1,1.6,1.3,(lt,wt,ft)=>{lt.fillStyle="#ffffff",on(lt,0,0,wt,ft,50),lt.fill(),lt.fillStyle="#ff3d8b",on(lt,20,20,wt-40,ft-40,36),lt.fill(),vn(lt,`${C}K`,wt/2,ft/2+8,230,"#ffffff","#1b1b3a",.14)},{postH:.7})}let I=t.sample(2475);G.lapBoard=X(I,1,4.4,2.6,(C,Q,at)=>{C.fillStyle="#1b1b3a",on(C,0,0,Q,at,40),C.fill(),C.fillStyle="#2e9bff",on(C,14,14,Q-28,at-28,30),C.fill(),vn(C,"LAP",Q/2,at*.28,90,"#ffffff","#1b1b3a",.18),vn(C,"2 OF 2",Q/2,at*.66,150,"#ffe14d","#1b1b3a",.14)},{postH:1.2}),G.lapM=2500;let ut=[],xt=[],Pt=[],At=[];function jt(C,Q,at,lt=3.2,wt=12){let ft=null;for(let It=C;It<=Q;It+=wt){let Jt=t.sample(It),zt=tn/2+1,Ft=Jt.x+Jt.rx*zt*at,Ut=Jt.z+Jt.rz*zt*at,st=t.heightAt(Ft,Ut);xt.push({x:Ft,y:st,z:Ut});let Nt=new V(Ft,st+lt,Ut);if(ft){let $t=[];for(let ie=0;ie<=12;ie++){let Me=ie/12,ke=ft.clone().lerp(Nt,Me);ke.y-=Math.sin(Me*Math.PI)*.6,$t.push(ke)}Pt.push($t);for(let ie=1;ie<12;ie++){let Me=$t[ie],ke=$t[ie+1].clone().sub($t[ie-1]);ut.push({x:Me.x,y:Me.y,z:Me.z,ry:Math.atan2(-ke.z,ke.x)})}}ft=Nt}}function dt(C,Q,at,lt=tn/2+2.2){for(let wt=C;wt<=Q;wt+=2.4){let ft=t.sample(wt),It=ft.x+ft.rx*lt*at,Jt=ft.z+ft.rz*lt*at;At.push({x:It,y:t.heightAt(It,Jt),z:Jt,ry:Math.atan2(ft.tx,ft.tz)})}}let ot=t.finishM;jt(ot-70,ot+10,1),jt(ot-70,ot+10,-1),jt(-6,50,1),jt(-6,50,-1),dt(ot-60,ot+14,1),dt(ot-60,ot+14,-1),dt(-4,40,1),dt(-4,40,-1);{let C=new Ye;C.setAttribute("position",new Te([-.3,0,0,.3,0,0,0,-.62,0],3)),C.setAttribute("normal",new Te([0,0,1,0,0,1,0,0,1],3));let Q=ut.map((Ft,Ut)=>[16727435,16765503,3054591,4054148,16747069,16777215][Ut%6]);nt(C,gt(16777215,{side:hn}),ut,{colors:Q,cast:!1});let at=new pe(.07,.09,3.3,6);at.translate(0,1.65,0),nt(at,gt(16777215),xt,{ol:1.5});let lt=new Ye().setFromPoints(Pt.flatMap(Ft=>Ft.slice(0,-1).flatMap((Ut,st)=>[Ut,Ft[st+1]]))),wt=new or(lt,new vs({color:3355443}));l(wt),o.push(lt);let ft=[];for(let Ft=0;Ft<4;Ft++){let Ut=new ze(.16,1,.06);Ut.translate(-.9+Ft*.6,.5,0),ft.push(Ut)}let It=new ze(2.4,.12,.05);It.translate(0,.65,.05),ft.push(It);let Jt=It.clone();Jt.translate(0,-.35,0),ft.push(Jt);let zt=fn(ft);zt.rotateY(Math.PI/2),nt(zt,gt(16777215),At,{ol:1.8})}let St=[],ht=(C,Q,at,lt,wt,ft=1.35)=>St.push({m0:C,m1:Q,side:at,off:tn/2+3,depth:lt,density:wt,spacing:ft});ht(ot-58,ot+12,1,6,1),ht(ot-58,ot+12,-1,6,1),ht(-2,38,1,5,.9),ht(-2,38,-1,5,.9),ht(1940,2010,1,4,.7),ht(1960,2010,-1,3,.6),ht(Tt-10,Tt+40,-1,3,.55),ht(2440,2490,-1,3,.7),ht(Tt-70,Tt+10,1,3,.5),ht(Tt-70,Tt-20,-1,3,.45),ht(2080,2160,1,4,.75),ht(2080,2160,-1,4,.75),ht(800,860,1,3,.6),ht(1250,1310,-1,3,.6),G.crowdZones=St;{let C=s.pois.filter(lt=>lt.kind==="bench"&&y(lt.pos[0],lt.pos[1])&&u(lt.pos[0],lt.pos[1],1)).map(lt=>({x:lt.pos[0],y:t.heightAt(lt.pos[0],lt.pos[1]),z:lt.pos[1],ry:he()*6})),Q=fn([new ze(1.8,.12,.5).translate(0,.5,0),new ze(1.8,.4,.1).translate(0,.8,-.22),new ze(.1,.5,.45).translate(-.8,.25,0),new ze(.1,.5,.45).translate(.8,.25,0)]);nt(Q,gt(11892031),C,{ol:1.5});let at=s.pois.filter(lt=>lt.kind==="cafe"&&y(lt.pos[0],lt.pos[1])&&u(lt.pos[0],lt.pos[1],4));for(let lt of at){let wt=new _e;wt.add(Le(new Ue(5,3,4,2,.2),gt(16774108),{ol:2.5})).position.y=1.5;let ft=yn(128,16,(zt,Ft,Ut)=>{for(let st=0;st<8;st++)zt.fillStyle=st%2?"#fff":"#ff4f6d",zt.fillRect(st*16,0,16,Ut)});o.push(ft);let It=Le(new ze(5.6,.2,2),gt(16777215,{map:ft}),{ol:2});It.position.set(0,2.9,2.3),It.rotation.x=.35,wt.add(It);let Jt=Le(new rn(4,1.6,4),gt(3054591),{ol:2.5});Jt.position.y=3.8,Jt.rotation.y=Math.PI/4,wt.add(Jt),wt.position.set(lt.pos[0],t.heightAt(lt.pos[0],lt.pos[1]),lt.pos[1]),wt.rotation.y=he()*6,l(wt),v(lt.pos[0],lt.pos[1],5)}}for(let C of St)for(let Q=C.m0-8;Q<=C.m1+8;Q+=4){let at=t.sample(Q),lt=C.off+C.depth/2;v(at.x+at.rx*lt*C.side,at.z+at.rz*lt*C.side,C.depth/2+3)}for(let C of[D,bt])v(C.x,C.z,14);function yt(C,Q){let at=null,lt=1e9;for(let wt of f){let ft=(wt[0]-C)**2+(wt[1]-Q)**2;ft<lt&&(lt=ft,at=wt)}return at}G.nearestOnRibbon=yt,G.ribbonSamples=f;let Yt=new Map;for(let C of f){let Q=`${Math.floor(C[0]/10)},${Math.floor(C[1]/10)}`,at=Yt.get(Q);at||Yt.set(Q,at=[]),at.push(C)}let Gt=(C,Q,at=1)=>{let lt=Math.floor(C/10),wt=Math.floor(Q/10),ft=(tn/2+at)**2;for(let It=-1;It<=1;It++)for(let Jt=-1;Jt<=1;Jt++)for(let zt of Yt.get(`${lt+It},${wt+Jt}`)||[])if((zt[0]-C)**2+(zt[1]-Q)**2<ft)return!0;return!1};G.reserve=v,G.clearOf=u;let Wt=[],ae=(C,Q,at,lt)=>!u(C,Q,2.5*lt)||b(C,Q,1.5)?!1:(Wt.push({x:C,z:Q,kind:at,s:lt}),v(C,Q,2.2*lt),!0);for(let C of s.pois)C.kind==="tree"&&ae(C.pos[0],C.pos[1],0,.85+he()*.35);for(let C of s.features)if(C.kind==="wood"&&C.closed){let Q=Zn(C.pts),at=(Q[2]-Q[0])*(Q[3]-Q[1]);for(let lt=0;lt<at/90;lt++){let wt=Q[0]+he()*(Q[2]-Q[0]),ft=Q[1]+he()*(Q[3]-Q[1]);ur(C.pts,wt,ft)&&ae(wt,ft,1,.9+he()*.5)}}{let C=Zn(S);for(let Q=0;Q<2600;Q++){let at=C[0]+he()*(C[2]-C[0]),lt=C[1]+he()*(C[3]-C[1]);!y(at,lt)||-to(S,at,lt)>45&&he()<.75||ae(at,lt,he()<.7?1:2,.8+he()*.5)}for(let Q of s.features)if(Q.kind==="road"&&!Q.closed)for(let at=1;at<Q.pts.length;at++){let lt=Q.pts[at-1],wt=Q.pts[at],ft=Math.hypot(wt[0]-lt[0],wt[1]-lt[1]);for(let It=0;It<ft;It+=22){let Jt=It/ft,zt=lt[0]+(wt[0]-lt[0])*Jt,Ft=lt[1]+(wt[1]-lt[1])*Jt,Ut=-(wt[1]-lt[1])/ft,st=(wt[0]-lt[0])/ft,Nt=8+he()*2;he()<.5&&ae(zt+Ut*Nt,Ft+st*Nt,0,.6+he()*.2)}}}{let C=[3978315,5031250,3121226,6539594,8376650,3450963],Q=new pe(.32,.5,4.2,7);Q.translate(0,2.1,0);let at=new pn(3.2,1);at.scale(1,1.08,1),at.translate(0,6.6,0);let lt=fn([new pn(3,1).translate(0,6.2,0),new pn(2.3,0).translate(1.9,5.3,.6),new pn(2.2,0).translate(-1.7,5.5,-.8),new pn(2,0).translate(.2,8.2,.3)].map(Iu)),wt=fn([new rn(3,4.2,8).translate(0,5,0),new rn(2.4,3.6,8).translate(0,7.2,0),new rn(1.6,3,8).translate(0,9.2,0)].map(Iu)),ft=Wt.map(zt=>({x:zt.x,y:t.heightAt(zt.x,zt.z)-.2,z:zt.z,ry:he()*6.28,s:zt.s}));nt(Q,gt(9067062),ft,{ol:2,olRef:40,chunk:160,occluder:!0});let It=gt(16777215);at.computeVertexNormals(),[at,lt,wt].forEach((zt,Ft)=>{let Ut=ft.filter((st,Nt)=>Wt[Nt].kind===Ft);nt(zt,It,Ut,{ol:2.2,olRef:40,colors:Ut.map(()=>C[Math.floor(he()*C.length)]),chunk:160,occluder:!0})}),G.treeCount=Wt.length}{let C=fn([0,1,2,3].map(ft=>{let It=new rn(.09,.55,3);return It.translate(0,.27,0),It.rotateZ((ft-1.5)*.25),It.rotateY(ft*1.7),It.translate((ft-1.5)*.08,0,ft%2*.06),It.index?It.toNonIndexed():It})),Q=fn([new pe(.03,.03,.35,4).translate(0,.17,0).toNonIndexed(),new pn(.13,0).translate(0,.38,0)]),at=[],lt=[],wt=[];for(let ft=0;ft<9e3;ft++){let It=f[Math.floor(he()*f.length)],Jt=he()*6.283,zt=tn/2+1+he()*22,Ft=It[0]+Math.cos(Jt)*zt,Ut=It[1]+Math.sin(Jt)*zt;if(!y(Ft,Ut)||b(Ft,Ut,.5)||!u(Ft,Ut,.2))continue;let st=t.heightAt(Ft,Ut)-.03;he()<.62?at.push({x:Ft,y:st,z:Ut,ry:he()*6,s:.5+he()*.6}):(lt.push({x:Ft,y:st,z:Ut,ry:he()*6,s:.35+he()*.25}),wt.push(["#ff5d8f","#ffd93b","#ffffff","#b06bff","#ff8a3d","#57c7ff"][Math.floor(he()*6)]))}nt(C,gt(5226296),at,{cast:!1,chunk:120}),nt(Q,gt(16777215),lt,{cast:!1,colors:wt,chunk:120})}let ge=new Nn({side:En,depthWrite:!1,fog:!1,uniforms:{top:{value:new fe(3116287)},mid:{value:new fe(9425919)},bot:{value:new fe(15333631)}},vertexShader:"varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.); }",fragmentShader:`uniform vec3 top; uniform vec3 mid; uniform vec3 bot; varying vec3 vP; void main(){ float h=vP.y; vec3 c = h>0.12? mix(mid, top, smoothstep(0.12,0.7,h)) : mix(bot, mid, smoothstep(-0.05,0.12,h)); gl_FragColor=vec4(c,1.);
#include <colorspace_fragment>
}`}),Ie=new We(new Pe(5e3,32,16),ge);Ie.renderOrder=-10,Ie.frustumCulled=!1,n.add(Ie),o.push(ge,Ie.geometry);let et=fn([[0,0,0,14],[13,-3,2,10],[-13,-4,-1,10],[6,6,-2,9],[-6,5,3,8],[22,-6,0,6],[-22,-7,1,6]].map(([C,Q,at,lt])=>new pn(lt,2).translate(C,Q,at)));et.scale(1,.7,.8);let Kt=[c.x0+h/2,c.z0+m/2],Rt=[];for(let C=0;C<26;C++){let Q=he()*6.28,at=300+he()*1300;Rt.push({x:Kt[0]+Math.cos(Q)*at,y:170+he()*120,z:Kt[1]+Math.sin(Q)*at,ry:he()*6,s:.8+he()*1.4})}let Dt=nt(et,gt(16777215,{emissive:6981808,emissiveIntensity:.35,fog:!1}),Rt,{ol:1.5,olRef:300,cast:!1}),ee=[];for(let C=0;C<18;C++){let Q=C/18*6.28+he()*.2,at=1900+he()*500;ee.push({x:Kt[0]+Math.cos(Q)*at,y:-40,z:Kt[1]+Math.sin(Q)*at,sx:320+he()*260,sy:80+he()*90,sz:260+he()*200,ry:he()*6})}nt(new Pe(1,24,12),gt(7128954),ee,{cast:!1,colors:ee.map((C,Q)=>[8047487,6273413,9425290][Q%3])});function ne(C){var Q;Y.uTime.value=C;for(let at of mt)at.g.position.y=(((Q=t.lake)==null?void 0:Q._waterLevel)??0)+.1+Math.sin(C*1.7+at.ph)*.08,at.g.rotation.z=Math.sin(C*1.3+at.ph)*.06,at.g.rotation.y=at.a+Math.sin(C*.1+at.ph)*.4;Dt&&(Dt.position.x=Math.sin(C*.01)*40)}function we(){var C;a.traverse(Q=>{Q.geometry&&Q.geometry.dispose()});for(let Q of o)(C=Q.dispose)==null||C.call(Q);n.remove(a),n.remove(Ie)}return{group:a,anchors:G,update:ne,dispose:we,inPark:y,clearOf:u,reserve:v,blocked:b,groundTex:N,onPath:Gt,registerInstanced:M,clearArea:F,redrawGround:R,setOcclusionCorridor:P}}function Iu(n){let t=n.index?n.toNonIndexed():n;return t.computeVertexNormals(),t}function Ba(n){let t=0,e=0;for(let i of n)t+=i[0],e+=i[1];return[t/n.length,e/n.length]}function on(n,t,e,i,s,r){n.beginPath(),n.moveTo(t+r,e),n.arcTo(t+i,e,t+i,e+s,r),n.arcTo(t+i,e+s,t,e+s,r),n.arcTo(t,e+s,t,e,r),n.arcTo(t,e,t+i,e,r),n.closePath()}var Lu=[16735631,16765503,5752831,8248938,16747069,11566079,5234888,16739179,16777215,9414911],ku=[4054148,16727435,16765503,3054591,16777215];function ex(){let n=[];for(let i=0;i<=8;i++){let s=i/8,r=s*1.25,o=s<.12?.48+s*1.2:Math.sqrt(Math.max(0,1-Math.pow((s-.12)/.88,2.2)))*.62;n.push(new Ht(Math.max(.001,o),r))}n.unshift(new Ht(.001,0));let e=new Zr(n,12);return e.computeVertexNormals(),e}function bh(n,t){let e=zn(99),i=t.length,s=new _e;if(n.add(s),!i)return{update(){},hideWhere(){},setMask(){},dispose(){n.remove(s)},group:s};let r=ex(),o=new Pe(.15,8,5);o.scale(.8,1.15,.5);let a=new Pe(.075,6,4);a.scale(.85,1.2,.5);let l=new Pe(.13,6,5),c=new rn(.14,.36,6);c.translate(0,.18,0);let h=new rn(.26,.55,8);h.translate(0,.27,0);let m=new Pe(.2,7,5),g=(Y,k,mt,bt)=>{let D=new dn(Y,k,mt);return D.castShadow=!0,D.receiveShadow=!0,D.userData.ol=bt,s.add(D),D},d=g(r,gt(16777215),i,2.6),p=g(o,new On({color:16777215}),i*2,0),v=g(a,new On({color:1709088}),i*2,0),u=g(l,gt(16777215),i*2,2);p.castShadow=v.castShadow=!1;let f=[g(c,gt(16777215),i,2),g(h,gt(16777215),i,2),g(m,gt(16777215),i,2)],S=[0,0,0],y=new fe,x=t.map((Y,k)=>{let mt=Y.colour??Lu[Math.floor(e()*Lu.length)];d.setColorAt(k,y.set(mt)),u.setColorAt(k*2,y),u.setColorAt(k*2+1,y);let bt=e()<.3?-1:Math.floor(e()*3),D=-1;return bt>=0&&(D=S[bt]++,f[bt].setColorAt(D,y.set(ku[Math.floor(e()*ku.length)]))),{...Y,s:Y.scale??.85+e()*.35,ph:e()*6.28,sp:5+e()*4,tk:bt,ti:D,wave:e()<.5,ex:.3}});f.forEach((Y,k)=>{Y.count=S[k]});for(let Y of[d,u,...f])Y.instanceColor&&(Y.instanceColor.needsUpdate=!0);let L=new Fe().makeScale(0,0,0),b=null,T=new Fe,A=new $n,M=new ii,_=new V,w=new V,P=new Fe,E=new Fe;function F(Y,k,mt){let bt=x[Y];if(bt.hidden||b&&b(bt.x,bt.z)){for(let J of[d])J.setMatrixAt(Y,L);for(let J=0;J<2;J++)p.setMatrixAt(Y*2+J,L),v.setMatrixAt(Y*2+J,L),u.setMatrixAt(Y*2+J,L);bt.tk>=0&&f[bt.tk].setMatrixAt(bt.ti,L);return}let D=bt.ex,G=k*bt.sp*(.5+D*.6)+bt.ph,q=Math.max(0,Math.sin(G))*.32*D,W=1-Math.cos(G*2)*.05*D;M.set(0,bt.yaw+Math.sin(k*.8+bt.ph)*.25*(1-D),Math.sin(G*.5)*.08*D),A.setFromEuler(M),P.compose(_.set(bt.x,bt.y+q,bt.z),A,w.set(bt.s/Math.sqrt(W),bt.s*W,bt.s/Math.sqrt(W))),d.setMatrixAt(Y,P);for(let J=0;J<2;J++){let it=J?.19:-.19;E.makeTranslation(it,.86,.5),T.multiplyMatrices(P,E),p.setMatrixAt(Y*2+J,T),E.makeTranslation(it*1.02,.84+(D>.6?.03:0),.565),T.multiplyMatrices(P,E),v.setMatrixAt(Y*2+J,T);let Mt=D>.55?1:.15+.2*Math.max(0,Math.sin(G)),Ct=bt.wave?Math.sin(G*1.5+J*3)*.25*D:0,nt=(J?1:-1)*(.62+Mt*.05+Ct*.3),pt=.45+Mt*.85+Ct;E.makeTranslation(nt,pt,.12),T.multiplyMatrices(P,E),u.setMatrixAt(Y*2+J,T)}bt.tk>=0&&(E.makeTranslation(0,1.22,0),bt.tk===0&&E.multiply(new Fe().makeRotationZ(Math.sin(G)*.3)),T.multiplyMatrices(P,E),f[bt.tk].setMatrixAt(bt.ti,T))}for(let Y=0;Y<i;Y++)F(Y,0,!0);let R=()=>{for(let Y of[d,p,v,u,...f])Y.instanceMatrix.needsUpdate=!0};R();for(let Y of[d,p,v,u,...f]){if(!Y.count){Y.visible=!1;continue}Y.computeBoundingSphere(),Y.boundingSphere.radius+=2,Y.userData.ol&&oi(Y,Y.userData.ol,void 0,18)}function N(Y,k,mt=[],bt=null){let D=!1;for(let G=0;G<i;G++){let q=x[G];if(k&&(q.x-k.x)**2+(q.z-k.z)**2>260*260)continue;let W=.25;if(bt!=null)W=bt;else for(let J of mt){let it=(J.x-q.x)**2+(J.z-q.z)**2;it<45*45&&(W=Math.max(W,1-Math.sqrt(it)/70))}q.ex+=(W-q.ex)*.05,F(G,Y),D=!0}D&&R()}function U(){for(let Y of[r,o,a,l,c,h,m])Y.dispose();for(let Y of[d,p,v,u,...f])Y.dispose();n.remove(s)}function z(Y){let k=!1;for(let mt=0;mt<i;mt++)!x[mt].hidden&&Y(x[mt].x,x[mt].z)&&(x[mt].hidden=!0,F(mt,0),k=!0);k&&R()}function Z(Y){if(Y!==b){b=Y;for(let k=0;k<i;k++)F(k,0);R()}}return{update:N,dispose:U,hideWhere:z,setMask:Z,group:s,members:x}}function Du(n,t,e=5,i=null,s=null){let r=zn(e),o=[];for(let[a,l]of t.entries())for(let c=l.m0;c<=l.m1;c+=l.spacing??1.35){let h=n.sample(c),m=Math.max(1,Math.round(l.depth/1.25));for(let g=0;g<m;g++){if(r()>l.density)continue;let d=l.off+g*1.25+r()*.35,p=(r()-.5)*.6,v=h.x+h.rx*d*l.side+h.tx*p,u=h.z+h.rz*d*l.side+h.tz*p;i&&i(v,u,1.4)||s&&s(v,u,.6)||o.push({zone:a,x:v,y:n.heightAt(v,u),z:u,yaw:Math.atan2(-h.rx*l.side,-h.rz*l.side)+(r()-.5)*.5})}}return o}var Uu={stocky:{torso:[.9,.76,.58],leg:.66,legR:.16,arm:.66,armR:.14,head:.47,hand:.19,shoe:[.34,.25,.6]},lanky:{torso:[.56,.86,.38],leg:1.06,legR:.095,arm:.9,armR:.085,head:.39,hand:.15,shoe:[.27,.21,.62]},compact:{torso:[.68,.6,.5],leg:.52,legR:.13,arm:.52,armR:.11,head:.5,hand:.17,shoe:[.3,.23,.5]},tall:{torso:[.7,.94,.46],leg:.92,legR:.125,arm:.8,armR:.11,head:.43,hand:.17,shoe:[.31,.24,.6]}},Nu=["#2b1d14","#5a3a1e","#c8642a","#e8c66a","#1d1d24","#a9a9b3","#3a2a1e","#8a5a2b","#ff5fa2"],nx=3.2,so=new Map,le=(n,t)=>(so.has(n)||so.set(n,t()),so.get(n));function Fu(){for(let n of so.values())n.dispose();so.clear()}function ix(n){let t=2166136261;for(let e of n)t^=e.charCodeAt(0),t=Math.imul(t,16777619);return t>>>0}function sx(n,t,e,i,s,r){n.fillStyle=i,n.fillRect(0,0,t,e);let o=t*.25,a=e*.47,l=e*.64,c=t*.058,h="#1a1420";n.fillStyle="rgba(255,90,90,0.28)";for(let u of[-1,1])n.beginPath(),n.ellipse(o+u*c*1.75,l-e*.03,t*.022,e*.03,0,0,7),n.fill();let m=(u,f)=>{if(f==="heart"){n.fillStyle="#ff2d6f",n.strokeStyle=h,n.lineWidth=5,n.beginPath();let b=t*.03;n.moveTo(u,a+b*1.1),n.bezierCurveTo(u-b*2.2,a-b*.2,u-b*.9,a-b*1.9,u,a-b*.6),n.bezierCurveTo(u+b*.9,a-b*1.9,u+b*2.2,a-b*.2,u,a+b*1.1),n.fill(),n.stroke();return}if(f==="closed"||f==="happy"){n.strokeStyle=h,n.lineWidth=9,n.lineCap="round",n.beginPath(),f==="happy"?n.arc(u,a+e*.02,t*.024,Math.PI*1.1,Math.PI*1.9):(n.moveTo(u-t*.025,a),n.lineTo(u+t*.025,a)),n.stroke();return}if(f==="x"){n.strokeStyle=h,n.lineWidth=8,n.lineCap="round";let b=t*.02;n.beginPath(),n.moveTo(u-b,a-b),n.lineTo(u+b,a+b),n.moveTo(u+b,a-b),n.lineTo(u-b,a+b),n.stroke();return}if(f==="wink"&&u>o&&(f="happy"),f==="wink"&&(f="open"),f==="happy"){n.strokeStyle=h,n.lineWidth=9,n.lineCap="round",n.beginPath(),n.arc(u,a+e*.02,t*.024,Math.PI*1.1,Math.PI*1.9),n.stroke();return}let S=f==="wide"?1.3:1,y=t*.03*S,x=e*.085*S;n.fillStyle="#fff",n.strokeStyle=h,n.lineWidth=6,n.beginPath(),n.ellipse(u,a,y,x,0,0,7),n.fill(),n.stroke();let L=f==="wide"?.38:.55;n.fillStyle=h,n.beginPath(),n.ellipse(u+y*.15,a+x*.12,y*L,x*L*1.1,0,0,7),n.fill(),n.fillStyle="#fff",n.beginPath(),n.arc(u+y*.35,a-x*.2,y*.22,0,7),n.fill(),f==="half"&&(n.fillStyle=i,n.fillRect(u-y-4,a-x-4,y*2+8,x*1.05),n.strokeStyle=h,n.lineWidth=7,n.beginPath(),n.moveTo(u-y-2,a-x*.1),n.lineTo(u+y+2,a-x*.1),n.stroke())},g={sleepy:"half",smug:"half",cheeky:"wink","wide-eyed":"wide"}[s]||"open";r==="happy"&&(g="happy"),r==="love"&&(g="heart"),r==="dead"&&(g="x"),r==="effort"&&s!=="goofy"&&(g="open");for(let u of[-1,1])m(o+u*c,g);n.strokeStyle=h,n.lineWidth=10,n.lineCap="round";let d=r==="effort"||s==="determined"||s==="gritted"?.35:r==="sad"||s==="worried"?-.35:s==="smug"||s==="cheeky"?.15:s==="wide-eyed"?-.2:0;for(let u of[-1,1]){let f=o+u*c,S=a-e*.13,y=t*.026,x=f-u*y,L=f+u*y;n.beginPath(),n.moveTo(L,S-d*18),n.lineTo(x,S+d*18),n.stroke()}n.lineWidth=8,n.strokeStyle=h,n.fillStyle="#7a1e2e";let p=o,v=r||"normal";if(v==="happy"||v==="normal"&&s==="grin")n.beginPath(),n.moveTo(p-t*.04,l-e*.02),n.quadraticCurveTo(p,l+e*.12,p+t*.04,l-e*.02),n.closePath(),n.fill(),n.stroke(),n.fillStyle="#fff",n.fillRect(p-t*.03,l-e*.018,t*.06,e*.03),n.fillStyle="#ff7d8f",n.beginPath(),n.ellipse(p,l+e*.06,t*.015,e*.02,0,0,7),n.fill();else if(v==="effort"){n.fillStyle="#fff",n.beginPath(),on(n,p-t*.035,l-e*.03,t*.07,e*.065,10),n.fill(),n.stroke(),n.lineWidth=4,n.beginPath(),n.moveTo(p-t*.035,l),n.lineTo(p+t*.035,l);for(let u=-2;u<=2;u++)n.moveTo(p+u*t*.012,l-e*.03),n.lineTo(p+u*t*.012,l+e*.035);n.stroke()}else if(v==="sad"||v==="dead")n.beginPath(),n.moveTo(p-t*.03,l+e*.04),n.quadraticCurveTo(p,l-e*.04,p+t*.03,l+e*.04),n.stroke(),v==="dead"&&(n.fillStyle="#ff7d8f",n.beginPath(),n.ellipse(p+t*.012,l+e*.07,t*.012,e*.04,.2,0,7),n.fill(),n.stroke());else if(v==="love"||v==="pant")n.beginPath(),n.ellipse(p,l+e*.02,t*.022,e*.05,0,0,7),n.fill(),n.stroke();else if(s==="gritted"){n.fillStyle="#fff",n.beginPath(),on(n,p-t*.04,l-e*.03,t*.08,e*.06,10),n.fill(),n.stroke(),n.lineWidth=4,n.beginPath(),n.moveTo(p-t*.04,l),n.lineTo(p+t*.04,l);for(let u=-2;u<=2;u++)n.moveTo(p+u*t*.014,l-e*.03),n.lineTo(p+u*t*.014,l+e*.03);n.stroke()}else if(s==="tongue-out")n.beginPath(),n.moveTo(p-t*.035,l),n.quadraticCurveTo(p,l+e*.05,p+t*.035,l),n.stroke(),n.fillStyle="#ff6f8a",n.beginPath(),n.ellipse(p+t*.008,l+e*.06,t*.016,e*.05,.15,0,7),n.fill(),n.stroke(),n.strokeStyle="rgba(0,0,0,0.35)",n.lineWidth=3,n.beginPath(),n.moveTo(p+t*.008,l+e*.03),n.lineTo(p+t*.01,l+e*.08),n.stroke();else if(s==="wide-eyed")n.beginPath(),n.ellipse(p,l+e*.02,t*.016,e*.04,0,0,7),n.fill(),n.stroke();else if(s==="cheeky")n.beginPath(),n.moveTo(p-t*.04,l-e*.01),n.quadraticCurveTo(p,l+e*.08,p+t*.045,l-e*.035),n.stroke();else if(s==="smug")n.beginPath(),n.moveTo(p-t*.03,l+e*.01),n.quadraticCurveTo(p+t*.01,l+e*.05,p+t*.04,l-e*.03),n.stroke();else if(s==="worried"){n.beginPath(),n.moveTo(p-t*.03,l+e*.02);for(let u=0;u<=6;u++)n.lineTo(p-t*.03+u*t*.01,l+e*.02+(u%2?-1:1)*e*.012);n.stroke()}else s==="goofy"?(n.beginPath(),n.moveTo(p-t*.04,l),n.quadraticCurveTo(p,l+e*.09,p+t*.04,l),n.closePath(),n.fill(),n.stroke(),n.fillStyle="#ff7d8f",n.beginPath(),n.ellipse(p+t*.01,l+e*.07,t*.016,e*.045,0,0,7),n.fill(),n.stroke(),n.fillStyle="#fff",n.fillRect(p-t*.02,l-2,t*.016,e*.03)):s==="determined"?(n.beginPath(),n.moveTo(p-t*.03,l+e*.01),n.lineTo(p+t*.03,l+e*.01),n.stroke()):(n.beginPath(),n.moveTo(p-t*.035,l-e*.01),n.quadraticCurveTo(p,l+e*.07,p+t*.035,l-e*.01),n.stroke());n.strokeStyle="rgba(0,0,0,0.25)",n.lineWidth=6,n.beginPath(),n.arc(o,a+e*.09,t*.012,.2,Math.PI-.2),n.stroke()}function rx(n,t){return yn(256,200,(e,i,s)=>{e.fillStyle="#ffffff",on(e,0,0,i,s,20),e.fill(),e.fillStyle=t,e.fillRect(0,0,i,44),e.font=`30px ${Mh}`,e.fillStyle="#fff",e.textAlign="center",e.textBaseline="middle",e.fillText("MARKRUN",i/2,24),vn(e,String(n),i/2,128,140,"#1a1420","#1a1420",0),e.fillStyle="#c33";for(let[r,o]of[[16,60],[i-16,60],[16,s-16],[i-16,s-16]])e.beginPath(),e.arc(r,o,6,0,7),e.fill()})}function ox(n){return yn(128,128,(t,e,i)=>{if(t.fillStyle="#ffffff",t.strokeStyle="#1a1420",t.lineWidth=8,t.beginPath(),t.arc(e/2,i/2-6,48,0,7),t.fill(),t.stroke(),t.beginPath(),t.moveTo(e/2-12,i-26),t.lineTo(e/2,i-4),t.lineTo(e/2+8,i-28),t.fill(),n==="!")vn(t,"!",e/2,i/2-4,84,"#ff3d8b","#1a1420",.12);else if(n==="heart"){t.fillStyle="#ff2d6f";let s=e/2,r=i/2-2,o=16;t.beginPath(),t.moveTo(s,r+o*1.3),t.bezierCurveTo(s-o*2.6,r-o*.3,s-o,r-o*2.2,s,r-o*.7),t.bezierCurveTo(s+o,r-o*2.2,s+o*2.6,r-o*.3,s,r+o*1.3),t.fill(),t.stroke()}else if(n==="floss"){t.fillStyle="#ff9bd2";for(let[s,r,o]of[[54,44,18],[74,46,17],[64,30,16],[62,54,16]])t.beginPath(),t.arc(s,r,o,0,7),t.fill();t.strokeStyle="#c99a5a",t.lineWidth=6,t.beginPath(),t.moveTo(64,62),t.lineTo(64,96),t.stroke()}else if(n==="sweat"){t.fillStyle="#57c7ff";for(let[s,r]of[[50,50],[78,64]])t.beginPath(),t.moveTo(s,r-22),t.quadraticCurveTo(s+14,r,s,r+10),t.quadraticCurveTo(s-14,r,s,r-22),t.fill(),t.stroke()}})}function Ou(n,t={}){var At,jt;let e=n.look||{},i=Uu[e.build]||Uu.compact,s=ix(n.id+(n.nickname||"")),r=zn(s),o=((At=n.colour)==null?void 0:At.primary)||"#ff4757",a=((jt=n.colour)==null?void 0:jt.secondary)||"#ffffff",l=e.skin||"#f1c6a5",c=Nu[s%Nu.length],h=[],m=gt(o),g=gt(a),d=gt(l),p=gt(c),v=new fe(a).getHSL({}).l>.85?"#ffffff":a,u=gt(v),f=gt("#ffffff"),S=gt("#22202c"),y=(dt,ot,St=nx)=>Le(dt,ot,{ol:St,olRef:9}),x=new _e;x.name=`runner-${n.id}`;let L=new _e;x.add(L);let b=new _e;L.add(b);let T=i.leg/2,A=i.leg+i.shoe[1]*.75;b.position.y=A;let M=y(le(`shorts${e.build}`,()=>new Ue(i.torso[0]*.92,.32,i.torso[2]*.95,3,.12)),g);M.position.y=.02,b.add(M);let _=new _e;_.position.y=.12,b.add(_);let w=y(le(`torso${e.build}`,()=>new Ue(...i.torso,4,Math.min(i.torso[2],i.torso[0])*.42)),m);w.position.y=i.torso[1]/2,_.add(w);for(let dt of[-1,1]){let ot=Le(le(`stripe${e.build}`,()=>new ze(.06,i.torso[1]*.8,i.torso[2]*.7)),gt(a),{cast:!1});ot.position.set(dt*i.torso[0]*.5,i.torso[1]*.5,0),_.add(ot)}let P=rx(n.lane??0,o);h.push(P);let E=new We(le("bib",()=>new Tn(1,.78)),gt(16777215,{map:P})),F=Math.min(.42,i.torso[0]*.6);E.scale.setScalar(F),E.position.set(0,i.torso[1]*.45,i.torso[2]/2+.012),_.add(E);let R=new _e;R.position.y=i.torso[1]+.02,_.add(R);let N=new _e;R.add(N);let U=document.createElement("canvas");U.width=1024,U.height=512;let z=new ar(U);z.colorSpace=Sn,z.anisotropy=4,h.push(z);let Z=null,Y=dt=>{dt!==Z&&(Z=dt,sx(U.getContext("2d"),1024,512,l,e.face||"grin",dt),z.needsUpdate=!0)};Y("normal");let k=i.head,mt=y(le(`head${k}`,()=>new Pe(k,32,20).scale(1,.98,.96)),gt(16777215,{map:z}));mt.position.y=k*.92,N.add(mt);for(let dt of[-1,1]){let ot=y(le(`ear${k}`,()=>new Pe(k*.2,10,8).scale(.6,1,.8)),d,2.5);ot.position.set(dt*k*.97,k*.9,0),N.add(ot)}let bt=y(le(`nose${k}`,()=>new Pe(k*.14,10,8)),d,2);bt.position.set(0,k*.84,k*.97),N.add(bt),pt(e.hair,e.hat),H(e.hat);let D=[];for(let dt of[-1,1]){let ot=new _e;ot.position.set(dt*(i.torso[0]/2+i.armR*.55),i.torso[1]-i.armR*1.1,0),_.add(ot);let St=y(le(`sleeve${e.build}`,()=>new Pe(i.armR*1.65,14,10)),m);ot.add(St);let ht=y(le(`uarm${e.build}`,()=>new si(i.armR,i.arm/2-i.armR,4,10).translate(0,-i.arm/4,0)),d);ot.add(ht);let yt=new _e;yt.position.y=-i.arm/2+i.armR*.4,ot.add(yt);let Yt=y(le(`farm${e.build}`,()=>new si(i.armR*.95,i.arm/2-i.armR,4,10).translate(0,-i.arm/4,0)),d);yt.add(Yt);let Gt=y(le(`hand${e.build}`,()=>new Pe(i.hand,14,10).scale(1,1.1,.9)),d);Gt.position.y=-i.arm/2-i.hand*.4,yt.add(Gt),D.push({sh:ot,el:yt,hand:Gt})}let G=[];for(let dt of[-1,1]){let ot=new _e;ot.position.set(dt*i.torso[0]*.24,0,0),b.add(ot);let St=y(le(`thigh${e.build}`,()=>new si(i.legR*1.15,T-i.legR,4,10).translate(0,-T/2,0)),d);ot.add(St);let ht=y(le(`sleg${e.build}`,()=>new pe(i.legR*1.6,i.legR*1.5,T*.5,12).translate(0,-T*.2,0)),g);ot.add(ht);let yt=new _e;yt.position.y=-T,ot.add(yt);let Yt=y(le(`shin${e.build}`,()=>new si(i.legR,T-i.legR,4,10).translate(0,-T/2,0)),d);yt.add(Yt);let Gt=y(le(`sock${e.build}`,()=>new pe(i.legR*1.12,i.legR*1.12,T*.25,10).translate(0,-T*.86,0)),gt(16777215),2.5);yt.add(Gt);let Wt=new _e;Wt.position.y=-T,yt.add(Wt);let ae=y(le(`shoe${e.build}`,()=>new Ue(...i.shoe,3,i.shoe[1]*.45).translate(0,-i.shoe[1]*.25,i.shoe[2]*.22)),u);Wt.add(ae);let ge=Le(le(`sole${e.build}`,()=>new Ue(i.shoe[0]*1.04,i.shoe[1]*.3,i.shoe[2]*1.03,2,.05).translate(0,-i.shoe[1]*.62,i.shoe[2]*.22)),f,{ol:2.5,olRef:9});Wt.add(ge);let Ie=Le(le(`swoosh${e.build}`,()=>new ze(i.shoe[0]*1.06,i.shoe[1]*.18,i.shoe[2]*.5).translate(0,-i.shoe[1]*.2,i.shoe[2]*.2)),gt(o),{cast:!1});Wt.add(Ie),G.push({hp:ot,kn:yt,an:Wt})}qt(e.accessory);let q=new _e;q.visible=!1;{let dt=Le(le("flossStick",()=>new pe(.025,.025,.6,5).rotateX(Math.PI/2).translate(0,0,.3)),gt("#e8d0a0"),{cast:!1}),ot=Le(le("flossFluff",()=>{let St=zn(5);return fn(Array.from({length:7},()=>new pn(.16+St()*.06,1).translate((St()-.5)*.22,(St()-.5)*.22,.72+(St()-.5)*.2)))}),gt("#ff9bd2"),{ol:2.5,olRef:9});q.add(dt,ot),q.userData.fluff=ot,q.position.y=-i.arm/2-i.hand*.4,D[0].el.add(q)}function W(dt,ot){dt==="floss"&&(q.visible=ot>0,ot>0&&q.userData.fluff.scale.setScalar(Math.max(.15,ot)))}let J={},it=new va(new Gr({transparent:!0,depthTest:!1}));it.scale.setScalar(.9),it.visible=!1,it.renderOrder=20,x.add(it);let Mt=dt=>{if(!dt){it.visible=!1;return}J[dt]||(J[dt]=ox(dt),h.push(J[dt])),it.material.map=J[dt],it.material.needsUpdate=!0,it.visible=!0},Ct=A+.12+i.torso[1]+.02+k*2;it.position.y=Ct+.45;let nt=new Set([w,M,mt,...D.flatMap(dt=>[dt.hand]),...G.map(dt=>dt.an.children[0])]);for(let dt of D)dt.sh.children.forEach(ot=>ot.isMesh&&nt.add(ot));for(let dt of G)dt.hp.children.forEach(ot=>ot.isMesh&&nt.add(ot));x.traverse(dt=>{dt.isMesh&&!dt.userData.isOutline&&(dt.castShadow=nt.has(dt))});function pt(dt,ot){let St=dt||"short";if(St==="bald")return;let ht=(yt=1.07,Yt=.48)=>{let Gt=y(le(`hcap${k}${yt}${Yt}`,()=>new Pe(k*yt,24,14,0,Math.PI*2,0,Math.PI*Yt)),p);return Gt.position.y=k*.92,Gt.rotation.x=-.32,N.add(Gt),Gt};if(St==="curly"||St==="afro"){let yt=le(`curly${k}`,()=>{let Gt=zn(7),Wt=[];for(let ae=0;ae<26;ae++){let ge=Gt()*Math.PI*.55,Ie=Gt()*Math.PI*2,et=new V(Math.sin(ge)*Math.cos(Ie),Math.cos(ge),Math.sin(ge)*Math.sin(Ie)).multiplyScalar(k*1.02);et.z>k*.55&&et.y<k*.75||Wt.push(new pn(k*.33,1).translate(et.x,et.y,et.z-k*.08))}return fn(Wt)}),Yt=y(yt,p);Yt.position.y=k*.98,St==="afro"&&(Yt.scale.setScalar(1.28),Yt.position.y=k*1.05),N.add(Yt);return}if(ot==="beanie"||ot==="bucket"||ot==="bobble"){if(ht(1.05,.5),St==="mullet"||St==="long"||St==="ponytail"){let yt=y(le(`mul${k}`,()=>new Ue(k*1.5,k*.9,k*.4,3,k*.15)),p);yt.position.set(0,k*.35,-k*.78),N.add(yt)}return}if(St==="buzz"){let yt=y(le(`buzz${k}`,()=>new Pe(k*1.025,24,14,0,Math.PI*2,0,Math.PI*.45)),p,2);yt.position.y=k*.92,yt.rotation.x=-.32,N.add(yt);return}if(ht(),St==="quiff"||St==="swept"){let yt=y(le(`quiff${k}${St}`,()=>new Pe(k*.55,16,10).scale(St==="quiff"?1.3:1.7,St==="quiff"?.75:.45,1)),p);yt.position.set(St==="swept"?k*.25:0,k*1.82,k*.38),yt.rotation.set(-.5,0,St==="swept"?-.35:0),N.add(yt)}if(St==="mullet"){let yt=y(le(`mul${k}`,()=>new Ue(k*1.5,k*.9,k*.4,3,k*.15)),p);yt.position.set(0,k*.35,-k*.78),N.add(yt)}if(St==="long"){let yt=y(le(`hlong${k}`,()=>new Ue(k*1.8,k*1.6,k*.5,3,k*.2)),p);yt.position.set(0,k*.4,-k*.62),N.add(yt)}if(St==="ponytail"){let yt=new _e;yt.position.set(0,k*1.35,-k*.85),N.add(yt);for(let Yt=0;Yt<3;Yt++){let Gt=y(le(`pt${k}${Yt}`,()=>new Pe(k*(.32-Yt*.05),12,8)),p);Gt.position.set(0,-Yt*k*.32,-Yt*k*.18),yt.add(Gt)}N.userData.pony=yt}if(St==="bun"){let yt=y(le(`bun${k}`,()=>new Pe(k*.38,14,10)),p);yt.position.set(0,k*2,-k*.2),N.add(yt)}if(St==="mohawk"||St==="spiky"){let yt=St==="mohawk"?5:9;for(let Yt=0;Yt<yt;Yt++){let Gt=y(le(`spk${k}`,()=>new rn(k*.2,k*.7,8)),p),Wt=St==="mohawk"?0:Yt/yt*Math.PI*2,ae=St==="mohawk"?-.9+Yt/(yt-1)*1.8:.6;Gt.position.set(Math.sin(Wt)*Math.sin(ae)*k,k*.92+Math.cos(ae)*k*1.05,(St==="mohawk"?Math.sin(ae):Math.cos(Wt)*Math.sin(ae))*k),Gt.lookAt(Gt.position.clone().multiplyScalar(3)),Gt.rotateX(Math.PI/2),N.add(Gt)}}}function H(dt){if(!dt)return;let ot=gt(a==="#ffffff"||a==="#f8f8f8"?o:a),St=gt(o);if(dt==="backwards-cap"){let ht=y(le(`capd${k}`,()=>new Pe(k*1.1,24,12,0,Math.PI*2,0,Math.PI*.42)),ot);ht.position.y=k*.98,ht.rotation.x=-.18,N.add(ht);let yt=y(le(`brim${k}`,()=>new pe(k*.75,k*.75,k*.08,20,1,!1,-Math.PI/2,Math.PI).scale(1.2,1,1.15)),St);yt.position.set(0,k*1.42,-k*.62),yt.rotation.set(-.12,Math.PI,0),N.add(yt)}else if(dt==="bobble"){let ht=y(le(`bean${k}`,()=>new Pe(k*1.1,24,14,0,Math.PI*2,0,Math.PI*.5).scale(1,1.15,1)),St);ht.position.y=k*.96,ht.rotation.x=-.12,N.add(ht);let yt=y(le(`brim2${k}`,()=>new ln(k*1.05,k*.17,8,24)),ot);yt.rotation.x=Math.PI/2-.12,yt.position.y=k*1.12,N.add(yt);let Yt=y(le(`bigbob${k}`,()=>new pn(k*.48,1)),ot);Yt.position.y=k*2.45,N.add(Yt),N.userData.bobble=Yt}else if(dt==="cap"||dt==="visor"){if(dt==="cap"){let yt=y(le(`capd${k}`,()=>new Pe(k*1.1,24,12,0,Math.PI*2,0,Math.PI*.42)),ot);yt.position.y=k*.98,yt.rotation.x=-.18,N.add(yt)}else{let yt=y(le(`vband${k}`,()=>new ln(k*1,k*.12,8,24)),ot);yt.rotation.x=Math.PI/2-.25,yt.position.y=k*1.35,N.add(yt)}let ht=y(le(`brim${k}`,()=>new pe(k*.75,k*.75,k*.08,20,1,!1,-Math.PI/2,Math.PI).scale(1.2,1,1.15)),St);ht.position.set(0,k*1.42,k*.62),ht.rotation.x=.12,N.add(ht)}else if(dt==="beanie"){let ht=y(le(`bean${k}`,()=>new Pe(k*1.1,24,14,0,Math.PI*2,0,Math.PI*.5).scale(1,1.15,1)),ot);ht.position.y=k*.96,ht.rotation.x=-.12,N.add(ht);let yt=y(le(`brim2${k}`,()=>new ln(k*1.05,k*.17,8,24)),St);yt.rotation.x=Math.PI/2-.12,yt.position.y=k*1.12,N.add(yt);let Yt=y(le(`bob${k}`,()=>new pn(k*.3,1)),St);Yt.position.y=k*2.25,N.add(Yt)}else if(dt==="headband"||dt==="sweatband"){let ht=y(le(`hb${k}`,()=>new ln(k*1,k*.13,8,28)),ot);ht.rotation.x=Math.PI/2-.2,ht.position.y=k*1.3,N.add(ht);let yt=y(le(`hbt${k}`,()=>new Ue(k*.2,k*.5,k*.08,2,.02)),ot);yt.position.set(.12,k*1.1,-k*1.05),yt.rotation.z=.5,N.add(yt),N.userData.tail=yt}else if(dt==="bucket"){let ht=y(le(`buck${k}`,()=>new pe(k*.8,k*1.02,k*.7,20)),ot);ht.position.y=k*1.75,N.add(ht);let yt=y(le(`buckb${k}`,()=>new pe(k*1.5,k*1.5,k*.06,24)),St);yt.position.y=k*1.42,yt.rotation.x=.1,N.add(yt)}else if(dt==="crown"||dt==="tiara"){let ht=y(le(`crown${k}`,()=>new pe(k*.7,k*.62,k*.5,8,1,!0)),gt("#ffd23f",{side:hn}));ht.position.y=k*2,N.add(ht)}else if(dt==="wizard"||dt==="party"){let ht=y(le(`cone${k}`,()=>new rn(k*.8,k*1.8,16)),ot);ht.position.y=k*2.3,ht.rotation.z=.15,N.add(ht);let yt=y(le(`bob${k}`,()=>new pn(k*.3,1)),St);yt.position.set(-k*.12,k*3.15,0),N.add(yt)}else if(dt==="helmet"||dt==="bike_helmet"){let ht=y(le(`helm${k}`,()=>new Pe(k*1.14,20,12,0,Math.PI*2,0,Math.PI*.46).scale(1,.9,1.15)),ot);ht.position.y=k*1,N.add(ht)}else if(dt==="santa"){let ht=y(le(`santa${k}`,()=>new rn(k*.95,k*1.6,16)),gt("#e8313f"));ht.position.y=k*2.2,ht.rotation.z=.5,N.add(ht);let yt=y(le(`santar${k}`,()=>new ln(k*.95,k*.2,8,24)),gt("#ffffff"));yt.rotation.x=Math.PI/2,yt.position.y=k*1.45,N.add(yt)}else{let ht=y(le(`cone${k}`,()=>new rn(k*.8,k*1.8,16)),ot);ht.position.y=k*2.3,N.add(ht)}}function qt(dt){if(dt){if(dt==="sunglasses"||dt==="glasses"){let ot=dt==="sunglasses";for(let ht of[-1,1]){let yt=y(le(`lens${k}${ot}`,()=>new Ue(k*.5,k*.32,k*.08,2,k*.06)),ot?gt("#141420"):gt("#cfefff"),2);yt.position.set(ht*k*.3,k*1.02,k*.98),yt.rotation.y=ht*.28,N.add(yt)}let St=Le(le(`bridge${k}`,()=>new ze(k*.3,k*.06,k*.06)),gt("#141420"),{cast:!1});St.position.set(0,k*1.06,k*1.04),N.add(St)}else if(dt==="medal"){let ot=y(le("ribbon",()=>new ln(.2,.03,6,20,Math.PI)),gt("#2e9bff"),2);ot.rotation.z=Math.PI,ot.position.set(0,i.torso[1]+.02,i.torso[2]/2-.05),ot.rotation.x=-.3,_.add(ot);let St=y(le("medal",()=>new pe(.11,.11,.04,16).rotateX(Math.PI/2)),gt("#ffd23f",{emissive:"#664400",emissiveIntensity:.3}),2.5);St.position.set(0,i.torso[1]-.22,i.torso[2]/2+.05),_.add(St),E.position.y-=.1,E.position.x=.12,E.scale.multiplyScalar(.8)}else if(dt==="headphones"){let ot=y(le(`hp${k}`,()=>new ln(k*1.08,k*.07,6,24,Math.PI)),gt("#22202c"),2);ot.position.y=k*.95,N.add(ot);for(let St of[-1,1]){let ht=y(le(`hpc${k}`,()=>new pe(k*.3,k*.3,k*.2,14).rotateZ(Math.PI/2)),gt(o),2.5);ht.position.set(St*k*1.02,k*.92,0),N.add(ht)}}else if(dt==="sweatband"||dt==="wristbands"||dt==="watch")for(let ot of D){let St=y(le(`wb${e.build}`,()=>new pe(i.armR*1.3,i.armR*1.3,.12,10).translate(0,-i.arm/2+.1,0)),gt(dt==="watch"?"#22202c":a),2);if(ot.el.add(St),dt==="watch")break}else if(dt==="scarf"){let ot=y(le("scarf",()=>new ln(.22,.08,8,18)),gt(a));ot.rotation.x=Math.PI/2,ot.position.y=.02,R.add(ot);let St=y(le("scarft",()=>new Ue(.14,.5,.06,2,.03)),gt(a));St.position.set(.1,-.15,-.25),St.rotation.x=.5,R.add(St),N.userData.tail2=St}else if(dt==="cape"){let ot=y(le(`cape${e.build}`,()=>new Tn(i.torso[0]*1.2,i.torso[1]*1.5,1,4).translate(0,-i.torso[1]*.75,0)),gt(a,{side:hn}),2),St=new _e;St.position.set(0,i.torso[1],-i.torso[2]/2-.03),St.add(ot),_.add(St),N.userData.cape=St}else if(dt==="backpack"){let ot=y(le(`bp${e.build}`,()=>new Ue(i.torso[0]*.7,i.torso[1]*.7,.25,3,.08)),gt(a));ot.position.set(0,i.torso[1]*.5,-i.torso[2]/2-.12),_.add(ot)}else if(dt==="moustache"||dt==="mustache"){let ot=y(le(`mou${k}`,()=>new si(k*.09,k*.5,4,8).rotateZ(Math.PI/2)),gt("#3a2616"),2);ot.position.set(0,k*.7,k*.98),N.add(ot)}else if(dt==="beard"){let ot=y(le(`beard${k}`,()=>new Pe(k*.78,18,12,0,Math.PI*2,Math.PI*.45,Math.PI*.55).scale(1.05,1,.75)),p,2.5);ot.position.set(0,k*.78,k*.32),N.add(ot);let St=y(le(`mou${k}`,()=>new si(k*.09,k*.5,4,8).rotateZ(Math.PI/2)),p,2);St.position.set(0,k*.7,k*.98),N.add(St)}else if(dt==="bumbag"){let ot=y(le(`bum${e.build}`,()=>new Ue(i.torso[0]*.5,.2,.18,2,.07)),gt(a==="#ffffff"||a==="#f8f8f8"?"#22202c":a));ot.position.set(i.torso[0]*.12,.08,i.torso[2]/2+.08),b.add(ot);let St=Le(le(`strap${e.build}`,()=>new ln(i.torso[0]*.48,.025,6,24).scale(1,i.torso[2]/i.torso[0]*1.05,1).rotateX(Math.PI/2)),gt("#22202c"),{cast:!1});St.position.y=.1,b.add(St)}else if(dt==="bib"){let ot=new We(le("bib",()=>new Tn(1,.78)),E.material);ot.scale.copy(E.scale),ot.position.set(0,i.torso[1]*.5,-i.torso[2]/2-.012),ot.rotation.y=Math.PI,_.add(ot),E.scale.multiplyScalar(1.3)}else if(dt==="bowtie")for(let ot of[-1,1]){let St=y(le("bow",()=>new rn(.08,.16,4).rotateZ(Math.PI/2)),gt(a),2);St.position.set(ot*.08,i.torso[1]-.06,i.torso[2]/2+.03),St.rotation.z=ot>0?Math.PI:0,_.add(St)}else if(dt==="tutu"){let ot=y(le(`tutu${e.build}`,()=>new pe(i.torso[0]*.55,i.torso[0]*.9,.18,16,1,!0)),gt("#ff9bd2",{side:hn}),2);ot.position.y=-.05,b.add(ot)}}}let tt={phase:r()*6.28,t:r()*10,lean:0,j:{},look:0,lookPitch:0},K=tt.j,Et=["hipLx","hipRx","kneeL","kneeR","ankL","ankR","shLx","shRx","shLz","shRz","elL","elR","twist","lean","bob","roll","headY","headX","bodyX","bodyY","bodyZ","hipSpread"];for(let dt of Et)K[dt]=0;let X={},Tt="idle",B=null,I=0;function ut(dt,ot=null){(dt!==Tt||ot!==B)&&(Tt=dt,B=ot,I=0)}function xt(dt,ot={}){tt.t+=dt,I+=dt;let St=tt.t;for(let Gt of Et)X[Gt]=0;let ht="normal",yt=10;if(Tt==="run"||Tt==="jog"||Tt==="trudge"||Tt==="distracted"){let Gt=Math.max(.5,ot.speed??3.5),Wt=Math.max(.2,ot.rate??1),ae=Tt==="trudge",ge=ae?1.7:(2.55+.14*(Gt-3.5))*Math.pow(Wt,.3)*(Tt==="jog"?.8:1);tt.phase+=dt*Math.PI*ge;let Ie=tt.phase,et=Math.sin(Ie),Kt=Math.cos(Ie),Rt=ae?.4:Math.max(.45,Math.min(1,.62+.13*(Gt-3.5)));X.hipLx=-Rt*et,X.hipRx=Rt*et,X.kneeL=.2+(ae?.5:1.35)*Math.max(0,Kt)*(.7+Rt*.3),X.kneeR=.2+(ae?.5:1.35)*Math.max(0,-Kt)*(.7+Rt*.3),X.ankL=-.2*et,X.ankR=.2*et;let Dt=ae?.3:.75*Rt+.15;X.shLx=Dt*et,X.shRx=-Dt*et,X.shLz=-.18,X.shRz=.18,X.elL=ae?-.5:-1.5,X.elR=ae?-.5:-1.5,X.twist=.16*et,X.roll=.05*et,X.bob=(ae?.03:.11)*(Math.abs(Kt)-.4),X.lean=(ae?.05:.16)+Math.max(-.25,Math.min(.45,(ot.slope??0)*1.6)),X.headX=-X.lean*.6,X.headY=-.08*et,yt=18,ht=ot.effort>.6?"effort":ot.effort>.3?"pant":"normal",ae&&(X.headX=.35,X.lean=.25,ht="sad"),Tt==="distracted"&&(X.headY=ot.lookYaw??.9,X.headX=-.15,X.twist+=(ot.lookYaw??.9)*.3,ht="love")}else if(Tt==="ready")X.hipLx=-.5,X.hipRx=.35,X.kneeL=.6,X.kneeR=.5,X.lean=.35,X.bob=-.12,X.shLx=.5,X.shRx=-.6,X.elL=-1.3,X.elR=-1.3,X.headX=-.25,X.bob+=Math.sin(St*3)*.01,ht="effort";else if(Tt==="wave")X.shRz=2.7,X.elR=.2*Math.sin(St*9)-.25,X.shRx=Math.sin(St*9)*.25,X.shLz=-.3,X.elL=-.4,X.bob=Math.abs(Math.sin(St*4))*.05,X.headY=.1*Math.sin(St*2),ht="happy";else if(Tt==="pose"){let Gt=B||"flex";if(Gt==="flex")X.shLz=-1.5,X.shRz=1.5,X.elL=-1.9-Math.sin(St*6)*.15,X.elR=-1.9-Math.sin(St*6+1)*.15,X.shLx=-0,X.bob=-.06+Math.abs(Math.sin(St*3))*.03,X.hipSpread=.25,X.kneeL=.3,X.kneeR=.3,ht="effort";else if(Gt==="point")X.shRx=-1.5,X.elR=0,X.shLz=-.3,X.elL=-1.6,X.shLx=-.3,X.headX=-.1,X.lean=-.05,ht="happy",X.bob=Math.sin(St*5)*.02;else if(Gt==="stretch")X.hipRx=-.2,X.kneeR=2.3,X.shRx=.8,X.elR=-.6,X.shLz=-2.6,X.lean=.08+Math.sin(St*2)*.04,ht="smug";else if(Gt==="spin"){let Wt=Math.min(1,I/1.1);X.bodyY=(1-(1-Wt)**2)*Math.PI*4,X.shLz=Wt<1?-1.3:-2.6,X.shRz=Wt<1?1.3:2.6,X.bob=Wt<1?Math.abs(Math.sin(St*7))*.2:Math.abs(Math.sin(St*5))*.12,ht="happy"}else Gt==="bow"?(X.lean=.75+Math.sin(St*2)*.05,X.shLx=.4,X.shRx=-1.2,X.elR=-1.6,X.shRz=.4,X.headX=-.2,ht="happy"):(X.shLz=-2.5,X.shRz=2.5,X.bob=Math.abs(Math.sin(St*6))*.25,ht="happy");ht==="smug"&&(ht="normal")}else if(Tt==="celebrate"){let Gt=B||"jump";if(Gt==="jump"){let Wt=Math.abs(Math.sin(St*5.5));X.bob=Wt*.55,X.shLz=-2.6-Wt*.3,X.shRz=2.6+Wt*.3,X.elL=-.2,X.elR=-.2,X.kneeL=X.kneeR=(1-Wt)*.8,X.hipLx=X.hipRx=-(1-Wt)*.4,ht="happy",yt=22}else if(Gt==="fist"){let Wt=Math.sin(St*7);X.shRx=-2.6,X.elR=-.4+Wt*.4,X.shLx=.4,X.elL=-1.8,X.bob=Math.abs(Wt)*.08,X.lean=-.1,ht="happy"}else Gt==="kneel"?(X.lean=.85,X.kneeL=X.kneeR=.7,X.hipLx=X.hipRx=-.6,X.bob=-.25+Math.sin(St*7)*.025,X.shLx=X.shRx=-.55,X.elL=X.elR=-.1,X.shLz=-.15,X.shRz=.15,X.headX=-.6,ht="pant"):Gt==="collapse"?(X.bodyX=-Math.PI/2+.05,X.shLz=-2.2,X.shRz=2.2,X.hipSpread=.4,X.kneeL=.3+Math.max(0,Math.sin(St*9))*.4*(Math.sin(St*.7)>.6?1:0),X.kneeR=.2,ht="dead",yt=4):Gt==="shrug"&&(X.shLz=-.9,X.shRz=.9,X.elL=-1.4,X.elR=-1.4,X.shLx=-.5,X.shRx=-.5,X.headX=.1,X.headY=Math.sin(St*1.5)*.3,ht="sad")}else X.bob=Math.sin(St*2)*.015,X.shLz=-.18,X.shRz=.18,X.elL=-.25,X.elR=-.25,X.headY=Math.sin(St*.7)*.25,X.lean=.02,X.kneeL=X.kneeR=.05;ot.lookYaw!=null&&Tt!=="distracted"&&(X.headY+=ot.lookYaw);let Yt=1-Math.exp(-yt*dt);for(let Gt of Et){if(Gt==="bodyY"&&Tt==="pose"&&B==="spin"){K[Gt]=X[Gt];continue}K[Gt]+=(X[Gt]-K[Gt])*Yt}if(Tt==="pose"&&B==="spin"||(K.bodyY=K.bodyY%(Math.PI*2),K.bodyY>Math.PI&&(K.bodyY-=Math.PI*2)),G[0].hp.rotation.set(K.hipLx,0,-K.hipSpread),G[1].hp.rotation.set(K.hipRx,0,K.hipSpread),G[0].kn.rotation.x=K.kneeL,G[1].kn.rotation.x=K.kneeR,G[0].an.rotation.x=K.ankL-K.kneeL*.35,G[1].an.rotation.x=K.ankR-K.kneeR*.35,D[0].sh.rotation.set(K.shLx,0,K.shLz-0),D[1].sh.rotation.set(K.shRx,0,K.shRz),D[0].el.rotation.x=K.elL,D[1].el.rotation.x=K.elR,_.rotation.set(K.lean,K.twist,0),b.rotation.set(0,-K.twist*.5,K.roll),b.position.y=A+K.bob,N.rotation.set(K.headX,K.headY,0),L.rotation.set(K.bodyX,K.bodyY,K.bodyZ),L.position.y+=((Tt==="celebrate"&&B==="collapse"?i.torso[2]*.5+.08:0)-L.position.y)*Yt,N.userData.bobble&&(N.userData.bobble.position.y=k*2.45+Math.abs(Math.sin(tt.phase))*.04),N.userData.pony&&(N.userData.pony.rotation.x=.4+Math.sin(tt.phase*2)*.35),N.userData.tail&&(N.userData.tail.rotation.x=.6+Math.sin(tt.phase*2)*.3),N.userData.cape&&(N.userData.cape.rotation.x=-.3-Math.min(1.1,(ot.speed??0)*.15)+Math.sin(St*8)*.08),ot.expr&&(ht=ot.expr),Y(ht),it.visible){it.position.y=Ct+.45+Math.sin(St*6)*.08;let Gt=.9+Math.sin(St*9)*.05;it.scale.set(Gt,Gt,Gt)}}function Pt(){var dt;for(let ot of h)(dt=ot.dispose)==null||dt.call(ot);it.material.dispose()}return{id:n.id,info:n,root:x,update:xt,set:ut,setPop:Mt,setExpr:Y,setProp:W,dispose:Pt,height:Ct,hipH:A,get state(){return Tt},get variant(){return B}}}var ax=(n,t,e)=>{let i=Math.max(0,Math.min(1,(e-n)/(t-n)));return i*i*(3-2*i)};function zu(n,t,e){let i=n.timeMap,s={};e.forEach((M,_)=>s[M.id]=M.lane??_+1);let r=n.runners.length,o=Object.values(s),a=(Math.min(...o)+Math.max(...o))/2,l=Math.min(1.25,(tn-1.6)/Math.max(1,r-1)),c=n.runners.map((M,_)=>{let w=Di(i,M.officialS),P=((s[M.id]??_+1)-a)*l;return{...M,finishB:w,base:P,seed:_*1.7+.3}}),h=Object.fromEntries(c.map(M=>[M.id,M])),m=[...c].sort((M,_)=>M.officialS-_.officialS).map(M=>M.id),g=Object.fromEntries(m.map((M,_)=>[M,_+1])),d=h[m[0]],p=m.map(M=>h[M].officialS),v=h[m[0]].finishB,u=h[m.at(-1)].finishB,f=r>1&&p[1]-p[0]<=1.5,S=M=>Math.max(.05,(Ui(i,M+.05)-Ui(i,M-.05))/.1),y=new Map;function x(M){let _=Math.round(M*1e3);if(y.has(_))return y.get(_);let w=M<=0?0:Ui(i,M),P=M<=0?4:S(M),E={b:M,raceS:w,rate:P,byId:{},order:[]};for(let U of c){let z=li(U.progress,w),Z=w>=U.officialS&&M>=U.finishB-1e-6,Y=(li(U.progress,w+1)-li(U.progress,Math.max(0,w-1)))/(w>1?2:1);E.byId[U.id]={id:U.id,m:z,finished:Z,vRace:Z?0:Y,place:g[U.id]}}for(let U of c){let z=E.byId[U.id],Z=z.m,Y=U.base;Y+=.22*Math.sin(z.m/85+U.seed);for(let bt of c){if(bt===U)continue;let D=E.byId[bt.id],G=z.m-D.m;if(Math.abs(G)<4&&!z.finished&&!D.finished){let q=(1-Math.abs(G)/4)*.32;Y+=Math.sign(U.base-bt.base||U.seed-bt.seed)*q}}let k=0;if(z.finished){let bt=M-U.finishB,D=(li(U.progress,U.officialS)-li(U.progress,U.officialS-2))/2*S(U.finishB),G=Math.min(14,Math.max(4,D)),q=1.6;Z=5e3+(bt<q?G*(bt-bt*bt/(2*q)):G*q/2+Math.min(10+g[U.id]*1.5,(bt-q)*.9));let J=(g[U.id]-(r+1)/2)*1.6;Y=Y+(J-Y)*ax(0,2.5,bt),k=bt}let mt=t.sample(Z,U.id);Y*=1-mt.div,Y=Math.max(-tn/2+.6,Math.min(tn/2-.6,Y)),Object.assign(z,{mVis:Z,x:mt.x+mt.rx*Y,z:mt.z+mt.rz*Y,y:t.heightAt(mt.x+mt.rx*Y,mt.z+mt.rz*Y)+.16,tx:mt.tx,tz:mt.tz,slope:mt.slope,div:mt.div,divInfo:mt.divInfo,lat:Y,post:k,distToFinish:Math.max(0,5e3-z.m)})}let F=c.filter(U=>E.byId[U.id].finished).sort((U,z)=>U.officialS-z.officialS),R=c.filter(U=>!E.byId[U.id].finished).sort((U,z)=>E.byId[z.id].m-E.byId[U.id].m||U.officialS-z.officialS);E.order=[...F,...R].map(U=>U.id),E.leader=E.byId[E.order[0]];let N=h[E.order[0]];for(let[U,z]of E.order.entries()){let Z=E.byId[z];if(Z.finished)Z.gapText=U===0?Ha(h[z].officialS):`+${(h[z].officialS-d.officialS).toFixed(0)}s`;else if(U===0)Z.gapText="LEADER";else{let Y=E.byId[E.order[0]].finished?d:N;Z.gapText=`+${Math.max(0,w-ci(Y.progress,Z.m)).toFixed(1)}s`}}return y.size>400&&y.clear(),y.set(_,E),E}return{stateAt:x,orderAt:M=>x(M).order,gapM:(M,_,w)=>{var E,F;let P=x(w);return Math.abs((((E=P.byId[M])==null?void 0:E.m)??0)-(((F=P.byId[_])==null?void 0:F.m)??0))},finishedAt:(M,_)=>{var w;return(w=x(_).byId[M])==null?void 0:w.finished},allFinishedAt:M=>M>u,firstFinishB:v,lastFinishB:u,photoFinish:f,finishOrder:m,place:g,byId:h,R:c,rateAt:S,durationS:i.durationS}}function Ha(n){let t=Math.floor(n/60),e=Math.round(n-t*60);return`${t}:${String(e).padStart(2,"0")}`}var lx=1.3,cx=2.4,hx=.24,fx=16/9,Hu=n=>n*180/Math.PI,Bu=(n,t=hx)=>Hu(2*Math.atan(cx/(2*t*n)));function Sh({plan:n,sim:t,backedIds:e=[],C:i,world:s,funfair:r}){var F;let o=[],a=n.timeMap,l=R=>Di(a,Math.min(...n.runners.map(N=>ci(N.progress,R)))),c=R=>R<=0?4:t.rateAt(R),h=(R,N)=>{let U=0,z=0;for(let Z=R;Z<=N;Z+=Math.max(.5,(N-R)/12))U+=c(Z),z++;return U/Math.max(1,z)},m=t.firstFinishB,g=t.lastFinishB,d=R=>{let N=t.stateAt(Math.max(0,R)),U=N.order.filter(Z=>!N.byId[Z].finished),z=U[0]??N.order[0];return(U.length?U:N.order).filter(Z=>Math.abs(N.byId[Z].m-N.byId[z].m)<120)},p=R=>{let N=t.stateAt(Math.max(0,R)),U=N.order.filter(Z=>!N.byId[Z].finished),z=U[0]??N.order[0];return(U.length?U:N.order).filter(Z=>Math.abs(N.byId[Z].m-N.byId[z].m)<20)},v=(R,N)=>{let U=t.stateAt(Math.max(0,N));return U.order.filter(z=>!U.byId[z].finished&&Math.abs(U.byId[z].m-U.byId[R].m)<20)},u=(R,N)=>{let U=[];for(let G=0;G<=6;G++)U.push(t.stateAt(Math.max(0,R+(N-R)*G/6)));let z=U[0].order.filter(G=>!U[0].byId[G].finished&&!U.at(-1).byId[G].finished),Z=[];for(let G=0;G<z.length;G++)for(let q=G+1;q<z.length;q++){let W=z[G],J=z[q],it=0;for(let Ct of U)it=Math.max(it,Math.abs(Ct.byId[W].m-Ct.byId[J].m));let Mt=U[3].order.indexOf(W)+U[3].order.indexOf(J);Z.push({ids:[W,J],gap:it,backed:e.includes(W)||e.includes(J),pos:Mt})}let Y=G=>G.sort((q,W)=>q.gap+q.pos*2-(W.gap+W.pos*2))[0],k=Y(Z.filter(G=>G.backed&&G.gap<=30))||Y(Z.filter(G=>G.gap<=40));if(k){let G=[...k.ids];for(let q of z)!G.includes(q)&&U.every(W=>{let J=k.ids.map(it=>W.byId[it].m);return W.byId[q].m>Math.min(...J)-6&&W.byId[q].m<Math.max(...J)+6})&&G.push(q);return{ids:G,kind:k.backed?"backedPair":"pair",gap:k.gap}}let mt=U[3],bt=mt.order.filter(G=>z.includes(G)),D=[bt[0]];for(let G=0;G<bt.length;G++){let q=bt.filter(W=>mt.byId[bt[G]].m-mt.byId[W].m>=0&&mt.byId[bt[G]].m-mt.byId[W].m<150);q.length>D.length&&(D=q)}return{ids:D.length?D:null,kind:"pack"}},f=(R,N)=>R.kind==="pack"?"drone":R.gap>24||N==="side"?"headon":"side",S=.25+8;for(let R=.25;R<30;R+=.25)if(c(R)>7){S=Math.max(S,R);break}let y=m-6;for(let R=m-12;R>S;R-=.25)if(c(R)>6){y=R;break}let x=Math.max(y+4,Math.min(m-3,l(4850))),L=Math.max(y,Math.min(x,l(4700)));o.push({type:"heli",a:-8.5,b:-3.2,hard:!0}),o.push({type:"startgo",a:-3.2,b:.25}),o.push({type:"side",a:.25,b:S,hard:!0,ids:null});let b=[],T=n.runners.find(R=>{var N;return(N=R.diversions)==null?void 0:N.length});if(T&&r){let R=T.diversions[0],N=Di(a,ci(T.progress,R.fromM))-.5,U=Di(a,ci(T.progress,R.toM))+.8;b.push({type:"side",tag:"fair",a:N,b:Math.max(N+8,U),ids:[T.id],fair:!0,prio:3})}for(let R of Ph){let N=l(R);b.push({type:"headon",tag:"hill",a:N-1.5,b:N+8,prio:2})}b.sort((R,N)=>N.prio-R.prio);let A=[];for(let R of b){let N=Math.min(y,R.b),U=Math.max(S,Math.min(R.a,N-8));N-U<6||A.some(z=>U<z.b&&N>z.a)||A.push({...R,a:U,b:N})}A.sort((R,N)=>R.a-N.a);let M=(R,N)=>{var Z;let U=N-R;if(U<=.01)return;if(U<8&&o.length>=3){o.at(-1).b=N;return}let z=Math.max(1,Math.round(U/11));for(let Y=0;Y<z;Y++){let k=R+U*Y/z,mt=R+U*(Y+1)/z,bt=u(k,mt);o.push({type:f(bt,(Z=o.at(-1))==null?void 0:Z.type),a:k,b:mt,ids:bt.ids,subject:bt.kind,pack:bt.kind==="pack"})}},_=S;for(let R of A){if(M(_,R.a),R.tag==="hill"){let N=u(R.a,R.b);N.kind!=="pack"&&(R.ids=N.ids,R.subject=N.kind)}o.push(R),_=R.b}M(_,y);{let R=L-y;if(R>=8){let Z=Math.max(1,Math.round(R/11));for(let Y=0;Y<Z;Y++){let k=y+R*Y/Z,mt=y+R*(Y+1)/Z,bt=u(k,mt);o.push({type:f(bt,(F=o.at(-1))==null?void 0:F.type),a:k,b:mt,ids:bt.ids,subject:bt.kind,pack:bt.kind==="pack"})}}let N=Math.max(y,o.at(-1).b),U=u(N,x),z={type:(U.kind==="pack","headon"),a:N,b:x,ids:U.kind==="pack"?null:U.ids,subject:U.kind};o.at(-1).type==="headon"&&o.at(-1).a>=y&&String(o.at(-1).ids)===String(z.ids)?o.at(-1).b=x:o.push(z)}if(o.at(-1).b-o.at(-1).a<6&&o.length>4){let R=o.pop();o.at(-1).b=R.b}o.push({type:"finishcam",a:x,b:g+2.5,hard:!0}),o.push({type:"celebrate",a:g+2.5,b:g+90});let w=(n.events||[]).filter(R=>(R.type==="lead_change"||R.type==="overtake"&&(e.includes(R.by)||e.includes(R.on)))&&R.broadcastS>S+2&&R.broadcastS<y-3),P=-1e9;for(let R of w){let N=R.type==="lead_change"?[R.to,R.from]:[R.by,R.on];if(R.broadcastS-P<12)continue;let U=o.findIndex(Y=>R.broadcastS>=Y.a&&R.broadcastS<Y.b);if(U<0)continue;let z=o[U];if(["heli","startgo","finishcam","celebrate","drone"].includes(z.type)||z.interrupt||z.tag||z.hard||z.subject==="backedPair")continue;let Z=z.ids||p((z.a+z.b)/2);if(!N.every(Y=>Z.includes(Y))){if(R.broadcastS-z.a<8||z.b-R.broadcastS<8)Object.assign(z,{type:"side",ids:N,interrupt:R.type,pack:!1,subject:"pair"});else{let Y=R.broadcastS-1.8;o.splice(U,1,{...z,b:Y},{type:"side",a:Y,b:z.b,ids:N,interrupt:R.type,subject:"pair"})}P=R.broadcastS}}for(let R of o)if(R.rate=h(Math.max(0,R.a),Math.max(.5,R.b)),R.ids=R.ids||null,R.type==="side"||R.type==="headon"||R.type==="drone"){let N=R.ids||(R.type==="drone"?d((R.a+R.b)/2):p((R.a+R.b)/2));R.type==="drone"&&!R.ids&&(R.pack=!0);let U=0;for(let z=0;z<=6;z++){let Z=t.stateAt(Math.max(0,R.a+(R.b-R.a)*z/6)),Y=N.map(k=>Z.byId[k]).filter(k=>k&&!k.finished).map(k=>k.m);Y.length&&(U=Math.max(U,Math.max(...Y)-Math.min(...Y)))}if(R.spread=U,R.type==="side"){R.dist=Ki.clamp(14+1.7*R.rate,18,48);let z=Bu(R.dist),Z=U+7,Y=Hu(2*Math.atan(Z/(2*fx*R.dist)));R.fov=Ki.clamp(Math.max(z,Y),10,34),R.side=E(R,N)}else R.type==="headon"?(R.dist=Ki.clamp(16+1.9*R.rate,20,52)+U*.6,R.fov=Ki.clamp(Bu(R.dist-U*.3,.2),10,30)):(R.back=30+2.2*R.rate+U*.35,R.height=16+1.9*R.rate+U*.25,R.fov=40,R.side=E(R,N))}return o;function E(R,N){let U=J=>{let it=t.stateAt(Math.max(0,J)),Mt=N.map(pt=>it.byId[pt]).filter(Boolean),Ct=Mt.reduce((pt,H)=>pt+H.x,0)/Mt.length,nt=Mt.reduce((pt,H)=>pt+H.z,0)/Mt.length;return[Ct,nt]},z=U(R.a),Z=U((R.a+R.b)/2),Y=U(R.b),k=(Z[0]-z[0])*(Y[1]-Z[1])-(Z[1]-z[1])*(Y[0]-Z[0]),mt=R.fair?null:k>0?1:-1;if(R.fair&&r){let J=r.anchors.center,it=[Y[0]-z[0],Y[1]-z[1]],Mt=[-it[1],it[0]];return mt=(J.x-Z[0])*Mt[0]+(J.z-Z[1])*Mt[1]>0?-1:1,mt}let bt=[Y[0]-z[0],Y[1]-z[1]],D=Math.hypot(...bt)||1,G=[-bt[1]/D,bt[0]/D],q=R.dist||40,W=J=>s.inPark(Z[0]+G[0]*q*J,Z[1]+G[1]*q*J);return!W(mt)&&W(-mt)&&(mt=-mt),mt}}function Vu({camera:n,C:t,sim:e,world:i,funfair:s}){let r={pos:new V,look:new V},o=new V(0,1,0),a=null,l=null,c=!0,h=null,m=new $n,g=new Fe;function d(y,x){let L=e.stateAt(Math.max(0,x)),b=(y||L.order.slice(0,1)).map(M=>L.byId[M]).filter(Boolean),T=b.filter(M=>!M.finished);T.length&&(b=T);let A=new V;for(let M of b)A.add(new V(M.x,M.y,M.z));return A.divideScalar(Math.max(1,b.length))}function p(y,x,L){let b=d(y,x),T=d(y,x-L*1.5),A=d(y,x+L*1.5),M=new V(A.x-T.x,0,A.z-T.z);if(M.lengthSq()<1e-4){let _=(y==null?void 0:y[0])??e.stateAt(Math.max(0,x)).order[0],w=e.stateAt(Math.max(0,x)).byId[_];M.set(w.tx,0,w.tz)}return M.normalize(),{c:b,h:M,r:new V(-M.z,0,M.x)}}let v=(y,x)=>{if(y.ids)return y.ids;if(!y._group){let L=(y.a+y.b)/2,b=e.stateAt(Math.max(0,L)),T=b.order.filter(M=>!b.byId[M].finished),A=T[0]??b.order[0];y._group=(T.length?T:b.order).filter(M=>Math.abs(b.byId[M].m-b.byId[A].m)<(y.pack?120:20)),y._group.length||(y._group=[A])}return y._group};function u(y,x){let L=i.anchors.finish,b=i.anchors.start,T,A,M=40,_=y.rate>8?2.2:1.2;switch(y.type){case"heli":{let w=(x-y.a)/Math.max(.01,y.b-y.a),P=new V(150,0,0),E=new V(b.x,b.y,b.z),F=wh(Math.min(1,w)),R=-1.2+F*1.6,N=420-F*360;T=new V(P.x+Math.cos(R)*N,170-F*140,P.z+Math.sin(R)*N).lerp(new V(E.x-b.tx*40+b.rx*25,E.y+22,E.z-b.tz*40+b.rz*25),F*F),A=P.clone().setY(10).lerp(E,Math.min(1,F*1.3)),M=50;break}case"startgo":{let w=new V(b.x,b.y,b.z),P=new V(b.tx,0,b.tz),E=new V(-P.z,0,P.x);T=w.clone().addScaledVector(P,10.5).addScaledVector(E,2.6).add(o.clone().multiplyScalar(1.9)),A=w.clone().add(o.clone().multiplyScalar(1.3)).addScaledVector(P,-1),M=42;break}case"side":{let{c:w,h:P,r:E}=p(v(y,x),x,_);T=w.clone().addScaledVector(E,y.side*y.dist).addScaledVector(P,y.dist*.18).add(o.clone().multiplyScalar(2.5+y.dist*.2)),A=w.clone().add(o.clone().multiplyScalar(1.1)),M=y.fov;break}case"headon":{let{c:w,h:P,r:E}=p(v(y,x),x,_);T=w.clone().addScaledVector(P,y.dist).addScaledVector(E,1.5).add(o.clone().multiplyScalar(2+y.dist*.16)),A=w.clone().add(o.clone().multiplyScalar(1.15)),M=y.fov;break}case"drone":{let{c:w,h:P,r:E}=p(v(y,x),x,_*1.3);T=w.clone().addScaledVector(P,-y.back).addScaledVector(E,y.side*y.back*.5).add(o.clone().multiplyScalar(y.height)),A=w.clone().addScaledVector(P,y.back*.15),M=y.fov;break}case"finishcam":{let w=new V(L.tx,0,L.tz),P=new V(-w.z,0,w.x);y.fside||(y.fside=i.inPark(L.x+P.x*16,L.z+P.z*16)?1:-1);let E=new V(L.x,L.y+1,L.z);T=E.clone().addScaledVector(P,y.fside*15).addScaledVector(w,11).add(o.clone().multiplyScalar(1.9));let F=e.stateAt(Math.max(0,x)),R=F.order.map(z=>F.byId[z]).find(z=>!z.finished),U=F.order.map(z=>F.byId[z]).filter(z=>z.finished).sort((z,Z)=>z.post-Z.post)[0];if(U&&U.post<6&&(!R||R.distToFinish>45))A=new V(U.x,U.y+1.1,U.z);else{let z=R?Math.min(1,Math.max(0,R.distToFinish/150)):0;A=R?E.clone().lerp(new V(R.x,R.y+1,R.z),Math.min(1,.25+z)):E}M=22,y.smoothLook=!0;break}case"celebrate":{let w=e.stateAt(Math.max(0,x)),P=new V;for(let N of w.order)P.add(new V(w.byId[N].x,w.byId[N].y,w.byId[N].z));P.divideScalar(w.order.length);let E=new V(L.tx,0,L.tz),F=new V(-E.z,0,E.x),R=Math.sin((x-y.a)*.08)*.5;T=P.clone().addScaledVector(E,-11*Math.cos(R)).addScaledVector(F,11*Math.sin(R)).add(o.clone().multiplyScalar(2.8)),A=P.clone().add(o.clone().multiplyScalar(1.2)),M=44;break}default:{let{c:w,h:P}=p(v(y,x),x,_);T=w.clone().addScaledVector(P,-12).add(o.clone().multiplyScalar(5)),A=w.clone()}}return{pos:T,look:A,fov:M}}function f(y,x,L){let b=L.find(E=>y>=E.a&&y<E.b)||L.at(-1),T=!1;if(b!==a){let E=c||!!b.hard;l=E?null:{from:{pos:n.position.clone(),look:r.look.clone(),fov:n.fov},t0:y},T=E,c=!1,a=b,h=null}let A=u(b,y),M=t.heightAt(A.pos.x,A.pos.z)+1.2;A.pos.y<M&&(A.pos.y=M),b.smoothLook&&(h||(h=A.look.clone()),h.lerp(A.look,1-Math.exp(-2.5*x)),A.look.copy(h)),g.lookAt(A.pos,A.look,o),m.setFromRotationMatrix(g);let _=A.pos,w=m,P=A.fov;if(l){let E=(y-l.t0)/lx;if(E>=1||E<0)l=null;else{let F=E*E*E*(E*(E*6-15)+10),R=Math.sin(Math.PI*F)*Math.min(12,l.from.pos.distanceTo(A.pos)*.12);_=l.from.pos.clone().lerp(A.pos,F).add(o.clone().multiplyScalar(R));let N=Math.min(1,E*2.2),U=l.from.look.clone().lerp(A.look,N*N*(3-2*N));g.lookAt(_,U,o),w=new $n().setFromRotationMatrix(g),P=l.from.fov+(A.fov-l.from.fov)*F}}return r.pos.copy(A.pos),r.look.copy(A.look),n.position.copy(_),n.quaternion.copy(w),Math.abs(n.fov-P)>.001&&(n.fov=P,n.updateProjectionMatrix()),{shot:b,cut:T}}function S(y=!0){a=null,l=null,c=!!y,h=null}return{update:f,reset:S,evaluate:u,get shot(){return a},get gliding(){return!!l},cam:r}}function wh(n){return n<.5?2*n*n:1-Math.pow(-2*n+2,2)/2}var ro=new Set(["drone","heli"]);var ux=`
.mr-hud{position:absolute;inset:0;pointer-events:none;overflow:hidden;font-family:var(--font-display,"Lilita One","Arial Black",Impact,sans-serif);color:#fff;
  --ink:#14183c;--blue:#2a62e0;--blue2:#173c9c;--yellow:#ffd23f;--pink:#ff6fb5;--tomato:#ff4d5a;--grass:#2ec27e;--u:calc(min(1vw,1.78vh));letter-spacing:.02em;
  --ease:cubic-bezier(.2,.8,.2,1);--fast:150ms;--slow:400ms;--sk:-8deg;--usk:8deg;--ol:calc(var(--u)*.37);--drop:0 calc(var(--u)*.65) 0 var(--ink);--body:var(--font-body,Nunito,"Arial Rounded MT Bold",sans-serif)}
.mr-hud *{box-sizing:border-box}
.mr-num{color:var(--yellow);-webkit-text-stroke:calc(var(--u)*.38) var(--ink);paint-order:stroke fill;text-shadow:0 calc(var(--u)*.3) 0 rgba(0,0,0,.35)}
.mr-panel{background:linear-gradient(180deg,#3d86ff,#2457c8);border:var(--ol) solid var(--ink);border-radius:calc(var(--u)*.9);transform:skewX(var(--sk));box-shadow:var(--drop)}
.mr-panel>.mr-unskew{transform:skewX(var(--usk))}
.mr-top{position:absolute;left:calc(var(--u)*2.2);top:calc(var(--u)*1.8);display:flex}
.mr-pill{display:flex;align-items:center;gap:calc(var(--u)*.7);background:rgba(20,24,60,.85);border-radius:calc(var(--u)*.9);transform:skewX(var(--sk));padding:calc(var(--u)*.35) calc(var(--u)*1.1);font-size:calc(var(--u)*1.35);line-height:1.2}
.mr-pill b{font-weight:400;color:var(--yellow)}
.mr-pill .mr-dot{width:calc(var(--u)*.7);height:calc(var(--u)*.7);border-radius:50%;background:#ff3d5a;display:inline-block}
.mr-pill .mr-sep{width:1px;align-self:stretch;background:rgba(255,255,255,.3)}
.mr-pill .mr-clk{font-family:var(--body);font-weight:800;font-size:.8em;opacity:.65}
.mr-live{background:var(--pink);padding:calc(var(--u)*.5) calc(var(--u)*1.2);font-size:calc(var(--u)*1.5);display:flex;align-items:center;gap:calc(var(--u)*.5)}
.mr-live i{width:calc(var(--u)*.9);height:calc(var(--u)*.9);border-radius:50%;background:#fff;display:inline-block;}
@keyframes mrblink{50%{opacity:.25}}
.mr-clock{padding:calc(var(--u)*.2) calc(var(--u)*1.4);font-size:calc(var(--u)*2.9);line-height:1.1;min-width:calc(var(--u)*12);text-align:center}
.mr-lap{padding:calc(var(--u)*.2) calc(var(--u)*1.2);display:flex;align-items:center;gap:calc(var(--u)*.6);font-size:calc(var(--u)*1.4)}
.mr-lap b{font-size:calc(var(--u)*2.9);font-weight:400}
.mr-dist{padding:calc(var(--u)*.3) calc(var(--u)*1.2);font-size:calc(var(--u)*1.4);display:flex;flex-direction:column;justify-content:center;min-width:calc(var(--u)*11)}
.mr-bar{height:calc(var(--u)*.7);background:rgba(0,0,0,.35);border-radius:9px;margin-top:calc(var(--u)*.3);overflow:hidden;border:2px solid var(--ink)}
.mr-bar>i{display:block;height:100%;background:var(--yellow);width:0}
.mr-tower{position:absolute;left:calc(var(--u)*2.2);top:calc(var(--u)*5.2);width:calc(var(--u)*21)}
.mr-row{position:absolute;left:0;width:100%;height:calc(var(--u)*2.9);display:flex;align-items:center;transition:transform var(--slow) var(--ease),opacity var(--slow) var(--ease)}
.mr-row.off{opacity:0}
.mr-row .mr-pos{width:calc(var(--u)*3.8);font-size:calc(var(--u)*2.2);text-align:center;line-height:1}
.mr-row .mr-pos small{font-size:.42em;margin-right:2px;vertical-align:middle;color:#fff}
.mr-row .mr-pos sup{font-size:.45em;vertical-align:top;margin-left:1px}
.mr-row .mr-card{flex:1;min-width:0;height:calc(var(--u)*2.4);display:flex;align-items:center;padding:0 calc(var(--u)*.6) 0 0;background:rgba(20,24,60,.82);border-radius:calc(var(--u)*.45);transform:skewX(var(--sk));overflow:hidden}
.mr-row .mr-card>*{transform:skewX(var(--usk))}
.mr-row .mr-chip{width:calc(var(--u)*.8);align-self:stretch;margin-right:calc(var(--u)*.6)}
.mr-row .mr-name{flex:1;min-width:0;font-size:calc(var(--u)*1.25);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mr-row .mr-gap{font-family:var(--body);font-weight:900;font-size:calc(var(--u)*.95);color:#cfe0ff;margin-left:calc(var(--u)*.5)}
.mr-row.lead .mr-card{background:linear-gradient(90deg,rgba(255,210,63,.95),rgba(255,160,40,.92));color:var(--ink)}
.mr-row.lead .mr-gap{color:var(--ink)}
.mr-row.fin .mr-gap{color:#7dff9a}
.mr-row.lead.fin .mr-gap{color:var(--ink)}
.mr-badge{display:inline-flex;align-items:center;gap:.2em;background:var(--bc,#fff);color:var(--ink);border:calc(var(--u)*.18) solid var(--ink);border-radius:99px;font-size:calc(var(--u)*1.05);padding:.05em .55em;margin-left:calc(var(--u)*.35);line-height:1.2;box-shadow:0 calc(var(--u)*.15) 0 rgba(0,0,0,.35);white-space:nowrap}
.mr-inis{display:inline-flex;gap:calc(var(--u)*.2);margin-left:calc(var(--u)*.4);flex-shrink:0}
.mr-ini{display:inline-flex;align-items:center;justify-content:center;width:calc(var(--u)*1.25);height:calc(var(--u)*1.25);border-radius:50%;background:var(--bc);color:var(--ink);font-family:var(--body);font-weight:900;font-size:calc(var(--u)*.8);line-height:1;border:1px solid rgba(26,20,32,.6)}

.mr-tag .mr-tb{display:inline-flex;gap:calc(var(--u)*.15)}
.mr-title{position:absolute;left:41%;top:9%;width:max-content;max-width:64%;transform:translate(-50%,-30%) scale(.8);opacity:0;text-align:center;transition:opacity var(--slow) var(--ease),transform var(--slow) var(--ease)}
.mr-title.on{opacity:1;transform:translate(-50%,0) scale(1)}
.mr-title .mr-t0{display:inline-block;font-size:calc(var(--u)*1.7);background:var(--pink);padding:.1em .9em;border:calc(var(--u)*.3) solid var(--ink);border-radius:calc(var(--u)*.8);transform:skewX(var(--sk))}
.mr-title .mr-t1{display:block;white-space:normal;margin-top:calc(var(--u)*.6);font-size:calc(var(--u)*5.2);line-height:1.02;color:#fff;-webkit-text-stroke:calc(var(--u)*.45) var(--ink);paint-order:stroke fill;text-shadow:0 calc(var(--u)*.5) 0 rgba(0,0,0,.35)}
.mr-title .mr-t2{display:inline-block;margin-top:calc(var(--u)*.8);font-size:calc(var(--u)*2.1);color:var(--ink);background:var(--yellow);padding:.1em .9em;border:calc(var(--u)*.3) solid var(--ink);border-radius:calc(var(--u)*.8);transform:skewX(var(--sk))}
.mr-pcap{position:absolute;left:50%;bottom:19%;transform:translateX(-50%) skewX(var(--sk));background:var(--ink);color:#fff;border:calc(var(--u)*.3) solid #fff;padding:calc(var(--u)*.4) calc(var(--u)*2);font-size:calc(var(--u)*2.2);white-space:nowrap}
.mr-market{position:absolute;inset:0;opacity:0;transition:opacity var(--slow) var(--ease);background:radial-gradient(ellipse at center,rgba(0,0,0,0) 45%,rgba(20,10,40,.55) 100%)}
.mr-market.on{opacity:1}
.mr-market .mr-m1{position:absolute;left:60%;top:15%;transform:translate(-50%,-50%) skewX(var(--sk)) rotate(-2deg);background:linear-gradient(180deg,#3ddc84,#1f9d5a);border:var(--ol) solid var(--ink);border-radius:calc(var(--u)*1.2);padding:calc(var(--u)*.35) calc(var(--u)*1.8);font-size:calc(var(--u)*3.5);white-space:nowrap;color:#fff;-webkit-text-stroke:calc(var(--u)*.35) var(--ink);paint-order:stroke fill;box-shadow:var(--drop);}
@keyframes mrpulse{50%{transform:translate(-50%,-50%) skewX(var(--sk)) rotate(-2deg) scale(1.04)}}
.mr-market .mr-m2{position:absolute;left:60%;top:22%;transform:translateX(-50%);font-size:calc(var(--u)*2.3);-webkit-text-stroke:calc(var(--u)*.3) var(--ink);paint-order:stroke fill;white-space:nowrap}
.mr-market .mr-mt{position:absolute;right:calc(var(--u)*3);top:calc(var(--u)*25);font-size:calc(var(--u)*1.6);background:var(--ink);padding:.2em .8em;border-radius:calc(var(--u)*.6)}
.mr-map{position:absolute;right:calc(var(--u)*2.2);top:calc(var(--u)*1.8);width:calc(var(--u)*11);height:calc(var(--u)*13.5);padding:calc(var(--u)*.4);transition:opacity var(--slow) var(--ease)}
.mr-hud.mr-nomap .mr-map{opacity:0}
.mr-map canvas{position:relative;width:100%;height:100%;display:block}
.mr-mapwrap{position:absolute;inset:0;background:rgba(255,255,255,.72);border-radius:calc(var(--u)*1)}
.mr-banner{position:absolute;left:50%;top:13%;transform:translate(-50%,-50%) scale(0);text-align:center;white-space:nowrap;transition:transform var(--fast) var(--ease)}
.mr-banner.on{transform:translate(-50%,-50%) scale(1)}
.mr-banner .mr-b1{display:inline-block;box-shadow:var(--drop);padding:calc(var(--u)*.2) calc(var(--u)*1.6);font-size:calc(var(--u)*2.8);line-height:1.05;background:var(--pink);border:var(--ol) solid var(--ink);border-radius:calc(var(--u)*1.2);transform:skewX(var(--sk)) rotate(-3deg);box-shadow:var(--drop)}
.mr-banner .mr-b1 span{display:inline-block;transform:skewX(var(--usk))}
.mr-banner .mr-b2{display:block;margin-top:calc(var(--u)*.6);font-size:calc(var(--u)*1.8);-webkit-text-stroke:calc(var(--u)*.3) var(--ink);paint-order:stroke fill}
.mr-tags{position:absolute;inset:0}
.mr-tag{position:absolute;left:0;top:0;transform:translate(-50%,-100%);white-space:nowrap;display:flex;align-items:center;gap:calc(var(--u)*.3);font-size:calc(var(--u)*1.05);will-change:transform;transition:opacity var(--fast) var(--ease)}
.mr-tag .mr-tp{background:var(--ink);color:var(--yellow);border-radius:calc(var(--u)*.5);padding:0 calc(var(--u)*.45);font-size:calc(var(--u)*1.35)}
.mr-tag .mr-tn{padding:calc(var(--u)*.05) calc(var(--u)*.6);border:calc(var(--u)*.22) solid var(--ink);border-radius:calc(var(--u)*.6);-webkit-text-stroke:calc(var(--u)*.22) var(--ink);paint-order:stroke fill;box-shadow:0 calc(var(--u)*.25) 0 rgba(0,0,0,.3)}
.mr-tag:after{content:"";position:absolute;left:50%;bottom:calc(var(--u)*-.75);border:calc(var(--u)*.45) solid transparent;border-top-color:var(--ink);transform:translateX(-50%)}
.mr-card3{position:absolute;left:calc(var(--u)*5);bottom:19%;display:flex;align-items:stretch;opacity:0;transform:translateX(-30%);transition:opacity var(--slow) var(--ease),transform var(--slow) var(--ease)}
.mr-card3.on{opacity:1;transform:none}
.mr-card3 .mr-lane{width:calc(var(--u)*8);font-size:calc(var(--u)*6.5);display:flex;align-items:center;justify-content:center;border:var(--ol) solid var(--ink);border-radius:calc(var(--u)*1.2);transform:skewX(var(--sk));margin-right:calc(var(--u)*-.6);z-index:1}
.mr-card3 .mr-lane span{transform:skewX(var(--usk))}
.mr-card3 .mr-info{padding:calc(var(--u)*.8) calc(var(--u)*3) calc(var(--u)*.8) calc(var(--u)*2.4)}
.mr-card3 .mr-nick{font-size:calc(var(--u)*4.4);line-height:1;-webkit-text-stroke:calc(var(--u)*.3) var(--ink);paint-order:stroke fill}
.mr-card3 .mr-tagl{font-family:var(--body);font-weight:900;font-size:calc(var(--u)*1.55);opacity:.95;margin-top:calc(var(--u)*.4)}
.mr-count{position:absolute;left:50%;top:42%;transform:translate(-50%,-50%) scale(1);font-size:calc(var(--u)*16);opacity:0}
.mr-count.pop{animation:mrpop .8s var(--ease)}
@keyframes mrpop{0%{transform:translate(-50%,-50%) scale(2.2);opacity:0}20%{transform:translate(-50%,-50%) scale(1);opacity:1}80%{opacity:1}100%{transform:translate(-50%,-50%) scale(.8);opacity:0}}
.mr-photo{position:absolute;inset:0;opacity:0;transition:opacity var(--fast) var(--ease);background:radial-gradient(ellipse at center,rgba(0,0,0,0) 50%,rgba(0,0,0,.55) 100%)}
.mr-photo.on{opacity:1}
.mr-photo .mr-flash{position:absolute;inset:0;background:#fff;opacity:0}
.mr-photo.on .mr-flash{animation:mrflash var(--slow) var(--ease)}
@keyframes mrflash{0%{opacity:.95}100%{opacity:0}}
.mr-photo .mr-pf{position:absolute;left:50%;top:14%;transform:translateX(-50%) skewX(var(--sk));background:#fff;color:var(--ink);border:var(--ol) solid var(--ink);padding:calc(var(--u)*.4) calc(var(--u)*2.5);font-size:calc(var(--u)*4)}
.mr-photo .mr-line{position:absolute;left:0;top:0;height:calc(var(--u)*.35);background:rgba(255,40,80,.9);transform-origin:0 50%;box-shadow:0 0 6px rgba(255,40,80,.8)}
.mr-results{position:absolute;right:calc(var(--u)*3);top:50%;transform:translate(120%,-50%);transition:transform var(--slow) var(--ease);width:calc(var(--u)*30)}
.mr-results.on{transform:translate(0,-50%)}
.mr-results .mr-rh{font-size:calc(var(--u)*3);margin-bottom:calc(var(--u)*.8);padding:calc(var(--u)*.3) calc(var(--u)*1.5);display:inline-block}
.mr-results .mr-rr{display:flex;align-items:center;gap:calc(var(--u)*.8);margin:calc(var(--u)*.5) 0;font-size:calc(var(--u)*1.8);background:rgba(20,24,60,.88);border:calc(var(--u)*.25) solid var(--ink);border-radius:calc(var(--u)*.6);padding:calc(var(--u)*.3) calc(var(--u)*1);transform:skewX(var(--sk))}
.mr-results .mr-rr>*{transform:skewX(var(--usk))}
.mr-results .mr-rr .mr-num{font-size:calc(var(--u)*2.6);width:calc(var(--u)*4.2)}
.mr-results .mr-rr .mr-t{margin-left:auto;font-family:var(--body);font-weight:900}
.mr-dim .mr-tower,.mr-dim .mr-top,.mr-dim .mr-map,.mr-dimtop .mr-tower,.mr-dimtop .mr-top{opacity:0}
.mr-tower,.mr-top,.mr-map{transition:opacity var(--slow) var(--ease)}

.mr-replay{position:absolute;right:calc(var(--u)*2.2);top:calc(var(--u)*1.8);display:flex;align-items:center;gap:calc(var(--u)*.6);padding:calc(var(--u)*.35) calc(var(--u)*1.2);background:var(--tomato);border:var(--ol) solid var(--ink);border-radius:calc(var(--u)*.9);box-shadow:var(--drop);transform:skewX(var(--sk)) translateX(140%);font-size:calc(var(--u)*2);transition:transform var(--slow) var(--ease)}
.mr-replay>*{transform:skewX(var(--usk))}
.mr-replay i{width:calc(var(--u)*.9);height:calc(var(--u)*.9);border-radius:50%;background:#fff}
.mr-hud.mr-inreplay .mr-replay{transform:skewX(var(--sk)) translateX(0)}
.mr-hud.mr-inreplay .mr-map,.mr-hud.mr-inreplay .mr-tags{opacity:0}
.mr-replayframe{position:absolute;inset:0;border:calc(var(--u)*.5) solid rgba(255,77,90,.0);transition:border-color var(--slow) var(--ease);pointer-events:none}
.mr-hud.mr-inreplay .mr-replayframe{border-color:rgba(255,77,90,.55)}
.mr-wipe{position:absolute;top:-10%;bottom:-10%;left:-60%;width:45%;background:linear-gradient(90deg,var(--blue),var(--blue2));border-left:var(--ol) solid var(--ink);border-right:var(--ol) solid var(--ink);transform:skewX(var(--sk)) translateX(0);opacity:0}
.mr-wipe.go{animation:mrwipe var(--slow) var(--ease)}
@keyframes mrwipe{0%{opacity:1;transform:skewX(var(--sk)) translateX(0)}100%{opacity:1;transform:skewX(var(--sk)) translateX(420%)}}

.mr-close{position:absolute;right:calc(var(--u)*2.2);top:calc(var(--u)*1.8);display:flex;align-items:center;gap:calc(var(--u)*.6);padding:calc(var(--u)*.35) calc(var(--u)*1.1) calc(var(--u)*.35) calc(var(--u)*.5);background:rgba(20,24,60,.85);border-radius:calc(var(--u)*.9);transform:skewX(var(--sk));font-family:var(--body);font-weight:800;font-size:calc(var(--u)*1.25);opacity:0;transition:opacity var(--slow) var(--ease),top var(--slow) var(--ease),background var(--fast) var(--ease);white-space:nowrap}
.mr-close>*{transform:skewX(var(--usk))}
.mr-close.on{opacity:1}
.mr-hud:not(.mr-nomap) .mr-close{top:calc(var(--u)*16.2)}
.mr-close .mr-cc{width:calc(var(--u)*.7);align-self:stretch;border-radius:calc(var(--u)*.3)}
.mr-close b{font-family:var(--font-display,"Lilita One",sans-serif);font-weight:400;color:var(--yellow)}
.mr-close.hot{background:rgba(255,77,90,.92)}
.mr-close.hot b{color:#fff}
`,Gu=n=>`${n}<sup>${["th","st","nd","rd"][n%100>10&&n%100<14||n%10>3?0:n%10]}</sup>`,dx=n=>`${n}${["th","st","nd","rd"][n%100>10&&n%100<14||n%10>3?0:n%10]}`,px=n=>{n=Math.max(0,n);let t=Math.floor(n/60),e=Math.floor(n%60);return`${t}:${String(e).padStart(2,"0")}`},oo=n=>String(n??"").replace(/[&<>"]/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[t]),mx=n=>{let t=parseInt(n.slice(1),16);return(t>>16&255)*.299+(t>>8&255)*.587+(t&255)*.114>165?"#1a1420":"#ffffff"};function $u(n,{runners:t,backedBy:e={},course:i,park:s,C:r}){if(!document.getElementById("mr-hud-css")){let tt=document.createElement("style");tt.id="mr-hud-css",tt.textContent=ux,document.head.appendChild(tt)}let o=document.createElement("div");o.className="mr-hud mr-dim",o.innerHTML=`
    <div class="mr-top"><div class="mr-pill"><i class="mr-dot"></i><span>LAP <b data-k="lap">1</b>/2</span><span class="mr-sep"></span><span data-k="dist">0.0 KM</span><span class="mr-clk" data-k="clock">0:00</span></div></div>
    <div class="mr-tower"></div>
    <div class="mr-map"><div class="mr-mapwrap"></div><canvas></canvas></div>
    <div class="mr-tags"></div>
    <div class="mr-banner"><div class="mr-b1"><span></span></div><span class="mr-b2"></span></div>
    <div class="mr-card3"><div class="mr-lane mr-num"><span></span></div><div class="mr-panel mr-info"><div class="mr-unskew"><div class="mr-nick"></div><div class="mr-tagl"></div></div></div></div>
    <div class="mr-count mr-num"></div>
    <div class="mr-photo"><div class="mr-flash"></div><div class="mr-line"></div><div class="mr-pf">PHOTO FINISH!</div><div class="mr-pcap"></div></div>
    <div class="mr-market"><div class="mr-m1">MARKET OPEN</div><div class="mr-m2"></div></div>
    <div class="mr-title"><div class="mr-t0"></div><span class="mr-t1"></span><div class="mr-t2"></div></div>
    <div class="mr-results"></div>
    <div class="mr-close"><i class="mr-cc"></i><span><b class="mr-cn"></b> <span class="mr-ct"></span></span></div><div class="mr-replayframe"></div><div class="mr-replay"><i></i><span>REPLAY</span></div><div class="mr-wipe"></div>`,n.appendChild(o);let a=tt=>o.querySelector(tt),l={};o.querySelectorAll("[data-k]").forEach(tt=>l[tt.dataset.k]=tt);let c=a(".mr-tower"),h={},m={};for(let tt of t){let K=document.createElement("div");K.className="mr-row",K.innerHTML=`<div class="mr-pos mr-num">1</div><div class="mr-card"><div class="mr-chip" style="background:${tt.colour.primary};border-right:4px solid ${tt.colour.secondary}"></div><div class="mr-name">${oo(Ss(tt))}</div><span class="mr-inis"></span><div class="mr-gap"></div></div>`,c.appendChild(K),h[tt.id]={el:K,pos:K.querySelector(".mr-pos"),gap:K.querySelector(".mr-gap"),last:""};let Et=document.createElement("div");Et.className="mr-tag",Et.innerHTML=`<span class="mr-tp mr-num"></span><span class="mr-tb"></span><span class="mr-tn" style="background:${tt.colour.primary};color:#fff">${oo(Ss(tt))}</span>`,Et.style.opacity="0",a(".mr-tags").appendChild(Et),m[tt.id]={el:Et,pos:Et.querySelector(".mr-tp"),x:0,y:0,vis:!1}}function g(tt={}){for(let K of t){let Et=(tt[K.id]||[]).filter(B=>B!=null&&B!==""),X=Et.map(B=>`<span class="mr-ini" style="--bc:${Eh(B)}">${oo(yx(B))}</span>`).join(""),Tt=h[K.id].el;Tt.classList.toggle("backed",Et.length>0),Tt.querySelector(".mr-inis").innerHTML=X,m[K.id].el.querySelector(".mr-tb").innerHTML=X}}g(e);let d=a(".mr-map canvas"),p=d.getContext("2d"),v=null,u=340,f=420;d.width=u,d.height=f;let S=i.points,y=1e9,x=1e9,L=-1e9,b=-1e9;for(let tt of S)y=Math.min(y,tt[0]),L=Math.max(L,tt[0]),x=Math.min(x,tt[2]),b=Math.max(b,tt[2]);if(i.funfair){let[tt,K]=i.funfair.center,Et=i.funfair.radius*.6;y=Math.min(y,tt-Et),L=Math.max(L,tt+Et),x=Math.min(x,K-Et),b=Math.max(b,K+Et)}for(let tt in r.diversions)for(let K of r.diversions[tt])for(let Et of K.path)y=Math.min(y,Et[0]),L=Math.max(L,Et[0]),x=Math.min(x,Et[1]),b=Math.max(b,Et[1]);let T=26,A=Math.min((u-T*2)/(L-y),(f-T*2)/(b-x)),M=(u-(L-y)*A)/2,_=(f-(b-x)*A)/2,w=tt=>M+(tt-y)*A,P=tt=>_+(tt-x)*A;function E(){let tt=document.createElement("canvas");tt.width=u,tt.height=f;let K=tt.getContext("2d"),Et=(xt,Pt,At,jt)=>{K.beginPath(),xt.forEach((dt,ot)=>ot?K.lineTo(w(dt[0]),P(dt[1])):K.moveTo(w(dt[0]),P(dt[1]))),K.strokeStyle=Pt,K.lineWidth=At,K.lineJoin=K.lineCap="round",K.setLineDash(jt||[]),K.stroke(),K.setLineDash([])},X=(xt,Pt)=>{for(let At of s.features)At.kind===xt&&At.closed&&(K.beginPath(),At.pts.forEach((jt,dt)=>dt?K.lineTo(w(jt[0]),P(jt[1])):K.moveTo(w(jt[0]),P(jt[1]))),K.fillStyle=Pt,K.fill())},Tt=s.features.filter(xt=>xt.kind==="park").sort((xt,Pt)=>Pt.pts.length-xt.pts.length)[0];K.save(),K.beginPath(),Tt.pts.forEach((xt,Pt)=>Pt?K.lineTo(w(xt[0]),P(xt[1])):K.moveTo(w(xt[0]),P(xt[1]))),K.fillStyle="#9be27a",K.fill(),K.restore(),X("water","#49a6ff"),X("track","#ff7a5c");for(let xt in r.diversions)for(let Pt of r.diversions[xt])Et(Pt.path,"#c79a5a",4,[6,6]);let B=[];for(let xt=0;xt<=r.LAP1_END_DRAW;xt+=10)B.push(r.baseXZ(xt));Et(B,"#1a1420",11),Et(B,"#8fa0c4",6);let I=[];for(let xt=r.MAP_TO-80;xt<=r.finishM;xt+=10)I.push(r.baseXZ(xt));Et(I,"#1a1420",11),Et(I,"#8fa0c4",6);let ut=r.rawExt(r.finishM);return K.fillStyle="#fff",K.strokeStyle="#1a1420",K.lineWidth=3,K.fillRect(w(ut[0])-7,P(ut[1])-7,14,14),K.strokeRect(w(ut[0])-7,P(ut[1])-7,14,14),K.fillStyle="#1a1420",K.fillRect(w(ut[0])-7,P(ut[1])-7,7,7),K.fillRect(w(ut[0]),P(ut[1]),7,7),tt}v=E();function F(){v=E()}let R=0,N=0,U=[],z=a(".mr-banner");function Z(){for(;U.length&&N-U[0].at>2;)U.shift();let tt=U.shift();tt&&(z.querySelector(".mr-b1 span").textContent=tt.text,z.querySelector(".mr-b1").style.background=tt.colour,z.querySelector(".mr-b2").textContent="",z.classList.remove("on"),z.offsetWidth,z.classList.add("on"),R=Math.min(1.5,tt.secs))}function Y(tt,K="",Et="#ff3d8b",X=1.4){U.length>=3&&U.shift(),U.push({text:tt,colour:Et,secs:X,at:N}),R<=0&&Z()}let k="";function mt(tt,K){var Et;if(N+=tt,R>0?(R-=tt,R<=0&&(z.classList.remove("on"),R=-.25)):R<0&&(R=Math.min(0,R+tt),R===0&&Z()),!!K){if(K.map!=null&&o.classList.toggle("mr-nomap",!K.map),"closing"in K){let X=K.closing,Tt=a(".mr-close");Tt.classList.toggle("on",!!X),X&&(Tt.classList.toggle("hot",!!X.hot),Tt.querySelector(".mr-cc").style.background=X.colour,Tt.querySelector(".mr-cn").textContent=X.name,Tt.querySelector(".mr-ct").textContent=X.text==="ALONGSIDE!"?"ALONGSIDE!":X.text)}if(K.raceS!=null&&(l.clock.textContent=px(K.raceS)),K.leaderM!=null&&(l.lap.textContent=K.leaderM>=2500?"2":"1",l.dist.textContent=`${(Math.min(5e3,K.leaderM)/1e3).toFixed(1)} KM`),K.order){let X=c.clientHeight||0,Tt=(((Et=c.querySelector(".mr-row"))==null?void 0:Et.offsetHeight)||40)+6,B=0;K.order.forEach((I,ut)=>{let xt=h[I.id];if(!xt||(xt.el.classList.toggle("off",!!I.hidden),I.hidden))return;B===3&&(B+=.35),xt.el.style.transform=`translateY(${B*Tt}px)`,B++;let At=`${ut}|${I.gapText}|${I.finished}`+(I.posHtml||"");At!==xt.last&&(xt.last=At,xt.pos.innerHTML=I.posHtml??Gu(ut+1),xt.gap.textContent=I.gapText,xt.el.classList.toggle("lead",ut===0&&!I.posHtml),xt.el.classList.toggle("fin",!!I.finished))})}if(K.tags)for(let X of K.tags){let Tt=m[X.id];Tt&&(X.visible!==Tt.vis&&(Tt.vis=X.visible,Tt.el.style.opacity=X.visible?"1":"0"),X.visible&&(Tt.el.style.transform=`translate(${X.x}px, ${X.y}px) translate(-50%,-100%) scale(${X.scale??1})`,Tt.p!==X.pos&&(Tt.p=X.pos,Tt.pos.textContent=X.pos?dx(X.pos):"",Tt.pos.style.display=X.pos?"":"none")))}if(K.dots){p.clearRect(0,0,u,f),p.drawImage(v,0,0);for(let X of[...K.dots].reverse())p.beginPath(),p.arc(w(X.x),P(X.z),X.lead?11:9,0,7),p.fillStyle=X.colour,p.fill(),p.lineWidth=3.5,p.strokeStyle="#1a1420",p.stroke(),X.focus&&(p.beginPath(),p.arc(w(X.x),P(X.z),15,0,7),p.strokeStyle="#fff",p.lineWidth=3,p.stroke());K.camDot&&(p.save(),p.translate(w(K.camDot.x),P(K.camDot.z)),p.rotate(K.camDot.a),p.fillStyle="rgba(26,20,32,.6)",p.beginPath(),p.moveTo(0,0),p.lineTo(-10,-22),p.lineTo(10,-22),p.fill(),p.restore())}}}function bt(tt){o.classList.toggle("mr-dim",!!tt)}function D(tt){o.classList.toggle("mr-dimtop",!!tt)}function G(){R=0,U.length=0,z.classList.remove("on")}function q(tt){let K=a(".mr-card3");if(!tt){K.classList.remove("on");return}K.querySelector(".mr-lane span").textContent=tt.lane??"",K.querySelector(".mr-lane").style.background=tt.colour.primary,K.querySelector(".mr-info").style.background=`linear-gradient(180deg, ${tt.colour.primary}, ${vx(tt.colour.primary,-.25)})`,K.querySelector(".mr-nick").textContent=tt.nickname,K.querySelector(".mr-nick").style.color="#fff",K.querySelector(".mr-tagl").textContent=tt.tagline||"",K.querySelector(".mr-tagl").style.color=mx(tt.colour.primary)==="#ffffff"?"#fff":"#1a1420",K.classList.remove("on"),K.offsetWidth,K.classList.add("on")}function W(tt){let K=a(".mr-count");K.textContent=tt,K.classList.remove("pop"),K.offsetWidth,K.classList.add("pop")}function J(){let tt=a(".mr-wipe");tt.classList.remove("go"),tt.offsetWidth,tt.classList.add("go")}function it(tt){let K=o.classList.contains("mr-inreplay");o.classList.toggle("mr-inreplay",!!tt),!!tt!==K&&J()}function Mt(tt,K=""){a(".mr-photo").classList.toggle("on",!!tt),a(".mr-pcap").textContent=K,a(".mr-pcap").style.display=K?"":"none"}function Ct(tt,K="Place your halfway bets!"){a(".mr-market").classList.toggle("on",!!tt),a(".mr-market .mr-m2").textContent=K}function nt(tt,{title:K="",kicker:Et="",theme:X=""}={}){let Tt=a(".mr-title");if(tt){Tt.querySelector(".mr-t0").textContent=Et,Tt.querySelector(".mr-t1").textContent=K;let B=Tt.querySelector(".mr-t2");B.textContent=X,B.style.display=X?"":"none",Tt.querySelector(".mr-t0").style.display=Et?"":"none"}Tt.classList.toggle("on",!!tt)}function pt(tt,K){let Et=K[0]-tt[0],X=K[1]-tt[1],Tt=Math.hypot(Et,X)||1,B=Et/Tt,I=X/Tt,ut=tt[0]-B*Tt*.6,xt=tt[1]-I*Tt*.6,Pt=a(".mr-photo .mr-line");Pt.style.width=`${Tt*2.2}px`,Pt.style.transform=`translate(${ut}px, ${xt}px) rotate(${Math.atan2(I,B)}rad)`}function H(tt){let K=a(".mr-results");if(!tt){K.classList.remove("on");return}K.innerHTML='<div class="mr-panel mr-rh"><div class="mr-unskew">RESULTS</div></div>'+tt.map(Et=>`<div class="mr-rr"><span class="mr-num">${Gu(Et.place)}</span><span style="width:calc(var(--u)*1.2);height:calc(var(--u)*2.2);background:${Et.colour};border:2px solid #1a1420;border-radius:4px"></span><span>${oo(Et.nickname)}</span><span class="mr-t">${oo(Et.timeText||"")}</span></div>`).join(""),requestAnimationFrame(()=>K.classList.add("on"))}function qt(){o.remove()}return{root:o,update:mt,setBackedBy:g,replay:it,wipe:J,redrawMap:F,showBanner:Y,clearBanner:G,setDim:bt,setDimTop:D,introCard:q,countdown:W,photo:Mt,photoLine:pt,results:H,market:Ct,titleCard:nt,dispose:qt}}function Ss(n){if(n.shortName)return n.shortName;let t=String(n.nickname||n.id).replace(/^the\s+/i,"");if(t.length<=14)return t;let e=t.split(/\s+/),i=e.slice(-2).join(" ");return i.length<=14?i:e.at(-1).slice(0,14)}var Wu=["#ffd23f","#ff8fc8","#7fe0ff","#9dff8a","#ffb067","#c7a6ff"],Va=new Map;function Eh(n){return Va.has(n)||Va.set(n,Va.size),Wu[Va.get(n)%Wu.length]}var gx=n=>new RegExp("\\p{Extended_Pictographic}","u").test(String(n));function yx(n){let t=String(n).trim();if(gx(t))return[...t][0];let e=t.split(/\s+/).filter(Boolean);return(e.length>1&&e[0].length<=3?e[0][0]+e[1][0]:t[0]||"?").toUpperCase()}function vx(n,t){let e=parseInt(n.slice(1),16),i=e>>16&255,s=e>>8&255,r=e&255,o=a=>Math.max(0,Math.min(255,Math.round(t<0?a*(1+t):a+(255-a)*t)));return`rgb(${o(i)},${o(s)},${o(r)})`}var Ga=(n,t,e=12,i=!0)=>yn(256,256,(s,r,o)=>{for(let a=0;a<e;a++)s.fillStyle=a%2?n:t,i?s.fillRect(a*r/e,0,r/e+1,o):s.fillRect(0,a*o/e,r,o/e+1)});function Xu(n,t,e,i){let s=zn(42),r=new _e;n.add(r);let o=[],a=[],l=(P,E=3)=>(oi(P,E,void 0,30),P),c=(P,E,F=3)=>Le(P,E,{ol:F,olRef:30}),h=[];for(let P=0;P<i.path.length;P++){let E=i.path[P],F=e.anchors.nearestOnRibbon(E[0],E[1]),R=Math.hypot(E[0]-F[0],E[1]-F[1]);h.push({x:(E[0]+F[0])/2,z:(E[1]+F[1])/2,gap:R})}let m=0;h.forEach((P,E)=>{E&&(m+=Math.hypot(P.x-h[E-1].x,P.z-h[E-1].z)),P.s=m});let g=m,d=P=>{let E=0;for(;E<h.length-2&&h[E+1].s<P;)E++;let F=h[E],R=h[E+1],N=Math.max(0,Math.min(1,(P-F.s)/Math.max(1e-6,R.s-F.s))),U=F.x+(R.x-F.x)*N,z=F.z+(R.z-F.z)*N,Z=Math.hypot(R.x-F.x,R.z-F.z)||1;return{x:U,z,gap:F.gap+(R.gap-F.gap)*N,tx:(R.x-F.x)/Z,tz:(R.z-F.z)/Z,y:t.heightAt(U,z)}},p=h.filter(P=>P.gap>26),v=p.length?p[0].s:g*.25,u=p.length?p.at(-1).s:g*.75,f=P=>Array.from({length:P},(E,F)=>d(v+(F+.5)/P*(u-v))),S=(P,E,F=0)=>(P.position.set(E.x,E.y-.1,E.z),P.rotation.y=Math.atan2(E.tx,E.tz)+F,r.add(P),P),y={center:d((v+u)/2),rides:[]},x=f(7);{let P=x.slice(1,6).sort((W,J)=>J.gap-W.gap)[0],E=new _e,F=17,R=F+2.6,N=new pe(.35,.5,R/Math.cos(.32)+1,8);for(let W of[-1,1])for(let J of[-1,1]){let it=c(N,gt("#ffffff"));it.position.set(W*1.8,R/2,J*Math.tan(.32)*R/2),it.rotation.x=-J*.32,E.add(it)}let U=c(new Ue(6,1,8,2,.3),gt("#2e9bff"));U.position.y=.5,E.add(U);let z=new _e;z.position.y=R,E.add(z);let Z=c(new ln(F,.45,8,64),gt("#ff3d8b"));Z.rotation.y=Math.PI/2,Z.position.x=1.2,z.add(Z);let Y=c(new ln(F,.45,8,64),gt("#ff3d8b"));Y.rotation.y=Math.PI/2,Y.position.x=-1.2,z.add(Y);let k=c(new pe(1.3,1.3,3.2,16).rotateZ(Math.PI/2),gt("#ffd23f"));z.add(k);let mt=16,bt=[],D=[];for(let W=0;W<mt;W++){let J=W/mt*Math.PI*2,it=c(new ze(.18,F,.18).translate(0,F/2,0),gt("#ffffff"),2);it.rotation.x=J,it.position.x=1.2,z.add(it);let Mt=it.clone();Mt.position.x=-1.2,z.add(Mt);let Ct=new _e;Ct.position.set(0,Math.cos(J)*F,Math.sin(J)*F),z.add(Ct);let nt=new _e;Ct.add(nt);let pt=["#ffd23f","#3ddc84","#2e9bff","#ff8a3d","#b07bff"][W%5],H=c(new Ue(1.7,1.3,1.5,2,.35),gt(pt));H.position.y=-1.3,nt.add(H);let qt=c(new rn(1.2,.7,4).rotateY(Math.PI/4),gt("#ffffff"),2);qt.position.y=-.1,nt.add(qt),bt.push(Ct);for(let tt=0;tt<3;tt++){let K=J+tt/3*(Math.PI*2/mt);D.push([1.2,Math.cos(K)*F,Math.sin(K)*F],[-1.2,Math.cos(K)*F,Math.sin(K)*F])}}let G=new dn(new Pe(.32,8,6),new On({color:16777215}),D.length),q=new qe;D.forEach((W,J)=>{q.position.set(...W),q.updateMatrix(),G.setMatrixAt(J,q.matrix),G.setColorAt(J,new fe(["#fff27a","#ff7ac8","#7affff"][J%3]))}),z.add(G),S(E,P,0),a.push(W=>{z.rotation.x=W*.18;for(let J of bt)J.rotation.x=-W*.18}),y.rides.push({kind:"wheel",obj:E,pos:new V(P.x,P.y+R,P.z),r:F}),P.used=!0}{let P=x.filter(D=>!D.used).sort((D,G)=>G.gap-D.gap)[0];P.used=!0;let E=new _e,F=Math.min(6.5,P.gap*.28);E.scale.setScalar(1.45);let R=Ga("#ffffff","#ff4f6d",16);o.push(R);let N=c(new pe(F,F+.3,.9,32),gt("#ffffff",{map:R}));N.position.y=.45,E.add(N);let U=new _e;E.add(U);let z=c(new pe(.7,.7,5,16),gt("#ffd23f"));z.position.y=3,U.add(z);let Z=Ga("#ffd23f","#ff3d8b",16);o.push(Z);let Y=c(new rn(F+.8,2.8,16),gt("#ffffff",{map:Z}));Y.position.y=6.6,U.add(Y);let k=c(new pe(F+.8,F+.8,.7,16,1,!0),gt("#2e9bff",{side:hn}));k.position.y=4.9,U.add(k);let mt=c(new Pe(.5,12,8),gt("#ff3d8b"));mt.position.y=8.2,U.add(mt);let bt=[];for(let D=0;D<8;D++){let G=D/8*Math.PI*2,q=F*.72,W=new _e;W.position.set(Math.cos(G)*q,0,Math.sin(G)*q),W.rotation.y=-G,U.add(W);let J=c(new pe(.06,.06,4.2,6),gt("#ffd23f"),1.5);J.position.y=2.9,W.add(J);let it=new _e;W.add(it);let Mt=["#ffffff","#ffd6f0","#d6f0ff","#fff2b0"][D%4],Ct=c(new Ue(.7,.7,1.6,2,.3),gt(Mt));it.add(Ct);let nt=c(new Ue(.45,.9,.5,2,.2),gt(Mt));nt.position.set(0,.55,.7),nt.rotation.x=.4,it.add(nt);let pt=c(new Ue(.45,.45,.8,2,.2),gt(Mt));pt.position.set(0,.95,1.05),it.add(pt);let H=c(new Ue(.15,.8,.3,1,.06),gt(["#ff3d8b","#2e9bff","#3ddc84","#ff8a3d"][D%4]),2);H.position.set(0,.75,.55),H.rotation.x=.4,it.add(H);let qt=c(new Ue(.75,.2,.6,1,.08),gt("#ff3d8b"),2);qt.position.y=.4,it.add(qt);for(let[tt,K]of[[-.22,.55],[.22,.55],[-.22,-.55],[.22,-.55]]){let Et=c(new ze(.16,.7,.16),gt(Mt),1.5);Et.position.set(tt,-.55,K),Et.rotation.x=K>0?-.5:.5,it.add(Et)}it.rotation.y=Math.PI/2,bt.push({horse:it,ph:D*.8})}S(E,P),a.push(D=>{U.rotation.y=D*.6;for(let G of bt)G.horse.position.y=2+Math.sin(D*2.2+G.ph)*.35}),y.rides.push({kind:"carousel",obj:E,pos:new V(P.x,P.y+6,P.z),r:F*1.45})}{let P=x.filter(D=>!D.used).sort((D,G)=>G.gap-D.gap)[0];P.used=!0;let E=new _e,F=15;E.scale.setScalar(1.5);let R=Ga("#ff3d3d","#ffffff",10,!1);o.push(R);let N=c(new pe(1.6,2.6,F,16),gt("#ffffff",{map:R}));N.position.y=F/2,E.add(N);let U=c(new rn(2.6,3.4,16),gt("#2e9bff"));U.position.y=F+1.7,E.add(U);let z=c(new pe(.06,.06,2,6),gt("#ffffff"),1.5);z.position.y=F+4.2,E.add(z);let Z=c(new Tn(1.2,.7).translate(.6,0,0),gt("#ffd23f",{side:hn}),1.5);Z.position.y=F+4.8,E.add(Z);let Y=[],k=3.2;for(let D=0;D<=160;D++){let G=D/160,q=G*k*Math.PI*2,W=2.6+(1-G)*-.8+1.6;Y.push(new V(Math.cos(q)*W,F-1-G*(F-2),Math.sin(q)*W))}let mt=c(new Ca(new qr(Y),220,.55,8,!1),gt("#ffd23f"));mt.scale.y=1,E.add(mt);let bt=c(new Ue(3,.3,2,2,.1),gt("#3ddc84"),2);bt.position.set(Y.at(-1).x+1,.15,Y.at(-1).z),E.add(bt),S(E,P),a.push(D=>{Z.rotation.y=Math.sin(D*3)*.4}),y.rides.push({kind:"helter",obj:E,pos:new V(P.x,P.y+12,P.z),r:6})}let L=[["CANDYFLOSS","#ff9bd2"],["HOOK-A-DUCK","#57c7ff"],["DOUGHNUTS","#ffb347"],["COCONUT SHY","#8ee86b"],["TOFFEE APPLES","#ff5d5d"],["HOOK-A-DUCK","#57c7ff"]],b=[];[...x.filter(P=>!P.used),...f(13).filter((P,E)=>E%2===1)].slice(0,7).forEach((P,E)=>{let[F,R]=L[E%L.length],N=new _e,U=E%2?1:-1,z=c(new Ue(4.2,2.4,3,2,.2),gt("#fff6e0"));z.position.y=1.2,N.add(z);let Z=c(new Ue(4.4,1.1,.8,2,.15),gt(R));Z.position.set(0,.55,1.7),N.add(Z);let Y=Ga("#ffffff",R,10);o.push(Y);let k=c(new ze(4.8,.18,2.4),gt("#ffffff",{map:Y}));k.position.set(0,2.9,1.4),k.rotation.x=.32,N.add(k);for(let J of[-1,1]){let it=c(new pe(.09,.09,2.6,6),gt("#ffffff"),1.5);it.position.set(J*2.2,1.6,2.4),N.add(it)}let mt=ai(512,128,(J,it,Mt)=>{J.fillStyle="#1a1420",on(J,0,0,it,Mt,30),J.fill(),J.fillStyle=R,on(J,8,8,it-16,Mt-16,24),J.fill(),vn(J,F,it/2,Mt/2+4,F.length>11?52:64,"#ffffff","#1a1420",.2)},o),bt=Le(new Ue(4.2,1.05,.3,2,.1),[gt(R),gt(R),gt(R),gt(R),gt("#ffffff",{map:mt}),gt("#ffffff",{map:mt})],{ol:2.5,olRef:30});if(bt.position.set(0,3.7,.4),N.add(bt),F==="CANDYFLOSS")for(let J=0;J<4;J++){let it=c(new pn(.32,1),gt("#ff9bd2"),1.5);it.position.set(-1.4+J*.9,1.45,1.75),N.add(it)}if(F==="HOOK-A-DUCK"){let J=c(new pe(1.6,1.6,.6,20),gt("#57c7ff"),2);J.position.set(0,.3,3.6),N.add(J);let it=new _e;it.position.set(0,.7,3.6),N.add(it);for(let Mt=0;Mt<6;Mt++){let Ct=Mt/6*Math.PI*2,nt=c(new Pe(.22,10,8),gt("#ffd23f"),1.5);nt.position.set(Math.cos(Ct)*1.1,0,Math.sin(Ct)*1.1);let pt=c(new Pe(.14,8,6),gt("#ffd23f"),1.2);pt.position.set(0,.22,.12),nt.add(pt),it.add(nt)}b.push(it)}let D=e.anchors.nearestOnRibbon(P.x,P.z),G=Math.atan2(D[0]-P.x,D[1]-P.z),q=Math.min(P.gap*.3,7)*U,W=S(N,{...P,x:P.x+P.tz*q,z:P.z-P.tx*q,y:t.heightAt(P.x+P.tz*q,P.z-P.tx*q)});W.rotation.y=G+(U>0?0:Math.PI)*0}),a.push(P=>{for(let E of b)E.rotation.y=P*.8});{let P=[],E=[],F=[],R=[],N=[];for(let mt of[-1,1]){let bt=null;for(let D=v-10;D<=u+10;D+=9){let G=d(D),q=(G.gap/2-6)*mt,W=G.x+G.tz*q,J=G.z-G.tx*q,it=t.heightAt(W,J),Mt=new V(W,it+4.2,J),Ct=c(new pe(.08,.1,4.3,6),gt("#ffffff"),1.5);if(Ct.position.set(W,it+2.1,J),r.add(Ct),bt)for(let nt=0;nt<=10;nt++){let pt=nt/10,H=bt.clone().lerp(Mt,pt);H.y-=Math.sin(pt*Math.PI)*.7,P.push(H),nt<10&&(nt%2?(E.push(H.clone()),F.push(["#fff27a","#ff7ac8","#7affff","#9dff7a"][(nt+Math.round(D))%4])):(R.push({v:H.clone(),a:Math.atan2(-(Mt.z-bt.z),Mt.x-bt.x)}),N.push(["#ff3d8b","#ffd23f","#2e9bff","#3ddc84","#ff8a3d"][(nt+Math.round(D/9))%5])))}bt=Mt}}let U=new qe,z=new dn(new Pe(.16,8,6),new On({color:16777215}),E.length);E.forEach((mt,bt)=>{U.position.copy(mt),U.updateMatrix(),z.setMatrixAt(bt,U.matrix),z.setColorAt(bt,new fe(F[bt]))}),r.add(z);let Z=new Ye;Z.setAttribute("position",new Te([-.32,0,0,.32,0,0,0,-.65,0],3)),Z.setAttribute("normal",new Te([0,0,1,0,0,1,0,0,1],3));let Y=new dn(Z,gt("#ffffff",{side:hn}),R.length);R.forEach((mt,bt)=>{U.position.copy(mt.v),U.rotation.set(0,mt.a,0),U.updateMatrix(),Y.setMatrixAt(bt,U.matrix),Y.setColorAt(bt,new fe(N[bt]))}),r.add(Y);let k=[];for(let mt=0;mt+1<P.length;mt++)P[mt].distanceTo(P[mt+1])<3&&k.push(P[mt],P[mt+1]);r.add(new or(new Ye().setFromPoints(k),new vs({color:3355443}))),a.push(mt=>{z.material.color.setScalar(.85+.15*Math.sin(mt*6))})}{let P=d(v-4),E=ai(1024,256,(R,N,U)=>{R.fillStyle="#1a1420",on(R,0,0,N,U,60),R.fill(),R.fillStyle="#ff3d8b",on(R,10,10,N-20,U-20,52),R.fill(),vn(R,"\u2605 FUNFAIR \u2605",N/2,U/2+6,120,"#ffe14d","#1a1420",.18)},o),F=Le(new Ue(10,2.4,.4,2,.15),[gt("#ff3d8b"),gt("#ff3d8b"),gt("#ff3d8b"),gt("#ff3d8b"),gt("#ffffff",{map:E}),gt("#ffffff",{map:E})],{ol:3,olRef:30});F.position.set(P.x,P.y+7.5,P.z),F.rotation.y=Math.atan2(P.tx,P.tz)+Math.PI/2,r.add(F);for(let R of[-1,1]){let N=c(new pe(.25,.3,7.6,8),gt("#ffd23f"));N.position.set(P.x+P.tz*4.5*R,P.y+3.8,P.z-P.tx*4.5*R),r.add(N)}}let A=[];for(let P=0;P<60;P++){let E=v+s()*(u-v),F=d(E),R=(s()-.5)*(F.gap-16),N=F.x+F.tz*R,U=F.z-F.tx*R;A.push({x:N,y:t.heightAt(N,U),z:U,yaw:s()*6.28})}function M(P,E){for(let F of h){if(F.s<v-20||F.s>u+20)continue;let R=Math.max(6,F.gap/2-4);if((P-F.x)**2+(E-F.z)**2<R*R)return!0}return!1}function _(P){for(let E of a)E(P)}function w(){var P;r.traverse(E=>{E.geometry&&E.geometry.dispose()});for(let E of o)(P=E.dispose)==null||P.call(E);n.remove(r)}return{group:r,update:_,dispose:w,anchors:y,crowd:A,at:d,s0:v,s1:u,contains:M}}function qu(n,t,e,i,s,{camera:r,offsetX:o=3.2}){let a=new _e;n.add(a);let l=[],c=t.sample(t.finishM+28),h=new V(c.tx,0,c.tz),m=new V(c.rx,0,c.rz),g=new V(c.x,t.heightAt(c.x,c.z),c.z),d=Math.atan2(h.x,h.z);a.position.copy(g),a.rotation.y=d;let p=[{place:2,x:-2.3,hgt:1.3,col:"#c9d3e6"},{place:1,x:0,hgt:1.9,col:"#ffd23f"},{place:3,x:2.3,hgt:.9,col:"#e59a5c"}];for(let E of p){let F=ai(256,256,(N,U,z)=>{N.fillStyle="#2e6fe0",N.fillRect(0,0,U,z),N.fillStyle=E.col,N.fillRect(0,0,U,26),vn(N,String(E.place),U/2,z/2+14,170,E.col,"#1a1420",.16)},l),R=Le(new Ue(2.25,E.hgt,2,3,.12),[gt("#2e6fe0"),gt("#2e6fe0"),gt(E.col),gt("#2e6fe0"),gt("#ffffff",{map:F}),gt("#2e6fe0")],{ol:3.5,olRef:12});R.position.set(E.x,E.hgt/2,0),a.add(R),E.top=E.hgt}let v=ai(1024,256,(E,F,R)=>{E.fillStyle="#1a1420",on(E,0,0,F,R,50),E.fill(),E.fillStyle="#ff3d8b",on(E,10,10,F-20,R-20,42),E.fill(),vn(E,"MARKRUN CHAMPIONS",F/2,R/2+6,80,"#ffffff","#1a1420",.16)},l),u=Le(new Ue(9,2.2,.3,2,.1),[gt("#ff3d8b"),gt("#ff3d8b"),gt("#ff3d8b"),gt("#ff3d8b"),gt("#ffffff",{map:v}),gt("#ffffff",{map:v})],{ol:3,olRef:14});u.position.set(0,5.6,-2.4),a.add(u);for(let E of[-1,1]){let F=Le(new pe(.14,.16,5.6,8),gt("#ffffff"),{ol:2,olRef:14});F.position.set(E*4.3,2.8,-2.4),a.add(F)}let f=s.length,S=[];for(let E of s){let F=i[E.runnerId];if(!F)continue;let R=p.find(z=>z.place===E.place),N=R?new V(R.x,R.top,.1):null,U;if(E.place===1?U=["celebrate","jump"]:E.place===2?U=["pose","flex"]:E.place===3?U=["celebrate","fist"]:E.place===f&&f>3?U=["celebrate","collapse"]:U=["celebrate","shrug"],!N){S.push({rr:F,o:E,pose:U});continue}y(F,N,U)}S.forEach((E,F)=>{let R=F%2?1:-1,N=Math.floor(F/2),U=E.pose[1]==="collapse",z=new V(R*(U?4.6:4.2+N*1.6),0,U?1.6:.6+N*.8);y(E.rr,z,E.pose,U?-R*Math.PI/2:0)});function y(E,F,R,N=0){let U=F.clone().applyAxisAngle(new V(0,1,0),d).add(g);F.y===0&&(U.y=t.heightAt(U.x,U.z)+.05),E.root.position.copy(U),E.root.rotation.set(0,d+N,0),E.set(...R),E.setPop(null)}let x=zn(3),L=420,b=new dn(new Tn(.16,.26),new On({side:hn}),L),T=[],A=["#ff3d8b","#ffd23f","#2e9bff","#3ddc84","#ff8a3d","#ffffff","#b07bff"];for(let E=0;E<L;E++)T.push({x:(x()-.5)*14,y:x()*12,z:(x()-.5)*8,vy:1+x()*1.6,sp:x()*6,ph:x()*6.28}),b.setColorAt(E,new fe(A[E%A.length]));b.frustumCulled=!1,a.add(b);let M=new qe,_=0;function w(E,F){_+=E;for(let Z=0;Z<L;Z++){let Y=T[Z];Y.y-=Y.vy*E,Y.y<0&&(Y.y+=12),M.position.set(Y.x+Math.sin(_*1.3+Y.ph)*.5,Y.y,Y.z+Math.cos(_+Y.ph)*.4),M.rotation.set(_*Y.sp+Y.ph,_*Y.sp*.7,Y.ph),M.updateMatrix(),b.setMatrixAt(Z,M.matrix)}b.instanceMatrix.needsUpdate=!0;let R=Math.sin(_*.18)*.4,N=15-Math.min(2.5,_*.2),U=new V(Math.sin(R)*N,3+Math.sin(_*.3)*.3,Math.cos(R)*N).applyAxisAngle(new V(0,1,0),d);r.position.copy(g).add(U);let z=new V(o,2.2,0).applyAxisAngle(new V(0,1,0),d).add(g);r.lookAt(z),r.fov!==42&&(r.fov=42,r.updateProjectionMatrix())}function P(){var E;a.traverse(F=>{F.geometry&&F.geometry.dispose()}),b.material.dispose();for(let F of l)(E=F.dispose)==null||E.call(F);n.remove(a)}return{update:w,dispose:P,center:g}}var en=(n,t)=>{n=n.index?n.toNonIndexed():n;let e=new fe(t).convertSRGBToLinear(),i=n.getAttribute("position").count,s=new Float32Array(i*3);for(let r=0;r<i;r++)s[r*3]=e.r,s[r*3+1]=e.g,s[r*3+2]=e.b;return n.setAttribute("color",new Qe(s,3)),n.getAttribute("uv")&&n.deleteAttribute("uv"),n},Rn=(n,t,e,i,s=0,r=1.6)=>(n.scale(r,r,r),n.rotateY(s),n.translate(t,e,i),n);function Yu(n,t,e,i){let s=zn(777),r=new _e;n.add(r);let o=[],a=[],l=(p,v)=>`lawn:${Math.floor(p/140)},${Math.floor(v/140)}`,c=(p,v,u,f=.8,S)=>a.push({x:p,y:t.heightAt(p,v),z:v,yaw:u,scale:f,colour:S,zone:l(p,v)}),{ribbonSamples:h}=e.anchors;function m(p,v,u){for(let f=0;f<40;f++){let S=h[Math.floor(s()*h.length)],y=s()*Math.PI*2,x=p+s()*(v-p),L=S[0]+Math.cos(y)*x,b=S[1]+Math.sin(y)*x;if(!(!e.inPark(L,b)||e.blocked(L,b,u+1)||!e.clearOf(L,b,u)||e.onPath(L,b,u+2)))return e.reserve(L,b,u),{x:L,z:b,y:t.heightAt(L,b),toPath:Math.atan2(S[0]-L,S[1]-b)}}return null}{let p=[],v=["#ff5d8f","#ffd23f","#2e9bff","#3ddc84","#ff8a3d","#b07bff"],u=(b,T,A,M,_,w)=>{p.push(Rn(en(new ze(1.6,.2,1.6).translate(0,2,0),_),b,T,A,M));for(let[F,R]of[[-.7,-.7],[.7,-.7],[-.7,.7],[.7,.7]])p.push(Rn(en(new pe(.08,.08,2,6).translate(F,1,R),"#ffffff"),b,T,A,M));p.push(Rn(en(new rn(1.25,1,4).rotateY(Math.PI/4).translate(0,2.6,0),w),b,T,A,M));let P=new ze(.9,.12,3.3);P.rotateX(-.62),P.translate(0,1.05,2.1),p.push(Rn(en(P,w),b,T,A,M));let E=new ze(.8,.08,2.4);E.rotateX(1),E.translate(0,1,-1.3),p.push(Rn(en(E,"#ffffff"),b,T,A,M))},f=(b,T,A,M,_)=>{for(let w of[-1.8,1.8])for(let P of[-.6,.6]){let E=new pe(.08,.08,2.8,6);E.rotateX(P>0?.22:-.22),E.translate(w,1.35,P*.5),p.push(Rn(en(E,_),b,T,A,M))}p.push(Rn(en(new pe(.1,.1,3.8,8).rotateZ(Math.PI/2).translate(0,2.7,0),_),b,T,A,M));for(let w of[-.8,.8]){p.push(Rn(en(new ze(.6,.08,.35).translate(w,.75,0),"#22202c"),b,T,A,M));for(let P of[-.25,.25])p.push(Rn(en(new pe(.02,.02,1.9,4).translate(w+P,1.7,0),"#888888"),b,T,A,M))}},S=(b,T,A,M)=>{let _=new Pe(1.6,8,5,0,Math.PI*2,0,Math.PI/2);p.push(Rn(en(_,M),b,T,A)),p.push(Rn(en(new pe(.4,.4,.5,8).translate(0,1.7,0),"#ffffff"),b,T,A))},y=(b,T,A,M,_)=>{p.push(Rn(en(new pe(1.5,1.5,.25,16).translate(0,.35,0),M),b,T,A)),p.push(Rn(en(new pe(.1,.1,1,6).translate(0,.9,0),_),b,T,A)),p.push(Rn(en(new ln(.9,.06,6,16).rotateX(Math.PI/2).translate(0,1.2,0),_),b,T,A))},x=(b,T,A,M,_)=>{p.push(Rn(en(new Pe(.45,10,8).scale(1,.9,1.4).translate(0,.95,0),_),b,T,A,M)),p.push(Rn(en(new Pe(.3,8,6).translate(0,1.4,.55),_),b,T,A,M)),p.push(Rn(en(new pe(.12,.12,.6,6).translate(0,.3,0),"#888888"),b,T,A,M))},L=[u,f,S,y,x];for(let b of i.features){if(b.kind!=="playground"||!b.closed)continue;let T=Zn(b.pts),A=(T[2]-T[0])*(T[3]-T[1]),M=Math.max(1,Math.min(9,Math.round(A/380))),_=[];for(let w=0,P=0;w<M&&P<80;P++){let E=T[0]+3+s()*(T[2]-T[0]-6),F=T[1]+3+s()*(T[3]-T[1]-6);if(!ur(b.pts,E,F)||_.some(Y=>Math.hypot(Y[0]-E,Y[1]-F)<8.5))continue;_.push([E,F]),w++;let R=t.heightAt(E,F)-.05,N=s()*6.28,U=v[Math.floor(s()*v.length)],z=v[Math.floor(s()*v.length)],Z=L[(w+_.length+Math.floor(s()*5))%L.length];Z===u||Z===f||Z===x?Z(E,R,F,N,U,z):Z(E,R,F,U,z),s()<.6&&c(E+2.5,F+1.5,s()*6,.55)}}if(p.length){let b=Le(fn(p),gt("#ffffff",{vertexColors:!0}),{ol:2,olRef:30});r.add(b)}}{let p=yn(64,64,(A,M,_)=>{for(let w=0;w<6;w++)for(let P=0;P<6;P++)A.fillStyle=(w+P)%2?"#ffffff":"#c8c8c8",A.fillRect(w*M/6,P*_/6,M/6+1,_/6+1)});o.push(p);let v=new Tn(2.8,2.2);v.rotateX(-Math.PI/2);let u=[],f=[],S=[],y=["#ff4f6d","#2e9bff","#3ddc84","#ffd23f","#ff8a3d","#b07bff"];for(let A=0;A<90;A++){let M=m(12,70,3);if(!M)continue;let _=s()*6.28;u.push({x:M.x,y:M.y+.06,z:M.z,ry:_}),f.push(y[A%y.length]),S.push({x:M.x+Math.cos(_)*.7,y:M.y+.05,z:M.z-Math.sin(_)*.7,ry:_});let w=1+Math.floor(s()*3);for(let P=0;P<w;P++){let E=_+P/w*Math.PI*2+.5,F=M.x+Math.cos(E)*.9,R=M.z-Math.sin(E)*.9;c(F,R,M.toPath+(s()-.5),.62+s()*.15)}}let x=new dn(v,gt("#ffffff",{map:p,polygonOffset:!0,polygonOffsetFactor:-1}),u.length),L=new qe;u.forEach((A,M)=>{L.position.set(A.x,A.y,A.z),L.rotation.set(0,A.ry,0),L.updateMatrix(),x.setMatrixAt(M,L.matrix),x.setColorAt(M,new fe(f[M]))}),x.receiveShadow=!0,x.computeBoundingSphere(),r.add(x),e.registerInstanced(x,u);let b=fn([en(new Ue(.7,.45,.5,2,.08).translate(0,.22,0),"#c98a4a"),en(new ln(.25,.04,6,12,Math.PI).translate(0,.45,0),"#8a5a36")]),T=new dn(b,gt("#ffffff",{vertexColors:!0}),S.length);S.forEach((A,M)=>{L.position.set(A.x,A.y,A.z),L.rotation.set(0,A.ry,0),L.updateMatrix(),T.setMatrixAt(M,L.matrix)}),T.castShadow=!0,T.computeBoundingSphere(),oi(T,1.6,void 0,20),r.add(T),e.registerInstanced(T,S)}{let p=fn([new si(.22,.5,4,8).rotateX(Math.PI/2).translate(0,.45,0),new Pe(.22,10,8).translate(0,.72,.42),new Pe(.1,6,5).scale(.6,1.4,.6).translate(-.14,.86,.36),new Pe(.1,6,5).scale(.6,1.4,.6).translate(.14,.86,.36),new Pe(.09,6,5).translate(0,.66,.64),...[[-.13,.25],[.13,.25],[-.13,-.25],[.13,-.25]].map(([A,M])=>new pe(.06,.06,.32,6).translate(A,.16,M)),new pe(.04,.03,.35,5).rotateX(-.9).translate(0,.6,-.42)].map(A=>A.index?A.toNonIndexed():A).map(A=>(A.deleteAttribute("uv"),A))),v=fn([en(new Pe(.55,12,8,0,Math.PI*2,Math.PI*.45,Math.PI*.55).scale(1,.8,1.3).translate(0,.95,0),"#ffffff"),en(new Pe(.56,12,8,Math.PI,Math.PI,0,Math.PI*.5).scale(1,.9,.9).translate(0,.95,-.2),"#ffffff"),...[[-.45,.45],[.45,.45],[-.45,-.45],[.45,-.45]].map(([A,M])=>en(new ln(.2,.06,6,12).rotateY(Math.PI/2).translate(A,.22,M),"#22202c")),en(new pe(.03,.03,.9,5).rotateX(.6).translate(0,1.15,-.85),"#22202c")]),u=[],f=[],S=[],y=[],x=["#c98a4a","#3b2a20","#f2e6d0","#8a8a8a","#e0b070","#ffffff"];for(let A=0;A<64;A++){let M=m(8,60,1.6);if(!M)continue;let _=s()*6.28;c(M.x,M.z,_,.82);let w=Math.sin(_),P=Math.cos(_);A%4===3?(S.push({x:M.x+w*1.4,y:M.y,z:M.z+P*1.4,ry:_,s:1}),y.push(["#ffb3c7","#b3dcff","#c8f0b0","#fff0a0"][A%4])):(u.push({x:M.x+w*1.6+P*.8,y:M.y,z:M.z+P*1.6-w*.8,ry:_+(s()-.5)*.8,s:.8+s()*.6}),f.push(x[Math.floor(s()*x.length)]))}let L=new qe,b=(A,M,_,w)=>{let P=new dn(A,M,_.length);return _.forEach((E,F)=>{L.position.set(E.x,E.y,E.z),L.rotation.set(0,E.ry,0),L.scale.setScalar(E.s),L.updateMatrix(),P.setMatrixAt(F,L.matrix),w&&P.setColorAt(F,new fe(w[F]))}),P.castShadow=!0,P.receiveShadow=!0,P.computeBoundingSphere(),oi(P,2,void 0,18),r.add(P),e.registerInstanced(P,_),P},T=u.length?b(p,gt("#ffffff"),u,f):null;S.length&&b(v,gt("#ffffff",{vertexColors:!0}),S,y)}{let p=[],v=[],u=[],f=["#ff5d8f","#ffd23f","#ffffff","#b06bff","#ff8a3d","#ff3d3d"];for(let T=0;T<26;T++){let A=m(9,40,3.2);if(!A)continue;let M=2.2+s()*.8;p.push({x:A.x,y:A.y-.05,z:A.z,s:M});let _=[f[T%f.length],f[(T+2)%f.length]];for(let w=0;w<60;w++){let P=s()*6.28,E=Math.sqrt(s())*(M-.25);v.push({x:A.x+Math.cos(P)*E,y:A.y+.25,z:A.z+Math.sin(P)*E,s:.8+s()*.5}),u.push(_[w%2])}}let S=new qe,y=fn([en(new pe(1,1.05,.35,20).translate(0,.17,0),"#4f9e3a"),en(new ln(1.02,.08,6,24).rotateX(Math.PI/2).translate(0,.35,0),"#ffffff")]),x=new dn(y,gt("#ffffff",{vertexColors:!0}),p.length);p.forEach((T,A)=>{S.position.set(T.x,T.y,T.z),S.scale.set(T.s,1,T.s),S.updateMatrix(),x.setMatrixAt(A,S.matrix)}),x.receiveShadow=!0,x.computeBoundingSphere(),oi(x,1.6,void 0,20),r.add(x),e.registerInstanced(x,p);let L=new pn(.24,0);L.computeVertexNormals();let b=new dn(L,gt("#ffffff"),v.length);S.scale.setScalar(1),v.forEach((T,A)=>{S.position.set(T.x,T.y,T.z),S.scale.setScalar(T.s),S.updateMatrix(),b.setMatrixAt(A,S.matrix),b.setColorAt(A,new fe(u[A]))}),b.computeBoundingSphere(),r.add(b),e.registerInstanced(b,v)}{let p=t.sample(55),v=-1,u=tn/2+9,f=p.x+p.rx*u*v,S=p.z+p.rz*u*v;e.blocked(f,S,3)&&(f=p.x-p.rx*u*v,S=p.z-p.rz*u*v);let y=new _e,x=yn(128,16,(F,R,N)=>{for(let U=0;U<8;U++)F.fillStyle=U%2?"#fff":"#3a9d5d",F.fillRect(U*16,0,16,N)});o.push(x),y.add(Le(new Ue(3.2,1.6,1.8,3,.25),gt("#3a9d5d"),{ol:3,olRef:20})).position.y=1.15;let L=Le(new Ue(3.4,.15,2,2,.05),gt("#f4e3c0"),{ol:2,olRef:20});L.position.y=2,y.add(L);let b=Le(new ze(3.8,.15,2.4),gt("#ffffff",{map:x}),{ol:2.5,olRef:20});b.position.y=3.2,y.add(b);for(let F of[-1.6,1.6]){let R=Le(new pe(.06,.06,1.2,6),gt("#ffffff"),{ol:1.5});R.position.set(F,2.6,.9),y.add(R)}for(let F of[-1.1,1.1]){let R=Le(new pe(.4,.4,.2,14).rotateZ(Math.PI/2),gt("#22202c"),{ol:2});R.position.set(F,.4,.95),y.add(R);let N=R.clone();N.position.z=-.95,y.add(N)}let T=Le(new pe(.75,.55,1.3,16),gt("#ffffff"),{ol:3,olRef:20});T.position.y=4,y.add(T);let A=Le(new pe(.82,.82,.22,16),gt("#5a3a24"),{ol:2.5,olRef:20});A.position.y=4.75,y.add(A);let M=Le(new pe(.72,.62,.45,16),gt("#c98a4a"),{ol:2,olRef:20});M.position.y=3.95,y.add(M);let _=ai(512,128,(F,R,N)=>{F.fillStyle="#1a1420",on(F,0,0,R,N,28),F.fill(),F.fillStyle="#ffd23f",on(F,6,6,R-12,N-12,22),F.fill(),vn(F,"FLAT WHITES",R/2,N/2+4,62,"#ffffff","#1a1420",.2)},o),w=new We(new Tn(2.8,.7),gt("#ffffff",{map:_}));w.position.set(0,1.4,.92),y.add(w);let P=w.clone();P.rotation.y=Math.PI,P.position.z=-.92,y.add(P);let E=Math.atan2(p.x-f,p.z-S);y.position.set(f,t.heightAt(f,S),S),y.rotation.y=E,r.add(y);for(let F=0;F<5;F++){let R=f+Math.sin(E)*(2.2+F*1.1)+Math.cos(E)*(F%2?.3:-.3),N=S+Math.cos(E)*(2.2+F*1.1);c(R,N,E+Math.PI,.8)}e.anchors.coffeeCart=y}function g(){}function d(){var p;r.traverse(v=>{v.geometry&&v.geometry.dispose()});for(let v of o)(p=v.dispose)==null||p.call(v);n.remove(r)}return{group:r,crowd:a,update:g,dispose:d}}var ao=8.5;function xx(n,t={}){let{course:e,park:i,round:s}=t,r=t.plan||null,o=t.backedBy||{},a=Object.keys(o).filter($=>(o[$]||[]).length),l=[...(s==null?void 0:s.runners)||[]].sort(($,j)=>($.lane??0)-(j.lane??0)),c=!1,h=new pa({antialias:!0,powerPreference:"high-performance",preserveDrawingBuffer:!!t.preserveDrawingBuffer});h.setPixelRatio(Math.min(window.devicePixelRatio||1,t.maxPixelRatio??1.5)),h.outputColorSpace=Sn,h.toneMapping=pi,h.shadowMap.enabled=!0,h.shadowMap.type=rh;let m=h.domElement;m.style.cssText="position:absolute;inset:0;width:100%;height:100%;display:block",getComputedStyle(n).position==="static"&&(n.style.position="relative"),n.appendChild(m);let g=new ga;g.fog=new ma(13496063,700,3200);let d=new Dn(45,16/9,.3,9e3),p=new ka(14676223,9420912,1.45);g.add(p);let v=new Da(16774109,2.3),u=new V(-.45,.82,.38).normalize();v.castShadow=!0,v.shadow.mapSize.set(2048,2048),v.shadow.bias=-4e-4,v.shadow.normalBias=.03,v.shadow.radius=3,g.add(v),g.add(v.target);let f=Au(e,i,r),S=Pu(g,f,{course:e,park:i}),y=null,x=null,L=Du(f,S.anchors.crowdZones,5,S.onPath,S.blocked),b=Yu(g,f,S,i);L.push(...b.crowd);let T=new Map;for(let $ of L){let j=$.zone??"x";T.has(j)||T.set(j,[]),T.get(j).push($)}let A=[...T.values()].map($=>bh(g,$)),M={update:(...$)=>{A.forEach(j=>j.update(...$)),x==null||x.update(...$)},setMask:$=>A.forEach(j=>j.setMask($)),dispose:()=>{A.forEach($=>$.dispose()),x==null||x.dispose()}},_={};for(let $ of l){let j=Ou($);_[$.id]=j,g.add(j.root)}let w=l.map($=>$.id),P=Object.fromEntries(l.map($=>[$.id,$])),E=$u(n,{runners:l,backedBy:o,course:e,park:i,C:f}),F=null,R=null,N=[],U=null,z=[],Z=!1;function Y($){var j;if(r=$||null,f.setPlan(r),c=!!((j=r==null?void 0:r.runners)!=null&&j.some(kt=>kt.diversions&&kt.diversions.length)),y&&(y.dispose(),y=null),x&&(x.dispose(),x=null),c){let kt=r.runners.find(Lt=>{var Bt;return(Bt=Lt.diversions)==null?void 0:Bt.length}).id;y=Xu(g,f,S,f.diversions[kt][0]),S.clearArea(y.contains),A.forEach(Lt=>Lt.hideWhere(y.contains)),x=bh(g,y.crowd)}if((c||Z)&&(S.redrawGround(),E.redrawMap()),Z=c,z=[],r){R=zu(r,f,l),N=Sh({plan:r,sim:R,backedIds:a,hasDiversion:c,C:f,world:S,funfair:y}),U=Vu({camera:d,C:f,sim:R,world:S,funfair:y});for(let kt of r.events||[])z.push({at:kt.broadcastS,evt:{...kt,kind:"event"}});for(let kt of r.commentary||[])z.push({at:kt.broadcastS,evt:{...kt,kind:"commentary"}});z.sort((kt,Lt)=>kt.at-Lt.at)}else R=null,N=[],U=null}let k="idle",mt=!1,bt=!1,D=-ao,G=0,q=null,W=null,J=0,it=!1,Mt=!1,Ct=null,nt=!1,pt=1,H=0,qt=.35,tt=3.2,K=0,Et=0,X=!1,Tt=0,B=Math.max(.05,Number(t.speed)||1),I=null,ut=0,xt=new Set;function Pt(){let $=n.clientWidth||window.innerWidth,j=n.clientHeight||window.innerHeight;h.setSize($,j,!1),d.aspect=$/j,d.updateProjectionMatrix(),xh.uRes.value.set($*h.getPixelRatio(),j*h.getPixelRatio())}let At=typeof ResizeObserver<"u"?new ResizeObserver(Pt):null;At==null||At.observe(n),window.addEventListener("resize",Pt),Pt();let jt={};{let $=w.length;w.forEach((j,kt)=>{let Lt=(kt-($-1)/2)*Math.min(1.25,(tn-1.6)/Math.max(1,$-1)),Bt=f.sample(0);jt[j]={x:Bt.x+Bt.rx*Lt-Bt.tx*1.2,z:Bt.z+Bt.rz*Lt-Bt.tz*1.2,yaw:Math.atan2(Bt.tx,Bt.tz)},jt[j].y=f.heightAt(jt[j].x,jt[j].z)+.16})}function dt($="idle"){for(let j of w){let kt=jt[j],Lt=_[j];Lt.root.position.set(kt.x,kt.y,kt.z),Lt.root.rotation.set(0,kt.yaw,0),$&&Lt.set($),Lt.setPop(null)}}dt(),Y(r);let ot=($,j)=>$===1?"jump":$===2||$===3?"fist":$===j?"collapse":"kneel";function St($,j){var Bt;let kt=R.stateAt(Math.max(0,$)),Lt=w.length;for(let me of w){let Xt=kt.byId[me],Vt=_[me];if($<0)continue;Vt.root.position.set(Xt.x,Xt.y,Xt.z);let Ke=Math.atan2(Xt.tx,Xt.tz)+(Xt.finished&&Xt.post>2.4&&!(Xt.place>3&&Xt.post<4)?Math.PI*(Xt.place%2?1:-1)*.92:0),Ae=Vt.root.rotation.y,ye=Ke-Ae;for(;ye>Math.PI;)ye-=2*Math.PI;for(;ye<-Math.PI;)ye+=2*Math.PI;Vt.root.rotation.y=Ae+ye*Math.min(1,j*10);let ve={speed:Xt.vRace,rate:kt.rate*pt,slope:Xt.slope},be=(Bt=f.diversions[me])==null?void 0:Bt[0];if(be&&Vt.setProp("floss",Xt.m>be.toM-20?Math.max(.25,1-(Xt.m-be.toM)/3500):0),Xt.finished){let Qt=Xt.place;Xt.post<1.6?(Vt.set("run"),ve.speed=3,ve.rate=1.2):Qt>3&&Xt.post<4?Vt.set("trudge"):Vt.set("celebrate",ot(Qt,Lt)),Vt.setPop(null)}else if(Xt.div>.3){Vt.set("distracted");let Qt=y==null?void 0:y.anchors.rides.reduce((xe,ce)=>!xe||ce.pos.distanceToSquared(Vt.root.position)<xe.pos.distanceToSquared(Vt.root.position)?ce:xe,null);if(Qt){let ce=Math.atan2(Qt.pos.x-Xt.x,Qt.pos.z-Xt.z)-Vt.root.rotation.y;for(;ce>Math.PI;)ce-=2*Math.PI;for(;ce<-Math.PI;)ce+=2*Math.PI;ve.lookYaw=Math.max(-1.3,Math.min(1.3,ce))}Vt.setPop(["!","heart","floss"][Math.floor((Xt.m-Xt.divInfo.fromM)/120)%3])}else{Vt.set("run"),Vt.setPop(null);let Qt=f.geoOf(Xt.m);ve.effort=Xt.m>4300?.4+(Xt.m-4300)/700*.5:Qt>1700&&Qt<2060?.7:.1}Vt.update(j*pt,ve)}}let ht=new V,yt=null,Yt=-1,Gt=()=>{if(Yt!==G||!yt){let $=m.getBoundingClientRect();yt=[...E.root.querySelectorAll(".mr-tower, .mr-map, .mr-top")].filter(j=>!E.root.classList.contains("mr-dim")&&!(E.root.classList.contains("mr-dimtop")&&!j.classList.contains("mr-map"))).map(j=>{var me;let kt=j.getBoundingClientRect(),Lt=kt.right,Bt=kt.bottom;if(j.classList.contains("mr-tower")){Bt=kt.top+j.querySelectorAll(".mr-row").length*((((me=j.querySelector(".mr-row"))==null?void 0:me.offsetHeight)||40)+6);for(let Xt of j.querySelectorAll(".mr-badges")){let Vt=Xt.getBoundingClientRect();Vt.width&&(Lt=Math.max(Lt,Vt.right))}}return{left:kt.left-$.left,right:Lt-$.left,top:kt.top-$.top,bottom:Bt-$.top}}),Yt=G}return yt};function Wt($,j=!0){var ve,be,Qt,xe;d.updateMatrixWorld();let kt=m.clientWidth,Lt=m.clientHeight,Bt=[];for(let ce of w){let Re=_[ce];ht.set(Re.root.position.x,Re.root.position.y+Re.height+.55,Re.root.position.z);let Ne=ht.distanceTo(d.position);ht.project(d);let je=j&&ht.z<1&&ht.z>-1&&Math.abs(ht.x)<.95&&ht.y<.82&&ht.y>-.62&&Ne>9.5&&Ne<(ro.has((ve=U==null?void 0:U.shot)==null?void 0:ve.type)?450:150);Re.height/Math.max(.1,Ne)*(Lt/(2*Math.tan(Ki.degToRad(d.fov)/2)))>Lt*.3&&(je=!1),Bt.push({id:ce,x:(ht.x*.5+.5)*kt,y:(-ht.y*.5+.5)*Lt,visible:je,pos:$?$.order.indexOf(ce)+1:0,scale:Math.max(.7,Math.min(1.15,30/Ne)),dist:Ne})}let me=k==="race"&&ro.has((be=U==null?void 0:U.shot)==null?void 0:be.type)&&!(U!=null&&U.gliding),Xt=$?$.order:w,Vt=new Set([...Xt.slice(0,3),...a]);Bt.sort((ce,Re)=>Xt.indexOf(ce.id)-Xt.indexOf(Re.id));let Ke=[];for(let ce of Bt){if((!me||!Vt.has(ce.id))&&(ce.visible=!1),!ce.visible)continue;let Re=(Ss(P[ce.id]).length*10+50+(((Qt=o[ce.id])==null?void 0:Qt.length)||0)*18)*ce.scale,Ne=26*ce.scale,je=10,Ze={l:ce.x-Re/2,r:ce.x+Re/2,t:ce.y-Ne,b:ce.y+6};if(Ke.some(Cn=>Ze.l<Cn.r+4&&Ze.r>Cn.l-4&&Ze.t<Cn.b+2&&Ze.b>Cn.t-2)){ce.visible=!1;continue}if(Gt().some(Cn=>Ze.l<Cn.right+je&&Ze.r>Cn.left-je&&Ze.t<Cn.bottom+je&&Ze.b>Cn.top-je)){ce.visible=!1;continue}Ke.push(Ze)}if(!$)return k!=="race"?{tags:Bt,closing:null}:{tags:Bt,raceS:0,leaderM:0,map:!1,closing:null,order:w.map(ce=>({id:ce,hidden:!0,gapText:""}))};let Ae=$.leader.m>=4e3,ye=$.order.map((ce,Re)=>{let Ne=$.byId[ce],je=Re<3||a.includes(ce),Ze=Ae||Ne.finished?Ne.gapText:"";if(!Ze&&a.includes(ce)&&Re>0&&!Ne.finished){let Cn=$.byId[$.order[Re-1]],Ts=$.raceS-ci(R.byId[$.order[Re-1]].progress,Ne.m);!Cn.finished&&Ts>=0&&Ts<=5&&(Ze=`\u2191${Ts.toFixed(1)}s`)}return{id:ce,gapText:Ze,finished:Ne.finished,hidden:!je}});return{raceS:$.raceS,leaderM:$.leader.m,tags:Bt,order:ye,map:ro.has((xe=U==null?void 0:U.shot)==null?void 0:xe.type),closing:ge($),dots:$.order.map((ce,Re)=>{var Ne,je;return{x:$.byId[ce].x,z:$.byId[ce].z,colour:P[ce].colour.primary,lead:Re===0,focus:(je=(Ne=U==null?void 0:U.shot)==null?void 0:Ne.ids)==null?void 0:je.includes(ce)}})}}let ae=null;function ge($){if(!a.length||Ct||J>0||I!=null)return ae=null,null;let j=(ve,be)=>$.raceS-ci(R.byId[ve].progress,$.byId[be].m),kt=[];$.order.forEach((ve,be)=>{if(be===0||$.byId[ve].finished||$.byId[$.order[be-1]].finished)return;let Qt=$.order[be-1],xe=a.includes(ve),ce=a.includes(Qt);if(!xe&&!ce)return;let Re=j(Qt,ve);Re>=0&&Re<=5&&kt.push({key:`${Qt}>${ve}`,ahead:Qt,behind:ve,g:Re,who:xe?ve:Qt,role:xe?"chase":"hunted"})});let Lt=ae&&kt.find(ve=>ve.key===ae.key);if(!Lt&&ae){let[ve,be]=ae.key.split(">"),Qt=!$.byId[be].finished&&$.order.indexOf(be)===$.order.indexOf(ve)+1?j(ve,be):99;Qt<=5.5&&(Lt={...ae,g:Qt})}let Bt=kt.sort((ve,be)=>ve.g-be.g)[0];if((!Lt||Bt&&Bt.key!==Lt.key&&Bt.g<Lt.g*.6)&&(Lt=Bt?{...Bt,g0:Bt.g}:null),!Lt)return ae=null,null;(!ae||ae.key!==Lt.key)&&(ae={...Lt,g0:Lt.g0??Lt.g});let me=ae.g0,Xt=Lt.g,Vt=Ss(P[Lt.who]),Ke=P[Lt.who].colour.primary;if(Xt<.5)return{text:"ALONGSIDE!",name:Vt,colour:Ke,hot:!0};let Ae=Xt<me-.15,ye=Lt.role==="chase"?Ae?"closing":"chasing":Ae?"under pressure":"holding on";return{name:Vt,colour:Ke,text:Ae?`${ye}: ${me.toFixed(1)} s \u2192 ${Xt.toFixed(1)} s`:`${ye}: ${Xt.toFixed(1)} s`,hot:Xt<1.5}}let Ie=new lr(.78,1,48);Ie.rotateX(-Math.PI/2);let et={};function Kt(){for(let $ of w){let j=et[$]||(et[$]=new _e);j.parent||_[$].root.add(j);for(let kt of[...j.children])j.remove(kt),kt.material.dispose();(o[$]||[]).forEach((kt,Lt)=>{let Bt=new We(Ie,new On({color:Eh(kt),transparent:!0,opacity:.9,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-4}));Bt.scale.setScalar(1+Lt*.32),Bt.position.y=.06+Lt*.01,Bt.renderOrder=2,j.add(Bt)})}}function Rt(){for(let $ of w){let j=et[$];if(!j||!j.children.length)continue;let kt=d.position.distanceTo(_[$].root.position);j.scale.setScalar(Ki.clamp(kt*.016,.9,3.2))}}Kt();function Dt($,j){let kt=Math.max(30,Math.min(220,j)),Lt=v.shadow.camera;Lt.right!==kt&&(Lt.left=-kt,Lt.right=kt,Lt.top=kt,Lt.bottom=-kt,Lt.near=1,Lt.far=900,Lt.updateProjectionMatrix());let Bt=2*kt/v.shadow.mapSize.x,me=Math.round($.x/Bt)*Bt,Xt=Math.round($.z/Bt)*Bt;v.target.position.set(me,$.y,Xt),v.position.set(me+u.x*400,$.y+u.y*400,Xt+u.z*400)}let ee=["wave","flex","point","stretch","spin","bow"];function ne($,j){let kt=[...$.personality||$.id].reduce((Lt,Bt)=>Lt+Bt.charCodeAt(0),j);return ee[kt%ee.length]}function we($,j={}){k="intro",E.setDim(!0),E.clearBanner(),E.photo(!1),E.results(null),ke(),E.market(!1),I=null,mt=!1,m.style.filter="",dt("idle");let kt=j.perRunnerS??t.introPerRunnerS??4.2,Lt=j.flyoverS??7;return W={t:0,idx:-1,per:kt,fly:Lt,onDone:$,waiting:!1,segStart:0,minSeg:2.5,done:!1,group:!1},{flyoverS:Lt,perRunnerS:kt,runners:w.slice()}}function Ve($){let j=W;if(!j)return;j.t+=$;let kt=jt;if(j.idx===-1){!j.title&&j.t>.8&&(j.title=!0,C(!0));let ye=Math.min(1,j.t/j.fly),ve=wh(ye),be=f.sample(0),Qt=new V(170,0,-40),xe=2.2-ve*2,ce=520-ve*470,Re=new V(Qt.x+Math.cos(xe)*ce,190-ve*170,Qt.z+Math.sin(xe)*ce),Ne=new V(be.x+be.tx*22+be.rx*10,be.y+9,be.z+be.tz*22+be.rz*10);Re.lerp(Ne,ve*ve);let je=Qt.clone().setY(15).lerp(new V(be.x,be.y+1,be.z),Math.min(1,ve*1.2));d.position.copy(Re),d.lookAt(je),_t(50),ye>=1&&Q();return}if(j.group){let ye=f.sample(0),ve=(j.t-j.segStart)/3;if(d.position.set(ye.x+ye.tx*(9+ve*2)+ye.rx*2,ye.y+2.2+ve*.6,ye.z+ye.tz*(9+ve*2)+ye.rz*2),d.lookAt(ye.x,ye.y+1.3,ye.z),_t(46),ve>=1&&!j.done){j.done=!0,E.introCard(null);let be=j.onDone;W=null,k="idle",be==null||be()}return}let Lt=w[j.idx],Bt=kt[Lt],me=j.t-j.segStart,Xt=new V(Math.sin(Bt.yaw),0,Math.cos(Bt.yaw)),Vt=new V(-Xt.z,0,Xt.x),Ke=_[Lt].height,Ae=3.2+Ke*.6-Math.min(.6,me*.12);d.position.set(Bt.x+Xt.x*Ae+Vt.x*.9,Bt.y+Ke*.62,Bt.z+Xt.z*Ae+Vt.z*.9),d.lookAt(Bt.x-Vt.x*1.25,Bt.y+Ke*.55,Bt.z-Vt.z*1.25),_t(40),!j.waiting&&me>=j.per&&Q(),j.waiting==="released"&&me>=j.minSeg&&Q()}function C($){let j=s||{};E.titleCard($,{title:j.title||"MARKRUN",kicker:j.number?`ROUND ${j.number}`:"LIVE FROM FINSBURY PARK",theme:j.theme?typeof j.theme=="string"?j.theme:j.theme.label||j.theme.name||"":""})}function Q(){var Bt;let $=W;$.idx===-1&&C(!1),$.idx++,$.segStart=$.t;for(let me of w)_[me].set("idle");if($.idx>=w.length){$.group=!0;for(let me of w)_[me].set("pose","point");E.introCard(null),setTimeout(()=>{},0);for(let me of w)_[me].set("wave");return}let j=w[$.idx];_[j].set(ne(P[j],$.idx)==="wave"?"wave":"pose",ne(P[j],$.idx)),t.introCards!==!1&&E.introCard(P[j]),$.waiting=!1;let Lt=(Bt=t.onIntroRunner)==null?void 0:Bt.call(t,j,$.idx);Lt&&typeof Lt.then=="function"&&($.waiting=!0,Lt.then(()=>{W===$&&($.waiting="released")},()=>{W===$&&($.waiting="released")}))}function at($,j){if(!R)throw new Error("createRaceView: playRace needs a plan (pass opts.plan or call loadPlan(plan) first)");k="race",E.setDim(!1),E.results(null),ke(),W=null,E.introCard(null),E.titleCard(!1),E.market(!1),I=null,mt=!1,m.style.filter="",D=-ao,K=0,Et=0,J=0,it=!1,Mt=!1,Ct=null,nt=!1,pt=1,E.replay(!1),xt.clear(),X=!!t.skipRaceTitle,E.setDimTop(!1),q={onEvent:$,onDone:j},dt("idle"),U.reset()}let lt=[[-3,"3"],[-2,"2"],[-1,"1"],[0,"GO!"]];function wt($){switch($.type){case"lead_change":return["LEAD CHANGE","","#ff3d8b"];case"overtake":return a.includes($.by)||a.includes($.on)?["OVERTAKE","","#2e6fe0"]:null;case"hill":return["THE HILL","","#3aa845"];case"lap":return["LAP 2","","#2e6fe0"];case"final_stretch":return["FINAL STRETCH","","#ff8a1f"];case"diversion":return xt.has("div")?null:(xt.add("div"),["DISTRACTED!","","#b04bff"]);case"finish":return $.place===1&&!R.photoFinish?["WINNER","","#ffb000"]:null;default:return null}}function ft($){var kt,Lt,Bt,me;if(J>0){J-=$,J<=0&&(E.photo(!1),m.style.filter="",S.anchors.finishArch.visible=!0,zt());return}if(Ct){Ft($);return}let j=D;for(pt=It(D),D+=$*pt,D<-4.2&&!X&&(X=!0,C(!0),E.setDimTop(!0)),D>=-3.6&&X===!0&&(X="done",C(!1),E.setDimTop(!1));Et<lt.length&&D>=lt[Et][0];){let[Xt,Vt]=lt[Et++];if(E.countdown(Vt),(kt=q==null?void 0:q.onEvent)==null||kt.call(q,{kind:"countdown",n:Vt==="GO!"?0:Number(Vt),text:Vt,broadcastS:Xt}),Xt===-3)for(let Ke of w)_[Ke].set("ready")}for(;K<z.length&&D>=z[K].at;){let Xt=z[K++].evt;try{(Lt=q==null?void 0:q.onEvent)==null||Lt.call(q,Xt)}catch(Vt){console.error(Vt)}if(Xt.kind==="event"){let Vt=wt(Xt);Vt&&E.showBanner(...Vt)}}if(R.photoFinish&&!it&&D>=R.firstFinishB){it=!0,D=R.firstFinishB,J=t.photoFreezeS??1.4;{let[Xt,Vt]=R.finishOrder;E.photo(!0,`${Ss(P[Xt])} or ${Ss(P[Vt])}? Checking the camera...`)}m.style.filter="grayscale(0.55) sepia(0.35) contrast(1.12)",(Bt=q==null?void 0:q.onEvent)==null||Bt.call(q,{kind:"photo_finish",broadcastS:D,ids:R.finishOrder.slice(0,2)})}!nt&&!Ct&&D>=R.firstFinishB+1.1&&zt(),!Mt&&D>=R.lastFinishB+3.5&&(Mt=!0,(me=q==null?void 0:q.onDone)==null||me.call(q))}function It($){if(!R||t.finishSlowMo===!1)return 1;let j=Math.abs($-R.firstFinishB),kt=j<1?1:j<1.6?1-Jt((j-1)/.6):0;return 1-(1-qt)*kt}function Jt($){return $=Math.max(0,Math.min(1,$)),$*$*(3-2*$)}function zt(){if(nt||t.finishReplay===!1){nt=!0,st();return}let $=R.byId[R.finishOrder[0]];Ct={t:0,b0:Math.max(0,Di(r.timeMap,ci($.progress,4940))),b1:R.firstFinishB+.6,resume:D},E.replay(!0)}function Ft($){Ct.t+=$,Ct.t>=tt&&(Ct=null,nt=!0,E.replay(!1),U.reset(!0),st())}function Ut(){let $=Math.min(1,Ct.t/tt);return Ct.b0+(Ct.b1-Ct.b0)*(1-Math.pow(1-$,1.7))}function st(){var kt;let $=R.finishOrder[0],j={kind:"winner_replay_done",winnerId:$,photoFinish:!!R.photoFinish,broadcastS:D};try{(kt=q==null?void 0:q.onEvent)==null||kt.call(q,j)}catch(Lt){console.error(Lt)}if(t.onWinnerStamp)try{t.onWinnerStamp({winnerId:$,photoFinish:!!R.photoFinish})}catch(Lt){console.error(Lt)}else E.showBanner("WINNER","","#ffb000")}function Nt($){o=$||{},a=Object.keys(o).filter(j=>(o[j]||[]).length),E.setBackedBy(o),Kt()}function $t($,j=1.2){if(!R)throw new Error("createRaceView: seek in a race needs a plan");$=Math.max(-ao,Math.min(R.lastFinishB+3.5,Number($)||0)),k="race",W=null,ke(),q=q||{},E.setDim(!1),E.introCard(null),E.results(null),E.photo(!1),E.market(!1),E.clearBanner(),E.titleCard(!1),E.setDimTop(!1),m.style.filter="",S.anchors.finishArch.visible=!0,I=null,X=$>=-3.6?"done":$<-4.2?!1:"done",U.reset();let kt=Math.round(j*30);for(let Lt=kt;Lt>=0;Lt--){if(D=$-Lt/30,D<-3)for(let Bt of w)_[Bt].set("idle");else if(D<0)for(let Bt of w)_[Bt].set("ready");if(Lt>0)if(U.update(D,1/30,N),D>=0)St(D,1/30);else for(let Bt of w)_[Bt].update(1/30,{})}D=$,K=z.findIndex(Lt=>Lt.at>D),K<0&&(K=z.length),Et=lt.findIndex(Lt=>Lt[0]>D),Et<0&&(Et=lt.length),it=D>=R.firstFinishB,Mt=D>=R.lastFinishB+3.5,J=0,Ct=null,nt=D>=R.firstFinishB+1.1,pt=1,E.replay(!1)}function ie($){let j=W;if(!j)return;$=Math.max(0,Number($)||0);let kt=w.length;if($<j.fly){j.t=$;return}C(!1),j.title=!0;let Lt=Math.min(kt,Math.floor(($-j.fly)/j.per));j.idx=Lt-1,j.t=$,Q(),j.segStart=j.fly+Lt*j.per}function Me($){return k==="intro"?ie($):$t($)}function ke(){F&&(F.dispose(),F=null)}function He($,{card:j}={}){var Lt;k="podium",E.setDim(!0),E.clearBanner(),W=null,E.titleCard(!1),E.market(!1),I=null,mt=!1,m.style.filter="",E.photo(!1),ke();let kt=(Lt=$==null?void 0:$.finishOrder)!=null&&Lt.length?[...$.finishOrder].sort((Bt,me)=>Bt.place-me.place):((R==null?void 0:R.finishOrder)||w).map((Bt,me)=>({runnerId:Bt,place:me+1,officialS:(R==null?void 0:R.byId[Bt].officialS)??0,timeText:R?Ha(R.byId[Bt].officialS):""}));F=qu(g,f,S,_,kt,{camera:d,offsetX:(j??t.podiumCard)!==!1?3.2:0}),(j??t.podiumCard)!==!1&&E.results(kt.map(Bt=>{var me,Xt;return{place:Bt.place,nickname:((me=P[Bt.runnerId])==null?void 0:me.nickname)||Bt.runnerId,colour:((Xt=P[Bt.runnerId])==null?void 0:Xt.colour.primary)||"#888",timeText:Bt.timeText||Ha(Bt.officialS)}}))}let O=performance.now(),rt=0,vt={frames:0,acc:0,fps:0};function _t($){Math.abs(d.fov-$)>.01&&(d.fov=$,d.updateProjectionMatrix())}function ct($,j=!1){var me,Xt,Vt,Ke,Ae;G+=$;let kt=null;mt||(k==="intro"&&Ve($),k==="race"&&ft($));let Lt=mt?0:$;if(k==="race"){if(J>0){let Qt=S.anchors.finish;S.anchors.finishArch.visible=!1,d.position.set(Qt.x+Qt.rx*9-Qt.tx*.6,Qt.y+6.4,Qt.z+Qt.rz*9-Qt.tz*.6),d.lookAt(Qt.x-Qt.rx*.6-Qt.tx*.6,Qt.y+.8,Qt.z-Qt.rz*.6-Qt.tz*.6),_t(42),d.updateMatrixWorld();let xe=new V(Qt.x+Qt.rx*3,Qt.y+.05,Qt.z+Qt.rz*3).project(d),ce=new V(Qt.x-Qt.rx*3,Qt.y+.05,Qt.z-Qt.rz*3).project(d);E.photoLine([(xe.x*.5+.5)*m.clientWidth,(-xe.y*.5+.5)*m.clientHeight],[(ce.x*.5+.5)*m.clientWidth,(-ce.y*.5+.5)*m.clientHeight])}else if(Ct){let Qt=S.anchors.finish,xe=Ut(),ce=R.stateAt(xe).byId[R.finishOrder[0]];d.position.set(Qt.x+Qt.tx*30+Qt.rx*2.2,Qt.y+1.1,Qt.z+Qt.tz*30+Qt.rz*2.2),d.lookAt(ce.x,ce.y+1,ce.z),_t(13)}else if(mt&&I!=null){I+=$;let Qt=R.stateAt(Math.max(0,D)),xe=Qt.byId[Qt.order[0]],ce=Qt.order.slice(0,3).map(is=>Qt.byId[is]).filter(is=>Math.abs(is.m-xe.m)<25),Re=new V;for(let is of ce)Re.add(new V(is.x,is.y,is.z));Re.divideScalar(Math.max(1,ce.length)),ut||(ut=Math.atan2(d.position.x-Re.x,d.position.z-Re.z));let Ne=ut+I*.12,je=10+Math.min(25,xe.m-ce.at(-1).m)*.4,Ze=Math.min(1,I/1.2),Cn=Ze*Ze*(3-2*Ze),Ts=Re.x+Math.sin(Ne)*je,Ih=Re.z+Math.cos(Ne)*je;d.position.set(Ts,Math.max(Re.y+3+Cn*2,f.heightAt(Ts,Ih)+2.5),Ih),d.lookAt(Re.x,Re.y+2.3,Re.z),_t(44)}else U.update(D,Lt,N);kt=D>=0?R.stateAt(D):null,Ct&&(kt=R.stateAt(Ut()));let ye=!J&&I==null&&["side","headon","finishcam"].includes((me=U.shot)==null?void 0:me.type);S.setOcclusionCorridor(ye?d.position:null,ye?U.cam.look:null);let ve=!J&&!Ct&&((Xt=U.shot)==null?void 0:Xt.type)==="finishcam"?U.shot.fside:0;if(ve!==H){H=ve;let Qt=S.anchors.finish;M.setMask(ve?(xe,ce)=>{let Re=((xe-Qt.x)*Qt.rx+(ce-Qt.z)*Qt.rz)*ve,Ne=(xe-Qt.x)*Qt.tx+(ce-Qt.z)*Qt.tz;return Re>0&&Re<16&&Ne>-75&&Ne<14&&Re<15*(Ne+150)/161+2.5}:null)}if(D<0)for(let Qt of w)_[Qt].update(Lt,{});else if(Ct){let Qt=Math.min(1,Ct.t/tt);pt=Math.max(.2,(Ct.b1-Ct.b0)/tt*1.7*Math.pow(1-Qt,.7)),St(Ut(),Lt)}else St(D,J>0?0:Lt);let be=(Vt=U.shot)==null?void 0:Vt.type;Dt(U.cam.look,ro.has(be)?160:70)}else if(k==="podium"&&F){S.setOcclusionCorridor(null),F.update(Lt,G);for(let ye of w)_[ye].update(Lt,{});Dt(F.center,40)}else{for(let ye of w)_[ye].update(Lt,{});if(k==="idle"){let ye=f.sample(0),ve=G*.12;d.position.set(ye.x+Math.sin(ve)*14,ye.y+4.5,ye.z+Math.cos(ve)*14),d.lookAt(ye.x,ye.y+1.2,ye.z),_t(45)}Dt(new V(((Ke=jt[w[0]])==null?void 0:Ke.x)??0,0,((Ae=jt[w[0]])==null?void 0:Ae.z)??0),k==="intro"&&(W==null?void 0:W.idx)===-1?160:40)}if(Tt+=$,j)return;Rt(),S.update(G),y==null||y.update(G);let Bt=w.map(ye=>_[ye].root.position);M.update(G,d.position,Bt,k==="podium"?.9:null),E.update(Tt,k==="race"?Wt(kt,D>-1&&I==null&&!Ct):Wt(null,!1)),Tt=0,h.render(g,d)}let Zt=2;function re($){if(bt)return;rt=requestAnimationFrame(re);let j=Math.max(0,($-O)/1e3);O=$,vt.frames++,vt.acc+=j,vt.acc>1&&(vt.fps=vt.frames/vt.acc,vt.frames=0,vt.acc=0),ue(Math.min(Zt,j)*B)}function ue($){let j=$;if(j<=1e-6){ct(0);return}for(;j>1e-6;){let kt=Math.min(j,.1);j-=kt,ct(kt,j>1e-6)}}t.manualLoop||(rt=requestAnimationFrame(re));function de(){var $;bt=!0,cancelAnimationFrame(rt),At==null||At.disconnect(),window.removeEventListener("resize",Pt);for(let j in et)for(let kt of et[j].children)kt.material.dispose();Ie.dispose(),ke();for(let j of w)g.remove(_[j].root),_[j].dispose();M.dispose(),y==null||y.dispose(),b.dispose(),S.dispose(),E.dispose(),g.traverse(j=>{j.geometry&&j.geometry.dispose()}),Fu(),Cu(),h.dispose(),($=h.forceContextLoss)==null||$.call(h),m.remove()}let Ee={seek($,j=1.2){$t($,j),mt=!0,ct(0)},introAt($,j=1.5){if(we(()=>{},{}),mt=!1,$<0){W.t=j,Ve(0),ct(0),mt=!0;return}for(W.t=W.fly,Ve(0);W&&W.idx<$;)W.t=W.segStart+W.per+.01,Ve(0);for(let kt=0;kt<j*30;kt++){Ve(1/30);for(let Lt of w)_[Lt].update(1/30,{})}mt=!0,ct(0)},podiumAt($=3){E.introCard(null),He(null);for(let j=0;j<$*30;j++){F.update(1/30,j/30);for(let kt of w)_[kt].update(1/30,{})}mt=!0,ct(0)},photoAt(){this.seek(R.firstFinishB-.05),mt=!1,it=!1;for(let $=0;$<3;$++)ct(1/30);mt=!0,ct(0)},render(){ct(0)},unpause(){mt=!1},lookFrom($,j,kt,Lt,Bt,me,Xt=45){k="debugcam",d.position.set($,j,kt),d.lookAt(Lt,Bt,me),_t(Xt),E.setDim(!0),h.render(g,d)},step($,j=!0){ct($,!j)},get mode(){return k},get b(){return D},get shots(){return N},get sim(){return R},C:f,get director(){return U},renderer:h,scene:g,camera:d,info:()=>h.info,fps:()=>vt.fps};return{playIntro:we,playRace:at,showPodium:He,setPaused($,{market:j=!0,marketText:kt}={}){$=!!$,$!==mt&&(mt=$,k==="race"&&J<=0&&t.marketOnPause!==!1&&j&&($?(I=0,ut=0,E.market(!0,kt??t.marketText??"Place your halfway bets!"),m.style.filter="saturate(1.2) contrast(1.06)"):(I=null,E.market(!1),m.style.filter="",U.reset(!1))))},setSpeed($){B=Math.max(.05,Number($)||1)},seek:Me,loadPlan($,{backedBy:j}={}){if(k==="race")throw new Error("createRaceView: loadPlan during a race");j&&Nt(j),Y($)},setBackedBy($){Nt($),R&&k!=="race"&&(N=Sh({plan:r,sim:R,backedIds:a,hasDiversion:c,C:f,world:S,funfair:y}))},dispose:de,hudRoot:E.root,get broadcastTime(){return k==="intro"?(W==null?void 0:W.t)??0:D},get durationS(){return R?ao+R.lastFinishB+3.5:0},preRollS:ao,_debug:Ee}}function Zu(n){let e=Array.from({length:201},(r,o)=>Math.round(o*25/5e3*1500*1e3)/1e3),i=((n==null?void 0:n.runners)||[]).map(r=>({id:r.id,officialS:1500,progress:e,pacingSource:"intro"})),s=Lh((n==null?void 0:n.roundId)||"intro",i);return s.events=[],s.commentary=[],s}var Xa=(n,...t)=>{try{return typeof ja[n]=="function"?ja[n](...t):null}catch{return null}},po=new URLSearchParams(location.search),Es=Math.max(.25,Number(po.get("speed"))||1),Wa=po.get("race")==="2d",Hn=n=>Math.round(n/Es);window.__markrun={events:[],speed:Es};var Kn=n=>{window.__markrun.events.push({at:Date.now(),...n}),window.__markrun.events.length>500&&window.__markrun.events.shift()},gr=Se("#stage"),ki=Se("#screen"),yr=Se("#hud-bottom"),xr=Se("#subs"),bx=Se("#reactions"),lo=Se("#next-hint"),mr=Se("#race-layer"),se=null,xn=null,ho=po.has("autostart"),ts=po.has("mute"),oe=Nh(),jn=Oh({onLine:Cx,onIdle:()=>{oe.duck(!1)}});function rd(){let n=Math.min(window.innerWidth/1920,window.innerHeight/1080);gr.style.transform=`translate(-50%, -50%) scale(${n})`,gr.style.transformOrigin="center center",gr.style.left="50%",gr.style.top="50%"}window.addEventListener("resize",rd);rd();var Th=null,Sx=Promise.all([fetch("/data/course.json").then(n=>n.json()),fetch("/data/park.json").then(n=>n.json()).catch(()=>null)]).then(([n,t])=>(Th={course:n,park:t},Th)),$a=po.get("key");try{$a&&localStorage.setItem("markrun.tvkey",$a)}catch{}var wx=()=>{try{return $a||localStorage.getItem("markrun.tvkey")}catch{return $a}},qa=Uh({role:"tv",getKey:wx,onWelcome:n=>{var t;if(n.key)try{localStorage.setItem("markrun.tvkey",n.key)}catch{}(t=Se("#tvauth"))==null||t.remove()},onStatus:n=>{Se("#conn").classList.toggle("hidden",n==="open"||n==="connecting")},onState:n=>Ex(n),onMessage:n=>{var t;n.t==="react"?Px(n.playerId,n.emoji):n.t==="refresh"?fd(n.step,n.msg):n.t==="refreshDone"?Nx(n.ok,n.msg):n.t==="claimRequest"?Ux(n):n.t==="claimClosed"?((t=Se("#tvmodal"))==null?void 0:t.dataset.req)===n.reqId&&Li():n.t==="error"&&n.code==="tv_auth"?Dx(n.msg):n.t==="error"&&ns(n.msg,"red")}}),An=n=>qa.send(n);function _r(){var n;if(!(ho&&oe.ready())){ho=!0,oe.unlock(),Se("#gesture").classList.add("gone");try{(n=window.speechSynthesis)==null||n.getVoices()}catch{}Ya(),se&&ld(se,!0)}}ho&&Se("#gesture").classList.add("gone");Se("#gesture").addEventListener("click",_r);window.addEventListener("pointerdown",()=>{oe.ready()||_r()});function Ya(){let n=(se==null?void 0:se.settings)||{};oe.setVolume(n.volume??.8),oe.setMuted(ts),oe.setMusicEnabled(n.music!==!1),jn.setEnabled(!ts&&n.voice!==!1&&Es<=1.5),jn.setVolume(Math.min(1,(n.volume??.8)+.1)),Se("#btn-mute").textContent=ts?"\u{1F507}":"\u{1F50A}"}Se("#btn-mute").addEventListener("click",n=>{n.stopPropagation(),ts=!ts,Ya()});Se("#btn-fs").addEventListener("click",n=>{n.stopPropagation(),od()});function od(){var n,t,e;document.fullscreenElement?(n=document.exitFullscreen)==null||n.call(document):(e=(t=document.documentElement).requestFullscreen)==null||e.call(t).catch(()=>{})}var Ju;window.addEventListener("mousemove",()=>{document.body.classList.remove("hide-cursor"),clearTimeout(Ju),Ju=setTimeout(()=>document.body.classList.add("hide-cursor"),3e3)});window.addEventListener("keydown",n=>{var e,i,s;if((i=(e=n.target).closest)!=null&&i.call(e,"input, textarea"))return;if(!ho){_r();return}if(kx()){if(n.key==="Escape"){let r=Se("#tvmodal [data-cancel]:not([disabled])");r?r.click():Li()}else n.key==="Enter"&&((s=Se("#tvmodal [data-ok]"))==null||s.click());return}oe.ready()||oe.unlock();let t=n.key;if(t==="m"||t==="M"){ts=!ts,Ya(),ns(ts?"Muted":"Sound on");return}if(t==="f"||t==="F"){od();return}if(t==="l"||t==="L"){(se==null?void 0:se.phase)==="BETTING"&&!se.revealed&&(An({t:"forceLock"}),ns("Locking everyone in!"));return}if(t===" "||t==="Enter"||t==="ArrowRight"||t==="n"||t==="N"){if(n.preventDefault(),vr===!1){vr=!0;return}Rh()}});function Rh(){if(se){if(se.phase==="LOBBY"&&!se.players.length){ns("Scan the QR code to join first!","red");return}if(se.phase==="BETTING"&&!se.revealed){ns("Waiting for everyone to lock in (press L to force it)");return}An({t:"advance",from:se.phase,stage:se.phase==="RESULTS"?se.resultsStage:void 0})}}var Ku=new Map;function Ex(n){var s;let t=se;se=n,Ya();let e=new Map(n.players.map(r=>[r.id,r]));if(t)for(let r of n.players){let o=Ku.get(r.id);if(!o)oe.play("join"),n.phase==="LOBBY"&&jn.say(`${r.name} has entered the paddock!`,"pam",{priority:1});else if(!o.locked&&r.locked&&n.phase==="BETTING"){oe.play("thunk"),oe.play("lock");let a=Xa("lockLine",{name:r.name})||{text:Ix(r.name),speaker:"jeff"};jn.say(a.text,a.speaker,{priority:2})}else o.connected&&!r.connected&&setTimeout(()=>{let a=se==null?void 0:se.players.find(l=>l.id===r.id);a&&!a.connected&&ns(`${r.name}'s phone dropped out \u2014 it'll reconnect`,"red")},5e3)}Ku=e;let i=Tx(n);if(!xn||xn.key!==i)if(!xn)Qu(i,n,t);else{let r=xn;xn={key:i,pending:!0,destroy:()=>{var o;return(o=r.destroy)==null?void 0:o.call(r)}},ad(),setTimeout(()=>{xn.key===i&&xn.pending&&(xn=r,Qu(i,se,t))},210)}else xn.pending||(s=xn.update)==null||s.call(xn,n,t);Ax(n),Rx(n),ld(n)}function Tx(n){var e;let t=((e=n.round)==null?void 0:e.roundId)||"";return n.phase==="BETTING"?`BETTING|${t}|${n.revealed?"reveal":"bet"}`:["INTRO","RACE","RESULTS","SCOREBOARD"].includes(n.phase)?`${n.phase}|${t}`:`${n.phase}|${n.gameNumber}`}var ws=Je('<div id="wipe"><i></i><b></b></div>');document.body.appendChild(ws);ws.addEventListener("animationend",n=>{n.target.tagName==="B"&&ws.classList.remove("go")});var ju=null;function ad(){ws.classList.remove("go"),ws.offsetWidth,ws.classList.add("go"),clearTimeout(ju),ju=setTimeout(()=>ws.classList.remove("go"),700),window.__markrun.wipeUntil=Date.now()+700,oe.play("wipe")}function Qu(n,t,e){var o,a;try{(o=xn==null?void 0:xn.destroy)==null||o.call(xn)}catch(l){console.warn(l)}ki.innerHTML="",jn.clear(),xr.innerHTML="";let i=t.phase;document.body.className=document.body.className.replace(/\bphase-\w+/g,"").trim()+` phase-${i}`,document.body.classList.toggle("revealed",!!t.revealed),document.body.classList.toggle("racing",i==="RACE"||i==="INTRO"&&!!$e),Kn({type:"screen",key:n});let s={LOBBY:Lx,INTRO:Fx,BETTING:t.revealed?Gx:Vx,RACE:Wx,RESULTS:$x,SCOREBOARD:Qx,FINALE:t_}[i];if(xn=s?s(t,e):{},xn.key=n,i==="BETTING"&&$e&&Ja===((a=t.round)==null?void 0:a.roundId)&&ud($e)){try{$e.setPaused(!0)}catch{}document.body.classList.remove("racing")}else i!=="RACE"&&i!=="RESULTS"&&i!=="INTRO"&&co()}var td=null;function ld(n,t=!1){if(!ho)return;let e={LOBBY:"lobby",BETTING:n.revealed?null:"betting",SCOREBOARD:"lobby",RESULTS:null,INTRO:null,RACE:null,FINALE:null}[n.phase];e===td&&!t||(td=e,e?oe.startMusic(e):oe.stopMusic(1.2))}function cd(n){let t=[...n].sort((i,s)=>s.bankroll-i.bankroll),e=new Map;return t.forEach((i,s)=>e.set(i.id,s>0&&i.bankroll===t[s-1].bankroll?e.get(t[s-1].id):s+1)),e}function Ax(n){let t=n.phase==="BETTING"&&!n.revealed;if(yr.classList.toggle("hidden",!t),document.body.classList.toggle("no-hud",!t),!t){yr.innerHTML="";return}let e=cd(n.players),i=n.phase==="RACE"?n.bets||{}:{};yr.innerHTML=n.players.map(s=>`<span class="pill ${s.connected?s.locked?"locked":"":"off"}" data-pid="${s.id}">${cn(s.avatar,40)}<b>${Ot(s.name)}</b><i>${s.connected?s.locked?"\u{1F512} locked":"\u{1F914}":"\u{1F4F5}"}</i></span>`).join("")}function Rx(n){let t={INTRO:"Skip intros \u23ED",RACE:"Skip race \u23ED",RESULTS:"Next \u25B6",SCOREBOARD:n.roundNumber>=n.roundsPerGame?"Final results \u25B6":"Next round \u25B6",FINALE:(()=>{let e=[...n.players].sort((i,s)=>i.bankroll-s.bankroll)[0];return n.players.length>1&&e?`${e.name} demands a REMATCH \u21BB`:"Play again \u21BB"})(),BETTING:n.revealed?"Start race \u25B6":null}[n.phase];if(!t){lo.innerHTML="";return}lo.dataset.label!==t&&(lo.dataset.label=t,lo.innerHTML=`<button class="btn ${n.phase==="RACE"||n.phase==="INTRO"?"ghost small":n.phase==="FINALE"?"red big rematch":"white"}">${t} <span style="opacity:.6;font-size:.7em">SPACE</span></button>`,lo.firstElementChild.addEventListener("click",e=>{e.stopPropagation(),_r(),Rh()}))}function ns(n,t=""){let e=Je(`<div class="t panel ${t==="red"?"red":"yellow"} anim-pop">${Ot(n)}</div>`),i=Se("#toast");i.innerHTML="",i.appendChild(e),setTimeout(()=>{e.parentNode&&e.remove()},3200)}function Cx(n){oe.duck(!0);let t=Je(`<div class="sub"><span class="who ${n.speaker==="pam"?"pam":"jeff"}">${n.speaker==="pam"?"PAM":"JEFF"}</span><span>${Ot(n.text)}</span></div>`);xr.appendChild(t);let e=1;for(;xr.children.length>e;)xr.firstElementChild.remove();let i=Math.max(3e3,n.text.split(/\s+/).length*420+1500);setTimeout(()=>{t.classList.add("out"),setTimeout(()=>t.remove(),450)},i),Kn({type:"line",text:n.text,speaker:n.speaker})}var Oe=(n,t="jeff",e=2)=>jn.say(n,t,{priority:e});function Ix(n){let t=[`${n} has locked in. No take-backs!`,`And ${n}'s money is down!`,`${n} has committed. Bold. Possibly foolish.`,`Bets are in from ${n}!`];return t[Math.floor(Math.random()*t.length)]}function Px(n,t){let e=se==null?void 0:se.players.find(o=>o.id===n),i=yr.querySelector(`[data-pid="${n}"]`),s;if(i&&!yr.classList.contains("hidden")){let o=i.getBoundingClientRect(),a=gr.getBoundingClientRect(),l=a.width/1920;s=(o.left+o.width/2-a.left)/l+(Math.random()-.5)*160}else{let o=(se==null?void 0:se.players.findIndex(a=>a.id===n))??0;s=((se==null?void 0:se.phase)==="RACE"?1790-o*90:o%2===0?70:1790)+(Math.random()-.5)*60}let r=Je(`<div class="react" style="left:${Math.round(s-60)}px;--rot:${Math.round((Math.random()-.5)*40)}deg"><span class="e">${Ot(t)}</span>${e?cn(e.avatar,46):""}</div>`);bx.appendChild(r),oe.play("pop"),setTimeout(()=>r.remove(),3300)}function _n(n,t){return new Promise(e=>{let i=setTimeout(e,Hn(n));t==null||t.timers.push(i)})}function Za(){return{cancelled:!1,timers:[]}}function fo(n){n.cancelled=!0,n.timers.forEach(t=>{clearTimeout(t),clearInterval(t)})}async function Bn(n,t,e=12e3){let i=Date.now();if(await _n(t,n),!(Es>1.5))for(;!n.cancelled&&jn.busy&&Date.now()-i<e;)await new Promise(s=>setTimeout(s,150))}var yi=(n,t=120)=>Fh(n,{size:t,idSuffix:Math.random().toString(36).slice(2,6)});function hd(){return`<div class="clouds">${[0,1,2,3,4].map(n=>`<div class="cloud" style="top:${40+n*70}px;width:${180+n%3*70}px;height:${50+n%2*18}px;animation-duration:${70+n*17}s;animation-delay:-${n*19}s"></div>`).join("")}</div>
  <svg class="hills" viewBox="0 0 1920 260" preserveAspectRatio="none"><path d="M0 150 Q 240 40 520 120 T 1040 110 T 1500 90 T 1920 130 V260 H0Z" fill="#2ec27e" stroke="#14183c" stroke-width="6"/><path d="M0 200 Q 300 140 640 190 T 1280 180 T 1920 190 V260 H0Z" fill="#169c5b" stroke="#14183c" stroke-width="6"/></svg>`}var dr=[100,250,500,1e3,2e3,5e3],pr=[0,60,90,120,180];function Lx(n){let t=Je(`<div class="lobby">
    ${hd()}
    <div class="logo"><div class="word outlined">MARK<span class="r">RUN</span></div><br><div class="ribbon"><span>THE FINSBURY PARK FORM GUIDE</span></div></div>
    <div class="tagline">Real parkruns. Real Mark. Fake money. \u{1F377}</div>
    <div class="qr-card panel white"><div class="qr"></div><div class="scan">\u{1F4F1} SCAN TO JOIN</div><div class="url"></div></div>
    <div class="slots"></div>
    <div class="settings panel cream hidden"></div>
    <div class="start-wrap"></div>
  </div>`);ki.appendChild(t),Se(".qr",t).innerHTML=n.qrSvg||"",Se(".url",t).textContent=(n.joinUrl||"").replace(/^https?:\/\//,""),Oe(n.players.length?"Welcome back to MARKRUN!":"Welcome to MARKRUN! Grab your phones and scan the code.","jeff",1);let e=(l,c,h,m)=>`<div class="set" data-k="${c}"><div class="lbl">${l}</div><div class="ctl-row">${m.replace("{val}",`<span class="val">${h}</span>`)}</div></div>`;function i(l){let c=[],h=Math.max(2,l.players.length);for(let p=0;p<h;p++){let v=l.players[p];if(v){let u=v.connected?v.ready?'<span class="tag" style="background:var(--grass);color:#fff">\u2713 READY</span>':'<span class="tag">joined</span>':'<span class="tag" style="background:var(--tomato);color:#fff">\u{1F4F5} offline</span>';c.push(`<div class="slot panel slant ${s.has(v.id)?"":"joined"}" style="background:${Ot(v.avatar.colour)}"><div class="unslant" style="display:flex;align-items:center;gap:24px;width:100%">${cn(v.avatar,92)}<div><div class="sname">${Ot(v.name)}${l.settings.runnerPlayerId===v.id?' <span class="tag markt">\u{1F3C3} THE REAL MARK</span>':""}</div><div class="ssub">${Mn(v.bankroll)} to gamble${l.settings.runnerPlayerId&&l.settings.runnerPlayerId!==v.id?" \xB7 gets an extra \u{1F525} hot tip":""}</div></div><span class="slot-badge">${u}</span><button class="btn small white kick" data-kick="${v.id}" title="Remove player">\u2715</button></div></div>`)}else c.push(`<div class="slot panel slant empty"><div class="unslant" style="display:flex;align-items:center;gap:24px"><div class="ghost-av">?</div><div><div class="sname">Player ${p+1}</div><div class="ssub">Scan the code to take this seat</div></div></div></div>`)}s=new Set(l.players.map(p=>p.id)),Se(".slots",t).innerHTML=c.join(""),Se(".slots",t).classList.toggle("many",h>2);let m=l.settings,g=Math.round((m.volume??.8)*10);Se(".settings",t).innerHTML=[e("Starting pot","startingBankroll",Mn(m.startingBankroll),'<button class="btn small white" data-d="-1">\u2212</button>{val}<button class="btn small white" data-d="1">+</button>'),e("Rounds","roundsPerGame",m.roundsPerGame,'<button class="btn small white" data-d="-1">\u2212</button>{val}<button class="btn small white" data-d="1">+</button>'),e("Bet timer","betTimer",m.betTimer?`${m.betTimer}s`:"Off",'<button class="btn small white" data-d="-1">\u2212</button>{val}<button class="btn small white" data-d="1">+</button>'),e("Drinking","drinkingMode","",`<button class="btn small toggle ${m.drinkingMode?"on":"off"}" data-toggle>${m.drinkingMode?"\u{1F37A} ON":"OFF"}</button>`),e("Voice","voice","",`<button class="btn small toggle ${m.voice?"on":"off"}" data-toggle>${m.voice?"\u{1F399}\uFE0F ON":"OFF"}</button>`),e("Music","music","",`<button class="btn small toggle ${m.music?"on":"off"}" data-toggle>${m.music?"\u{1F3B5} ON":"OFF"}</button>`),e("Volume","volume",`${g*10}%`,'<button class="btn small white" data-d="-1">\u2212</button>{val}<button class="btn small white" data-d="1">+</button>')].join("");let d=l.players.length&&l.players.every(p=>p.ready);Se(".start-wrap",t).innerHTML=`<button class="btn green ${l.players.length?"pulse":""}" data-start ${l.players.length?"":"disabled"}>${l.players.length?l.players.length===1?"START SOLO \u25B6":"LET'S RACE \u25B6":"Waiting for players\u2026"}</button>
      <div class="hint">${l.refreshing?"\u23F3 Refreshing historical data\u2026":l.players.length?d?"Everyone is ready!":"Press SPACE \u2014 or everyone taps READY on their phone":"Up to 4 players \xB7 best with 2"}</div>
      <button class="btn small white refresh-btn" data-options>\u2699 Options</button>`,r&&o(l)}let s=new Set(n.players.map(l=>l.id)),r=!1;function o(l){let c=Se("#tvmodal.opts");c||(c=uo('<h2 class="outlined white thin">\u2699 Options</h2><div class="optgrid"></div><div class="row"><button class="btn small white" data-refresh>\u27F3 Refresh Historical Data\u2026</button><span style="flex:1"></span><button class="btn green" data-ok>Done <small>ENTER</small></button></div>'),c.classList.add("opts"),c.addEventListener("click",h=>{let m=h.target.closest("button");if(m){if(m.dataset.ok!==void 0){r=!1,Li();return}a(m)}})),Se(".optgrid",c).innerHTML=Se(".settings",t).innerHTML}function a(l){var d;if(oe.play("tick"),l.dataset.refresh!==void 0)return r=!1,ed();let c=(d=l.closest("[data-k]"))==null?void 0:d.dataset.k;if(!c)return;let h=se.settings;if(l.dataset.toggle!==void 0)return An({t:"settings",settings:{[c]:!h[c]}});let m=Number(l.dataset.d),g;if(c==="startingBankroll"){let p=dr.indexOf(h[c]);g=dr[Math.max(0,Math.min(dr.length-1,(p<0?2:p)+m))]}else if(c==="betTimer"){let p=pr.indexOf(h[c]);g=pr[Math.max(0,Math.min(pr.length-1,(p<0?0:p)+m))]}else c==="volume"?g=Math.round(Math.max(0,Math.min(1,(h.volume??.8)+m*.1))*10)/10:g=h[c]+m;return An({t:"settings",settings:{[c]:g}})}return i(n),t.addEventListener("click",l=>{var p;_r();let c=l.target.closest("button");if(!c)return;if(oe.play("tick"),c.dataset.start!==void 0)return Rh();if(c.dataset.refresh!==void 0)return ed();if(c.dataset.options!==void 0)return r=!0,o(se);if(c.dataset.kick)return An({t:"kick",playerId:c.dataset.kick});let h=(p=c.closest("[data-k]"))==null?void 0:p.dataset.k;if(!h)return;let m=se.settings;if(c.dataset.toggle!==void 0)return An({t:"settings",settings:{[h]:!m[h]}});let g=Number(c.dataset.d),d;if(h==="startingBankroll"){let v=dr.indexOf(m[h]);d=dr[Math.max(0,Math.min(dr.length-1,(v<0?2:v)+g))]}else if(h==="betTimer"){let v=pr.indexOf(m[h]);d=pr[Math.max(0,Math.min(pr.length-1,(v<0?0:v)+g))]}else h==="volume"?d=Math.round(Math.max(0,Math.min(1,(m.volume??.8)+g*.1))*10)/10:d=m[h]+g;An({t:"settings",settings:{[h]:d}})}),{update:l=>i(l)}}var kx=()=>!!Se("#tvmodal");function Li(){var n;(n=Se("#tvmodal"))==null||n.remove()}function uo(n){Li();let t=Je(`<div id="tvmodal"><div class="tvm panel white anim-pop">${n}</div></div>`);return gr.appendChild(t),t.addEventListener("click",e=>{e.target===t&&Li()}),t}function Dx(n){Se("#tvauth")||document.body.appendChild(Je(`<div id="tvauth"><div class="panel white" style="padding:30px 40px;max-width:900px;font-size:26px"><h2 style="font-family:var(--font-display);font-weight:400;margin:0 0 10px">\u{1F4FA} Not the TV</h2><p>${Ot(n)}</p></div></div>`))}function Ux(n){_r(),oe.play("bell");let t=uo(`<h2 class="outlined white thin">\u{1F4F1} New phone for ${Ot(n.name||"a player")}?</h2>
    <p>Someone on a <b>new phone</b> wants to take over <b>${Ot(n.name||"")}</b>'s seat (and see their secret clues).</p>
    <p>Only allow it if ${Ot(n.name||"they")} really did switch phones. Auto-denied in 30 seconds.</p>
    <div class="row"><button class="btn white" data-cancel>Deny <small>ESC</small></button><button class="btn green" data-ok>Allow <small>ENTER</small></button></div>`);t.dataset.req=n.reqId,Se("[data-cancel]",t).onclick=()=>{An({t:"claimAnswer",reqId:n.reqId,allow:!1}),Li()},Se("[data-ok]",t).onclick=()=>{An({t:"claimAnswer",reqId:n.reqId,allow:!0}),Li()}}function ed(){if((se==null?void 0:se.phase)!=="LOBBY")return;let n=uo(`<h2 class="outlined white thin">\u27F3 Refresh Historical Data</h2>
    <p><b>This uses the internet.</b> It contacts parkrun, Strava (if set up) and the weather archive to fetch any new runs since the last refresh, then rebuilds the local database.</p>
    <p>It can take a few minutes. The game itself never goes online \u2014 this is the only button that does.</p>
    <div class="row"><button class="btn white" data-cancel>Cancel <small>ESC</small></button><button class="btn green" data-ok>Refresh now <small>ENTER</small></button></div>`);Se("[data-cancel]",n).onclick=Li,Se("[data-ok]",n).onclick=()=>{An({t:"refresh"}),uo('<h2 class="outlined white thin">\u27F3 Refreshing\u2026</h2><div class="rlog"></div><div class="row"><button class="btn white" data-cancel disabled>Working\u2026</button></div>')}}function fd(n,t){let e=Se("#tvmodal .rlog");for(e||(uo('<h2 class="outlined white thin">\u27F3 Refreshing\u2026</h2><div class="rlog"></div><div class="row"><button class="btn white" data-cancel disabled>Working\u2026</button></div>'),e=Se("#tvmodal .rlog")),e.appendChild(Je(`<div class="rl"><b>${Ot(n)}</b> ${Ot(t)}</div>`));e.children.length>9;)e.firstElementChild.remove()}function Nx(n,t){t&&fd("error",t);let e=Se("#tvmodal [data-cancel]");e&&(e.disabled=!1,e.textContent=n?"Done \u2713":"Close",e.onclick=Li),ns(n?"Historical data refreshed!":"Refresh had problems \u2014 existing data kept",n?"":"red")}var nd=null,vr=null,$e=null,es=null,Ja=null,ud=n=>es==="3d"&&typeof(n==null?void 0:n.loadPlan)=="function"&&(typeof(n==null?void 0:n.setBackedBy)=="function"||(n==null?void 0:n.loadPlan.length)>=2);function co(){if($e){try{$e.dispose()}catch(n){console.warn(n)}$e=null,es=null,Ja=null,mr.innerHTML="",document.body.classList.remove("racing")}}async function Ah(n,{allow2d:t=!0}={}){var s,r;co();let e=Th||await Sx,i={course:e.course,park:e.park,speed:Es,...n};if((s=Pi)!=null&&s.createRaceView&&!Wa)try{try{$e=await Pi.createRaceView(mr,i)}catch(o){if(i.plan||!i.round)throw o;mr.innerHTML="",$e=await Pi.createRaceView(mr,{...i,plan:Zu(i.round)})}return Ja=((r=i.round)==null?void 0:r.roundId)||null,es="3d",window.__markrun.raceView=$e,Kn({type:"raceview",kind:"3d"}),$e}catch(o){console.error("3D race view failed, using 2D fallback",o),Kn({type:"raceview-error",msg:String((o==null?void 0:o.message)||o)}),mr.innerHTML=""}return!t||!n.plan?null:($e=zh(mr,i),es="2d",window.__markrun.raceView=$e,Kn({type:"raceview",kind:"2d"}),$e)}function id(n){var e;((e=n.introLines)!=null&&e.length?n.introLines:[{speaker:"jeff",text:`Welcome to Finsbury Park for round ${n.number}: ${n.title}!`}]).slice(0,2).forEach(i=>Oe(i.text,i.speaker,3))}function Fx(n){var u;let t=Za(),e=n.round,i=[...e.runners].sort((f,S)=>f.lane-S.lane),s=Je(`<div class="intro">${hd()}<div class="tint"></div><div class="stagebox"></div><div class="intro-dots">${i.map(()=>"<i></i>").join("")}</div></div>`);ki.appendChild(s);let r=Se(".stagebox",s),o=(n.bailouts||[]).map(f=>{var S;return`${Ot(((S=n.players.find(y=>y.id===f.playerId))==null?void 0:S.name)||"")} got a ${Mn(f.amount)} bailout from the Bank of Mum &amp; Dad`}).join("<br>"),a=`<div class="title-card"><div class="anim-pop"><div class="rn outlined white">ROUND ${e.number} <span style="opacity:.8">of ${n.roundsPerGame}</span></div><div class="rt outlined" style="font-size:${e.title.length>22?104:150}px">${Ot(e.title)}</div><div class="rs">${i.length} runners. All of them Mark. Only one of them is having a good day.</div>${(u=e.theme)!=null&&u.label?`<div class="theme-badge panel slant grape"><div class="unslant"><span class="tk">THEME</span>${Ot(e.theme.label)}</div></div>${e.theme.blurb?`<div class="tblurb">${Ot(e.theme.blurb)}</div>`:""}`:""}${Number(e.payoutMultiplier)>=2?'<div class="double-badge outlined">DOUBLE PAYOUT FINALE \xD72</div>':""}${e.notice?`<div class="bail panel grape" style="color:#fff">\u{1F0CF} ${Ot(e.notice)}</div><br>`:""}${o?`<div class="bail panel yellow">\u{1F4B8} ${o}</div>`:""}</div></div>`,l=f=>{var S;return`<div class="l3 anim-left" style="--c1:${Ot(f.colour.primary)}"><div class="l3p">${yi(f,150)}</div><div class="l3t"><b>${Ot(Ch(f))}</b><span>${Ot(f.tagline||"")}</span></div><div class="l3o"><small>ODDS</small><span class="num">${Ot(((S=f.odds)==null?void 0:S.display)||"")}</span></div></div>`};async function c(f){let S=i[f];hi(".intro-dots i",s).forEach((x,L)=>x.classList.toggle("on",L===f)),r.innerHTML=l(S),oe.play("whoosh"),Oe(S.intro||`${S.nickname}. ${S.tagline||""}`,f%2?"pam":"jeff",3);let y=yo(S.publicClue,8);y.kicker&&!/^…/.test(y.kicker)&&Oe(`${y.headline} ${y.kicker}`,f%2?"jeff":"pam",2),await Bn(t,4800,6500)}async function h(){t.cancelled||(hi(".intro-dots i",s).forEach(f=>f.classList.remove("on")),r.innerHTML='<div class="bets-open"><div class="anim-pop"><div class="big outlined">BETS ARE OPEN!</div><div class="sub2 outlined white thin">\u{1F4F1} Grab your phones \u2014 your secret clues are waiting \u{1F92B}</div></div></div>',oe.play("kaching"),Oe("The book is open! Check your phones for your secret clues.","pam",3),await Bn(t,2500,4e3),t.cancelled||An({t:"introDone",roundId:e.roundId}))}let m=Date.now(),g=setInterval(()=>An({t:"progress",phase:"INTRO",roundId:e.roundId,value:Date.now()-m}),2e3);t.timers.push(g);async function d(){if(e.number!==1||nd===n.gameNumber)return;nd=n.gameNumber,r.innerHTML=`<div class="cold"><div class="cw outlined">MARK<span>RUN</span></div><div class="cs outlined white thin">${Ot(n.players.map(S=>S.name).join(" vs "))}</div><div class="cp">${n.players.map(S=>cn(S.avatar,110)).join('<span class="vsx outlined">VS</span>')}</div></div>`,oe.play("drumroll",{dur:1.4}),setTimeout(()=>{oe.play("fanfare"),oe.play("crowd",{dur:3,peak:.3})},Hn(1500));let f=Xa("coldOpenLines",n.players.map(S=>({name:S.name})))||[{speaker:"jeff",text:`Good evening, ${n.players.map(S=>S.name).join(" and ")}! Welcome to MARKRUN!`}];await _n(1600,t),f.slice(0,2).forEach(S=>Oe(S.text,S.speaker,3)),await Bn(t,6e3,9e3)}async function p(){if(e.number!==1)return;let f=[["\u{1F4FA} + \u{1F92B}","One clue on the telly,","one secret on your phone.","One clue on the telly, one secret on your phone. Read both."],["\u{1F525}","HOT TIP","means the bookie doesn't know this.","If it's got a fire on it, the bookie doesn't know about it. Use it."],["\xBD \xB7 \xD72","Half your pot per round.","The final round pays DOUBLE.","You can bet half your pot each round. The final round pays double. Pace yourselves."]];vr=!1;for(let[S,y,x,L]of f){if(t.cancelled||vr)break;r.innerHTML=`<div class="explain"><div class="anim-pop"><div class="ei">${S}</div><div class="e1 outlined">${Ot(y)}</div><div class="e2 outlined white thin">${Ot(x)}</div></div><div class="eskip">SPACE to skip</div></div>`,oe.play("reveal"),Oe(L,"pam",3);let b=Date.now();for(;!vr&&!t.cancelled&&(Date.now()-b<Hn(4500)||Es<=1.5&&jn.busy&&Date.now()-b<1e4);)await new Promise(T=>setTimeout(T,100))}vr=null,jn.clear()}async function v(f){var x;r.innerHTML=`${a}<div class="lineup">${i.map(L=>{var b;return`<div class="lu"><div class="rp">${yi(L,120)}</div><b>${Ot(As(L))}</b><span class="num">${Ot(((b=L.odds)==null?void 0:b.display)||"")}</span></div>`}).join("")}</div>`,oe.play("fanfare");let S=(e.introLines||[]).find(L=>L.text)||{speaker:"jeff",text:`Round ${e.number}: ${e.title}! Five Marks, one winner.`};Oe(S.text,S.speaker||"jeff",3);let y=i.map(L=>L.tagline).filter(Boolean)[Math.floor(Math.random()*i.length)];if(y&&Oe(y,"pam",2),f)try{let L=f.playIntro(()=>{}),b=i.length;(x=f.seek)==null||x.call(f,((L==null?void 0:L.flyoverS)??7)+b*((L==null?void 0:L.perRunnerS)??4.2)+.5)}catch(L){console.warn(L)}await Bn(t,5e3,11e3)}return(async()=>{var f,S,y,x,L,b;if(await d(),!t.cancelled&&(await p(),!t.cancelled)){if(e.number>=2){let T=null;if(!Wa&&((f=Pi)!=null&&f.createRaceView)&&(T=await Ah({round:e,backedBy:{},introCards:!1},{allow2d:!1}).catch(()=>null),T&&!t.cancelled&&(document.body.classList.add("racing"),s.classList.add("over3d"),(S=s.querySelector(".clouds"))==null||S.remove(),(y=s.querySelector(".hills"))==null||y.remove())),t.cancelled)return;await v(T),await h();return}if(!Wa&&((x=Pi)!=null&&x.createRaceView)){let T=new Map(i.map((M,_)=>[M.id,_])),A=await Ah({round:e,backedBy:{},introCards:!1,onIntroRunner:M=>t.cancelled?void 0:c(T.get(M)??0)},{allow2d:!1}).catch(()=>null);if(A&&!t.cancelled){document.body.classList.add("racing"),s.classList.add("over3d"),(L=s.querySelector(".clouds"))==null||L.remove(),(b=s.querySelector(".hills"))==null||b.remove(),r.innerHTML=a,oe.play("fanfare"),id(e);let M=!1,_=setTimeout(()=>{M||(M=!0,h())},Hn(15e4));t.timers.push(_);try{A.playIntro(()=>{M||(M=!0,clearTimeout(_),h())})}catch(w){console.error(w),M=!0,h()}return}}if(!t.cancelled){r.innerHTML=a,oe.play("fanfare"),id(e),await Bn(t,4200,6e3);for(let T=0;T<i.length&&!t.cancelled;T++)await c(T),t.cancelled||await _n(700,t);await h()}}})(),{destroy:()=>{fo(t)}}}var Ch=n=>n.nickname.length<=18?n.nickname:As(n);function Ox(n){var i;let{headline:t,kicker:e}=yo(n.publicClue,8);return`<div class="rc panel" data-rid="${n.id}">
    <div class="top stripe" style="--c1:${Ot(n.colour.primary)};--c2:${Ot(zx(n.colour.primary))}"><div class="rp">${yi(n,170)}</div></div>
    <div class="odds"><span class="num">${Ot(((i=n.odds)==null?void 0:i.display)||"")}</span></div>
    <div class="nick">${Ot(Ch(n))}</div>
    <div class="clue"><b>${Ot(t)}</b>${e?`<small>${Ot(e)}</small>`:""}</div>
  </div>`}function zx(n){let t=parseInt(String(n).replace("#",""),16),e=i=>Math.round(i+(255-i)*.25);return`#${[t>>16&255,t>>8&255,t&255].map(i=>e(i).toString(16).padStart(2,"0")).join("")}`}function Bx(n){let t=n==null?void 0:n.theme,e=Number(n==null?void 0:n.payoutMultiplier)>=2;return`${t!=null&&t.label?`<div class="theme-badge panel slant grape"><div class="unslant"><span class="tk">THEME</span>${Ot(t.label)}</div></div>`:""}${e?'<div class="double-badge outlined">DOUBLE PAYOUT \xD72</div>':""}`}function Hx(n){let t=(n.matchups||[]).map(i=>{let s=Xn(n,i.a),r=Xn(n,i.b);return!s||!r?"":`<span class="si"><i class="dot" style="background:${Ot(s.colour.primary)}"></i>${Ot(As(s))} <em>${Ot(i.odds.displayA||`\xD7${i.odds.a}`)}</em> <span class="vs">v</span> <i class="dot" style="background:${Ot(r.colour.primary)}"></i>${Ot(As(r))} <em>${Ot(i.odds.displayB||`\xD7${i.odds.b}`)}</em></span>`}),e=(n.props||[]).map(i=>{var s;return`<span class="si prop">\u{1F3A1} ${Ot(i.text)} <em>${Ot(((s=i.odds)==null?void 0:s.displayYes)||"")}</em></span>`});return[...t,...e].filter(Boolean).join('<span class="sep">\xB7</span>')}function Vx(n){var g;let t=n.round,e=[...t.runners].sort((d,p)=>d.lane-p.lane),i=Je(`<div class="betting">
    <div class="bet-head"><div class="h outlined">PLACE YOUR BETS!</div><div class="rt">Round ${t.number}/${n.roundsPerGame} \xB7 ${Ot(t.title)}</div>${Bx(t)}<div class="timer num hidden"></div></div>
    <div class="runner-grid n${e.length}">${e.map(d=>Ox(d)).join("")}</div>
    <div class="bstrip">${Hx(t)}</div>
    ${t.notice?`<div class="notice panel grape">\u{1F0CF} ${Ot(t.notice)}</div>`:""}
  </div>`);ki.appendChild(i),hi(".rc",i).forEach((d,p)=>{d.style.animation=`slide-up .5s ${p*.08}s cubic-bezier(.2,1.3,.4,1) both`});let s=Se(".timer",i),r=null;function o(){if(!(se!=null&&se.deadline)||se.phase!=="BETTING"||se.revealed){s.classList.add("hidden");return}let d=Math.max(0,Math.ceil((se.deadline-qa.serverNow())/1e3));s.classList.remove("hidden"),s.textContent=`${Math.floor(d/60)}:${String(d%60).padStart(2,"0")}`,d<=10&&d!==r&&oe.play("tick"),r=d}let a=setInterval(o,250);o();let l=[["jeff","Each of you has one red-hot insider tip on your phone. Find it. Use it."],["pam","Every one of these runners is Mark. The question is: which Mark turned up?"],["jeff","Head-to-heads are a lovely way to lose money slowly."]];Number(t.payoutMultiplier)>=2?Oe("Final round, and every payout is doubled! Fortunes will be made. Mostly lost.","jeff",3):(g=t.theme)!=null&&g.label&&Oe(`Today's theme: ${t.theme.label}. ${t.theme.blurb||""}`,"pam",2);let c=e.map(d=>({r:d,k:yo(d.publicClue,8).kicker})).filter(d=>d.k&&!/^…/.test(d.k)),h=c[Math.floor(Math.random()*c.length)],m=setTimeout(()=>{if(h)Oe(`${As(h.r)}: ${h.k}`,"pam",1);else{let d=l[Math.floor(Math.random()*l.length)];Oe(d[1],d[0],1)}},Hn(12e3));return{destroy:()=>{clearInterval(a),clearTimeout(m)}}}function Gx(n){let t=Za(),e=n.round,i=[...e.runners].sort((l,c)=>l.lane-c.lane),s=(n.revealSeq||[]).filter(l=>l&&l.bet);if(!s.length){let l=(n.betLines||[]).slice();s=n.players.flatMap(c=>{var h;return(((h=n.bets)==null?void 0:h[c.id])||[]).map(m=>({playerId:c.id,bet:m}))}).sort((c,h)=>c.bet.stake-h.bet.stake).map(c=>({...c,line:l.shift()||null}))}let r=l=>{var c,h;return((h=(c=n.players.find(m=>m.id===l))==null?void 0:c.avatar)==null?void 0:h.colour)||"#fff"},o=Je(`<div class="faceoff">
    <div class="rh outlined">THE BETS ARE IN!</div>
    <div class="fo-grid">${i.map(l=>{var c;return`<div class="fo-card" data-rid="${l.id}"><div class="fo-top" style="background:${Ot(l.colour.primary)}"><div class="rp">${yi(l,150)}</div></div><b>${Ot(Ch(l))}</b><span class="num">${Ot(((c=l.odds)==null?void 0:c.display)||"")}</span><div class="fo-chips"></div></div>`}).join("")}</div>
    <div class="fo-side"></div>
    <div class="fo-legend">${n.players.map(l=>`<span class="lg">${cn(l.avatar,40)}<b>${Ot(l.name)}</b><i data-tot="${l.id}">0pp</i></span>`).join("")}</div>
  </div>`);ki.appendChild(o);let a={};return(async()=>{var h,m,g,d,p;oe.play("drumroll",{dur:1.2/Es+.2}),Oe(s.length?"Right then. The bets, smallest first!":"Nobody has bet a penny. Cowards, the lot of them.","jeff",3),await _n(1300,t);let l=Math.max(1,...s.map(v=>v.bet.stake));for(let v=0;v<s.length&&!t.cancelled;v++){let{playerId:u,bet:f,line:S}=s[v],y=n.players.find(M=>M.id===u),x=go(f),L=v===s.length-1&&s.length>1,b=Je(`<div class="fchip ${L?"big":""} anim-pop" style="--pc:${Ot(r(u))}">${cn(y==null?void 0:y.avatar,34)}<b>${Mn(f.stake)}</b><small>wins +${Mn(el(e,f))}</small>${f.type==="h2h"?"<i>\u2694\uFE0F</i>":f.type==="special"||f.boost?"<i>\u{1F680}</i>":""}</div>`),T=x?o.querySelector(`.fo-card[data-rid="${x}"] .fo-chips`):null;T?T.appendChild(b):Se(".fo-side",o).appendChild(Je(`<div class="fside anim-pop" style="--pc:${Ot(r(u))}">${cn(y==null?void 0:y.avatar,34)}<span>\u{1F3A1} ${Ot(mo(e,f))}</span><b>${Mn(f.stake)}</b><small>wins +${Mn(el(e,f))}</small></div>`)),x&&((h=o.querySelector(`.fo-card[data-rid="${x}"]`))==null||h.classList.add("backed")),oe.play(L?"kaching":"chip",{p:f.stake/l}),a[u]=(a[u]||0)+f.stake;let A=o.querySelector(`[data-tot="${u}"]`);A&&(A.textContent=Mn(a[u])),S!=null&&S.text&&Oe(S.text,S.speaker||"jeff",L?3:1),await _n(L?1600:900,t)}if(t.cancelled)return;let c=[];if(n.players.length>=2){let[v,u]=n.players,f=((m=n.bets)==null?void 0:m[v.id])||[],S=((g=n.bets)==null?void 0:g[u.id])||[];for(let b of f.filter(T=>T.type==="h2h")){let T=S.find(A=>A.type==="h2h"&&A.matchupId===b.matchupId&&A.pick!==b.pick);T&&c.push([b.pick,T.pick])}let y=(b,T)=>b.filter(A=>A.type==="win"||A.type==="special").sort((A,M)=>M.stake-A.stake)[0],x=y(f),L=y(S);if(!c.length&&x&&L&&x.runnerId!==L.runnerId&&x.stake>=.2*v.bankroll&&L.stake>=.2*u.bankroll&&c.push([x.runnerId,L.runnerId]),c.length){for(let T of c[0])(d=o.querySelector(`.fo-card[data-rid="${T}"]`))==null||d.classList.add("clash");o.appendChild(Je('<div class="clash-stamp"><div class="anim-pop outlined">CLASH!</div></div>')),oe.play("sting"),oe.play("stamp");let b=s.map(T=>{var A;return(A=T.line)==null?void 0:A.text}).find(T=>/both|against|clash|opposite|other side/i.test(T||""));Oe(b||`${v.name} and ${u.name} are on opposite sides. Somebody's sleeping on the sofa tonight.`,"pam",3),await _n(2200,t)}}if(await Bn(t,1200,4e3),!t.cancelled){for(let v of(p=Pi)!=null&&p.createRaceView&&!Wa?[]:["3","2","1"]){if(t.cancelled)return;let u=Je(`<div class="countdown outlined anim-pop">${v}</div>`);o.appendChild(u),oe.play("beep"),await _n(700,t),u.remove()}t.cancelled||An({t:"revealDone",roundId:e.roundId})}})(),{destroy:()=>fo(t)}}function sd(n){let t=n.market,e=n.round;if(!t)return'<div class="mk-wait outlined white thin">Opening the market\u2026</div>';let i=new Set(n.players.filter(r=>{var o;return(((o=n.bets)==null?void 0:o[r.id])||[]).some(a=>a.type==="inplay")}).map(r=>r.id));return`<div class="mk panel white"><div class="mkh"><span class="outlined">HALFWAY MARKET</span><span class="mkt num" data-mkt></span></div>
    <div class="mks">One bet each, on your phone. Prices from the standings right now.</div>
    <div class="mkrows">${(t.standings||[]).map(r=>{var l;let o=Xn(e,r.runnerId),a=(l=t.odds)==null?void 0:l[r.runnerId];return`<div class="mkrow">${ss(r.place)}<span class="rp">${o?yi(o,64):""}</span><span class="nm">${Ot((o==null?void 0:o.nickname)||r.runnerId)}</span><span class="gp">${r.place===1?"LEADS":`+${Number(r.gapS).toFixed(1)}s`}</span><span class="od num">${Ot((a==null?void 0:a.display)||"")}</span></div>`}).join("")}</div>
    <div class="mkp">${n.players.map(r=>`<span class="mkpl ${i.has(r.id)?"in":""}">${cn(r.avatar,44)}${Ot(r.name)} ${i.has(r.id)?"\u2713 IN":"\u2026"}</span>`).join("")}</div></div>`}function Wx(n){let t=Za(),e=n.round,i=Je(`<div class="race-ov"><div class="live panel slant red"><div class="unslant" style="display:flex;gap:14px;align-items:center"><span class="dot"></span>LIVE \xB7 ${Ot(e.title)}</div></div><div class="market-layer"></div><div class="ifnow"></div><div class="stamps"></div></div>`);ki.appendChild(i),document.body.classList.add("racing");let s=Se(".market-layer",i),r=0,o=0,a="idle",l=Se(".ifnow",i),c={},h=null;function m(b){let T=n.racePlan,A=Ui(T.timeMap,Math.max(0,b));return T.runners.map(M=>({id:M.id,d:li(M.progress,A),f:M.officialS,done:A>=M.officialS})).sort((M,_)=>M.done&&_.done?M.f-_.f:_.d-M.d||M.f-_.f).map(M=>M.id)}function g(b){let T=b==null?void 0:b.broadcastTime;if(!Number.isFinite(T)||T<3||!(se!=null&&se.bets))return;let A;try{A=Ka(se.round,se.bets,m(T))}catch{return}l.children.length||(l.innerHTML=se.players.map(M=>`<div class="ifp" data-pid="${M.id}">${cn(M.avatar,40)}<span class="nm">${Ot(M.name)}</span><b class="num">\xB10</b></div>`).join("")+'<div class="ifl">if it ended now</div>');for(let M of se.players){let _=Math.round((A==null?void 0:A[M.id])??0);if(c[M.id]===_)continue;let w=l.querySelector(`.ifp[data-pid="${M.id}"]`);if(!w)continue;let P=w.querySelector("b"),E=c[M.id];if(c[M.id]=_,E==null){P.textContent=Ni(_);continue}Qa(P,E,_,600,F=>Ni(F)),w.classList.remove("up","down"),w.offsetWidth,w.classList.add(_>E?"up":"down")}}let d=!1;function p(){if(d||t.cancelled)return;d=!0;let b={};try{b=Ka(se.round,se.bets||{},n.racePlan.finishOrder)}catch{}let T=Se(".stamps",i);se.players.forEach((A,M)=>{let _=Math.round(b[A.id]??0);setTimeout(()=>{if(t.cancelled)return;T.appendChild(Je(`<div class="stamp ${_>0?"win":_<0?"lose":""}" style="--c:${Ot(A.avatar.colour)}">${cn(A.avatar,70)}<span>${Ot(A.name.toUpperCase())} ${_>0?`WINS ${Mn(_)}`:_<0?Ni(_):"BREAKS EVEN"}</span></div>`)),oe.play(_>0?"kaching":_<0?"boo":"stamp");let w=Xa("stampLine",{name:A.name,net:_});w&&Oe(w.text,w.speaker,3)},Hn(350+M*1100))})}let v=!1,u=null,f=null,S=null;async function y(b){a="waiting";try{b.setPaused(!0,{market:!0,marketText:"Bet on your phones \u2014 one bet each!"})}catch{}if(oe.play("bell"),oe.play("crowd",{dur:2,peak:.2}),jn.clear(),xr.innerHTML="",Oe("Halfway! The market is open. One bet each \u2014 quick!","jeff",3),An({t:"marketOpen",roundId:e.roundId}),s.innerHTML=sd(se),S=setInterval(()=>{var A;let T=s.querySelector("[data-mkt]");if(T&&((A=se==null?void 0:se.market)!=null&&A.closesAt)){let M=Math.max(0,Math.ceil((se.market.closesAt-qa.serverNow())/1e3));M<=10&&M!==T.dataset.last*1&&(T.dataset.last=M,oe.play("tick")),T.textContent=`${M}s`}},200),await new Promise(T=>{u=T,setTimeout(T,2e4),t.timers.push(setTimeout(()=>{se!=null&&se.market||T()},3500))}),clearInterval(S),a="done",s.innerHTML="",!t.cancelled){Oe("Market closed! Back to the action!","pam",2);try{b.setPaused(!1)}catch{}}}let x=Date.now(),L=setInterval(()=>An({t:"raceTime",roundId:e.roundId,b:-1e5+(Date.now()-x)/1e3}),2e3);return t.timers.push(L),(async()=>{var A,M;let b=null;if($e&&Ja===e.roundId&&ud($e))try{typeof $e.setBackedBy=="function"?($e.setBackedBy(n.backedBy||{}),$e.loadPlan(n.racePlan)):$e.loadPlan(n.racePlan,{backedBy:n.backedBy||{}}),$e.setPaused(!1),b=$e,Kn({type:"raceview",kind:"3d",reused:!0})}catch(_){console.warn("could not re-use the intro view",_)}if(b||(b=await Ah({round:e,plan:n.racePlan,backedBy:n.backedBy||{},onWinnerStamp:()=>p()})),clearInterval(L),t.cancelled)return;if(!b){i.appendChild(Je('<div class="race-err panel red">Race view failed to load</div>'));return}document.body.classList.add("racing"),es==="3d"&&((A=i.querySelector(".live"))==null||A.remove()),es!=="3d"?(oe.play("horn"),setTimeout(()=>oe.play("crowd",{dur:3,peak:.25}),300),Oe("And they're off!","jeff",3)):oe.play("crowd",{dur:4,peak:.2}),Kn({type:"race-start",kind:es}),f=setInterval(()=>{let _=b.broadcastTime;Number.isFinite(_)&&An({t:"raceTime",roundId:e.roundId,b:_})},1e3),h=setInterval(()=>g(b),500),b.playRace(_=>{var w;if(!(t.cancelled||!_)){if(Kn({type:"race-event",e:_.type||"line",text:_.text}),_.kind==="countdown"){oe.play(_.n===0?"go":"beep"),_.n===0&&(oe.play("horn"),oe.play("crowd",{dur:3,peak:.28}));return}if(_.kind==="photo_finish"){oe.play("stamp"),oe.play("heartbeat",{beats:5}),Oe("It's a photo finish! Hold your breath!","pam",3);return}if(_.kind==="winner_replay_done"){p();return}if(_.text&&(_.kind==="commentary"||!_.type)){a!=="waiting"&&jn.say(_.text,_.speaker||"jeff",{priority:_.priority||2});return}switch(_.type){case"overtake":Date.now()-r>1500&&(r=Date.now(),oe.play("whoosh"));break;case"lead_change":oe.play("whoosh"),oe.play("crowd",{dur:2,peak:.18});break;case"breakaway":oe.play("crowd",{dur:2.5,peak:.2});break;case"lap":a==="idle"&&(se!=null&&se.marketAvailable)?(Kn({type:"market"}),y(b)):oe.play("bell");break;case"final_stretch":oe.play("crowd",{dur:6,peak:.4}),((w=se==null?void 0:se.settings)==null?void 0:w.music)!==!1&&oe.startMusic("final");break;case"finish":o++,o===1&&(oe.stopMusic(.6),oe.play("fanfare"),oe.play("crowd",{dur:4,peak:.45}));break;default:break}}},async()=>{t.cancelled||(Kn({type:"race-done"}),d||(p(),await _n(400+se.players.length*1100,t)),await _n(2500,t),t.cancelled||An({t:"raceDone",roundId:e.roundId}))});let T=Number(n.resumeB)||0;if(T>2)try{typeof b.seek=="function"?b.seek(T):(M=b._debug)!=null&&M.seek&&(b._debug.seek(T),b.setPaused(!1)),Kn({type:"race-resume",b:T}),ns("Back on air! Resuming the race\u2026")}catch(_){console.warn("resume failed",_)}})(),{update(b){var T,A,M,_,w,P,E;if(a==="waiting"){if(b.market&&!b.market.open){u==null||u();return}if(b.market&&!v){v=!0;let F=((T=b.market.standings)==null?void 0:T.find(z=>z.place===1))||((A=b.market.standings)==null?void 0:A[0]),R=(M=b.market.standings)==null?void 0:M.find(z=>z.place===2),N=Xn(b.round,F==null?void 0:F.runnerId),U=Xn(b.round,R==null?void 0:R.runnerId);N&&Oe(`${N.nickname} leads at halfway and is now ${((w=(_=b.market.odds)==null?void 0:_[F.runnerId])==null?void 0:w.display)||"odds-on"}.${U?` ${U.nickname}, ${Number(R.gapS).toFixed(1)} seconds back, is ${((E=(P=b.market.odds)==null?void 0:P[R.runnerId])==null?void 0:E.display)||""}.`:""}`,"jeff",3)}s.innerHTML=sd(b)}},destroy:()=>{fo(t),clearInterval(f),clearInterval(S),clearInterval(h),u==null||u(),oe.stopMusic(.8)}}}function $x(n){let t=null,e=-1,i=Je('<div class="results"></div>');ki.appendChild(i);let s=n.round,r=n.results;function o(u,f){return f.players.filter(S=>{var y;return(((y=f.bets)==null?void 0:y[S.id])||[]).some(x=>go(x)===u)}).map(S=>cn(S.avatar,50))}let a=(u,f="")=>`<div class="res-head"><div class="h outlined">${u}</div>${f?`<div class="sh">${f}</div>`:""}</div>`,l=u=>{t.cancelled||An({t:"stageDone",stage:u})};async function c(u){let f=t,S=r.finishOrder.map(L=>{var T;let b=Xn(s,L.runnerId);return`<div class="orow panel slant ${L.place===1?"first":""}" style="${L.place===1?"":`background:${Ot(((T=b==null?void 0:b.colour)==null?void 0:T.primary)||"#2a62e0")}`}"><div class="unslant" style="display:flex;align-items:center;gap:26px;width:100%">
        ${ss(L.place)}<div class="rp">${b?yi(b,112):""}</div>
        <div class="nm ${L.place===1?"":"outlined white thin"}">${Ot((b==null?void 0:b.nickname)||L.runnerId)}${r.favouriteId===L.runnerId?' <span class="fav">FAV</span>':""}<small>${Ot((b==null?void 0:b.tagline)||"")}</small></div>
        <div class="bk">${o(L.runnerId,u).join("")}</div>
        <div class="tm"><span class="num">${Ot(L.timeText||kh(L.officialS))}</span>${L.place>1&&L.gapS!=null?`<span class="gap">+${Math.round(L.gapS)}s</span>`:""}</div></div></div>`});i.innerHTML=a("THE RESULT","Official times, as recorded by the volunteers \u{1F4CB}")+`<div class="order">${S.join("")}</div>`;let y=hi(".orow",i);for(let L=y.length-1;L>=0;L--){if(f.cancelled)return;y[L].classList.add("show"),L===0?(oe.play("fanfare"),Mr(document.body,{count:90})):oe.play("pop"),await _n(L===1?1600:800,f)}(r.commentary||[]).slice(0,2).forEach(L=>Oe(L.text,L.speaker,3)),await Bn(f,4e3,7e3),l(0)}async function h(){var A,M,_;let u=t,f=r.finishOrder.map(w=>w.runnerId),S=new Map((r.reveal||[]).map(w=>[w.runnerId,w]));i.innerHTML=a("WHO WERE THEY REALLY?","Every runner was a real Mark, on a real Saturday \u{1F575}\uFE0F \u2014 details on your phones")+`<div class="reveal-grid">${f.map((w,P)=>{var N,U;let E=Xn(s,w),F=S.get(w)||{},R=r.finishOrder[P];return`<div class="rv" data-i="${P}">
        <div class="face front" style="background:${Ot((N=E==null?void 0:E.colour)==null?void 0:N.primary)}"><div><div class="rp">${E?yi(E,220):""}</div><div class="q outlined">?</div></div></div>
        <div class="face back"><div class="bh" style="background:${Ot((U=E==null?void 0:E.colour)==null?void 0:U.primary)}"><div class="rp">${E?yi(E,74):""}</div><div class="n">${Ot((E==null?void 0:E.nickname)||w)}</div></div>
          <div class="date">${Ot(F.dateText||F.date||F.headline||"")}</div>
          <div class="time num">${Ot((R==null?void 0:R.timeText)||"")}</div>
          ${(()=>{let z=(F.funFacts||[]).filter(Boolean),Z=!F.stravaTitle||/^(morning|lunch|afternoon|evening|night)\s+(run|jog)$/i.test(String(F.stravaTitle).trim())||/^(run|parkrun)$/i.test(String(F.stravaTitle).trim()),Y=Z?z[0]?`<div class="strava fact"><span class="k">DID YOU KNOW?</span>${Ot(z[0])}</div>`:"":`<div class="strava"><span class="k">STRAVA TITLE</span>\u201C${Ot(F.stravaTitle)}\u201D</div>`,mt=(Array.isArray(F.context)?F.context[0]:F.context||F.contextLine||F.contextText)||F.punchline||z[Z?1:0];return Y+(mt?`<div class="ff">${Ot(mt)}</div>`:"")})()}
          ${F.wasPB||F.pbKind?`<div class="pb">${F.pbKind==="finsbury"?"COURSE PB!":"PB! \u{1F3C5}"}</div>`:""}
          <div class="place">${ss((R==null?void 0:R.place)||P+1)}</div>
        </div></div>`}).join("")}</div>`;let y=hi(".rv",i);await _n(900,u);for(let w=y.length-1;w>=0;w--){if(u.cancelled)return;y[w].classList.add("flip");let P=S.get(f[w]),E=Xn(s,f[w]);oe.play(w===0?"fanfare":"reveal"),w===y.length-1&&y.length>1&&Oe(`And in last place, ${E==null?void 0:E.nickname}: ${(P==null?void 0:P.dateText)||""}`,"pam",2),w===0&&(y[0].classList.add("winner-big"),Oe(`The winner, ${E==null?void 0:E.nickname}: ${(P==null?void 0:P.dateText)||""}, ${((A=r.finishOrder[0])==null?void 0:A.timeText)||""}.`,"jeff",3)),await _n(w===0?1800:2200,u)}let x=S.get(f[0])||{},L=!x.stravaTitle||/^(morning|lunch|afternoon|evening|night)\s+(run|jog)$/i.test(String(x.stravaTitle).trim()),b=x.punchline||(L?"":`\u201C${x.stravaTitle}\u201D`);await Bn(u,900,5e3),b&&!u.cancelled&&(i.appendChild(Je(`<div class="punch"><div class="anim-pop">${Ot(b)}</div></div>`)),oe.play("stamp"),Oe(b.replace(/[“”]/g,""),"pam",3));let T=typeof r.realMarkFact=="string"?r.realMarkFact:(M=r.realMarkFact)==null?void 0:M.text;T&&!u.cancelled&&(await Bn(u,2200,6e3),(_=i.querySelector(".punch"))==null||_.remove(),i.appendChild(Je(`<div class="punch rmf"><div class="anim-pop"><small>THE REAL MARK</small>${Ot(T)}</div></div>`)),Oe(T,"jeff",3)),await Bn(u,3e3,6e3),l(1)}async function m(u){let f=t,S=r.clueReview||[],y=S.filter(b=>b.highlight).slice(0,3);if(y.length||(y=S.filter(b=>b.verdict!=="neutral").slice(0,3)),!y.length){i.innerHTML="",await _n(300,f),l(2);return}let x=new Map((u.clues||[]).map(b=>[b.id,b]));i.innerHTML=a("THE CLUES THAT MATTERED","Useful\u2026 or a red herring? \u{1F41F}")+`<div class="clue-list big">${y.map(b=>{let T=Xn(s,b.runnerId),A=x.get(b.clueId),M=u.players.find(P=>P.id===b.owner),_=b.owner==="public"?`\u{1F4FA} PUBLIC CLUE${A!=null&&A.label?` \xB7 ${Ot(A.label.toUpperCase())}`:""}`:`${(A==null?void 0:A.tier)==="hot"?"\u{1F525}":"\u{1F92B}"} ${Ot((M==null?void 0:M.name)||"Secret")}'S ${(A==null?void 0:A.tier)==="hot"?"HOT TIP":"SECRET CLUE"}`,w={useful:"USEFUL \u2713",red_herring:"RED HERRING \u{1F41F}",neutral:"MEH"}[b.verdict]||Ot(b.verdict);return`<div class="cl panel"><div class="rp">${T?yi(T,100):""}</div><div class="txt"><div class="own">${_} \xB7 ${Ot((T==null?void 0:T.nickname)||"")}</div>${Ot(b.text||(A==null?void 0:A.text)||"")}${b.quip?`<div class="quip">${Ot(b.quip)}</div>`:""}</div><div class="verdict ${Ot(b.verdict)}">${w}</div></div>`}).join("")}</div>`;let L=hi(".cl",i);for(let b=0;b<L.length;b++){if(f.cancelled)return;L[b].classList.add("show"),setTimeout(()=>{oe.play("sting"),oe.play("stamp")},Hn(250)),y[b].quip&&Oe(y[b].quip,b%2?"jeff":"pam",2),await Bn(f,2500,5e3)}await Bn(f,2e3,4e3),l(2)}async function g(u){var b;let f=t,S=u.settings.drinkingMode;i.innerHTML=a("PAY DAY","The bookie settles up \u{1F4B0}")+`<div class="payouts">${u.players.map(T=>{var _;let A=((_=r.payouts)==null?void 0:_[T.id])||{bets:[],net:0,bankroll:T.bankroll},M=(A.bets||[]).map(w=>{let P=tl(w);return`<div class="pl ${P.kind==="won"?"won":P.kind==="push"?"push":"lost"}"><span class="mark">${P.kind==="won"?"\u2705":P.kind==="push"?"\u21A9\uFE0F":"\u274C"}</span><div class="lb">${Ot(mo(s,w))}<small>staked ${Mn(w.stake)} \xB7 ${Ot(Dh(s,w))}${P.kind==="won"?` \xB7 returned ${Mn(w.returned)}`:""}</small></div><div class="r">${P.text}</div></div>`}).join("")||'<div class="pl show"><div class="lb">No bets placed. Sensible. Boring.</div></div>';return`<div class="pay panel slant" data-pid="${T.id}" style="background:${Ot(T.avatar.colour)}"><div class="unslant" style="display:flex;flex-direction:column;height:100%">
        <div class="who">${cn(T.avatar,90)}${Ot(T.name)}</div>
        <div class="lines">${M}</div>
        <div class="net num outlined ${A.net>0?"green":A.net<0?"red":"white"}" data-net="${A.net}" style="visibility:hidden">${Ni(A.net)}</div>
        ${S?d(A.net,T.id):""}
      </div></div>`}).join("")}</div>${Xx(u,!0)}`,await _n(600,f);for(let T of hi(".pl",i)){if(f.cancelled)return;T.classList.add("show"),oe.play(T.classList.contains("won")?"kaching":"pop"),await _n(700,f)}await _n(400,f);let y=null,x=null;for(let T of u.players){let A=(b=r.payouts)==null?void 0:b[T.id];if(!A)continue;let M=i.querySelector(`.pay[data-pid="${T.id}"]`),_=M.querySelector(".net"),w=null;_.style.visibility="visible",_.classList.add("anim-pop"),(!y||A.net>y.net)&&(y={...A,p:T,panel:M}),(!x||A.net<x.net)&&(x={...A,p:T,panel:M})}if(qx(i,u),y&&y.net>0&&oe.play("coins",{n:Math.min(30,8+Math.round(y.net/40))}),await _n(1900,f),f.cancelled)return;let L=u.settings.drinkingMode?(r.drinks||[]).filter(T=>!T.playerId):[];L.length&&i.appendChild(Je(`<div class="drink-all panel yellow anim-pop">\u{1F37B} ${L.map(T=>Ot(T.text)).join(" \xB7 ")}</div>`)),y&&y.net>0&&(oe.play("kaching"),Mr(document.body,{count:140}),y.panel.classList.add("big-win"),y.panel.appendChild(Je('<div class="mood">\u{1F911}</div>')),Oe(Yx(y.p.name,y.net),"jeff",3)),x&&x.net<0&&(setTimeout(()=>oe.play("sadtrombone"),Hn(900)),x.panel.classList.add("big-loss"),x.panel.appendChild(Je('<div class="raincloud">\u{1F327}\uFE0F</div>')),Oe(Zx(x.p.name,x.net),"pam",3)),!(y!=null&&y.net)&&!(x!=null&&x.net)&&Oe("Nobody won, nobody lost. The bookie is furious.","pam",2),await Bn(f,5e3,8e3),l(3)}function d(u,f){if(Array.isArray(r.drinks))return r.drinks.filter(y=>y.playerId===f).map(y=>`<div class="drink panel yellow">\u{1F37A} ${Ot(y.text)}</div>`).join("");if(u<0){let S=Math.min(5,Math.max(1,Math.ceil(-u/100)));return`<div class="drink panel yellow">\u{1F37A} Take ${S} sip${S>1?"s":""}!</div>`}if(u>0){let S=Math.min(5,Math.max(1,Math.ceil(u/150)));return`<div class="drink panel yellow">\u{1F449} Hand out ${S} sip${S>1?"s":""}</div>`}return'<div class="drink panel yellow">\u{1F964} Water break</div>'}async function p(u){var y,x;let f=t,S=r.awards||[];if(!S.length&&!((y=r.archetype)!=null&&y.label)){await _n(200,f),l(4);return}i.innerHTML=a("ROUND AWARDS","\u{1F3C6}")+`<div class="awards">${(x=r.archetype)!=null&&x.label?`<div class="arch panel yellow anim-pop"><div class="al display">${Ot(r.archetype.label)}</div><div class="ab">${Ot(r.archetype.blurb||"")}</div></div>`:""}${S.map(L=>{let b=u.players.find(T=>T.id===L.playerId);return`<div class="award panel slant ${b?"":"yellow"}" style="${b?`background:${Ot(b.avatar.colour)}`:""}"><div class="unslant" style="display:flex;align-items:center;gap:28px"><span class="trophy">\u{1F3C6}</span>${b?cn(b.avatar,84):""}<div><div class="at outlined white thin">${Ot(L.title)}${b?` \u2014 ${Ot(b.name)}`:" \u2014 everyone"}</div><div class="ax" style="color:${b?"#fff":"var(--ink)"}">${Ot(L.text||"")}</div></div></div></div>`}).join("")}</div>`;for(let L of hi(".award",i)){if(f.cancelled)return;L.classList.add("show"),oe.play("fanfare"),await _n(1500,f)}S[0]&&Oe(`${S[0].title}! ${S[0].text||""}`,"jeff",2),await Bn(f,4500,7e3),l(4)}function v(u){var y;if(u.resultsStage===e)return;t&&fo(t),t=Za();let f=e===-1;e=u.resultsStage,jn.clear(),xr.innerHTML="",f||ad();let S=u.resultStages[u.resultsStage];if(Kn({type:"results-stage",stage:S}),S!=="order"&&$e&&co(),S==="order"&&$e&&es==="3d")try{(y=$e.showPodium)==null||y.call($e,r,{card:!1})}catch(x){console.warn(x)}else $e&&S==="order"&&co();document.body.classList.toggle("racing",!!$e),({order:c,reveal:h,clues:m,payouts:g,awards:p}[S]||(async()=>l(u.resultsStage)))(u).catch(x=>console.error(x))}return r&&v(n),{update:u=>{u.results&&v(u)},destroy:()=>{t&&fo(t),co()}}}function Xx(n,t){let e=n.results,i=n.players.map(r=>{var l;let o=(l=e==null?void 0:e.payouts)==null?void 0:l[r.id],a=(o==null?void 0:o.bankroll)??r.bankroll;return{p:r,before:Math.max(0,a-((o==null?void 0:o.net)||0)),after:Math.max(0,a)}}),s=i.reduce((r,o)=>r+(t?o.before:o.after),0)||1;return`<div class="tug">${i.map(r=>`<div class="seg" data-pid="${r.p.id}" data-after="${r.after}" style="flex-grow:${Math.max(1e-4,(t?r.before:r.after)/s)};background:${Ot(r.p.avatar.colour)}">${cn(r.p.avatar,56)}<b class="num" data-from="${r.before}">${Mn(t?r.before:r.after)}</b></div>`).join("")}</div>`}function qx(n,t){let e=hi(".tug .seg",n),i=e.reduce((s,r)=>s+Number(r.dataset.after),0)||1;e.forEach(s=>{s.style.flexGrow=String(Math.max(1e-4,Number(s.dataset.after)/i));let r=s.querySelector("b");Qa(r,Number(r.dataset.from),Number(s.dataset.after),Hn(1600),o=>Mn(o))})}function Yx(n,t){let e=[`${n} cleans up! Up ${Fi(t)}. Insufferable for the rest of the evening.`,`Kerching! ${n} is ${Fi(t)} richer and won't let anyone forget it.`,`${n} read that race like a book.`];return e[Math.floor(Math.random()*e.length)]}function Zx(n,t){let e=[`Oh dear. ${n} is down ${Fi(-t)}. The bank of Mark is not sympathetic.`,`${n} backed the wrong Mark. It happens to the best of us. Mostly to ${n}.`,`That's ${Fi(-t)} gone, ${n}. Thoughts and prayers.`];return e[Math.floor(Math.random()*e.length)]}function Jx(n,{compact:t=!1}={}){let e=cd(n.players),i=n.history.at(-1);return[...n.players].sort((s,r)=>r.bankroll-s.bankroll).map(s=>{var a;let r=e.get(s.id),o=((a=i==null?void 0:i.nets)==null?void 0:a[s.id])??0;return`<div class="srow panel slant ${r===1&&!t?"lead":""}" style="${r===1&&!t?"":`background:${Ot(s.avatar.colour)}`}"><div class="unslant" style="display:flex;align-items:center;gap:26px;width:100%">
      ${ss(r)}${cn(s.avatar,t?70:96)}<div class="nm">${Ot(s.name)}</div>
      ${t?"":`<span class="dl ${o>0?"up":o<0?"down":"flat"}">${Ni(o)}</span>`}
      <div class="bk num">${Mn(s.bankroll)}</div>
      ${!t&&s.ready?'<span class="tag" style="background:var(--grass);color:#fff">\u2713 READY</span>':""}
    </div></div>`}).join("")}function Kx(n){let t=n.history,e=n.settings.startingBankroll,i=n.players.map(v=>({p:v,pts:[e,...t.map(u=>{var f;return((f=u.bankrolls)==null?void 0:f[v.id])??e})]})),s=Math.max(2,(t.length||0)+1),r=Math.max(e*1.2,...i.flatMap(v=>v.pts)),o=540,a=420,l=36,c=v=>l+v*(o-l*2)/(s-1),h=v=>a-l-v/r*(a-l*2),m=[0,.5,1].map(v=>`<line x1="${l}" x2="${o-l}" y1="${h(r*v)}" y2="${h(r*v)}" stroke="#14183c22" stroke-width="2"/>`).join(""),g=`<line x1="${l}" x2="${o-l}" y1="${h(e)}" y2="${h(e)}" stroke="#14183c55" stroke-width="2" stroke-dasharray="8 8"/>`,d=i.map(({p:v,pts:u})=>`<polyline fill="none" stroke="#14183c" stroke-width="12" stroke-linejoin="round" stroke-linecap="round" points="${u.map((f,S)=>`${c(S)},${h(f)}`).join(" ")}"/><polyline fill="none" stroke="${Ot(v.avatar.colour)}" stroke-width="6" stroke-linejoin="round" stroke-linecap="round" points="${u.map((f,S)=>`${c(S)},${h(f)}`).join(" ")}"/>${u.map((f,S)=>`<circle cx="${c(S)}" cy="${h(f)}" r="8" fill="${Ot(v.avatar.colour)}" stroke="#14183c" stroke-width="4"/>`).join("")}`).join(""),p=Array.from({length:s},(v,u)=>`<text x="${c(u)}" y="${a-6}" text-anchor="middle" font-family="Lilita One" font-size="20" fill="#14183c">${u===0?"Start":`R${u}`}</text>`).join("");return`<svg viewBox="0 0 ${o} ${a}" width="100%" height="440">${m}${g}${d}${p}</svg>`}function jx(n,t){var o,a;let e=n.results;if(!((o=e==null?void 0:e.finishOrder)!=null&&o.length))return"";let i=Xn(n.round,e.finishOrder[0].runnerId),s=n.players.map(l=>{var m;let c=(m=e.payouts)==null?void 0:m[l.id],h=((c==null?void 0:c.bets)||[]).filter(g=>g.won).sort((g,d)=>d.returned-g.returned)[0];return`<div class="rcp">${cn(l.avatar,54)}<span class="rn">${Ot(l.name)}</span><span class="rx">${h?`\u2705 ${Ot(mo(n.round,h))} <b class="bw">${Ni(tl(h).net)}</b>`:((c==null?void 0:c.bets)||[]).length?"\u274C nothing came in":"\u{1F648} no bets"}</span><span class="rnet ${(c==null?void 0:c.net)>0?"up":(c==null?void 0:c.net)<0?"down":""}"><small>net</small> ${Ni((c==null?void 0:c.net)||0)}</span></div>`}).join(""),r=(e.awards||[]).slice(0,2).map(l=>{let c=n.players.find(h=>h.id===l.playerId);return`<span class="raw">\u{1F3C6} ${Ot(l.title)}${c?` \xB7 ${Ot(c.name)}`:""}</span>`}).join("");return`<div class="recap panel white ${t?"narrow":""}"><div class="rch"><span class="rp">${i?yi(i,64):""}</span><span>Last race: <b>${Ot((i==null?void 0:i.nickname)||"")}</b> won${(a=e.archetype)!=null&&a.label?` \xB7 ${Ot(e.archetype.label)}`:""}</span>${r}</div>${s}</div>`}function Qx(n){let t=Je('<div class="score"></div>');ki.appendChild(t);let e=null;function i(r){let a=r.roundNumber>=r.roundsPerGame?"\u{1F3C1} That was the final round! Champion next\u2026":r.roundNumber===r.roundsPerGame-1?"Up next: THE FINAL ROUND \u{1F62C}":`Up next: Round ${r.roundNumber+1} of ${r.roundsPerGame}`,l=r.history.length>=2;t.innerHTML=`<div class="res-head"><div class="h outlined">STANDINGS</div><div class="sh">After round ${r.roundNumber} of ${r.roundsPerGame}</div></div>
      <div class="standings ${l?"":"solo"}">${Jx(r)}</div>
      ${l?`<div class="chart panel white"><div class="ct">The money, round by round</div>${Kx(r)}</div>`:""}
      ${jx(r,l)}
      <div class="upnext panel yellow">${a}<span class="cd"></span></div>`}i(n);let s=[...n.players].sort((r,o)=>o.bankroll-r.bankroll);if(s.length>=2){let r=s[0].bankroll-s[1].bankroll;Oe(r===0?"It's dead level at the top!":`${s[0].name} leads by ${Fi(r)}.`,"jeff",2)}else s[0]&&Oe(`${s[0].name} is on ${Fi(s[0].bankroll)}.`,"jeff",2);return e=setInterval(()=>{let r=t.querySelector(".cd");if(!(!r||!se))if(se.deadline&&se.phase==="SCOREBOARD"){let o=Math.max(0,Math.ceil((se.deadline-qa.serverNow())/1e3));r.textContent=` \u2014 starting in ${o}\u2026`}else r.textContent=se.players.length?" \u2014 tap READY on your phones":""},300),{update:i,destroy:()=>clearInterval(e)}}function t_(n){let t=[...n.players].sort((p,v)=>v.bankroll-p.bankroll),e=t[0],i=t.length>1&&t[1].bankroll===(e==null?void 0:e.bankroll),s=(n.history||[]).flatMap(p=>(p.awards||[]).filter(v=>v.text).map(v=>({title:v.title,text:`${v.text} (round ${p.round})`,playerId:v.playerId}))).slice(0,3),r=[...(n.superlatives||[]).filter(p=>p&&p.title&&p.text),...s].slice(0,7),o=Je(`<div class="finale"><div class="rays"></div><div class="fconf"></div>
    <div class="champ">${e?`<div class="h outlined">${i?"IT'S A DRAW!":"CHAMPION!"}</div>
      <div class="who"><div class="crown">\u{1F451}</div>${cn(e.avatar,200)}<div class="nm outlined white">${Ot(i?t.filter(p=>p.bankroll===e.bankroll).map(p=>p.name).join(" & "):e.name)}</div><div class="bk num">${Mn(e.bankroll)}</div></div>`:'<div class="h outlined">GAME OVER</div>'}
      <div class="others">${t.slice(1).map((p,v)=>`<div class="srow panel slant" style="background:${Ot(p.avatar.colour)}"><div class="unslant" style="display:flex;align-items:center;gap:20px">${ss(v+2)}${cn(p.avatar,64)}<div class="nm">${Ot(p.name)}</div><div class="bk num">${Mn(p.bankroll)}</div></div></div>`).join("")}</div>
    </div>
    <div class="reel">${r.length?'<div class="reel-h outlined white thin">THE NIGHT IN AWARDS</div><div class="reel-card"></div><div class="reel-dots"></div>':""}</div>
  </div>`);ki.appendChild(o);let a=Se(".fconf",o);oe.play("drumroll",{dur:1.6}),setTimeout(()=>{oe.play("fanfare"),oe.play("crowd",{dur:5,peak:.45}),Mr(a,{count:200,duration:4500,contained:!0,zIndex:0})},Hn(1700));let l=setInterval(()=>Mr(a,{count:50,duration:3500,contained:!0,zIndex:0}),Hn(7e3));e&&Oe(i?"We have a dead heat! Nobody wins, which is very British.":`Ladies and gentlemen, your MARKRUN champion: ${e.name}, with ${Fi(e.bankroll)}!`,"jeff",3);let c=0,h=null,m=Se(".reel-card",o);function g(){if(!m||!r.length)return;let p=r[c%r.length],v=n.players.find(u=>u.id===p.playerId);m.innerHTML=`<div class="rc2 panel ${v?"":"yellow"} anim-pop" style="${v?`background:${Ot(v.avatar.colour)}`:""}"><div class="tro">\u{1F3C6}</div>${v?cn(v.avatar,84):""}<div class="t outlined ${v?"white":""} thin">${Ot(p.title)}</div>${v?`<div class="who2">${Ot(v.name)}</div>`:""}<div class="x">${Ot(p.text||"")}</div></div>`,Se(".reel-dots",o).innerHTML=r.map((u,f)=>`<i class="${f===c%r.length?"on":""}"></i>`).join(""),oe.play("reveal"),c<r.length&&Oe(`${p.title}! ${p.text||""}`,c%2?"pam":"jeff",2),c++}let d=setTimeout(()=>{g(),h=setInterval(g,Hn(6500))},Hn(6500));return setTimeout(()=>{let p=Xa("rematchLine",n.players.map(v=>({name:v.name,bankroll:v.bankroll})));Oe((p==null?void 0:p.text)||"Press space, or tap ready on your phones, to go again.",(p==null?void 0:p.speaker)||"pam",2)},Hn(6500*(Math.min(r.length,7)+1))),{destroy:()=>{clearInterval(l),clearInterval(h),clearTimeout(d)}}}
