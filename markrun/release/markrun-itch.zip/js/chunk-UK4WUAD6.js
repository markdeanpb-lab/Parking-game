import"./chunk-F4WF5Y7G.js";async function e(){throw new Error("Refresh needs the home-computer edition")}export{e as runRefresh};
