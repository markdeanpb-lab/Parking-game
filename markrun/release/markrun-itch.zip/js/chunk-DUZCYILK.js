var s={tv:{bodyClass:"tv sky-bg",html:`<div id="race-layer"></div>
  <div id="stage-wrap">
    <div id="stage">
      <div id="screen"></div>
      <div id="hud-top"></div>
      <div id="hud-bottom"></div>
      <div id="subs"></div>
      <div id="reactions"></div>
      <div id="toast"></div>
      <div id="next-hint"></div>
    </div>
  </div>
  <div id="controls">
    <button id="btn-mute" class="ctl" title="Mute (M)">\u{1F50A}</button>
    <button id="btn-fs" class="ctl" title="Fullscreen (F)">\u26F6</button>
  </div>
  <div id="conn" class="hidden">Reconnecting to the host\u2026</div>
  <div id="gesture">
    <div class="gesture-card">
      <div class="logo-small outlined">MARKRUN</div>
      <div class="gesture-title outlined white">Click or press any key to start the broadcast</div>
      <div class="gesture-sub">(browsers need a tap before they'll make noise)</div>
    </div>
  </div>`,css:["tv.css"]},phone:{bodyClass:"phone sky-bg",html:`<div id="app"><div class="splash"><div class="logo-s outlined">MARK<span>RUN</span></div><div class="spin"></div></div></div>
  <div id="modal"></div>
  <div id="ptoast"></div>
  <div id="offline" class="hidden">\u{1F4E1} Reconnecting\u2026</div>`,css:["phone.css"]}};async function a(i){let t=s[i];if(!t)throw new Error(`no page shell for ${i}`);await Promise.all(t.css.map(n=>new Promise(e=>{if(document.querySelector(`link[data-shell="${n}"]`))return e();let d=document.createElement("link");d.rel="stylesheet",d.href=n,d.dataset.shell=n,d.onload=e,d.onerror=e,document.head.appendChild(d)}))),document.body.className=`${t.bodyClass} web-edition web-${i}`,document.body.innerHTML=t.html,document.title=i==="tv"?"MARKRUN \u2014 TV":"MARKRUN"}export{a};
